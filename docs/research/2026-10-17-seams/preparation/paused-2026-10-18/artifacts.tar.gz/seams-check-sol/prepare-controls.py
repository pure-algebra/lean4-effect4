from pathlib import Path
s=Path('/private/tmp/seams-check-sol');o=s/'controls';o.mkdir(exist_ok=True)
probe=(s/'CheckProbe.lean').read_text();fixture=probe[probe.index('def n1'):probe.index('end SeamsCheckScout')]
(o/'V1Controls.lean').write_text('import Effect4.Program.Check\nset_option autoImplicit false\nnamespace SeamsV1Controls\nopen Effect4 Effect4.Program Check\nderiving instance DecidableEq for Verdict\ndef composed (i : CheckInput) := combine i ((deps i).map fun d => run d.input)\n'+fixture+'''\n#guard (Checked.ask Oracle.uncached (.part oneRow [] extCall)).trace.length = 1
#guard (Checked.ask Oracle.uncached (.module {} [] n1)).trace.length = 1
#guard (Checked.ask Oracle.uncached (.module {} [] (.defs [] .nil n1 .nil))).trace.length = 1
def moduleTrace := Checked.ask Oracle.uncached (.module {} [] checkedModule)
def learned := Memo.empty.learn moduleTrace
#guard learned.entries.length = (deps (.module {} [] checkedModule)).length
#guard (deps (.module {} [] checkedModule)).all fun d =>
  learned.entries.any (HitRule.exact.hit d.input)
end SeamsV1Controls
''')
f=(s/'S1FeedProbe.lean').read_text();f=f[f.index('namespace FeedControls'):f.index('/-! Draft compatibility')]
f=f.replace('open SeamsCheckScout','open SeamsV1Controls').replace('SeamsCheckScout.run','Check.run').replace('SourceSession.open_','SourceSession.open')
(o/'S1FeedControls.lean').write_text('import Effect4.Program.Typing.SourceDocument\nimport V1Controls\nset_option autoImplicit false\nnamespace SeamsS1Controls\nopen Effect4 Effect4.Program Check\n'+f+'\nend FeedControls\nend SeamsS1Controls\n')
d=(s/'S1DocControls.lean').read_text().replace('import S1DocProbe','import S1FeedControls').replace('SeamsS1Scout.DocControls','SeamsS1Controls.DocControls').replace('SeamsS1Scout.Doc','Effect4.Program.Doc').replace('open SeamsCheckScout','open SeamsV1Controls').replace('open Effect4 Effect4.Program','open Effect4 Effect4.Program Check')
(o/'S1DocControls.lean').write_text(d)
print(o)

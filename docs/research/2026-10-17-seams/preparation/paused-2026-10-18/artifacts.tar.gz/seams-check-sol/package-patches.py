from pathlib import Path
import difflib,json,hashlib
base=Path('/private/tmp/seams-check-sol');prod=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4')
def extend(state,folders):
 state=dict(state)
 for directory,prefix in folders:
  for p in (base/directory).rglob('*.lean'):
   state[prefix+str(p.relative_to(base/directory))]=p.read_text()
 return state
v1=extend({},[('overlay','src/'),('v1-laws','src/'),('caller-overlay',''),('v1-tests','')])
s1=extend(v1,[('s1-overlay','src/'),('s1-laws','src/'),('s1-callers',''),('s1-tests','')])
s2=extend(s1,[('s2-overlay','src/'),('s2-laws','src/'),('s2-callers',''),('s2-tests','')])
previous={}
for name,current in [('V1',v1),('S1',s1),('S2',s2)]:
 chunks=[];manifest=[]
 for rel,target in sorted(current.items()):
  actual=prod/rel;source=previous.get(rel,actual.read_text() if actual.exists() else '')
  if source==target:continue
  chunks.extend(difflib.unified_diff(source.splitlines(keepends=True),target.splitlines(keepends=True),fromfile='a/'+rel if source else '/dev/null',tofile='b/'+rel))
  manifest.append({'path':rel,'sha256':hashlib.sha256(target.encode()).hexdigest()})
 (base/f'{name}-package.patch').write_text(''.join(chunks));(base/f'{name}-manifest.json').write_text(json.dumps(manifest,indent=2));print(name,'paths',len(manifest),'diff lines',len(chunks))
 previous=current

from pathlib import Path
p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4')
o=Path('/private/tmp/seams-check-sol/overlay')
s=Path('/private/tmp/seams-check-sol')
def put(path,text):
 f=o/path; f.parent.mkdir(parents=True,exist_ok=True); f.write_text(text)
cache=(p/'src/Effect4/Program/Typing/CheckCache.lean').read_text()
data=cache[cache.index('deriving instance'):cache.index('/-! ## The checker-verdict cache -/')]
rows=cache[cache.index('/-- The rows of the data'):cache.index('/-- **A lookup**')].replace('_root_.Effect4.Program.','')
put(Path('Effect4/Program/Typing/SigData.lean'),'import Effect4.Program.Typing.Source\nset_option autoImplicit false\n'+data+rows+'\nend Effect4.Program\n')
put(Path('Effect4/Program/Typing/AnnotateFold.lean'),(s/'AnnotateFoldProbe.lean').read_text())
facts=(s/'CoreFactsProbe.lean').read_text().replace('import Effect4.Program.Typing.CheckCache','import Effect4.Program.Typing.SigData').replace('import AnnotateFoldProbe','import Effect4.Program.Typing.AnnotateFold')
put(Path('Effect4/Program/Typing/SignatureSupport.lean'),facts)
support=(s/'CoreSupportProbe.lean').read_text()
support=support[support.index('def readsBoolAlg'):support.index('structure HitRule')]
put(Path('Effect4/Program/Typing/Support.lean'),'import Effect4.Program.Typing.SignatureSupport\nset_option autoImplicit false\nset_option maxRecDepth 20000\nnamespace Effect4.Program.Check\nopen Effect4 Effect4.Program\n'+support+'\nend Effect4.Program.Check\n')
check=(p/'src/Effect4/Program/Check.lean').read_text().replace('import Effect4.Program.Typing.CheckCache','import Effect4.Program.Typing.Support')
probe=(s/'CheckProbe.lean').read_text()
internal=probe[probe.index('def place'):probe.index('theorem run_placed')]+probe[probe.index('inductive Role'):probe.index('def composed')]
check=check.replace('/-- A certified oracle:',internal.replace('Input', 'CheckInput').replace('TypeRefusal.rebase base', '(fun r => ⟨base ++ r.path, r.reason⟩)').replace('Table.Entry.rebase base', '(fun e => ⟨base ++ e.path, e.env, e.result.map (fun r => r.mapError (fun why => ⟨base ++ why.path, why.reason⟩))⟩)')+'\n/-- A certified oracle:')
# The certified module package keeps the exact existing answer in its value until combine_deps lands.
# Its trace now contains exactly the dependencies, so learning works without a new core proof premise.
start=check.index('/-- Ask the oracle and record')
end=check.index('\nend Checked',start)
check=check[:start]+'''/-- Record actual part requests for modules; retain the certified root answer. -/
def ask (o : Oracle) (i : CheckInput) : Checked Verdict :=
  match i with
  | .part .. => ⟨o.ask i, [(i, o.ask i)], fun p hp => by
      simp only [List.mem_singleton] at hp
      subst hp
      exact o.agrees i⟩
  | .module .. =>
    let trace := (deps i).map (fun d => (d.input, o.ask d.input))
    ⟨combine i (trace.map Prod.snd), trace, fun p hp => by
      obtain ⟨d, _hd, he⟩ := List.mem_map.mp hp
      subst p
      exact o.agrees d.input⟩


'''+check[end:]
ext=(s/'CoreSupportProbe.lean').read_text(); ext=ext[ext.index('def extensionHit'):ext.index('end SeamsCoreSupportScout')].replace('Input','CheckInput')
check=check.replace('/-- A memo-backed oracle',ext+'\n/-- A memo-backed oracle')
put(Path('Effect4/Program/Check.lean'),check)
print(o)

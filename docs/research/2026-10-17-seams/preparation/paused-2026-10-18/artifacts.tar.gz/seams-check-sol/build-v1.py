from pathlib import Path
import os,re,subprocess,sys,json
base=Path('/private/tmp/seams-check-sol');prod=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');work=base/'v1-full';src=work/'src';lib=work/'lib/lean';changed={}
for d,prefix in [('overlay',''),('v1-laws',''),('v1-tests','')]:
 for p in (base/d).rglob('*.lean'):changed[str(p.relative_to(base/d).with_suffix('')).replace('/','.')]=p.read_text()
for p in (base/'caller-overlay').rglob('*.lean'):
 rel=p.relative_to(base/'caller-overlay');rel=Path(*rel.parts[1:]);changed[str(rel.with_suffix('')).replace('/','.')]=p.read_text()
# V1 uses S0's document and source session, not the later S1 representation.
files={}
for root in [prod/'src',prod/'tools',prod/'Test']:
 for p in root.rglob('*.lean'):
  rel=p.relative_to(root);name=str(rel.with_suffix('')).replace('/','.')
  if root.name=='Test':name='Test.'+name
  files[name]=p.read_text()
files.update(changed)
imports=lambda s: re.findall(r'^(?:public )?import\s+([\w.]+)',s,re.M)
needs={};visiting=set()
def affected(n):
 if n in needs:return needs[n]
 if n in visiting:raise Exception('cycle '+n)
 if n not in files:return False
 visiting.add(n);hit=n in changed
 for d in imports(files[n]):hit=affected(d) or hit
 visiting.remove(n);needs[n]=hit;return hit
order=[];seen=set()
def visit(n):
 if n in seen or n not in files:return
 seen.add(n)
 for d in imports(files[n]):visit(d)
 if affected(n) or not ((lib/Path(*n.split("."))).with_suffix(".olean").exists() or (prod/".lake/build/lib/lean"/Path(*n.split("."))).with_suffix(".olean").exists()):order.append(n)
for n in sys.argv[1:] or ['Effect4.Laws.Program.CheckAgreement','Effect4.Laws.Program.Typing.CheckCache','Tools.Session','Effect4.Run.Kit','Test.Program.CheckCacheControls']:visit(n)
(work/'order.json').parent.mkdir(parents=True,exist_ok=True);(work/'order.json').write_text(json.dumps(order,indent=2));print('compile count',len(order),flush=True)
for p in (prod/'.lake/build/lib/lean').rglob('*'):
 if p.is_file():
  dst=lib/p.relative_to(prod/'.lake/build/lib/lean');dst.parent.mkdir(parents=True,exist_ok=True)
  if not dst.exists() and not dst.is_symlink():dst.symlink_to(p)
resume=os.environ.get('SEAMS_RESUME')
if resume:order=order[order.index(resume):]
for n in order:
 rel=Path(*n.split('.'));p=src/rel.with_suffix('.lean');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(files[n]);output=lib/rel.with_suffix('.olean');output.parent.mkdir(parents=True,exist_ok=True)
 for suf in ['.olean','.olean.private','.olean.server','.ir','.ir.sig']:
  f=lib/rel.with_suffix(suf)
  if f.is_symlink():f.unlink()
 result=subprocess.run(['lean','-DwarningAsError=true',f'--root={src}','-o',str(output),str(p)],env={**os.environ,'LEAN_PATH':str(lib)+':'+os.environ['LEAN_PATH']},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 log=work/'logs'/rel.with_suffix('.log');log.parent.mkdir(parents=True,exist_ok=True);log.write_text(result.stdout)
 print(n,result.returncode,result.stdout[-7000:] if result.returncode else '',flush=True)
 if result.returncode:raise SystemExit(result.returncode)

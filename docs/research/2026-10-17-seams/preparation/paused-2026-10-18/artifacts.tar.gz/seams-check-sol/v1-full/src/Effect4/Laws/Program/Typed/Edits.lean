import Effect4.Laws.Program.Typed.Commands.Race
import Effect4.Laws.Program.Handles.Evaluation

/-!
# Laws.Program.Typed.Edits — the decision edits over `J` and `I` (`M6Edits`)

Wave 2's fifth group (seat D3): the edits a decision makes outside the command loop
(`Machine/Fibers.lean:2111-2140`, `Machine.Lift.DecisionLift`'s fields), over the split's `J`
(`MachineTyped`), `I` (`ConfigTyped`) and the fire snapshot (`SnapshotTyped`).

* `yield` (`yieldVerdict`'s modify): a quiet edit of the override flag no clause reads.
* `interrupt` (`Machine.Lift.interruptEdit`): the interrupt record (`configTyped_interruptRecord`).
* `drain` (a `fire`'s drain and disarm): the owner's dispatcher emptied; its tasks become the
  snapshot, typed by the dispatcher's column (`TaskOk`), their keys the machine's internal ones.
* `clockNone` (an `advance` step that fires nothing): the timer store's clock moves; nothing any
  clause reads changes, and the timers stay well formed (`TimerStore.clockStep_wf`).
* `clockSome` (an `advance` step that fires a sleep): the clock-none restate with the timers'
  keys shrinking, and the fired sleeper's `resume` queued, its `void` typed at the sleeper's token
  by `J`'s timer column (decisions row 134 (a); `E4-TYPED-CE-024` repaired).
* `answer` (`prepareAsyncAnswer` and the `resume` it queues): the reference interpreter prepares
  nothing (`RunInterp.prepareAnswer`'s default), and the admission types the answer at a parked
  fiber's token (`AnswerOk`), which is what `resume_step` reads.
-/

set_option autoImplicit false
namespace Effect4.Program.Typed
open Effect4 Effect4.Machine Effect4.Program Effect4.Program.Sched Effect4.Program.Denote
open Contracts

/-- `J` with the empty residue is `I`. -/
theorem configTyped_nil {root : ProgramSource} {rootTy : EffTy} {w : World} {m : RState}
    (typed : MachineTyped root rootTy w m) : ConfigTyped root rootTy w m [] :=
  ⟨typed, fun _ _ _ ⟨_, r⟩ => r.elim (fun h => nomatch h) (fun h => nomatch h),
    queueOk_nil root w m⟩

/-- `J` with the due drain queued is `I`. -/
theorem configTyped_drainDue {root : ProgramSource} {rootTy : EffTy} {w : World} {m : RState}
    {q : List RCmd} (typed : ConfigTyped root rootTy w m q) :
    ConfigTyped root rootTy w m (.drainDue :: q) :=
  configTyped_cons_plain typed _ trivial trivial trivial (fun _ h => nomatch h) trivial rfl
    (fun _ _ _ h => nomatch h) (fun _ _ h => nomatch h) (fun _ _ _ h => nomatch h)
    (fun _ _ _ _ _ h => nomatch h) (fun _ _ h => nomatch h) (fun _ _ h => nomatch h)

/-! ## `yield` -/

/-- The verdict a `yieldVerdict` decision stores: a field no clause reads. -/
theorem quiet_yield (v : Bool) : QuietEdit (fun f : RFiber => { f with yieldOverride := some v }) :=
  ⟨fun _ => rfl, fun _ => rfl, fun _ => rfl, fun _ => rfl, fun _ => rfl, fun _ => rfl,
    fun _ => rfl, fun _ => rfl, fun _ => rfl,
    fun f => ⟨[], (List.append_nil f.observers).symm, fun _ h => nomatch h⟩⟩

/-- **`yield` keeps `J`**: the override flag is no clause's. -/
theorem edit_yield (root : ProgramSource) (rootTy : EffTy) : EditYield root rootTy := by
  intro w m id v typed
  exact (configTyped_modify_quiet (configTyped_nil typed) id (quiet_yield v)
    (fun _ _ o ho => Or.inl ho) (fun _ _ kept => Or.inl kept)).machine

/-! ## `interrupt` -/

/-- **`interrupt` keeps `J`**: the decision's interrupt is the command's record
(`configTyped_interruptRecord`), after the events it emits. -/
theorem edit_interrupt (root : ProgramSource) (rootTy : EffTy) : EditInterrupt root rootTy := by
  intro w m who extra target t typed ht
  have e1 := configTyped_emit (configTyped_nil typed) [RunEvent.interruptRecorded who target]
  unfold Machine.Lift.interruptEdit
  dsimp only
  split
  · have e2 := configTyped_emit e1 [RunEvent.interruptDeferred target]
    exact (configTyped_interruptRecord e2 ht who extra).machine
  · exact (configTyped_interruptRecord e1 ht who extra).machine

/-! ## `answer` -/

/-- The reference interpreter prepares an answer as its completion's code, at the same store. -/
theorem prepareAsyncAnswer_running (root : ProgramSource) (m : RState) (id : FiberId)
    (token : Nat) (answer : Completion Val Err Defect FiberId Ann) (stuck : m.stuck = none) :
    prepareAsyncAnswer (interpR root.program) m id token answer =
      (m.state, denoteCompletion answer) := by
  unfold prepareAsyncAnswer
  rw [stuck]
  rfl

/-- **`answer` keeps `J` and `I`** at the same world: a parked fiber's resume is typed by the
admission (`AnswerOk` and `denoteCompletion_typed`) and runs as the command (`resume_step`); an
inert one leaves the machine and the due drain. -/
theorem edit_answer (root : ProgramSource) (rootTy : EffTy) : EditAnswer root rootTy := by
  intro w m id token answer typed stuck admitted
  rw [prepareAsyncAnswer_running root m id token answer stuck]
  refine ⟨w, leHost_refl w, ?_⟩
  have rest : ConfigTyped root rootTy w { m with state := m.state } [Cmd.drainDue] :=
    configTyped_drainDue (configTyped_nil typed)
  have after := resume_step rest (id := id) (token := token) (answer := denoteCompletion answer)
    fun parked ty declared => by
      obtain ⟨ty', declared', strong⟩ := admitted parked
      rw [declared'] at declared
      cases declared
      exact fun row => ambientProg_of_admin root (denoteCompletion_typed root strong)
        (denoteCompletion_admin _) row
  exact ⟨after.machine, fun _ => ⟨after, queueOk_nil root w _⟩⟩

/-! ## `drain` -/

/-- A fiber edit that keeps the fiber's park and current code keeps every request. -/
theorem requestOfR_update_flags {m : RState} {f g : RFiber} (hf : m.fiber? f.id = some f)
    (hid : g.id = f.id) (parked : g.parked = f.parked) (current : g.frame.current = f.frame.current)
    (fiber : FiberId) (token : Nat) : requestOfR (m.update g) fiber token = requestOfR m fiber token := by
  by_cases same : fiber = g.id
  · subst same
    have look : (m.update g).fiber? g.id = some g := rfiber?_update_self hf hid
    have hf' : m.fiber? g.id = some f := by rw [hid]; exact hf
    by_cases hp : g.parked = .withGuard token
    · rw [requestOfR_of_parked look hp, requestOfR_of_parked hf' (parked ▸ hp), current]
    · rw [requestOfR_of_not_parked look hp,
        requestOfR_of_not_parked hf' (fun h => hp (parked.trans h))]
  · exact requestOfR_congr (rfiber?_update_other same) token

/-- A command list whose every command has a trivial registration tail is a registration
queue. -/
theorem registrationQueue_of_tails {l : List RCmd}
    (h : ∀ c ∈ l, ∀ rest, Guard.RegistrationQueue.RegistrationTail c rest) :
    Guard.RegistrationQueue.RegistrationQueue l := by
  induction l with
  | nil => trivial
  | cons c rest ih =>
    exact ⟨h c List.mem_cons_self rest, ih fun c' hc' => h c' (List.mem_cons_of_mem _ hc')⟩

/-- A drained task sits in one of the dispatcher's buckets. -/
theorem mem_drain {d : Dispatcher EffName EffThunk Val Err Defect FiberId Ann RProgram}
    {task : RTask} (h : task ∈ d.drain.1) : ∃ b ∈ d.buckets, task ∈ b.tasks := by
  obtain ⟨tasks, hl, ht⟩ := List.mem_flatten.mp h
  obtain ⟨b, hb, rfl⟩ := List.mem_map.mp hl
  exact ⟨b, hb, ht⟩

/-- **The snapshot a drain hands the fire is typed**: every task's command is typed by the
dispatcher's column (`TaskOk`: a resume's answer at its token), and its key is one of the
dispatcher's, below the token counter and requested by no park. -/
theorem snapshotTyped_drain {root : ProgramSource} {w : World} {m : RState}
    {d : Dispatcher EffName EffThunk Val Err Defect FiberId Ann RProgram}
    (ok : DispatcherOk (preds root) w Expect.root d)
    (keysBelow : ∀ k ∈ Guard.bucketKeys d.buckets, k.2 < m.nextToken)
    (keysFree : ∀ fiber token r, requestOfR m fiber token = some r →
      (fiber, token) ∉ Guard.bucketKeys d.buckets) :
    SnapshotTyped root w m d.drain.1 := by
  have keysOf : ∀ key ∈ (d.drain.1.flatMap taskCmds).flatMap Guard.commandKeys,
      key ∈ Guard.bucketKeys d.buckets := by
    intro key hk
    obtain ⟨c, hc, hkc⟩ := List.mem_flatMap.mp hk
    obtain ⟨task, ht, hct⟩ := List.mem_flatMap.mp hc
    obtain ⟨b, hb, htb⟩ := mem_drain ht
    have inBucket : ∀ k ∈ Guard.taskKeys task, k ∈ Guard.bucketKeys d.buckets := fun k hk' =>
      List.mem_flatMap.mpr ⟨b, hb, List.mem_flatMap.mpr ⟨task, htb, hk'⟩⟩
    cases task with
    | start child =>
      simp only [taskCmds, List.mem_cons, List.not_mem_nil, or_false] at hct
      rcases hct with rfl | rfl <;> cases hkc
    | resume target token code =>
      simp only [taskCmds, List.mem_cons, List.not_mem_nil, or_false] at hct
      rcases hct with rfl | rfl
      · exact inBucket key hkc
      · cases hkc
    | wake list phase =>
      simp only [taskCmds, List.mem_cons, List.not_mem_nil, or_false] at hct
      rcases hct with rfl | rfl <;> cases hkc
  refine
    { payload := fun c hc => ?_
      authority := fun c hc => ?_
      delivery := fun c hc => ?_
      owners := ?_
      registration := registrationQueue_of_tails fun c hc rest => taskCmd_tail hc rest
      keys := ⟨fun key hk => keysBelow key (keysOf key hk),
        fun fiber token r hr hk => keysFree fiber token r hr (keysOf _ hk)⟩
      observer := fun source exit observer h => ?_
      enroll := fun race child h => ?_
      noRaceAfterInterrupt := fun host yielding race h => ?_
      links := fun mode scope target interruptor extra h =>
        absurd rfl (taskCmd_not_link h mode scope target interruptor extra)
      raceObservers := fun source exit observer h => ?_ }
  · obtain ⟨task, ht, hct⟩ := List.mem_flatMap.mp hc
    obtain ⟨b, hb, htb⟩ := mem_drain ht
    have taskOk := (ok.c0 b hb).c0 task htb
    cases task with
    | start child =>
      simp only [taskCmds, List.mem_cons, List.not_mem_nil, or_false] at hct
      rcases hct with rfl | rfl <;> trivial
    | resume target token code =>
      simp only [taskCmds, List.mem_cons, List.not_mem_nil, or_false] at hct
      rcases hct with rfl | rfl
      · exact taskOk
      · trivial
    | wake list phase =>
      simp only [taskCmds, List.mem_cons, List.not_mem_nil, or_false] at hct
      rcases hct with rfl | rfl <;> trivial
  · rcases mem_taskCmds hc with ⟨_, rfl⟩ | ⟨_, _, _, rfl⟩ | ⟨_, _, rfl⟩ | rfl <;> trivial
  · rcases mem_taskCmds hc with ⟨_, rfl⟩ | ⟨_, _, _, rfl⟩ | ⟨_, _, rfl⟩ | rfl <;> trivial
  · rw [List.filterMap_eq_nil_iff.mpr fun _ member => taskCmd_owner m member]
    exact List.nodup_nil
  · rcases mem_taskCmds h with ⟨_, h'⟩ | ⟨_, _, _, h'⟩ | ⟨_, _, h'⟩ | h' <;> exact nomatch h'
  · rcases mem_taskCmds h with ⟨_, h'⟩ | ⟨_, _, _, h'⟩ | ⟨_, _, h'⟩ | h' <;> exact nomatch h'
  · rcases mem_taskCmds h with ⟨_, h'⟩ | ⟨_, _, _, h'⟩ | ⟨_, _, h'⟩ | h' <;> exact nomatch h'
  · rcases mem_taskCmds h with ⟨_, h'⟩ | ⟨_, _, _, h'⟩ | ⟨_, _, h'⟩ | h' <;> exact nomatch h'

/-- **`drain` keeps `J` and types the snapshot**: the owner's dispatcher is emptied (its column
holds over the empty bucket list) and disarmed; its tasks, typed by the column, are the snapshot. -/
theorem edit_drain (root : ProgramSource) (rootTy : EffTy) : EditDrain root rootTy := by
  intro w m owner f typed found
  have fid : f.id = owner := rfiber?_id found
  have hf : m.fiber? f.id = some f := by rw [fid]; exact found
  have hmem : f ∈ m.fibers := rfiber?_mem hf
  have wide := typed.wide
  have old := typed.fiber hmem
  let g : RFiber := { f with dispatcher := (f.dispatcher.drain).2 }
  have view : ObsView m (m.update g) := obsView_rupdate (g := g) hf rfl (PendingWeaker.refl _)
  have moved := fiberTyped_transport old view (Nat.le_refl _) (Nat.le_refl _)
  have fresh : FiberTyped root w (m.update g) g :=
    { ok := ⟨moved.ok.c0, moved.ok.c1, moved.ok.c2, moved.ok.c3, ⟨fun _ h => nomatch h⟩,
        moved.ok.c5⟩
      delivery := moved.delivery
      below := moved.below
      pendingShape := moved.pendingShape
      parkedIdle := moved.parkedIdle
      parkedBelow := moved.parkedBelow
      exited := moved.exited
      exitedStack := moved.exitedStack
      deferredCause := moved.deferredCause
      pendingOwner := moved.pendingOwner
      observers := moved.observers
      registration := moved.registration
      code := moved.code
      tokens := moved.tokens
      raceObservers := moved.raceObservers
      targetsBelow := moved.targetsBelow
      observersBelow := moved.observersBelow
      children := moved.children }
  have bucketsIn : ∀ k ∈ Guard.bucketKeys f.dispatcher.buckets, k ∈ Guard.internalKeys m :=
    fun k hk => fiberKeys_internal hmem (List.mem_append_right _ hk)
  have keysG : ∀ k ∈ Guard.fiberKeys g, k ∈ Guard.internalKeys m ∨
      (k.2 < m.nextToken ∧ requestOfR m k.1 k.2 = none) := by
    intro k hk
    rcases List.mem_append.mp hk with obs | buckets
    · exact Or.inl (fiberKeys_internal hmem (List.mem_append_left _ obs))
    · exact nomatch buckets
  have edited := configTyped_rupdate (g := g) (configTyped_nil typed) hf rfl (PendingWeaker.refl _)
    rfl rfl rfl rfl rfl (fun p => p) (fun d => d) ⟨.inr rfl, rfl⟩ rfl keysG fresh
  refine ⟨machineTyped_congr (m := m.update g) (m' := (m.update g).disarm owner) rfl rfl rfl rfl
    rfl rfl rfl edited.machine, ?_⟩
  refine snapshotTyped_drain old.ok.c4 (fun k hk => wide.keysBelow k (bucketsIn k hk)) ?_
  intro fiber token r hr hk
  have before : requestOfR m fiber token = some r := by
    have same := requestOfR_update_flags (m := m) (g := g) hf rfl rfl rfl fiber token
    rw [← same]
    exact hr
  exact wide.requestsOwned fiber token r before (bucketsIn _ hk)

/-! ## `clockNone` -/

/-- A store whose timers alone changed, to a well-formed timer store, is well-formed. -/
theorem wf_retime {t : Stores} (wf : t.WF) (timers : TimerStore) (htimers : timers.WF) :
    ({ t with timers := timers } : Stores).WF := by
  obtain ⟨hrefs, hscopes, hmemo, _⟩ := wf
  have le : t.le { t with timers := timers } := Stores.le_refl t
  refine ⟨fun v hv => Val.validIn_mono le v (hrefs v hv), fun e he => ?_, hmemo, htimers⟩
  have old := hscopes e he
  cases hc : e.scope.closingExit? with
  | none => rfl
  | some ex =>
    rw [hc] at old
    exact Val.validIn_mono le _ old

/-- **`clockNone` keeps `J`**, at the world over the advanced store: a clock step that fires no
sleep moves the clock alone (`TimerStore.clockStep_finish`), so the sleepers, every typed column
and every internal key are the old ones, and the timers stay well formed
(`TimerStore.clockStep_wf`). -/
theorem edit_clockNone (root : ProgramSource) (rootTy : EffTy) : EditClockNone root rootTy := by
  intro w m millis st typed _ step
  have wide := typed.wide
  have step' : (Option.map (Owed.mapCode denoteCompletion)
        (m.state.timers.clockStep millis
          (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).1,
      { m.state with timers := (m.state.timers.clockStep millis
          (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).2 }) =
      (none, st) := step
  rw [Prod.mk.injEq] at step'
  obtain ⟨fired, rfl⟩ := step'
  have noOwed : (m.state.timers.clockStep millis
      (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).1 = none :=
    Option.map_eq_none_iff.mp fired
  have wake : (m.state.timers.clockStep millis
      (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).2.wake =
      m.state.timers.wake := by
    cases h : TimerStore.dueMin (m.state.timers.target.getD (m.state.timers.now + millis))
        m.state.timers.wake.waiters with
    | none => rw [TimerStore.clockStep_finish _ millis _ h]
    | some x =>
      exfalso
      have owed := (TimerStore.fireNext_now m.state.timers _
        (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann) x h).1
      revert noOwed
      unfold TimerStore.clockStep
      dsimp only
      rcases hpair : m.state.timers.fireNext (m.state.timers.target.getD (m.state.timers.now + millis))
        (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)
        with ⟨fired', s'⟩
      rw [hpair] at owed
      cases fired' with
      | none => cases owed
      | some o =>
        dsimp only
        intro hnone
        cases hnone
  let T : TimerStore := (m.state.timers.clockStep millis
    (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).2
  have wf : ({ m.state with timers := T } : Stores).WF :=
    wf_retime wide.wf T (TimerStore.clockStep_wf wide.wf.2.2.2 millis
      (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann))
  have le : m.state.le { m.state with timers := T } := Stores.le_refl m.state
  have ord : w.leHost { w with state := { m.state with timers := T } } := by
    apply leHost_restate
    · rw [wide.state]
      exact le
    · rw [wide.state]
    · rw [wide.state]
    · rw [wide.state]
  obtain ⟨c0, c1, c2, c3, c4, c5⟩ := storesOk_world ord rfl rfl rfl wide.stores
  have keys : Guard.internalKeys ({ m with state := { m.state with timers := T } } : RState) ⊆
      Guard.internalKeys m := by
    intro k hk
    rw [internalKeys_fibers] at hk ⊢
    have e : (({ m with state := { m.state with timers := T } } : RState).state.timers.wake) =
        m.state.timers.wake := wake
    rw [e] at hk
    exact hk
  obtain ⟨_, restated⟩ := configTyped_restate (s := { m.state with timers := T })
    (configTyped_nil typed) le rfl rfl rfl wf ⟨c0, c1, c2, c3, c4, c5⟩ keys wide.live.dueOwners
    (by
      rw [show ({ m.state with timers := T } : Stores).timers.wake = m.state.timers.wake from wake]
      exact fun _ h => h)
  exact ⟨_, ord, restated.machine⟩

/-! ## `clockSome` -/

/-- The fired sleeper's answer, `void`, is a strong completion at every type `void` fits: row 134
(a)'s demand on a sleeper's token. -/
theorem completionStrong_sleep {w : World} {ty : EffTy} (demand : SleepDemand ty) :
    CompletionStrong w ty (.ofExit (.success .unit)) :=
  ⟨fitsExit_success w ty Val.unit (fits_sub w demand Val.unit trivial), trivial⟩

/-- **`clockSome` keeps `J` and `I`**, at the world over the advanced store. A clock step that
fires a sleep pops its waiter (`Guard.timer_clockStep_keys`: the timers' keys only shrink, so the
restate of `clockNone` applies) and owes its resume inline (`TimerStore.clockStep_owed`), so the
drain queues one `resume`. Its key is one the timer store held (`Guard.timer_clockStep_key`): row
134 (a) declares its token at a type `void` fits, which types the resume's code
(`completionStrong_sleep`, `denoteCompletion_typed`), and the guard's bookkeeping puts the key below
the token supply with no external request at it (`configTyped_cons_resume`). Whether the sleeper is
still parked at that token (an active park, a stale token, an absent fiber) is the queued
command's own case split (`resume_step`), not this edit's. -/
theorem edit_clockSome (root : ProgramSource) (rootTy : EffTy) : EditClockSome root rootTy := by
  intro w m millis owed st typed _ step
  have wide := typed.wide
  have step' : (Option.map (Owed.mapCode denoteCompletion)
        (m.state.timers.clockStep millis
          (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).1,
      { m.state with timers := (m.state.timers.clockStep millis
          (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).2 }) =
      (some owed, st) := step
  rw [Prod.mk.injEq] at step'
  obtain ⟨fired, rfl⟩ := step'
  obtain ⟨o, ho, rfl⟩ := Option.map_eq_some_iff.mp fired
  have facts := TimerStore.clockStep_owed m.state.timers millis
    (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann) o ho
  have key := Guard.timer_clockStep_key m.state.timers millis
    (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann) o ho
  let T : TimerStore := (m.state.timers.clockStep millis
    (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann)).2
  have timerKeys : Guard.wakeKeys T.wake ⊆ Guard.wakeKeys m.state.timers.wake :=
    Guard.timer_clockStep_keys m.state.timers millis _
  have wf : ({ m.state with timers := T } : Stores).WF :=
    wf_retime wide.wf T (TimerStore.clockStep_wf wide.wf.2.2.2 millis
      (Completion.ofExit (Exit.success Val.unit) : Completion Val Err Defect FiberId Ann))
  have le : m.state.le { m.state with timers := T } := Stores.le_refl m.state
  have ord : w.leHost { w with state := { m.state with timers := T } } := by
    apply leHost_restate
    · rw [wide.state]
      exact le
    · rw [wide.state]
    · rw [wide.state]
    · rw [wide.state]
  obtain ⟨c0, c1, c2, c3, c4, c5⟩ := storesOk_world ord rfl rfl rfl wide.stores
  have keys : Guard.internalKeys ({ m with state := { m.state with timers := T } } : RState) ⊆
      Guard.internalKeys m :=
    Guard.internalKeys_state_subset m _ (Guard.storeKeys_mono timerKeys (List.Subset.refl _))
  obtain ⟨_, restated⟩ := configTyped_restate (s := { m.state with timers := T })
    (configTyped_nil typed) le rfl rfl rfl wf ⟨c0, c1, c2, c3, c4, c5⟩ keys wide.live.dueOwners
    timerKeys
  have internal : (o.waiter, o.token) ∈ Guard.internalKeys m :=
    List.mem_append_left _ (List.mem_append_left _ (List.mem_append_left _
      (List.mem_append_left _ key)))
  have drained : drainOwed ({ m with state := { m.state with timers := T } } : RState)
      [o.mapCode denoteCompletion] = ({ m with state := { m.state with timers := T } },
        [Cmd.resume o.waiter o.token (denoteCompletion o.code)]) := by
    unfold drainOwed
    rw [Owed.mapCode_mode, facts.2]
    rfl
  rw [drained, List.singleton_append]
  refine ⟨_, ord, restated.machine, fun _ => ?_⟩
  refine configTyped_cons_resume (configTyped_drainDue restated) ?_ ?_ ?_
  · intro ty declared
    obtain ⟨ty', declared', demand⟩ := wide.timers _ key
    have same : w.Θ o.waiter o.token = some ty := declared
    rw [show w.Θ o.waiter o.token = some ty' from declared'] at same
    cases same
    rw [facts.1]
    exact fun row => ambientProg_of_admin root (denoteCompletion_typed root (completionStrong_sleep demand))
      (denoteCompletion_admin _) row
  · exact wide.keysBelow _ internal
  · cases hr : requestOfR m o.waiter o.token with
    | none => exact hr
    | some r => exact absurd internal (wide.requestsOwned _ _ r hr)

/-! ## M6b from what remains

The six edits are proved above. `DecisionKeeps` (`decision_preserves`) follows from the
eighteen command facts through the lift (`decisionKeeps_of_ledger`); these two theorems state
exactly that, so the goal closes by one line when its premises do. -/

/-- The six edits. -/
theorem decisionEdits (root : ProgramSource) (rootTy : EffTy) : DecisionEdits root rootTy :=
  { drain := edit_drain root rootTy
    yield := edit_yield root rootTy
    interrupt := edit_interrupt root rootTy
    clockNone := edit_clockNone root rootTy
    clockSome := edit_clockSome root rootTy
    answer := edit_answer root rootTy }

/-- **M6b from the eighteen command facts**: the six edits are proved here, and the lift
(`decisionKeeps_of_ledger`, `Machine.Lift.stepDecisionState_lift`) does the rest. -/
theorem decisionKeeps_of_steps (root : ProgramSource) (rootTy : EffTy) (fuel : Nat)
    (steps : ∀ command, StepPreserves root rootTy command) (d : Api.Decision) :
    DecisionKeeps root rootTy fuel d :=
  decisionKeeps_of_ledger root rootTy fuel d steps (decisionEdits root rootTy)

/-! ## M6c from what remains (step 6) -/

/-- **M6c from M5 and the eighteen command facts**: `reachable_of_ledger` over
`decisionKeeps_of_steps`, written as the proof it is, with the goals it consumes as premises. -/
theorem typedState_reachable_of_steps (root : ProgramSource) (rootTy : EffTy) (fuel : Nat)
    (load : LoadsTyped root rootTy fuel fuel) (steps : ∀ command, StepPreserves root rootTy command)
    (m : RState) : ReachableTyped root rootTy fuel m :=
  reachable_of_ledger root rootTy fuel load
    (fun d => decisionKeeps_of_steps root rootTy fuel steps d) m

end Effect4.Program.Typed

import Effect4.Laws.Program.Typed.Stack
import Effect4.Laws.Program.Typed.MaskEntry
import Effect4.Laws.Program.Typed.AmbientMachine
import Effect4.Laws.Program.Typed.State
import Effect4.Laws.Program.Guard.Core
import Effect4.Laws.Program.Guard.RegistrationQueue
import Effect4.Laws.Program.ReasonsR

/-!
H1 scheduler statements, without a command-preservation proof. The predicates inspect the
actual tables and finite buffered payloads. The exact reference code-site traversal is OPEN
(H1-RCODE-SITES); this file supplies neither a head-only approximation nor a predicate over
all possible continuation answers. The direct race-registration authority is settled.
-/
set_option autoImplicit false
namespace Effect4.Program.Typed
open Effect4 Effect4.Machine Effect4.Program Effect4.Program.Sched Effect4.Program.Denote

abbrev RPending := Pending EffName Val Err Defect FiberId Ann
abbrev RRace := Race EffName EffThunk Val Err Defect FiberId Ann RProgram

/-- The checker's two result types, not the source fiber type in both modes. -/
def observerDeliveredType (mode : Supervision.ObserverMode) (sourceTy : EffTy) : EffTy :=
  match mode with
  | .joinEffect => sourceTy
  | .awaitValue => EffTy.pure (.exitOf sourceTy.answer sourceTy.error)

def observerDeliveredExit (mode : Supervision.ObserverMode) (exit : ExitV) : ExitV :=
  match mode with
  | .joinEffect => exit
  | .awaitValue => .success (reifyExitVal exit)

/-- Reification is exactly the value at Exit<A,E> in FitsExit's definition. -/
theorem reifyExitVal_fits (w : World) (ty : EffTy) (exit : ExitV)
    (typed : FitsExit w ty exit) :
    Fits w (reifyExitVal exit) (.exitOf ty.answer ty.error) := typed

theorem observerDeliveredExit_fits (w : World) (ty : EffTy) (exit : ExitV)
    (mode : Supervision.ObserverMode) (typed : FitsExit w ty exit) :
    FitsExit w (observerDeliveredType mode ty) (observerDeliveredExit mode exit) := by
  cases mode with
  | joinEffect => exact typed
  | awaitValue => exact reifyExitVal_fits w ty exit typed

/-- The actual interpreter hook constructs the result just typed above. -/
theorem observer_exitValue_typed (root : ProgramSource) (w : World) (ty : EffTy)
    (exit : ExitV) (mode : Supervision.ObserverMode) (typed : ExitOk w ty exit) :
    TypedProg root w (observerDeliveredType mode ty)
      ((interpR root.program).exitValue exit mode) := by
  cases mode with
  | joinEffect => exact TypedProg.pure typed
  | awaitValue =>
    exact TypedProg.pure (strongExit_success w _ _ (reifyExitVal_fits w ty exit typed.1))

/-- Only the two exit columns are aggregated; requirement transport is H2's separate debt.
Declared columns are compared in the checker's order (decisions row 137, `Ty.subN`). -/
def FiberColumnsBelow (w : World) (id : FiberId) (answer error : Ty) : Prop :=
  ∃ ty, w.Γ id = some ty ∧ Ty.subN ty.answer answer = true ∧ Ty.subN ty.error error = true

/-- A race's one result declaration owns every buffered value and each unlaunched program.
Existing live fiber declarations are constrained; missing fibers are not invented. Columns are
compared in the checker's order (decisions row 137, `Ty.subN`). -/
structure RacePayload (root : ProgramSource) (w : World) (race : RRace)
    (resultTy : EffTy) : Prop where
  token : w.Θ race.host race.token = some resultTy
  failures : ExitOk w resultTy (.failure ⟨race.state.failures⟩)
  winner : ∀ pair ∈ race.state.winner, Fits w pair.2 resultTy.answer
  accepted : ∀ exit ∈ race.state.accepted, ExitOk w resultTy exit
  cleanup : ∀ wait ∈ race.state.cleanup, ExitOk w resultTy wait.result
  /-- Every live entrant is declared, below the result's columns (finding F-LIVE, owner's ruling
  2026-10-02): `raceCancel`'s reply walks the live set and reads each declaration
  (`CommandDeliveryOk`'s `FiberListColumns`); `enrollRace` supplies it (`EnrollRaceOk`). -/
  live : ∀ id ∈ race.state.live, FiberColumnsBelow w id resultTy.answer resultTy.error

/-- What a finished countdown's continuation is typed at (`countdownPark.resumePrim`), read from
its targets in order and their columns: the exits as a value at the tuple of the targets' columns
(the positional certificate, row 349), or at one list of exits whose columns every target shares
(`Resume.exitsValue`); `void`; or the restoring continuation's saved exit. -/
def CountdownResume (w : World) (resumeWith : Resume EffName) (targets : List FiberId)
    (cols : FiberId → Ty × Ty) (tokenTy : EffTy) : Prop :=
  match resumeWith with
  | .exitsValue =>
    tokenTy = EffTy.pure (.tuple (targets.map fun t => .exitOf (cols t).1 (cols t).2)) ∨
      ∃ a e, tokenTy = EffTy.pure (.list (.exitOf a e)) ∧ ∀ t ∈ targets, cols t = (a, e)
  | .void => tokenTy = EffTy.pure .unit
  | .continueWith (.restore saved) => ExitOk w tokenTy saved
  | .continueWith _ => ExitOk w tokenTy outsideExit

/-- The finite pending record reached by a countdown observer, read from the record alone
(decisions row 376 (2)). The countdown's targets, in order, are the visited ones (`done`), the one
it waits on now (`waitingOn`) and the ones after it (`remaining`). Each visited target's exit is
collected, in order, at that target's columns; each target to come is declared below its columns;
and the token is declared at what the resume answers over all of them. Joins also use Pending with
void metadata, so this predicate is attached only through an actual countdown observer. -/
structure CountdownPayload (w : World) (waiter : FiberId) (pending : RPending)
    (done : List FiberId) (cols : FiberId → Ty × Ty) (tokenTy : EffTy) : Prop where
  token : w.Θ waiter pending.token = some tokenTy
  collected : ListRel (fun t ex => ExitOk w ⟨(cols t).1, (cols t).2, Env.Requirement.empty⟩ ex)
    done pending.collected
  targets : ∀ t ∈ pending.waitingOn.toList ++ pending.remaining,
    FiberColumnsBelow w t (cols t).1 (cols t).2
  resume : CountdownResume w pending.resumeWith
    (done ++ (pending.waitingOn.toList ++ pending.remaining)) cols tokenTy

/-- Follow exactly fireObserver's waiter and pending lookups. Missing lookups are inert. The
payload reads the record and the world only: no column condition on the observer's source, so a
stale or duplicate firing, which the machine's guard drops, constrains nothing. -/
def CountdownAt (w : World) (m : RState) (waiter : FiberId) (token : Nat) : Prop :=
  match m.fiber? waiter with
  | none => True
  | some fiber =>
    match fiber.pending.find? (fun pending => pending.token = token) with
    | none => True
    | some pending => ∃ done cols tokenTy, CountdownPayload w waiter pending done cols tokenTy

/-- A stored observer's source declaration is connected to the destination token; a stored
scope-finalizer drop names a scope the store holds (row 139; `Stores.ScopeLive`, row 156's
predicate at the machine's store). -/
def StoredObserverOk (root : ProgramSource) (w : World) (m : RState)
    (source : FiberId) : Observer → Prop
  | .resumeAwait waiter token mode => ∃ sourceTy,
      w.Γ source = some sourceTy ∧ w.Θ waiter token = some (observerDeliveredType mode sourceTy)
  | .countdown waiter token => CountdownAt w m waiter token
  | .raceCallback raceId =>
    match m.race? raceId with
    | none => True
    | some race => ∃ resultTy, RacePayload root w race resultTy ∧
        (source ∈ race.state.live → FiberColumnsBelow w source resultTy.answer resultTy.error)
  -- `fireObserver` halts on an absent scope (`Machine/Fibers.lean:1668-1671`; row 139)
  | .dropScopeFinalizer scope _ => m.state.ScopeLive scope
  | .untrackChild _ | .callback _ => True

/-- A queued observer must type what it can deliver or buffer, including a race callback
while registration is still active; a scope-finalizer drop names a scope the store holds
(`Stores.ScopeLive`). A countdown types its exit at its source's declaration, which the record's
payload reads when the record waits on the source (`fireObserver`'s guard, decisions row 376 (2)).
The two remaining no-payload variants keep their machine guards. -/
def ObserverCommandOk (root : ProgramSource) (w : World) (m : RState)
    (source : FiberId) (exit : ExitV) : Observer → Prop
  | .resumeAwait waiter token mode => ∃ sourceTy,
      w.Γ source = some sourceTy ∧
      w.Θ waiter token = some (observerDeliveredType mode sourceTy) ∧ ExitOk w sourceTy exit
  | .countdown waiter token => CountdownAt w m waiter token ∧
      ∃ sourceTy, w.Γ source = some sourceTy ∧ ExitOk w sourceTy exit
  | .raceCallback raceId =>
    match m.race? raceId with
    | none => True
    | some race => ∃ resultTy, RacePayload root w race resultTy ∧
        (source ∈ race.state.live → ExitOk w resultTy exit)
  -- `fireObserver` halts on an absent scope (`Machine/Fibers.lean:1668-1671`; row 139)
  | .dropScopeFinalizer scope _ => m.state.ScopeLive scope
  | .untrackChild _ | .callback _ => True

/-- A queued enrollment names an id below `nextId` (decisions row 134 (e)), so fresh allocation
cannot activate a previously absent target. Missing old targets remain inert. Enrollment may
fire an already-exited entrant immediately; its columns use the same declared result as
`RacePayload`. -/
def EnrollRaceOk (root : ProgramSource) (w : World) (m : RState)
    (raceId : Nat) (child : FiberId) : Prop :=
  child.value < m.nextId ∧
    match m.race? raceId, m.fiber? child with
    | some race, some fiber => ∃ resultTy, RacePayload root w race resultTy ∧
        FiberColumnsBelow w fiber.id resultTy.answer resultTy.error
    | _, _ => True

structure ObserverState (root : ProgramSource) (w : World) (m : RState) : Prop where
  pendingOwner : ∀ fiber ∈ m.fibers, ∀ pending ∈ fiber.pending,
    (w.Θ fiber.id pending.token).isSome = true
  observers : ∀ fiber ∈ m.fibers, ∀ observer ∈ fiber.observers,
    StoredObserverOk root w m fiber.id observer

/-! ### Transport between machines with the same lookups

The observer correlations read the machine only through `fiber?`, `race?` and the store. A
countdown's payload reads the record and the world, so it moves along the host order, and the
correlation moves to any machine whose record at the waiter is one the first machine held. -/

/-- The resume's typing moves along the host order. -/
theorem countdownResume_mono {w w' : World} (ord : w.leHost w') {resumeWith : Resume EffName}
    {targets : List FiberId} {cols : FiberId → Ty × Ty} {tokenTy : EffTy}
    (h : CountdownResume w resumeWith targets cols tokenTy) :
    CountdownResume w' resumeWith targets cols tokenTy := by
  unfold CountdownResume at h ⊢
  split at h
  · exact h
  · exact h
  · exact strongExit_mono _ _ _ _ ord h
  · exact strongExit_mono _ _ _ _ ord h

/-- A countdown's payload moves along the host order: the token and the declarations persist, and
the collected exits keep their membership. -/
theorem countdownPayload_mono {w w' : World} (ord : w.leHost w') {waiter : FiberId}
    {pending : RPending} {done : List FiberId} {cols : FiberId → Ty × Ty} {tokenTy : EffTy}
    (h : CountdownPayload w waiter pending done cols tokenTy) :
    CountdownPayload w' waiter pending done cols tokenTy :=
  ⟨ord.1.2.2.2.2.2.1 _ _ _ h.token,
    by
      have moved := ListRel.of_map_mem
        (r := fun t ex => ExitOk w ⟨(cols t).1, (cols t).2, Env.Requirement.empty⟩ ex)
        (s := fun t ex => ExitOk w' ⟨(cols t).1, (cols t).2, Env.Requirement.empty⟩ ex)
        (f := id) (g := id) (fun _ _ _ hx => strongExit_mono _ _ _ _ ord hx) h.collected
      rwa [List.map_id, List.map_id] at moved,
    fun t ht => by
      obtain ⟨ty, declared, ha, he⟩ := h.targets t ht
      exact ⟨ty, ord.1.2.1 _ _ declared, ha, he⟩,
    countdownResume_mono ord h.resume⟩

/-- A countdown correlation, read at a found record. -/
theorem countdownAt_found {w : World} {m : RState} {waiter : FiberId} {token : Nat}
    {wf : RFiber} {p : RPending}
    (h : CountdownAt w m waiter token) (hw : m.fiber? waiter = some wf)
    (hp : wf.pending.find? (fun q => q.token = token) = some p) :
    ∃ done cols tt, CountdownPayload w waiter p done cols tt := by
  unfold CountdownAt at h
  rw [hw] at h
  dsimp only at h
  rw [hp] at h
  exact h

/-- A countdown correlation, given at a found record. -/
theorem countdownAt_of_found {w : World} {m : RState} {waiter : FiberId} {token : Nat}
    {g : RFiber} {p : RPending} (hw : m.fiber? waiter = some g)
    (hp : g.pending.find? (fun q => q.token = token) = some p)
    (h : ∃ done cols tt, CountdownPayload w waiter p done cols tt) :
    CountdownAt w m waiter token := by
  unfold CountdownAt
  rw [hw]
  dsimp only
  rw [hp]
  exact h

/-- **A countdown correlation moves** to a later world and to a machine whose record at the waiter
and the token, when it has one, is a record the first machine held there. -/
theorem countdownAt_transport {w w' : World} {m m' : RState} (ord : w.leHost w')
    {waiter : FiberId} {token : Nat}
    (record : ∀ f' p, m'.fiber? waiter = some f' →
      f'.pending.find? (fun q => q.token = token) = some p →
      ∃ f, m.fiber? waiter = some f ∧ f.pending.find? (fun q => q.token = token) = some p)
    (h : CountdownAt w m waiter token) : CountdownAt w' m' waiter token := by
  unfold CountdownAt
  cases hf : m'.fiber? waiter with
  | none => trivial
  | some f' =>
    dsimp only
    cases hp : f'.pending.find? (fun pending => pending.token = token) with
    | none => trivial
    | some p =>
      dsimp only
      obtain ⟨f, hf0, hp0⟩ := record f' p hf hp
      obtain ⟨done, cols, tt, payload⟩ := countdownAt_found h hf0 hp0
      exact ⟨done, cols, tt, countdownPayload_mono ord payload⟩

theorem countdownAt_congr {w : World} {m m' : RState} {waiter : FiberId} {token : Nat}
    (fibers : ∀ id, m'.fiber? id = m.fiber? id)
    (h : CountdownAt w m waiter token) : CountdownAt w m' waiter token :=
  countdownAt_transport (leHost_refl w) (fun f' _ hf hp => ⟨f', by rw [← fibers]; exact hf, hp⟩) h

theorem storedObserverOk_congr {root : ProgramSource} {w : World} {m m' : RState}
    {source : FiberId} (fibers : ∀ id, m'.fiber? id = m.fiber? id)
    (races : ∀ race, m'.race? race = m.race? race) (state : m'.state = m.state) (o : Observer)
    (h : StoredObserverOk root w m source o) : StoredObserverOk root w m' source o := by
  cases o with
  | resumeAwait waiter token mode => exact h
  | countdown waiter token => exact countdownAt_congr fibers h
  | raceCallback raceId =>
    unfold StoredObserverOk at h ⊢
    dsimp only at h ⊢
    rw [races]
    exact h
  | dropScopeFinalizer scope key =>
    unfold StoredObserverOk at h ⊢
    dsimp only at h ⊢
    rw [state]
    exact h
  | untrackChild parent => trivial
  | callback key => trivial

theorem observerCommandOk_congr {root : ProgramSource} {w : World} {m m' : RState}
    {source : FiberId} {exit : ExitV} (fibers : ∀ id, m'.fiber? id = m.fiber? id)
    (races : ∀ race, m'.race? race = m.race? race) (state : m'.state = m.state) (o : Observer)
    (h : ObserverCommandOk root w m source exit o) : ObserverCommandOk root w m' source exit o := by
  cases o with
  | resumeAwait waiter token mode => exact h
  | countdown waiter token => exact ⟨countdownAt_congr fibers h.1, h.2⟩
  | raceCallback raceId =>
    unfold ObserverCommandOk at h ⊢
    dsimp only at h ⊢
    rw [races]
    exact h
  | dropScopeFinalizer scope key =>
    unfold ObserverCommandOk at h ⊢
    dsimp only at h ⊢
    rw [state]
    exact h
  | untrackChild parent => trivial
  | callback key => trivial

/-- Settled guard state clauses on the shared machine. No reference code-site condition
is claimed here: frameCodes/internalCodes remain H1-RCODE-SITES. -/
structure SchedulerState (m : RState) : Prop where
  fiberIds : (m.fibers.map RunFiber.id).Nodup
  fibersBelow : ∀ fiber ∈ m.fibers, fiber.id.value < m.nextId
  raceIds : (m.races.map Race.id).Nodup
  racesBelow : ∀ race ∈ m.races, race.id < m.nextRace
  raceHosts : ∀ race ∈ m.races, ∃ fiber, m.fiber? race.host = some fiber
  keysBelow : Guard.InternalKeysBelow m
  requestsBelow : ∀ fiber token request, requestOfR m fiber token = some request → token < m.nextToken
  requestsOwned : ∀ fiber token request, requestOfR m fiber token = some request →
    (fiber, token) ∉ Guard.internalKeys m
  pendingShape : ∀ fiber ∈ m.fibers, Guard.PendingShape fiber
  parkedIdle : ∀ fiber ∈ m.fibers, fiber.parked ≠ .notParked → fiber.running = false
  parkedBelow : ∀ fiber ∈ m.fibers, ∀ token,
    fiber.parked = .withGuard token → token < m.nextToken
  exited : ∀ fiber ∈ m.fibers, fiber.exit.isSome = true →
    fiber.parked = .notParked ∧ fiber.running = false
  /-- Decisions row 134 (c): an exited fiber's saved stack is empty. Only `RunFiber.publish`
  (`Machine/Fibers.lean:1750`) writes an exit, from a queued `finish`, whose fiber's stack is
  empty (`CommandDeliveryOk`'s `finish` clause); `exitDone`'s clear keeps it empty. -/
  exitedStack : ∀ fiber ∈ m.fibers, fiber.exit.isSome = true → fiber.frame.stack = []
  deferredCause : ∀ fiber ∈ m.fibers, fiber.frame.deferredInterrupt = true →
    fiber.frame.interruptedCause.isSome = true
  /-- Decisions row 134 (d): no stored observer holds a race's key (F5). The registration's
  no-answer park writes a `void` pending record at that key (`Machine/Fibers.lean:1925-1929`),
  which a countdown observer there would read at its own type; a race takes a fresh token, above
  every key an observer holds (`keysBelow`). -/
  raceObservers : ∀ raceId race, m.race? raceId = some race → ∀ fiber ∈ m.fibers,
    ∀ o ∈ fiber.observers, (race.host, race.token) ∉ Guard.observerKeys o
  /-- Decisions row 134 (e): every fiber id the scheduler's records name is below `nextId` (F6), so
  a fiber spawned at `nextId` (`spawn`, `Machine/Fibers.lean:948-966`) is constrained by none of
  them: a race's live set (`RacePayload.live`), a countdown's targets
  (`CountdownPayload.targets`) and a stored observer's keys. -/
  liveBelow : ∀ raceId race, m.race? raceId = some race → ∀ id ∈ race.state.live,
    id.value < m.nextId
  targetsBelow : ∀ fiber ∈ m.fibers, ∀ p ∈ fiber.pending,
    ∀ id ∈ p.remaining, id.value < m.nextId
  observersBelow : ∀ fiber ∈ m.fibers, ∀ o ∈ fiber.observers, ∀ k ∈ Guard.observerKeys o,
    k.1.value < m.nextId

/-- The reference evaluator consumes this operation directly; interpR.parkOf is none. -/
def raceRegistrationR : RProgram → Option Nat
  | .vis (.inr (.raceRegister raceId)) _ => some raceId
  | _ => none

/-! ## Decisions row 188 (b): registration markers under injected yields -/

/-- **A registration arrow** (decisions row 188 (b), `E4-TYPED-CE-033`). `beginRace` leaves a race's
registration marker current with `loop` queued (`Machine/Fibers.lean:919-931`); a budget-triggered
`injectYield` (`:1056-1064`; the term core's `yieldBefore`, `Laws/Program/InterpR.lean:89-91`)
saves it in a success callback around `Yield`. The callback returns the marker, which is no typed
code: its reply is the race's. As an arrow of the host's stack it goes from `tin` to the race
token's declared type: every success answer returns race `raceId`'s marker, the race exists on
this machine with this host, and a failure skips into the rest at the token's type (the reply
`registrationDone` delivers once the walk makes the marker current again, `RegistrationState`).
The correlation sits on the arrow, so typed code cannot forge it. -/
inductive RegistrationArrowAt {Object Input : Type}
    (Ex : World → Input → Object → ExitV → Prop) (inputOf : Object → ExitV → Input)
    (typeOf : Object → EffTy) (w : World) (m : RState) (host : FiberId) :
    Object → Object → ScopeFrame → Prop
  | mk {tin result : Object} {next : ExitV → RProgram} {raceId : Nat} {race : RRace}
      (marker : ∀ v, raceRegistrationR (next (.success v)) = some raceId)
      (skip : ∀ w', w.leHost w' → ∀ c,
        Ex w' (inputOf tin (.failure c)) tin (.failure c) →
        Ex w' (inputOf tin (.failure c)) result (.failure c))
      (found : m.race? raceId = some race) (hosted : race.host = host)
      (token : w.Θ race.host race.token = some (typeOf result)) :
      RegistrationArrowAt Ex inputOf typeOf w m host tin result (.resume .onSuccess next)

/-- The original registration judgment is the unit-input instance of the same arrows. -/
abbrev RegistrationArrow :=
  RegistrationArrowAt (fun w (_ : Unit) => ExitOk w) (fun _ _ => ()) id

/-- A host stack's arrows retain the full completion position and the actual race correlation. -/
def HostEdgeAt {Object Input : Type}
    (TP : World → Input → Object → RProgram → Prop)
    (Ex : World → Input → Object → ExitV → Prop) (hooks : Contracts.FrameProtocols Object)
    (inputOf : Object → ExitV → Input) (restoreInput : Ctx → Input)
    (guardInput : GuardKind → Object → ExitV → Input) (typeOf : Object → EffTy)
    (w : World) (m : RState) (host : FiberId) (tin tout : Object) (frame : ScopeFrame) : Prop :=
  Contracts.FrameArrow TP Ex hooks inputOf restoreInput guardInput w tin tout frame ∨
    RegistrationArrowAt Ex inputOf typeOf w m host tin tout frame

/-- The original type-only host edge specializes the shared annotated edge. -/
abbrev HostEdge (root : ProgramSource) :=
  HostEdgeAt (fun w (_ : Unit) => TypedProg root w) (fun w (_ : Unit) => ExitOk w)
    (frameProtocols root) (fun _ _ => ()) (fun _ => ()) (fun _ _ _ => ()) id

/-- A host's saved stack is the existing ordered path over its complete edge positions. -/
abbrev HostStackAt {Object Input : Type}
    (TP : World → Input → Object → RProgram → Prop)
    (Ex : World → Input → Object → ExitV → Prop) (hooks : Contracts.FrameProtocols Object)
    (inputOf : Object → ExitV → Input) (restoreInput : Ctx → Input)
    (guardInput : GuardKind → Object → ExitV → Input) (typeOf : Object → EffTy)
    (w : World) (m : RState) (host : FiberId) :=
  Effect4.Contracts.Path (HostEdgeAt TP Ex hooks inputOf restoreInput guardInput typeOf w m host)

/-- The original type-only stack is the unit-input instance of the same path. -/
abbrev HostStack (root : ProgramSource) :=
  HostStackAt (fun w (_ : Unit) => TypedProg root w) (fun w (_ : Unit) => ExitOk w)
    (frameProtocols root) (fun _ _ => ()) (fun _ => ()) (fun _ _ _ => ()) id

/-- Current code and the correlated host path meet at the same complete position. -/
def CodeArrow {Object Input : Type}
    (TP : World → Input → Object → RProgram → Prop)
    (Ex : World → Input → Object → ExitV → Prop) (hooks : Contracts.FrameProtocols Object)
    (inputOf : Object → ExitV → Input) (restoreInput : Ctx → Input)
    (guardInput : GuardKind → Object → ExitV → Input) (typeOf : Object → EffTy)
    (w : World) (m : RState) (host : FiberId) (input : Input) (final : Object) (saved : RSaved) : Prop :=
  ∃ tin, TP w input tin saved.current ∧
    HostStackAt TP Ex hooks inputOf restoreInput guardInput typeOf w m host tin final saved.stack ∧
    Contracts.InterruptProvenance saved

/-- The original type-only current-code judgment is the unit-input shared instance. -/
abbrev CodeOk (root : ProgramSource) (w : World) (m : RState) (host : FiberId) (final : EffTy)
    (x : RSaved) : Prop :=
  CodeArrow (fun w (_ : Unit) => TypedProg root w) (fun w (_ : Unit) => ExitOk w)
    (frameProtocols root) (fun _ _ => ()) (fun _ => ()) (fun _ _ _ => ()) id w m host () final x

/-- A race's unlaunched entrants within a row: each is code typed at an entry row the row holds,
at the race token's columns. An entrant starts in a child holding the host's context, which covers
the row; its point's stack is typed at the registering fiber's row (`ambientFiberPre`'s race arm),
so the entry row is that row, not every row covering the entrant's requirements. -/
def EntrantsWithin (root : ProgramSource) (w : World) (race : RRace) (resultTy : EffTy)
    (row : Env.Requirement) : Prop :=
  ∀ code ∈ race.programs, ∃ (childTy : EffTy) (entry : Env.Requirement),
    AmbientProg root w entry ((childTy, entry, entry) : AmbientPosition) code ∧
    Row.Subset entry row ∧
    Ty.subN childTy.answer resultTy.answer = true ∧ Ty.subN childTy.error resultTy.error = true

theorem EntrantsWithin.mono {root : ProgramSource} {w w' : World} (ord : w.leHost w')
    {race : RRace} {resultTy : EffTy} {row : Env.Requirement}
    (h : EntrantsWithin root w race resultTy row) : EntrantsWithin root w' race resultTy row :=
  fun code hc => by
  obtain ⟨childTy, entry, child, covered⟩ := h code hc
  exact ⟨childTy, entry, ambientProg_mono root ord child, covered⟩

theorem EntrantsWithin.kept {root : ProgramSource} {w : World} {race race' : RRace}
    {resultTy : EffTy} {row : Env.Requirement} (h : EntrantsWithin root w race resultTy row)
    (programs : ∀ code ∈ race'.programs, code ∈ race.programs) :
    EntrantsWithin root w race' resultTy row :=
  fun code hc => h code (programs code hc)

/-- The race facts the registration arrows read move to a machine whose races keep their host
and token. -/
def RacesKept (m m' : RState) : Prop :=
  ∀ r race, m.race? r = some race →
    ∃ race', m'.race? r = some race' ∧ race'.host = race.host ∧ race'.token = race.token ∧
      ∀ code ∈ race'.programs, code ∈ race.programs

theorem racesKept_of_eq {m m' : RState} (races : ∀ r, m'.race? r = m.race? r) : RacesKept m m' :=
  fun r race h => ⟨race, (races r).trans h, rfl, rfl, fun _ hc => hc⟩

/-- Registration callbacks transport their complete positions through the existing world order.
Consumer: host stack transport at both unit and ambient instances. -/
theorem registrationArrowAt_mono {Object Input : Type}
    {Ex : World → Input → Object → ExitV → Prop} {inputOf : Object → ExitV → Input}
    {typeOf : Object → EffTy} {w w' : World} {m : RState} {host : FiberId}
    {a b : Object} {frame : ScopeFrame} (ord : w.leHost w')
    (h : RegistrationArrowAt Ex inputOf typeOf w m host a b frame) :
    RegistrationArrowAt Ex inputOf typeOf w' m host a b frame := by
  cases h with
  | mk marker skip found hosted token =>
    exact .mk marker (fun w'' o c hc => skip w'' (leHost_trans _ _ _ ord o) c hc) found hosted
      (ord.1.2.2.2.2.2.1 _ _ _ token)

theorem registrationArrow_mono {w w' : World} {m : RState} {host : FiberId} {a b : EffTy}
    {frame : ScopeFrame} (ord : w.leHost w') (h : RegistrationArrow w m host a b frame) :
    RegistrationArrow w' m host a b frame :=
  registrationArrowAt_mono ord h

theorem registrationArrow_races {w : World} {m m' : RState} {host : FiberId} {a b : EffTy}
    {frame : ScopeFrame} (kept : RacesKept m m') (h : RegistrationArrow w m host a b frame) :
    RegistrationArrow w m' host a b frame := by
  cases h with
  | mk marker skip found hosted token =>
    obtain ⟨race', found', host', token', _⟩ := kept _ _ found
    exact .mk marker skip found' (host'.trans hosted) (by rw [host', token']; exact token)

theorem hostStack_of_stackAccepts {root : ProgramSource} {w : World} {m : RState}
    {host : FiberId} {tin final : EffTy} {stack : List ScopeFrame}
    (h : Contracts.StackAccepts (TypedProg root) ExitOk (frameProtocols root) w tin final stack) :
    HostStack root w m host tin final stack :=
  (Contracts.framePath_of_stackAccepts h).map fun _ _ _ e => .inl e

theorem codeOk_of_saved {root : ProgramSource} {w : World} {m : RState} {host : FiberId}
    {final : EffTy} {x : RSaved}
    (h : Contracts.SavedOk (TypedProg root) ExitOk (frameProtocols root) w final x) :
    CodeOk root w m host final x := by
  obtain ⟨tin, code, stack, provenance⟩ := h
  exact ⟨tin, code, hostStack_of_stackAccepts stack, provenance⟩

/-- World growth retains the full correlated host path without changing its entry positions.
Consumer: unit and ambient current-code world transport. -/
theorem hostStackAt_mono {Object Input : Type}
    {TP : World → Input → Object → RProgram → Prop}
    {Ex : World → Input → Object → ExitV → Prop} {hooks : Contracts.FrameProtocols Object}
    {inputOf : Object → ExitV → Input} {restoreInput : Ctx → Input}
    {guardInput : GuardKind → Object → ExitV → Input} {typeOf : Object → EffTy}
    {w w' : World} {m : RState} {host : FiberId} {tin final : Object} {stack : List ScopeFrame}
    (ord : w.leHost w')
    (h : HostStackAt TP Ex hooks inputOf restoreInput guardInput typeOf w m host tin final stack) :
    HostStackAt TP Ex hooks inputOf restoreInput guardInput typeOf w' m host tin final stack :=
  h.map fun _ _ _ edge => edge.imp (Contracts.frameArrow_mono ord) (registrationArrowAt_mono ord)

/-- The current entry and the complete host path transport through the same shared laws.
Consumer: CodeOk at the existing machine's world-growth cuts. -/
theorem CodeArrow.mono {Object Input : Type}
    {TP : World → Input → Object → RProgram → Prop}
    {Ex : World → Input → Object → ExitV → Prop} {hooks : Contracts.FrameProtocols Object}
    {inputOf : Object → ExitV → Input} {restoreInput : Ctx → Input}
    {guardInput : GuardKind → Object → ExitV → Input} {typeOf : Object → EffTy}
    (tp : ∀ {w w' input ty code}, w.leHost w' → TP w input ty code → TP w' input ty code)
    {w w' : World} {m : RState} {host : FiberId} {input : Input} {final : Object} {saved : RSaved}
    (ord : w.leHost w')
    (typed : CodeArrow TP Ex hooks inputOf restoreInput guardInput typeOf w m host input final saved) :
    CodeArrow TP Ex hooks inputOf restoreInput guardInput typeOf w' m host input final saved := by
  obtain ⟨tin, code, stack, provenance⟩ := typed
  exact ⟨tin, tp ord code, hostStackAt_mono ord stack, provenance⟩

theorem hostStack_mono {root : ProgramSource} {w w' : World} {m : RState} {host : FiberId}
    {tin final : EffTy} {stack : List ScopeFrame} (ord : w.leHost w')
    (h : HostStack root w m host tin final stack) : HostStack root w' m host tin final stack :=
  hostStackAt_mono ord h

theorem hostStack_races {root : ProgramSource} {w : World} {m m' : RState} {host : FiberId}
    {tin final : EffTy} {stack : List ScopeFrame} (kept : RacesKept m m')
    (h : HostStack root w m host tin final stack) : HostStack root w m' host tin final stack :=
  h.map fun _ _ _ e => e.imp id (registrationArrow_races kept)

/-- A frame pushed on a host stack. -/
theorem hostStack_push {root : ProgramSource} {w : World} {m : RState} {host : FiberId}
    {a b final : EffTy} {f : ScopeFrame} {stack : List ScopeFrame}
    (hf : Contracts.FrameAccepts (TypedProg root) ExitOk (frameProtocols root) w a b f)
    (h : HostStack root w m host b final stack) : HostStack root w m host a final (f :: stack) :=
  .cons (.inl hf) h

theorem codeOk_mono {root : ProgramSource} {w w' : World} {m : RState} {host : FiberId}
    {final : EffTy} {x : RSaved} (ord : w.leHost w') (h : CodeOk root w m host final x) :
    CodeOk root w' m host final x :=
  CodeArrow.mono (TP := fun w (_ : Unit) => TypedProg root w)
    (fun {w w'} {_ ty code} ordered typed => typedProg_mono root w w' ty code ordered typed) ord h

theorem codeOk_races {root : ProgramSource} {w : World} {m m' : RState} {host : FiberId}
    {final : EffTy} {x : RSaved} (kept : RacesKept m m') (h : CodeOk root w m host final x) :
    CodeOk root w m' host final x := by
  obtain ⟨tin, code, stack, provenance⟩ := h
  exact ⟨tin, code, hostStack_races kept stack, provenance⟩

/-- **A position arrow** (decisions row 188 (b)), for the generated position clause, which reads no
machine: a success callback whose every success answer is a registration marker, typed by the
failures it skips alone. Its race correlation is the machine clauses' (`RegistrationArrow`). -/
inductive PositionArrowAt {Object Input : Type}
    (Ex : World → Input → Object → ExitV → Prop) (inputOf : Object → ExitV → Input)
    (w : World) : Object → Object → ScopeFrame → Prop
  | mk {tin middle : Object} {next : ExitV → RProgram}
      (marker : ∀ v, (raceRegistrationR (next (.success v))).isSome = true)
      (skip : ∀ w', w.leHost w' → ∀ c,
        Ex w' (inputOf tin (.failure c)) tin (.failure c) →
        Ex w' (inputOf tin (.failure c)) middle (.failure c)) :
      PositionArrowAt Ex inputOf w tin middle (.resume .onSuccess next)

/-- The original saved-position registration shape is the unit-input instance. -/
abbrev PositionArrow :=
  PositionArrowAt (fun w (_ : Unit) => ExitOk w) (fun _ _ => ())

/-- An annotated saved position forgets race identity, retaining its capability guarantees. -/
def PositionEdgeAt {Object Input : Type}
    (TP : World → Input → Object → RProgram → Prop)
    (Ex : World → Input → Object → ExitV → Prop) (hooks : Contracts.FrameProtocols Object)
    (inputOf : Object → ExitV → Input) (restoreInput : Ctx → Input)
    (guardInput : GuardKind → Object → ExitV → Input)
    (w : World) (tin tout : Object) (frame : ScopeFrame) : Prop :=
  Contracts.FrameArrow TP Ex hooks inputOf restoreInput guardInput w tin tout frame ∨
    PositionArrowAt Ex inputOf w tin tout frame

/-- The generated saved-position clause retains the same shared annotated path. -/
abbrev PositionStackAt {Object Input : Type}
    (TP : World → Input → Object → RProgram → Prop)
    (Ex : World → Input → Object → ExitV → Prop) (hooks : Contracts.FrameProtocols Object)
    (inputOf : Object → ExitV → Input) (restoreInput : Ctx → Input)
    (guardInput : GuardKind → Object → ExitV → Input) (w : World) :=
  Effect4.Contracts.Path (PositionEdgeAt TP Ex hooks inputOf restoreInput guardInput w)

abbrev PositionEdge (root : ProgramSource) :=
  PositionEdgeAt (fun w (_ : Unit) => TypedProg root w) (fun w (_ : Unit) => ExitOk w)
    (frameProtocols root) (fun _ _ => ()) (fun _ => ()) (fun _ _ _ => ())

abbrev PositionStack (root : ProgramSource) :=
  PositionStackAt (fun w (_ : Unit) => TypedProg root w) (fun w (_ : Unit) => ExitOk w)
    (frameProtocols root) (fun _ _ => ()) (fun _ => ()) (fun _ _ _ => ())

theorem positionArrow_mono {w w' : World} {a b : EffTy} {frame : ScopeFrame} (ord : w.leHost w')
    (h : PositionArrow w a b frame) : PositionArrow w' a b frame := by
  cases h with
  | mk marker skip => exact .mk marker (fun w'' o c hc => skip w'' (leHost_trans _ _ _ ord o) c hc)

/-- Forgetting a registration arrow's correlation leaves a position arrow (one-way). -/
theorem positionArrow_of_registration {w : World} {m : RState} {host : FiberId} {a b : EffTy}
    {frame : ScopeFrame} (h : RegistrationArrow w m host a b frame) : PositionArrow w a b frame := by
  cases h with
  | mk marker skip _ _ _ => exact .mk (fun v => by rw [marker v]; rfl) skip

theorem positionStack_of_stackAccepts {root : ProgramSource} {w : World} {tin final : EffTy}
    {stack : List ScopeFrame}
    (h : Contracts.StackAccepts (TypedProg root) ExitOk (frameProtocols root) w tin final stack) :
    PositionStack root w tin final stack :=
  (Contracts.framePath_of_stackAccepts h).map fun _ _ _ e => .inl e

theorem positionStack_mono {root : ProgramSource} {w w' : World} {tin final : EffTy}
    {stack : List ScopeFrame} (ord : w.leHost w') (h : PositionStack root w tin final stack) :
    PositionStack root w' tin final stack :=
  h.map fun _ _ _ e => e.imp (Contracts.frameAccepts_mono ord) (positionArrow_mono ord)

/-- A host stack is a position stack: the race correlation is forgotten. -/
theorem positionStack_of_host {root : ProgramSource} {w : World} {m : RState} {host : FiberId}
    {tin final : EffTy} {stack : List ScopeFrame} (h : HostStack root w m host tin final stack) :
    PositionStack root w tin final stack :=
  h.map fun _ _ _ e => e.imp id positionArrow_of_registration


/-! ## Machine stacks and current code (decisions row 349)

The machine's clauses type a fiber's code and saved stack with the row-indexed judgment, at a
row its actual context covers (`AmbientMachine.lean`). A host stack also holds row 188 (b)'s
registration callbacks. -/

/-- A registration callback over machine positions: every success answer returns the race's
marker, the race exists on this machine with this host, its unlaunched entrants are within the row,
and a failure skips to the race token's type. The callback is saved over the race's answer at the row the race entered at, and the code
above it keeps the context, so it meets the stack at that constant row on both sides. -/
inductive MRegistration (root : ProgramSource) (w : World) (m : RState) (host : FiberId) :
    MachinePos → MachinePos → ScopeFrame → Prop
  | mk {t' t : EffTy} {r : Env.Requirement} {b : Bool}
      {next : ExitV → RProgram} {raceId : Nat} {race : RRace}
      (marker : ∀ v, raceRegistrationR (next (.success v)) = some raceId)
      (skip : ∀ w', w.leHost w' → ∀ c, ExitOk w' t' (.failure c) → ExitOk w' t (.failure c))
      (found : m.race? raceId = some race) (hosted : race.host = host)
      (token : w.Θ race.host race.token = some t) (entrants : EntrantsWithin root w race t r) :
      MRegistration root w m host (((t', r, r) : AmbientPosition), b) (((t, r, r) : AmbientPosition), b)
        (.resume .onSuccess next)

/-- A machine host stack's edge: a frame, or a registration callback. -/
def MHostEdge (root : ProgramSource) (w : World) (m : RState) (host : FiberId)
    (tin tout : MachinePos) (frame : ScopeFrame) : Prop :=
  MFrame root w tin tout frame ∨ MRegistration root w m host tin tout frame

/-- A machine host stack: the shared path over its edges. -/
abbrev MHostStack (root : ProgramSource) (w : World) (m : RState) (host : FiberId) :=
  Effect4.Contracts.Path (MHostEdge root w m host)

theorem MRegistration.mono {root : ProgramSource} {w w' : World} {m : RState} {host : FiberId}
    {a b : MachinePos} {frame : ScopeFrame} (ord : w.leHost w') (h : MRegistration root w m host a b frame) :
    MRegistration root w' m host a b frame := by
  cases h with
  | mk marker skip found hosted token entrants =>
    exact .mk marker (fun w'' o c hc => skip w'' (leHost_trans _ _ _ ord o) c hc) found hosted
      (ord.1.2.2.2.2.2.1 _ _ _ token) (entrants.mono ord)

theorem MRegistration.races {root : ProgramSource} {w : World} {m m' : RState} {host : FiberId}
    {a b : MachinePos} {frame : ScopeFrame} (kept : RacesKept m m')
    (h : MRegistration root w m host a b frame) : MRegistration root w m' host a b frame := by
  cases h with
  | mk marker skip found hosted token entrants =>
    obtain ⟨race', found', host', token', programs⟩ := kept _ _ found
    exact .mk marker skip found' (host'.trans hosted) (by rw [host', token']; exact token)
      (entrants.kept programs)

theorem MHostStack.mono {root : ProgramSource} {w w' : World} {m : RState} {host : FiberId}
    {tin tout : MachinePos} {stack : List ScopeFrame} (ord : w.leHost w')
    (h : MHostStack root w m host tin tout stack) : MHostStack root w' m host tin tout stack :=
  h.map fun _ _ _ e => e.imp (MFrame.mono ord) (MRegistration.mono ord)

theorem MHostStack.races {root : ProgramSource} {w : World} {m m' : RState} {host : FiberId}
    {tin tout : MachinePos} {stack : List ScopeFrame} (kept : RacesKept m m')
    (h : MHostStack root w m host tin tout stack) : MHostStack root w m' host tin tout stack :=
  h.map fun _ _ _ e => e.imp id (MRegistration.races kept)

theorem MHostStack.of_stack {root : ProgramSource} {w : World} {m : RState} {host : FiberId}
    {tin tout : MachinePos} {stack : List ScopeFrame} (h : MStack root w tin tout stack) :
    MHostStack root w m host tin tout stack :=
  h.map fun _ _ _ e => .inl e

/-- A fiber's final position: its declared type, needing no service. -/
abbrev finalPos (final : EffTy) (flag : Bool) : MachinePos :=
  (((final, Env.Requirement.empty, Env.Requirement.empty) : AmbientPosition), flag)

/-- **A fiber's current code over its saved stack**, at a row its context covers: the code at
that row, a host stack from its position at the fiber's mask to the fiber's declared type, and
interrupt provenance. The code's failure row is within the row at either mask (the judgment's
entry, `MaskEntry.lean`), so an interrupt the machine injects there is covered, a deferred one
under a mask too (`runloopTop`; rc.112 `internal/effect.ts:639-642`, equal text in 4.0.1
`:632-635`). -/
def MCodeOk (root : ProgramSource) (w : World) (m : RState) (f : RFiber) (final : EffTy) : Prop :=
  ∃ (row : Env.Requirement) (tin : MachinePos) (flag : Bool),
    f.context.services.Satisfies row ∧ tin.2 = f.frame.interruptible ∧
    AmbientProg root w row tin.1 f.frame.current ∧
    MHostStack root w m f.id tin (finalPos final flag) f.frame.stack ∧
    Contracts.InterruptProvenance f.frame

theorem MCodeOk.mono {root : ProgramSource} {w w' : World} {m : RState} {f : RFiber}
    {final : EffTy} (ord : w.leHost w') (h : MCodeOk root w m f final) : MCodeOk root w' m f final := by
  obtain ⟨row, tin, flag, covered, mask, code, stack, provenance⟩ := h
  exact ⟨row, tin, flag, covered, mask, ambientProg_mono root ord code, stack.mono ord, provenance⟩

theorem MCodeOk.races {root : ProgramSource} {w : World} {m m' : RState} {f : RFiber}
    {final : EffTy} (kept : RacesKept m m') (h : MCodeOk root w m f final) : MCodeOk root w m' f final := by
  obtain ⟨row, tin, flag, covered, mask, code, stack, provenance⟩ := h
  exact ⟨row, tin, flag, covered, mask, code, stack.races kept, provenance⟩

/-- What is read of a fiber is its id, context and frame. -/
theorem MCodeOk.congr {root : ProgramSource} {w : World} {m : RState} {f g : RFiber}
    {final : EffTy} (h : MCodeOk root w m f final) (id : g.id = f.id) (context : g.context = f.context)
    (frame : g.frame = f.frame) : MCodeOk root w m g final := by
  unfold MCodeOk
  rw [id, context, frame]
  exact h

/-- A queued resume's code, at the target's token type, typed at every row and mask: a resume can
take no capability from its type in the token table (decisions row 349). -/
def ResumeCode (root : ProgramSource) (w : World) (target : FiberId) (token : Nat) (code : RProgram) :
    Prop :=
  ∀ ty, w.Θ target token = some ty → ∀ row,
    AmbientProg root w row ((ty, row, row) : AmbientPosition) code

/-- Administrative resumed code typed at its token's declaration is a resume's code. -/
theorem resumeCode_of_typed {root : ProgramSource} {w : World} {target : FiberId} {token : Nat}
    {code : RProgram} (typed : Contracts.ResumeOk (TypedProg root) w target token code)
    (admin : AdminCode code) : ResumeCode root w target token code :=
  fun ty declared row => ambientProg_of_admin root (typed ty declared) admin row

/-- Row-indexed code is no race registration marker: that operation's pre is `False`. -/
theorem raceRegistrationR_ambient {root : ProgramSource} {w : World} {available : Env.Requirement}
    {position : AmbientPosition} {p : RProgram} (h : AmbientProg root w available position p) :
    raceRegistrationR p = none := by
  unfold raceRegistrationR
  split
  · cases h with
    | fiber _ _ _ _ _ pre _ _ => cases pre
  · rfl

/-- A reply delivered to a fiber meets its saved stack at a row its context covers. -/
def StackReplyAt (root : ProgramSource) (w : World) (m : RState) (fiber : RFiber) (replyTy : EffTy)
    (row : Env.Requirement) : Prop :=
  ∃ final flag, w.Γ fiber.id = some final ∧ fiber.context.services.Satisfies row ∧
    MHostStack root w m fiber.id (((replyTy, row, row) : AmbientPosition), fiber.frame.interruptible)
      (finalPos final flag) fiber.frame.stack ∧
    Contracts.InterruptProvenance fiber.frame

theorem StackReplyAt.mono {root : ProgramSource} {w w' : World} {m m' : RState} {fiber : RFiber}
    {replyTy : EffTy} {row : Env.Requirement} (ord : w.leHost w') (kept : RacesKept m m')
    (h : StackReplyAt root w m fiber replyTy row) : StackReplyAt root w' m' fiber replyTy row := by
  obtain ⟨final, flag, declared, covered, stack, provenance⟩ := h
  exact ⟨final, flag, ord.1.2.1 _ _ declared, covered, (stack.races kept).mono ord, provenance⟩

theorem StackReplyAt.congr {root : ProgramSource} {w : World} {m : RState} {f g : RFiber}
    {replyTy : EffTy} {row : Env.Requirement} (h : StackReplyAt root w m f replyTy row)
    (id : g.id = f.id) (context : g.context = f.context) (frame : g.frame = f.frame) :
    StackReplyAt root w m g replyTy row := by
  unfold StackReplyAt
  rw [id, context, frame]
  exact h

/-- A registration callback with its race forgotten: the generated saved-position clause. -/
inductive MPositionArrow (w : World) : MachinePos → MachinePos → ScopeFrame → Prop
  | mk {t' t : EffTy} {r : Env.Requirement} {b : Bool} {next : ExitV → RProgram}
      (marker : ∀ v, (raceRegistrationR (next (.success v))).isSome = true)
      (skip : ∀ w', w.leHost w' → ∀ c, ExitOk w' t' (.failure c) → ExitOk w' t (.failure c)) :
      MPositionArrow w (((t', r, r) : AmbientPosition), b) (((t, r, r) : AmbientPosition), b)
        (.resume .onSuccess next)

/-- A machine position stack: frames and race-forgetting registration callbacks. -/
abbrev MPositionStack (root : ProgramSource) (w : World) :=
  Effect4.Contracts.Path (fun a b frame => MFrame root w a b frame ∨ MPositionArrow w a b frame)

theorem MPositionStack.of_host {root : ProgramSource} {w : World} {m : RState} {host : FiberId}
    {tin tout : MachinePos} {stack : List ScopeFrame} (h : MHostStack root w m host tin tout stack) :
    MPositionStack root w tin tout stack :=
  h.map fun _ _ _ e => e.imp id fun arrow => by
    cases arrow with
    | mk marker skip _ _ _ _ => exact .mk (fun v => by rw [marker v]; rfl) skip

theorem MPositionStack.mono {root : ProgramSource} {w w' : World} (ord : w.leHost w')
    {tin tout : MachinePos} {stack : List ScopeFrame} (h : MPositionStack root w tin tout stack) :
    MPositionStack root w' tin tout stack :=
  h.map fun _ _ _ e => e.imp (MFrame.mono ord) fun arrow => by
    cases arrow with
    | mk marker skip => exact .mk marker (fun w'' o c hc => skip w'' (leHost_trans _ _ _ ord o) c hc)

/-- A concrete reply must meet the actual saved stack, independently of whatever type
certified the current administrative operation. This names a local delivery boundary. The stack
may hold row 188 (b)'s injected registration callback (`HostStack`): every reply consumer
(`afterInterrupt`, `raceCancel`, `closeParAwait`, a registration's delivery) carries it. -/
def StackReply (root : ProgramSource) (w : World) (m : RState) (fiber : RFiber) (replyTy : EffTy) :
    Prop :=
  ∃ row, StackReplyAt root w m fiber replyTy row

theorem stackReply_races {root : ProgramSource} {w : World} {m m' : RState} {fiber : RFiber}
    {replyTy : EffTy} (kept : RacesKept m m') (h : StackReply root w m fiber replyTy) :
    StackReply root w m' fiber replyTy := by
  obtain ⟨row, final, flag, declared, covered, stack, provenance⟩ := h
  exact ⟨row, final, flag, declared, covered, stack.races kept, provenance⟩

/-- **A registering host's reply** (decisions rows 188 (b) and 349): its saved stack meets the
race token's type at a row its context covers, and while it lives the race's unlaunched entrants
are within that row, so each starts in a child its context covers. An exited host launches
nothing; its emptied stack forces the empty row. -/
def RaceReply (root : ProgramSource) (w : World) (m : RState) (host : RFiber) (race : RRace)
    (resultTy : EffTy) : Prop :=
  ∃ row, StackReplyAt root w m host resultTy row ∧
    (host.exit = none → EntrantsWithin root w race resultTy row)

/-- A race reply moves wherever its reply stack at the same row and its entrants move. -/
theorem RaceReply.imp {root : ProgramSource} {w w' : World} {m m' : RState} {host host' : RFiber}
    {race race' : RRace} {resultTy : EffTy} (h : RaceReply root w m host race resultTy)
    (reply : ∀ row, StackReplyAt root w m host resultTy row →
      StackReplyAt root w' m' host' resultTy row)
    (entrants : ∀ row, (host.exit = none → EntrantsWithin root w race resultTy row) →
      host'.exit = none → EntrantsWithin root w' race' resultTy row) :
    RaceReply root w' m' host' race' resultTy :=
  let ⟨row, r, e⟩ := h
  ⟨row, reply row r, entrants row e⟩

theorem RaceReply.races {root : ProgramSource} {w : World} {m m' : RState} {host : RFiber}
    {race : RRace} {resultTy : EffTy} (kept : RacesKept m m')
    (h : RaceReply root w m host race resultTy) : RaceReply root w m' host race resultTy :=
  h.imp (fun _ r => r.mono (leHost_refl w) kept) fun _ e => e

theorem RaceReply.kept {root : ProgramSource} {w : World} {m : RState} {host : RFiber}
    {race race' : RRace} {resultTy : EffTy} (h : RaceReply root w m host race resultTy)
    (programs : ∀ code ∈ race'.programs, code ∈ race.programs) :
    RaceReply root w m host race' resultTy :=
  h.imp (fun _ r => r) fun _ e live => (e live).kept programs

/-- An exited host's reply needs only its stack. -/
theorem RaceReply.of_exited {root : ProgramSource} {w : World} {m : RState} {host : RFiber}
    {race : RRace} {resultTy : EffTy} (h : StackReply root w m host resultTy)
    (exited : host.exit.isSome = true) : RaceReply root w m host race resultTy :=
  let ⟨row, reply⟩ := h
  ⟨row, reply, fun live => by rw [live] at exited; cases exited⟩

theorem RaceReply.stackReply {root : ProgramSource} {w : World} {m : RState} {host : RFiber}
    {race : RRace} {resultTy : EffTy} (h : RaceReply root w m host race resultTy) :
    StackReply root w m host resultTy :=
  let ⟨row, reply, _⟩ := h
  ⟨row, reply⟩

/-- The direct registration marker owns a real race on this fiber, and the race token's
result meets this host's saved continuation. This finite current-code clause covers both
immediate buffered settlement and parking; it is not the open recursive code-site scan. -/
def RegistrationState (root : ProgramSource) (w : World) (m : RState) : Prop :=
  ∀ fiber ∈ m.fibers, ∀ raceId, raceRegistrationR fiber.frame.current = some raceId →
    ∃ race resultTy, m.race? raceId = some race ∧ race.host = fiber.id ∧
      w.Θ race.host race.token = some resultTy ∧ RaceReply root w m fiber race resultTy

/-- A loaded code with no direct registration marker needs no race/token correlation yet. -/
theorem registrationState_load (root : ProgramSource) (w : World) (fuel compileFuel : Nat)
    (noMarker : raceRegistrationR (denoteR root.program root.program (rootPoint compileFuel)) = none) :
    RegistrationState root w (loadR root.program fuel compileFuel) := by
  intro fiber hf raceId marker
  change fiber ∈ [_] at hf
  rw [List.mem_singleton] at hf
  subst fiber
  change raceRegistrationR (denoteR root.program root.program (rootPoint compileFuel)) = some raceId at marker
  rw [noMarker] at marker
  cases marker

/-- The existing await protocol certifies a finite list of declared target columns.
This is a command-admission requirement; the runtime's missing-target behavior is unchanged. -/
def FiberListColumns (w : World) (targets : List FiberId) (answer error : Ty) : Prop :=
  ∀ id ∈ targets, FiberColumnsBelow w id answer error

/-- asVoid(awaitCode kind) has a unit answer. joinEffect can retain the target's typed
failures; awaitValue and awaitAll return encoded exits as successful values. -/
def AfterInterruptReply (w : World) : ParkKind → EffTy → Prop
  | .join target .joinEffect, replyTy => ∃ sourceTy, w.Γ target = some sourceTy ∧
      replyTy = ⟨.unit, sourceTy.error, Env.Requirement.empty⟩
  | .join target .awaitValue, replyTy => ∃ sourceTy, w.Γ target = some sourceTy ∧
      replyTy = EffTy.pure .unit
  | .awaitAll targets, replyTy => ∃ answer error, FiberListColumns w targets answer error ∧
      replyTy = EffTy.pure .unit
  | .race _, _ => False

/-- Commands with no carried code can still install a concrete reply or an iterator frame.
Their finite targets and result columns must meet the actual host stack. This does not ask
that an evaluated transition be typed, and does not quantify over unknown code continuations. -/
def CommandDeliveryOk (root : ProgramSource) (w : World) (m : RState) : RCmd → Prop
  | .afterInterrupt host _ kind => ∀ fiber, m.fiber? host = some fiber →
      ∃ replyTy, AfterInterruptReply w kind replyTy ∧ StackReply root w m fiber replyTy
  | .raceCancel _ host _ remaining visited => ∀ fiber, m.fiber? host = some fiber →
      ∃ answer error, FiberListColumns w (visited ++ remaining) answer error ∧
        StackReply root w m fiber (EffTy.pure .unit)
  /- Decisions row 134 (c): a queued `finish` names a fiber whose saved stack is empty: the loop
  queues it only from the `finished` outcome (`settle`), after `frameExitState` drained the
  stack. -/
  | .finish host _ => ∀ fiber, m.fiber? host = some fiber → fiber.frame.stack = []
  | .closeParAwait host _ targets => ∀ fiber, m.fiber? host = some fiber →
      ∃ answer error row, FiberListColumns w targets answer error ∧
        AmbientIteratorProtocol root w row row
          ⟨.list (.exitOf answer error), error, Env.Requirement.empty⟩
          ⟨.unit, error, Env.Requirement.empty⟩ (interpR root.program).closeDoneName ∧
        StackReplyAt root w m fiber ⟨.unit, error, Env.Requirement.empty⟩ row
  | _ => True

/-- The delivery reads see the fiber table only positively: a declaration exists, a column bound,
a reply stack's final type. They move along any world extension. -/
theorem fiberListColumns_mono {w w' : World} (ext : ∀ id t, w.Γ id = some t → w'.Γ id = some t)
    {targets : List FiberId} {answer error : Ty} (h : FiberListColumns w targets answer error) :
    FiberListColumns w' targets answer error := by
  intro id hid
  obtain ⟨t, declared, ha, he⟩ := h id hid
  exact ⟨t, ext _ _ declared, ha, he⟩

theorem afterInterruptReply_mono {w w' : World} (ext : ∀ id t, w.Γ id = some t → w'.Γ id = some t)
    {kind : ParkKind} {replyTy : EffTy} (h : AfterInterruptReply w kind replyTy) :
    AfterInterruptReply w' kind replyTy := by
  cases kind with
  | join target mode =>
    cases mode <;> (obtain ⟨sourceTy, declared, eq⟩ := h; exact ⟨sourceTy, ext _ _ declared, eq⟩)
  | awaitAll targets =>
    obtain ⟨answer, error, cols, eq⟩ := h
    exact ⟨answer, error, fiberListColumns_mono ext cols, eq⟩
  | race _ => exact h

theorem stackReply_mono {root : ProgramSource} {w w' : World} {m m' : RState} {fiber : RFiber}
    {replyTy : EffTy} (ord : w.leHost w') (ext : ∀ id t, w.Γ id = some t → w'.Γ id = some t)
    (kept : RacesKept m m') (h : StackReply root w m fiber replyTy) :
    StackReply root w' m' fiber replyTy := by
  obtain ⟨row, final, flag, declared, covered, stack, provenance⟩ := h
  exact ⟨row, final, flag, ext _ _ declared, covered, (stack.races kept).mono ord, provenance⟩

/-- **The delivery facts are monotone**: they read the world only positively, the machine only at
the command's owner (`Guard.commandOwner`, the host of every command that installs a reply), and
the races only through their host and token (row 188 (b)'s registration arrows). So they move
along a world extension to any machine that agrees at the owner and keeps the races' host and
token: a trace edit, a race edit, an allocation (`Commands/Launch.lean`). -/
theorem commandDelivery_mono {root : ProgramSource} {w w' : World} {m m' : RState}
    (ord : w.leHost w') (ext : ∀ id t, w.Γ id = some t → w'.Γ id = some t) (kept : RacesKept m m')
    {c : RCmd} (owner : ∀ o, Guard.commandOwner m c = some o → m'.fiber? o = m.fiber? o)
    (h : CommandDeliveryOk root w m c) : CommandDeliveryOk root w' m' c := by
  cases c with
  | afterInterrupt host _ kind =>
    intro f hf
    rw [owner host rfl] at hf
    obtain ⟨replyTy, reply, stack⟩ := h f hf
    exact ⟨replyTy, afterInterruptReply_mono ext reply, stackReply_mono ord ext kept stack⟩
  | raceCancel _ host _ remaining visited =>
    intro f hf
    rw [owner host rfl] at hf
    obtain ⟨answer, error, cols, stack⟩ := h f hf
    exact ⟨answer, error, fiberListColumns_mono ext cols, stackReply_mono ord ext kept stack⟩
  | closeParAwait host _ targets =>
    intro f hf
    rw [owner host rfl] at hf
    obtain ⟨answer, error, row, cols, protocol, stack⟩ := h f hf
    exact ⟨answer, error, row, fiberListColumns_mono ext cols, ambientIteratorProtocol_mono ord protocol,
      by
        obtain ⟨final, flag, declared, covered, st, provenance⟩ := stack
        exact ⟨final, flag, ext _ _ declared, covered, (st.races kept).mono ord, provenance⟩⟩
  | finish host _ =>
    intro f hf
    rw [owner host rfl] at hf
    exact h f hf
  | _ => trivial

def CommandAuthorityR (m : RState) : RCmd → Prop
  | .loop fiber _ | .deliver fiber _ | .finish fiber _ => Guard.ActiveAt m fiber
  | .afterInterrupt fiber _ _ | .closeParAwait fiber _ _ | .raceCancel _ fiber _ _ _ =>
      Guard.ActiveAt m fiber
  | .registrationDone raceId _ =>
      ∃ race fiber, m.race? raceId = some race ∧ m.fiber? race.host = some fiber ∧
        fiber.running = true ∧ fiber.parked = .notParked ∧
        raceRegistrationR fiber.frame.current = some raceId
  | .launch raceId | .enrollRace raceId _ =>
      ∃ race, m.race? raceId = some race ∧ Guard.ActiveAt m race.host
  | .exitDone fiber => ∃ found, m.fiber? fiber = some found ∧ found.exit.isSome = true
  | _ => True

/-- A queued command's owner exists: it is active, or it hosts the race the command completes. -/
theorem commandOwner_found {m : RState} {c : RCmd} (authority : CommandAuthorityR m c) {o : FiberId}
    (h : Guard.commandOwner m c = some o) : ∃ f, m.fiber? o = some f := by
  cases c with
  | registrationDone raceId _ =>
    obtain ⟨race, fiber, found, host, _⟩ := authority
    rw [show Guard.commandOwner m (.registrationDone raceId _) = (m.race? raceId).map Race.host
      from rfl, found, Option.map_some] at h
    cases h
    exact ⟨fiber, host⟩
  | _ => cases h <;> (obtain ⟨f, hf, _, _⟩ := authority; exact ⟨f, hf⟩)

/-- **Authority is monotone in the fiber table**: it reads fibers only through lookups that find
them (`ActiveAt`, an exited fiber, a race host) and races by id, so a machine that finds every old
fiber unchanged and keeps the races keeps it. -/
theorem commandAuthority_mono {m m' : RState}
    (look : ∀ id f, m.fiber? id = some f → m'.fiber? id = some f)
    (races : ∀ r, m'.race? r = m.race? r) {c : RCmd} (h : CommandAuthorityR m c) :
    CommandAuthorityR m' c := by
  have active : ∀ {id}, Guard.ActiveAt m id → Guard.ActiveAt m' id := by
    intro id a
    obtain ⟨f, hf, running, parked⟩ := a
    exact ⟨f, look _ _ hf, running, parked⟩
  cases c with
  | loop _ _ | deliver _ _ | finish _ _ | afterInterrupt _ _ _ | closeParAwait _ _ _
  | raceCancel _ _ _ _ _ => exact active h
  | registrationDone _ _ =>
    obtain ⟨race, fiber, found, host, running, parked, marker⟩ := h
    exact ⟨race, fiber, (races _).trans found, look _ _ host, running, parked, marker⟩
  | launch _ | enrollRace _ _ =>
    obtain ⟨race, found, a⟩ := h
    exact ⟨race, (races _).trans found, active a⟩
  | exitDone _ =>
    obtain ⟨found, hf, exited⟩ := h
    exact ⟨found, look _ _ hf, exited⟩
  | _ => trivial

structure ReservedKeysR (m : RState) (keys : List Guard.GuardKey) : Prop where
  below : ∀ key ∈ keys, key.2 < m.nextToken
  disjoint : ∀ fiber token request, requestOfR m fiber token = some request →
    (fiber, token) ∉ keys

def QueueFresh (m : RState) (commands : List RCmd) : Prop :=
  ∀ key ∈ commands.flatMap Guard.commandKeys, key.2 < m.nextToken

/-- The result obligation on resumeAwait is about the actual delivered program. -/
theorem observerCommand_resume_typed (root : ProgramSource) (w : World) (m : RState)
    (source waiter : FiberId) (token : Nat) (mode : Supervision.ObserverMode) (exit : ExitV)
    (typed : ObserverCommandOk root w m source exit (.resumeAwait waiter token mode)) :
    ResumeCode root w waiter token
      ((interpR root.program).exitValue exit mode) := by
  obtain ⟨sourceTy, _, declared, exitTyped⟩ := typed
  refine resumeCode_of_typed (fun tokenTy htoken => ?_) (by cases mode <;> exact .pure _)
  rw [declared] at htoken
  cases htoken
  exact observer_exitValue_typed root w sourceTy exit mode exitTyped

/-- A loaded machine has no active external request, regardless of the loaded code. -/
theorem requestOfR_load_none (program : NativeEff) (fuel compileFuel : Nat)
    (fiber : FiberId) (token : Nat) :
    requestOfR (loadR program fuel compileFuel) fiber token = none := by
  unfold requestOfR
  cases hf : (loadR program fuel compileFuel).fiber? fiber with
  | none => rfl
  | some found =>
    have member := List.mem_of_find?_eq_some hf
    change found ∈ [_] at member
    rw [List.mem_singleton] at member
    subst found
    rfl

theorem schedulerState_load (program : NativeEff) (fuel compileFuel : Nat) :
    SchedulerState (loadR program fuel compileFuel) := by
  constructor
  · exact List.nodup_cons.mpr ⟨List.not_mem_nil, List.nodup_nil⟩
  · intro fiber hf
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    exact Nat.zero_lt_succ 0
  · exact List.nodup_nil
  · intro race hr; cases hr
  · intro race hr; cases hr
  · intro key hk; cases hk
  · intro fiber token request hr
    rw [requestOfR_load_none] at hr
    cases hr
  · intro fiber token request hr
    rw [requestOfR_load_none] at hr
    cases hr
  · intro fiber hf
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    rfl
  · intro fiber hf hp
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    exact False.elim (hp rfl)
  · intro fiber hf token hp
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases hp
  · intro fiber hf hx
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases hx
  · intro fiber hf hx
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases hx
  · intro fiber hf hd
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases hd
  · intro raceId race hr; cases hr
  · intro raceId race hr; cases hr
  · intro fiber hf p hp
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases hp
  · intro fiber hf o ho
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases ho

theorem observerState_load (root : ProgramSource) (w : World) (fuel compileFuel : Nat) :
    ObserverState root w (loadR root.program fuel compileFuel) := by
  constructor
  · intro fiber hf pending hp
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases hp
  · intro fiber hf observer ho
    change fiber ∈ [_] at hf
    rw [List.mem_singleton] at hf
    subst fiber
    cases ho

end Effect4.Program.Typed

import Effect4.Laws.Program.Typed.RecordOperations
import Effect4.Program.Checker
import Effect4.Laws.Program.Sched
import Effect4.Laws.Program.Signature
import Effect4.Laws.Program.ReferenceTyping
import Effect4.Program.Definitions
import Effect4.Laws.Program.Definitions
import Effect4.Laws.Program.Typed.Scope
import Effect4.Laws.Program.Folds.Region

/-!
# Laws.Program.Typed.Admission — source and control admission for typed programs

D13 source admission (checking paths and environments against the checker) before protocol
contracts, using the value membership judgments from `Typed/Membership.lean`. The shared exit
judgment also excludes `badName` and `notImplemented`; clean failures require that explicit
exclusion premise. `missingService` remains admitted in part one. Control admission (FR-09) is an
arm of the one program judgment `TypedProg` in `Typed/Residual.lean` (ruling 2026-09-23).
-/

set_option autoImplicit false
namespace Effect4.Program.Typed

open Effect4 Effect4.Machine Effect4.Program Effect4.Program.Sched Effect4.Program.Denote
open Effect4.Laws.Effects

/-- Part one excludes only `badName` and `notImplemented`. The type argument is retained
for the shared exit interface; `missingService` remains admitted pending part two. -/
def NoShapeDefect (_ty : EffTy) : ExitV → Prop
  | .success _ => True
  | .failure cause => ∀ reason ∈ cause.reasons, match reason with
    | .die defect _ => defect ≠ .badName ∧ defect ≠ .notImplemented
    | _ => True

/-- Base membership and the part-one defect exclusion at every typed exit position. -/
def ExitOk (w : World) (ty : EffTy) (ex : ExitV) : Prop :=
  FitsExit w ty ex ∧ NoShapeDefect ty ex

/-- Part one's exclusion on a failure is `ShapeFree` on its cause, the predicate membership at an
exit type reads (decisions row 152). -/
theorem noShapeDefect_failure_iff (ty : EffTy) (c : CauseV) :
    NoShapeDefect ty (.failure c) ↔ ShapeFree c := Iff.rfl

/-- Part one: an interrupt reason carries neither excluded defect. -/
theorem noShapeDefect_of_interrupts (ty : EffTy) (cause : CauseV)
    (interrupts : ∀ reason ∈ cause.reasons, reason.tag = .interrupt) :
    NoShapeDefect ty (.failure cause) := by
  intro reason member
  have tag := interrupts reason member
  cases reason with
  | fail _ _ => trivial
  | die _ _ => cases tag
  | interrupt _ _ => trivial

/-- Removing Fail reasons does not introduce a shape defect. -/
theorem noShapeDefect_stripFail (ty : EffTy) (cause : CauseV)
    (shape : NoShapeDefect ty (.failure cause)) :
    NoShapeDefect ty (.failure cause.stripFail) := by
  intro reason member
  exact shape reason ((Cause.mem_stripFail reason cause).mp member).1

/-- Combine contains only reasons from its two inputs. -/
theorem noShapeDefect_combine (ty : EffTy) (left right : CauseV)
    (leftShape : NoShapeDefect ty (.failure left))
    (rightShape : NoShapeDefect ty (.failure right)) :
    NoShapeDefect ty (.failure (Cause.combine left right)) := by
  intro reason member
  rcases (Cause.mem_combine reason left right).mp member with fromLeft | fromRight
  · exact leftShape reason fromLeft
  · exact rightShape reason fromRight

/-- Sanitization strips Fail reasons and combines the remaining original reasons with
recorded interruption reasons; exclusion is required of both inputs. -/
theorem noShapeDefect_sanitize (ty : EffTy) (cause interrupted : CauseV)
    (shape : NoShapeDefect ty (.failure cause))
    (interruptShape : NoShapeDefect ty (.failure interrupted)) :
    NoShapeDefect ty (.failure (Cause.sanitize cause interrupted)) :=
  noShapeDefect_combine ty cause.stripFail interrupted
    (noShapeDefect_stripFail ty cause shape) interruptShape

/-- An evaluation environment typed pointwise at the corresponding static types. -/
def EnvTyped (w : World) (env : List Ty) (vals : List Val) : Prop :=
  env.length = vals.length ∧
  ∀ (i : Nat) (ty : Ty) (v : Val), env[i]? = some ty → vals[i]? = some v → Fits w v ty

/-- **Term soundness for membership (TY-07, proved)**, in the environment judgment the typed
state reads (`PointTyped`): under a signature whose atoms are the native table's (every
`nativeSignature`, every source signature), a term that types in a typed environment and
evaluates there evaluates to a value of the term's type, where the signature's declaration table
is within the world's (`TyDecls.Within`: empty, or the world's own). The proof is
`evalTerm_fitsAll` (`Typed/RecordOperations.lean`) through `fitsAll_of_pointwise`. -/
theorem evalTerm_fits {sig : Signature NativeOp} (hatom : sig.atomOf = nativeAtomTy)
    (hconst : sig.constAtom = nativeConstAtom) {w : World}
    (htypes : TyDecls.Within sig.types w.types) {env : List Ty}
    {vals : List Val} {t : Term} {ty : Ty} {v : Val} (henv : EnvTyped w env vals)
    (hty : termTy sig env t = some ty) (hev : evalTerm vals t = some v) : Fits w v ty :=
  evalTerm_fitsAll sig hatom hconst w htypes t vals env ty v (fitsAll_of_pointwise henv.1 henv.2)
    hty hev

/-- `evalTerm_fits` at a native signature over any row table. -/
theorem evalTerm_fits_native (table : RowTable) {w : World} {env : List Ty} {vals : List Val}
    {t : Term} {ty : Ty} {v : Val} (henv : EnvTyped w env vals)
    (hty : termTy (nativeSignature table) env t = some ty) (hev : evalTerm vals t = some v) :
    Fits w v ty :=
  evalTerm_fits rfl rfl (TyDecls.within_nil _) henv hty hev

/-- The program the typed state is about, with its signature (decisions row 111: the host-row
table, the service declarations and the named types, Σ_app) and the evidence that the signature is lawful
(row 114: M5 and M6 quantify over lawful sources, not over an authoring guard's callers). A
bare program coerces to a source with the empty signature, which is lawful
(`SigApp.lawful_empty`). -/
structure ProgramSource where
  program : NativeEff
  table : RowTable := []
  services : List (ServiceKey × Ty) := []
  types : TyDecls := []
  lawful : LawfulSig ⟨table, services, types⟩ := by exact SigApp.lawful_empty

instance : Coe NativeEff ProgramSource := ⟨fun program => { program }⟩

/-- The source's part of the signature. -/
def ProgramSource.sig (src : ProgramSource) : SigApp := ⟨src.table, src.services, src.types⟩

/-- **A world tied to its source**: the world's static tables are the source's, the service table
(decisions row 112) and the declaration table (the audit's D3), so `ServicesFit` reads the
source's carriers and `Fits` the source's named types. The world order fixes both tables
(`le_serviceTy`, `le_types`), so the tie holds along every run once it holds at the load
(`Tied.mono`). -/
structure Tied (src : ProgramSource) (w : World) : Prop where
  services : w.serviceTy = src.sig.serviceTy
  types : w.types = src.types

/-- A world tied to its source reads a declaration table the source's is within. -/
theorem Tied.within {src : ProgramSource} {w : World} (tie : Tied src w) :
    TyDecls.Within src.types w.types :=
  TyDecls.within_of_eq tie.types.symm

/-- The world order keeps the tie. -/
theorem Tied.mono {src : ProgramSource} {w w' : World} (ord : w.leHost w') (tie : Tied src w) :
    Tied src w' :=
  ⟨(le_serviceTy ord.1).trans tie.services, (le_types ord.1).trans tie.types⟩

/-- The checker's signature for the source's program: the signature over its tables
(`SigApp.signature`), extended by the program's own definition block (`Signature.withDefs`,
decisions row 328), so an invocation reads its definition's declared row. Every other field is
the tables' signature's, by definition; for a program with no block and no service declarations
it types every operation as `nativeSignature src.table` does. Admission certifies the program at
the tables' signature (`typeOfProgram src.sig.signature`), whose module check extends it by the
same block. -/
def ProgramSource.signature (src : ProgramSource) : Signature NativeOp :=
  src.sig.signature.withDefs src.program.defsOf

/-- The source's signature of a program with no definition block is its tables' signature
(`Signature.withDefs_nil`): an application's signature keeps every invocation outside its domain. -/
theorem ProgramSource.signature_of_defsOf_nil {src : ProgramSource} (h : src.program.defsOf = []) :
    src.signature = src.sig.signature := by
  show src.sig.signature.withDefs src.program.defsOf = _
  rw [h]
  exact Signature.withDefs_nil _ (SigApp.signature_callsOutside _)

/-- **The signature at a path** (decisions row 340, slice CX1): the source's signature extended by
the parameters in scope there (`scopeParams`, `Typed/Scope.lean`), as the module check checks a
body (`Checker.checkBodies`). Outside every body it is the source's signature
(`Signature.withParams` at `[]`). -/
def ProgramSource.scopeSig (src : ProgramSource) (path : List Nat) : Signature NativeOp :=
  src.signature.withParams (scopeParams src.program path)

/-- The source's signature keeps every run of a parameter outside its domain: only a body's
signature admits one. -/
theorem ProgramSource.signature_paramsOutside (src : ProgramSource) :
    ∀ op i, src.signature.paramOf op = some i → src.signature.dom op = false := by
  intro op i h
  cases op with
  | param j =>
    show (src.sig.signature.withDefs src.program.defsOf).dom (.param j) = false
    rw [Signature.withDefs_dom_of_none _ _ rfl]
    rfl
  | _ => cases h

/-- **The signature at a path extends the source's** (`Signature.extends_withParams`): the same
atoms, terms, services and declarations, and every row of the source's domain. The arms read a
term's type and a host row through it. -/
theorem ProgramSource.scopeSig_extends (src : ProgramSource) (path : List Nat) :
    SigExtends src.signature (src.scopeSig path) :=
  Signature.extends_withParams _ src.signature_paramsOutside _

/-- An operation that runs no parameter reads the source's domain bit and row at every scope
(`Signature.withParams_of_none`). A step of the row arms (`external_arm`, `builtinPerform_inv`). -/
theorem ProgramSource.scopeSig_of_none (src : ProgramSource) (path : List Nat) {op : NativeOp}
    (h : src.signature.paramOf op = none) :
    (src.scopeSig path).dom op = src.signature.dom op ∧
      (src.scopeSig path).rowOf op = src.signature.rowOf op :=
  Signature.withParams_of_none _ _ h

/-- Every scope reads the source's service table (`Signature.withParams_serviceTy`). A step of
`service_arm` and `provideService_arm`. -/
theorem ProgramSource.scopeSig_serviceTy (src : ProgramSource) (path : List Nat) :
    (src.scopeSig path).serviceTy = src.signature.serviceTy :=
  Signature.withParams_serviceTy _ _

/-- Every scope reads the source's declarations (`Signature.withParams_defOf`). A step of
`invoke_arm`. -/
theorem ProgramSource.scopeSig_defOf (src : ProgramSource) (path : List Nat) :
    (src.scopeSig path).defOf = src.signature.defOf :=
  Signature.withParams_defOf _ _

/-- **A child of a program node is checked at its node's signature** (`scopeParams_child`). A
step of `pointTyped_child` and of every arm that checks a child. -/
theorem ProgramSource.scopeSig_child (src : ProgramSource) {path : List Nat} {e : NativeEff}
    (hat : Node.at_ (.eff src.program) path = some (.eff e)) (i : Nat) :
    src.scopeSig (path ++ [i]) = src.scopeSig path := by
  unfold ProgramSource.scopeSig
  rw [scopeParams_child hat i]

/-- **The stack of the passed programs, typed at a scope** (decisions row 340, slice CX1;
`docs/research/2026-10-10-cx-lexical-scope.md` §4.3). For each parameter `j` in scope, the top
frame holds a site whose path addresses a program the checker types at the site's own scope,
over the caller's environment extended by the parameter's request, at a type the parameter
admits; the site's values fit the caller's environment; and the rest of the stack is typed at
the site's scope. With no parameter in scope it constrains nothing (`stackTyped_nil`). The
recursion is on the stack, and it mentions no program judgment. -/
def StackCertificates (root : ProgramSource) (world : World)
    (policy : ParamDecl → EffTy → Prop) (stack : List (List ArgSite)) : List ParamDecl → Prop :=
  stack.foldr (fun (sites : List ArgSite) (rest : List ParamDecl → Prop) (declarations : List ParamDecl) =>
    ∀ (index : Nat) (parameter : ParamDecl), declarations[index]? = some parameter →
      ∃ (site : ArgSite) (program : NativeEff) (environment : List Ty) (type : EffTy), sites[index]? = some site ∧
        Node.at_ (.eff root.program) site.path = some (.eff program) ∧
        Checker.check (root.scopeSig site.path) (environment ++ [parameter.request.normalize])
          site.path (Eff.expandIn root.program program) = .ok type ∧
        policy parameter type ∧ EnvTyped world environment site.env ∧
        rest (scopeParams root.program site.path)) (fun declarations => declarations = [])

/-- The existing unit stack judgment instantiates the shared certificate fold.
Its public type and old meaning stay unchanged; the retained candidate proves their agreement. -/
def StackTyped (src : ProgramSource) (w : World) : List ParamDecl → List (List ArgSite) → Prop :=
  fun declarations stack => StackCertificates src w
    (fun parameter type => parameter.admits type = true) stack declarations

/-- The ambient M5 stack input retains each actual passed program's checked requirement.
Consumer: argSites_typed birth and param_arm execution in Typed/Denotation.lean. -/
def AmbientStackTyped (src : ProgramSource) (w : World) (available : Env.Requirement)
    (declarations : List ParamDecl) (stack : List (List ArgSite)) : Prop :=
  StackCertificates src w (fun parameter type =>
    parameter.admits type = true ∧ Row.Subset type.requires available) stack declarations

/-- **With no parameter in scope every stack is typed**: outside every body, and in the body of a
definition that takes no program. -/
theorem stackTyped_nil (src : ProgramSource) (w : World) :
    ∀ stack : List (List ArgSite), StackTyped src w [] stack
  | [] => rfl
  | _ :: _ => fun j q h => by
    rw [List.getElem?_nil] at h
    cases h

/-- D13 source admission at an addressed program node, under the signature of its scope: its row
table (`E4-SCHED-CE-014`: the empty table refused bodies that perform a host row) and its service
declarations (rows 111–114; `src.signature` is `nativeSignature src.table` for a source with no
declarations, `SigApp.signature_nil`). The node is the program's as written, the one the run
denotes; the checker reads it through the rounds of the program's expansion (`Eff.expandIn`,
decisions row 153 (b)): the checker refuses a layer reference (`Program/Checker.lean:259`) and
certifies a program with references as its expansion (`typeOfProgram`), while the run hops from a
reference to its target (`denoteLayer_ref_redirect`). For a reference-free node the expansion is
the node itself (`Eff.expandIn_eq_self`).

The point's data is its environment and its completed view, both typed at the world (decisions
row 175, `E4-TYPED-CE-021`): the values in scope fit the checker's environment (`EnvTyped`), and
each completed exit the point carries fits its fiber's declared type, the `construction` post's
clause (`Typed/Residual.lean`), which is where a point's view is built. The denotation answers a
completed exit as an `await`'s result (`Point.awaitExit`), so an untyped view denotes an untyped
program at a checked node.

The node is checked at the signature of its scope (`ProgramSource.scopeSig`), and the point's
stack of passed programs is typed there (`StackTyped`, decisions row 340, slice CX1): a point
inside a definition's body reads the body's parameters, and their sites are typed closures. -/
def PointTyped (src : ProgramSource) (w : World) (point : Point) (ty : EffTy) : Prop :=
  ∃ (e : NativeEff) (env : List Ty),
    Node.at_ (.eff src.program) point.path = some (.eff e) ∧
    Checker.check (src.scopeSig point.path) env point.path (Eff.expandIn src.program e) = .ok ty ∧
    EnvTyped w env point.env ∧
    (∀ q ∈ point.completed, ∃ fty, w.Γ q.1 = some fty ∧ ExitOk w fty q.2) ∧
    StackTyped src w (scopeParams src.program point.path) point.params

/-- The ambient M5 input refines the unchanged point relation through the same stack fold.
It records no second point grammar. Consumer: actual source children and parameter-call entries. -/
def AmbientPointTyped (src : ProgramSource) (w : World) (available : Env.Requirement)
    (point : Point) (type : EffTy) : Prop :=
  PointTyped src w point type ∧
    AmbientStackTyped src w available (scopeParams src.program point.path) point.params

/-- **The block's bodies are typed** (decisions row 328): each declaration of the program's block
names a body at its path (`defBodyPath`), which the checker types at the source's signature
extended by the definition's parameters (`Signature.withParams`, decisions row 340), in the
environment of the declared request, at a type the declaration admits; and the declaration is
formed. A program with no block has no declaration, so it holds outright. The load discharges it
from the checker's verdict (`bodiesTyped_of_typeOf`, `Typed/Denotation.lean`), as it discharges
the references' formation: it is a premise of M5, never a field of `ProgramSource`. The
invocation's arm reads it (`call_arm`). -/
def BodiesTyped (src : ProgramSource) : Prop :=
  ∀ (k : Nat) (d : DefDecl), src.program.defsOf[k]? = some d →
    ∃ (path : List Nat) (body : NativeEff) (tb : EffTy),
      defBodyPath src.program k = some path ∧
      Node.at_ (.eff src.program) path = some (.eff body) ∧
      Checker.check (src.signature.withParams d.params) [d.request.normalize] path
        (Eff.expandIn src.program body) = .ok tb ∧
      d.formed = true ∧ d.admits tb = true

/-- **The module's layers are typed** (decisions row 341, step 2): at a root block, each whole
module layer, read through the expansion's rounds, is checked at the source's signature. The
load discharges it from the checker's verdict (`moduleLayersTyped_of_typeOf`,
`Typed/Denotation.lean`), as it discharges the bodies. A reference's hop into the module reads it
(`layerPointTyped_redirect_module`, `Typed/LayerArm.lean`): the hop leaves the reference's scope
for the module's, which has no parameters. -/
def ModuleLayersTyped (src : ProgramSource) : Prop :=
  ∀ (target : List Nat) (l : LayerTerm NativeOp), src.program.inModule target = true →
    Path.spineHead target.tail = true → (Node.eff src.program).layerAt target = some l →
    ∃ lt, Checker.checkLayer src.signature target (LayerTerm.expandIn src.program l) = .ok lt

/-- **The source's formation, for M5** (decisions rows 170, 328 and 341): its layer references
are well formed, its definition block's bodies are typed, and so are its module layers. Each is a
constant fact of the source, which the load discharges from the checker's verdict and every step
keeps (`MachineTyped.sourceWF`). M5's fundamental property reads them (`DenotesTyped`): the first
at a reference's target, the second at an invocation, the third at a reference into the module.
None is a field of `ProgramSource`. -/
structure SourceWF (src : ProgramSource) : Prop where
  refs : src.program.layerRefsWF = true
  bodies : BodiesTyped src
  layers : ModuleLayersTyped src

/-- A program with no definition block has its bodies typed: it declares none. -/
theorem BodiesTyped.of_nil {src : ProgramSource} (h : src.program.defsOf = []) : BodiesTyped src := by
  intro k d hd
  rw [h, List.getElem?_nil] at hd
  cases hd

/-- A program with no definition block has its module layers typed: it has no module
(decisions row 341). The third part of `SourceWF` for every program outside a block. -/
theorem ModuleLayersTyped.of_noBlock {src : ProgramSource} (h : src.program.block? = none) :
    ModuleLayersTyped src := by
  intro target l hin
  cases hprog : src.program with
  | defs decls bodies main layers =>
    rw [hprog] at h
    cases h
  | _ =>
    rw [hprog] at hin
    simp only [Eff.inModule, Bool.false_eq_true] at hin

/-- A capture's release is admitted: its path addresses an `acquireRelease` the checker types
under an environment its values fit, extended by the acquired value, and its context's
services are typed. The checker reads the node through the expansion's rounds, as `PointTyped`
does (decisions row 153 (b)). Here since decisions row 151 (a″): the scope registration's pre
reads it (`FinalizerAdmitted`, `Typed/Admission.lean`), as the generated bundle's `CaptureOk` does
(`preds`, `Typed/Assembly.lean`). The node is checked at the signature of its scope, and the
capture's stack is typed there, as `PointTyped`'s (slice CX1): a release in a definition's body
runs the body's parameters. The captured context holds the node's requirement row and types the
stack's passed programs (decisions row 349), so the release runs covered in it. -/
def CaptureTyped (root : ProgramSource) (w : World) (c : Capture) : Prop :=
  ∃ (acquire release : NativeEff) (env : List Ty) (t a : EffTy),
    Node.at_ (.eff root.program) c.path = some (.eff (.acquireRelease acquire release)) ∧
    Checker.check (root.scopeSig c.path) env c.path
      (Eff.expandIn root.program (.acquireRelease acquire release)) = .ok t ∧
    Checker.check (root.scopeSig c.path) env (c.path ++ [0]) (Eff.expandIn root.program acquire) =
      .ok a ∧
    EnvTyped w (env ++ [a.answer]) c.env ∧ ServicesFit w c.ctx.services ∧
    AmbientStackTyped root w c.ctx.services.keysRow (scopeParams root.program c.path) c.params ∧
    Row.Subset t.requires c.ctx.services.keysRow

/-- A capture retains the issued callback input at its actual release child.
Concept: residual-program-typing, R4 and R9; helper of the closed M5 source claim.
Consumer: foreign scope registration and the ambient acquireIn body producer.
The unit CaptureTyped judgment remains unchanged. -/
def AmbientCapturePolicy (root : ProgramSource) (w : World) (capture : Capture) : Prop :=
  ∀ later, w.leHost later → ∀ completed,
    (∀ entry ∈ completed, ∃ declared, later.Γ entry.1 = some declared ∧ ExitOk later declared entry.2) →
    ∀ exitValue, Fits later exitValue (.exitOf .unknown .unknown) → ∃ releaseType,
      AmbientPointTyped root later capture.ctx.services.keysRow
        ((Point.ofCapture capture completed).childWith 1 exitValue) releaseType ∧
      releaseType.error.normalize = .never ∧
      Row.Subset releaseType.requires capture.ctx.services.keysRow

/-- A layer point is admitted (decisions row 186 (a)): its path addresses a layer the checker
types, read through the expansion's rounds as `PointTyped` reads a program node and as the memo
rows read the memo layer (`storePre`'s `memoGet` arm, `Typed/Residual.lean`); its lexical
environment is the empty one a layer is checked and built in (`Point.layerBuild`, decisions rows
104, 105), and its completed view is typed as `PointTyped`'s is. `PointTyped` admits only a
program node, so a layer build's point needs its own admission. Its scope and stack are read
as `PointTyped`'s (slice CX1). -/
def LayerPointTyped (src : ProgramSource) (w : World) (point : Point) (lt : LayerTy) : Prop :=
  ∃ l : LayerTerm NativeOp,
    Node.at_ (.eff src.program) point.path = some (.layer l) ∧
    Checker.checkLayer (src.scopeSig point.path) point.path (LayerTerm.expandIn src.program l) =
      .ok lt ∧
    point.env = [] ∧
    (∀ q ∈ point.completed, ∃ fty, w.Γ q.1 = some fty ∧ ExitOk w fty q.2) ∧
    StackTyped src w (scopeParams src.program point.path) point.params

/-- **A finalizer the scope registration admits** (decisions row 151 (a″)): what makes its program
typed at rc.112's finalizer type `⟨unknown, never⟩` (`internal/effect.ts:3849`) at every later
world, read by name, since the pre cannot mention the program judgment it is a premise of. A
foreign finalizer's capture is typed (`CaptureTyped`: what the checker gives an
`acquireRelease`, whose release is declared `Effect<unknown, never, R2>`, `:3973`); a `release`
does not fail (a failing one answers a typed failure, which no `never` error column admits); a
finalizer that closes or detaches a scope names a present one. Every other name is typed by its
program alone. The bridge to the typing is `finalizerTyped_of_admitted` (`Typed/Assembly.lean`).
Read by the scope registration's pre (`storePre`, `Typed/Residual.lean`) and by a finalizer body's
admission (`BodyTyped.fin`). -/
def FinalizerAdmitted (root : ProgramSource) (w : World) : FinName → Prop
  | .foreign c => CaptureTyped root w c
  | .release _ fails => fails = false
  | .closeChildScope scope | .closeChildOnFailure scope => ScopeLive w scope
  | .detachFromParent parent _ => ScopeLive w parent
  -- the target's interrupt row demands it (finding F-PRE); `link` registers a fiber the machine holds
  | .interruptFiber fiber _ => (w.Γ fiber).isSome = true
  | .awaitNewChildren _ | .parkThen _ | .memoEntry _ _ => True
  -- `memoMapBuild`'s `onExit` (`Layer.ts:414-417`), never a scope's finalizer: its exit is the
  -- construction's, which `memoComplete`'s pre types at the layer's columns (decisions row 187)
  | .memoDone _ _ => False

/-- The output row of a leaf's construction: its key, or nothing for a discarded answer. -/
def constructOut : Option ServiceKey → Env.Requirement
  | some key => Env.Requirement.single key
  | none => Env.Requirement.empty

/-- The types a layer's build runs at: the context holding the layer's output row, at the
layer's checked error type and its requirement row (decisions rows 176 (b) and 349). -/
def buildTy (lt : LayerTy) : EffTy := ⟨.contextOf lt.out, lt.error, lt.requires⟩

/-- The existing Region fold records source admission before residual program typing.
A build answers the context of its layer's output row, and runs at the layer's requirement row.
Consumer: the provider mask's BodyTyped certificate and bodyTyped_typed. -/
def regionTypingAlgebra (src : ProgramSource) (w : World) :
    RegionAlgebra (fun _ => EffTy → Prop) where
  region_program := fun point ty => PointTyped src w point ty
  region_build := fun point memo scope ty => ∃ lt, ty = buildTy lt ∧
      LayerPointTyped src w point lt ∧ ScopeLive w scope ∧ MemoLive w memo
  region_buildAdding := fun point memo scope ty => ∃ lt, ty = buildTy lt ∧
      LayerPointTyped src w point lt ∧ ScopeLive w scope ∧ MemoLive w memo
  region_construct := fun point key ty => ∃ bodyTy,
      PointTyped src w point bodyTy ∧
      ty = ⟨.contextOf (constructOut key), bodyTy.error, bodyTy.requires⟩ ∧
      ∀ service, key = some service → ∃ carrier, w.serviceTy service = some carrier ∧
        Ty.subN bodyTy.answer carrier = true ∧ flatCarrier carrier = true


/-- Source admission for the existing Region data, through its generated algebra.
Consumer: BodyTyped.region and BodyTyped.contextEntry. -/
def RegionTyped (src : ProgramSource) (w : World) (region : Region) (ty : EffTy) : Prop :=
  cata_region (regionTypingAlgebra src w) region ty

/-- The generated Region fold reads its existing source point.
Consumer: ambient provider argument certificates at the actual installed-context cut. -/
def regionPointAlgebra : RegionAlgebra (fun _ => Point) where
  region_program := id
  region_build := fun point _ _ => point
  region_buildAdding := fun point _ _ => point
  region_construct := fun point _ => point

abbrev regionPoint (region : Region) : Point := cata_region regionPointAlgebra region

/-- A Region retains the existing argument certificate policy at its actual source point.
Consumer: BodyCoverage for protected context entry, then the closed M5 body bridge. -/
def RegionStackTyped (source : ProgramSource) (world : World) (available : Env.Requirement)
    (region : Region) : Prop :=
  AmbientStackTyped source world available (scopeParams source.program (regionPoint region).path)
    (regionPoint region).params

/-- A context update retains value membership at every permitted future world.
This judgment supplies no runtime capability coverage.
Consumer: the protected context-entry body's admission. -/
def ContextUpdateTyped (w : World) (update : Env.ContextUpdate) : Prop :=
  ∀ later, w.leHost later → ∀ previous : Env.Ctx, ServicesFit later previous →
    ServicesFit later (update.apply previous)

/-- **Admitted bodies**, one arm per `Body` constructor, each what its program needs (`bodyR`,
`Laws/Program/EvaluateR.lean`; the bridge is `bodyTyped_typed`, `Typed/Body.lean`): the pre of
`mask` and `fork` (`fiberPre`, `Typed/Residual.lean`).

- A body at a point is the point's admission (`PointTyped`).
- A finalizer body (`Body.fin`) is admitted at no type: it has no producer in the tree (the close
  walk passes `denoteFin` programs directly), and a foreign release needs a covering row its name
  does not carry (`E4-TYPED-CE-039`; the cut its register line proposed, decisions row 349).
- `acquireRelease`'s masked half (`acquireInR`) names its node and a context whose services fit: the
  release's registration reads both (`CaptureTyped`), and the acquire runs at the node's child 0.
- A capture's release restores a context whose services fit (`setContext`'s pre).
- A layer's build runs into a present scope and a present memo map (`layerBuild_typed` reads both,
  `Typed/LayerArm.lean`; the memo map is installed into the built context, finding F-WF) at the
  build's types: the built context at the layer's checked error (`buildTy`). -/
inductive BodyTyped (src : ProgramSource) (w : World) : Body → EffTy → Prop
  | at_ (p : Point) (ty : EffTy) (h : PointTyped src w p ty) :
      BodyTyped src w (.at_ p) ty
  | raceCleanup (race : Nat) :
      BodyTyped src w (.raceCleanup race) (EffTy.pure .unit)
  | acquireIn (p : Point) (ctx : Ctx) (ty : EffTy) (h : PointTyped src w p ty)
      (node : ∃ acquire release : NativeEff,
        Node.at_ (.eff src.program) p.path = some (.eff (.acquireRelease acquire release)))
      (services : ServicesFit w ctx.services) :
      BodyTyped src w (.acquireIn p ctx) ty
  | release (p : Point) (prev : Ctx) (ty : EffTy) (h : PointTyped src w p ty)
      (services : ServicesFit w prev.services) :
      BodyTyped src w (.release p prev) ty
  | layerBuild (p : Point) (m : MemoMapId) (scope : Nat) (lt : LayerTy)
      (h : LayerPointTyped src w p lt) (live : ScopeLive w scope) (memo : MemoLive w m) :
      BodyTyped src w (.layerBuild p m scope) (buildTy lt)
  | region (body : Region) (bodyTy ty : EffTy) (typed : RegionTyped src w body bodyTy)
      (answer : Ty.subN bodyTy.answer ty.answer = true)
      (error : Ty.subN bodyTy.error ty.error = true) :
      BodyTyped src w (.region body) ty
  | contextEntry (update : Env.ContextUpdate) (body : Region) (flag : Bool)
      (bodyTy ty : EffTy) (typed : RegionTyped src w body bodyTy)
      (answer : Ty.subN bodyTy.answer ty.answer = true)
      (error : Ty.subN bodyTy.error ty.error = true) (updateTyped : ContextUpdateTyped w update) :
      BodyTyped src w (.contextEntry update body flag) ty

/-- Membership at the answer column gives the successful exit; its defect exclusion is vacuous. -/
theorem strongExit_success (w : World) (ty : EffTy) (v : Val) (h : Fits w v ty.answer) :
    ExitOk w ty (.success v) := ⟨h, trivial⟩

/-- A clean failure has base membership at every effect type because the error column
constrains only `Fail` reasons. The strengthened exit judgment separately requires the
explicit defect-exclusion premise: `cleanExit` alone admits `badName` and `notImplemented`. -/
theorem strongExit_of_clean (w : World) (ty : EffTy) (c : CauseV)
    (h : cleanExit (.failure c) = true) (shape : NoShapeDefect ty (.failure c)) :
    ExitOk w ty (.failure c) := ⟨fitsExit_of_clean w ty c h shape, shape⟩

/-- At a `never` error column a fitting failure is clean: no value has type `never`. -/
theorem cleanExit_of_never (w : World) (ty : EffTy) (c : CauseV) (never : ty.error = .never)
    (h : ExitOk w ty (.failure c)) : cleanExit (.failure c) = true := cleanExit_of_never_fits w ty c never h.1

/-! ## `π` for services (C5) -/

/-- A world read at a signature's service table. -/
def restrictWorld (app : SigApp) (w : World) : World := { w with serviceTy := app.serviceTy }

/-- A context's services fit at the restriction exactly when they fit at the world, when the
two tables agree on the context's keys. -/
theorem servicesFit_restrict (app : SigApp) (w : World) (services : Env.Ctx)
    (hagree : ∀ key sv, services.getV key = some sv → w.serviceTy key = app.serviceTy key) :
    ServicesFit (restrictWorld app w) services ↔ ServicesFit w services := by
  constructor
  · intro h
    refine ⟨fun key sv sty hget hty => ?_, h.2⟩
    have hty' : app.serviceTy key = some sty := by
      rw [← hagree key sv hget]
      exact hty
    exact h.1 key sv sty hget hty'
  · intro h
    refine ⟨fun key sv sty hget hty => ?_, h.2⟩
    change app.serviceTy key = some sty at hty
    have hty' : w.serviceTy key = some sty := by
      rw [hagree key sv hget]
      exact hty
    exact h.1 key sv sty hget hty'

/-- Restriction retains membership when it keeps every declared service carrier.
Strong context promises make service retention explicit; `servicesFit_restrict` remains local. -/
theorem fits_restrict {app app' : SigApp} (hext : SigExtends app.signature app'.signature)
    (w : World) (hw : w.serviceTy = app'.serviceTy)
    (hkeep : TableExtends w.serviceTy app.serviceTy) (ty : Ty) (v : Val) (h : Fits w v ty) :
    Fits (restrictWorld app w) v ty := by
  have same : app.serviceTy = w.serviceTy := by
    funext key
    cases ha : app.serviceTy key with
    | some carrier =>
      have hc : w.serviceTy key = some carrier := by
        rw [hw]
        exact hext.service key carrier ha
      exact hc.symm
    | none =>
      cases hb : w.serviceTy key with
      | none => rfl
      | some carrier =>
        have hc := hkeep key carrier hb
        rw [ha] at hc
        cases hc
  exact @fits_map w (restrictWorld app w) (table_refl _) (table_refl _) (table_refl _)
    (fun _ _ hx => hx) (Stores.le_refl _) same rfl ty v h

end Effect4.Program.Typed

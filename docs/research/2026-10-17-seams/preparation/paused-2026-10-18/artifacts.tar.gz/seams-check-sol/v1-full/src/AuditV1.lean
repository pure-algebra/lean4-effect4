import Effect4.Program.Typing.SigData
import Effect4.Program.Typing.AnnotateFold
import Effect4.Program.Typing.SignatureSupport
import Effect4.Program.Typing.Support
import Effect4.Program.Check
import Effect4.Program.Typing.CheckCache
import Effect4.Laws.Program.Signature
import Effect4.Laws.Program.Definitions
import Effect4.Laws.Program.Sketch
import Effect4.Laws.Program.Typing.Annotate
import Effect4.Laws.Program.Typing.Restrict
import Effect4.Laws.Program.Typing.CheckCache
import Effect4.Laws.Program.CheckAgreement
import Test.Program.CheckCacheControls
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Program.Typing.SigData Effect4.Program.Typing.AnnotateFold Effect4.Program.Typing.SignatureSupport Effect4.Program.Typing.Support Effect4.Program.Check Effect4.Program.Typing.CheckCache Effect4.Laws.Program.Signature Effect4.Laws.Program.Definitions Effect4.Laws.Program.Sketch Effect4.Laws.Program.Typing.Annotate Effect4.Laws.Program.Typing.Restrict Effect4.Laws.Program.Typing.CheckCache Effect4.Laws.Program.CheckAgreement Test.Program.CheckCacheControls

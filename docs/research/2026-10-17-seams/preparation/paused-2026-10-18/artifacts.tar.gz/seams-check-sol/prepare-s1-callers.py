from pathlib import Path
b=Path('/private/tmp/seams-check-sol');p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');out=b/'s1-callers'
def put(rel,s):
 f=out/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
s=(b/'caller-overlay/tools/Tools/Session.lean').read_text()
s=s.replace('structure State where','structure State where\n  document : Option Doc := none')
s=s.replace('  st.source.map fun s => ⟨st.docId, s, st.revision⟩','  st.document')
s=s.replace('{ st with source := some d.session, docId := d.id, revision := d.revision }','{ st with document := some d, source := some d.session, docId := d.id, revision := d.revision }')
a=s.index('def targetJson');z=s.index('/-- What a delta says',a)
s=s[:a]+'''def targetJson (snap : Snap) (path : List Nat) (expected : NativeEff) (hex : Bool := false) : Json :=
  Json.mkObj <| [("doc", docIdJson snap.doc), ("revision", toJson snap.revision),
    ("path", toJson path), ("expectedJson", printJson expected)] ++
    if hex then [("expected", .str (toHex expected))] else []

def editRefusalJson (_sig : Signature NativeOp) (_prog : Option NativeEff) : DocRefusal → Json
  | .foreign expected => Json.mkObj [("reason",.str "foreign"),("expectedDoc",docIdJson expected)]
  | .stale now => Json.mkObj [("reason",.str "stale"),("currentRevision",toJson now.revision)]
  | .empty => Json.mkObj [("reason",.str "empty")]
  | .noEntry entry => Json.mkObj [("reason",.str "noEntry"),("entry",toJson entry)]
  | .place item _ => Json.mkObj [("reason",.str "place"),("item",toJson item)]
  | .feed item _ => Json.mkObj [("reason",.str "feed"),("item",toJson item)]

def policyFrom? : Option String → Option FeedPolicy
  | none | some "keepExactType" => some .keepExact
  | some "recheckSource" => some .recheck
  | _ => none

'''+s[z:]
a=s.index('def feedAnswer');z=s.index('/-- **Answer one request**',a)
s=s[:a]+'''def feedAnswer (st : State) (d : Doc) (req : Request) (e : Edit)
    (readLaws : List Lean.Name := []) : State × Answer :=
  let checked := d.step (st.cache.oracle (Check.HitRule.exact.or Check.extension)) d.snap (.draft e)
  let learned := { st with cache := st.cache.learn checked }
  match checked.value with
  | .error why => (learned, { op := req.op, app := st.app, ok := false,
      result := editRefusalJson d.session.app.signature (some d.session.sketch.program) why,
      error := some "the draft is refused", id := req.id })
  | .ok (next,receipt) =>
    let step := receipt.steps.headD ⟨e,none,.unchanged⟩
    ({ (learned.withDoc next) with journal := step :: st.journal },
      { op := req.op, app := st.app, laws := readLaws ++ [``SourceSession.reached_view], ok := true,
        result := Json.mkObj [("doc",docIdJson next.id),("revision",toJson next.revision),
          ("delta",deltaJson step.delta),("view",viewJson next.session)], id := req.id })

def commitAnswer (st : State) (d : Doc) (req : Request) (change : Change)
    (readLaws : List Lean.Name := []) : State × Answer :=
  let noTarget : State × Answer := (st,refused req.op "a checked edit needs its snapshot and expected program" req.id)
  match policyFrom? req.policy, req.docName, req.docGeneration, req.revision with
  | none,_,_,_ => (st,refused req.op "unknown policy" req.id)
  | some _,none,_,_ | some _,_,none,_ | some _,_,_,none => noTarget
  | some policy,some name,some generation,some revision =>
    match valueFrom? (α := NativeEff) req.expected req.expectedJson with
    | none => noTarget
    | some (none,_) => (st,unreadable (α := NativeEff) req.op "the expected program does not read" req.expectedJson req.id)
    | some (some expected,expLaws) =>
      let snap : Snap := ⟨⟨name,generation⟩,revision⟩
      let checked := d.step (st.cache.oracle (Check.HitRule.exact.or Check.extension)) snap
        (.commit [(.at_ req.path expected,change)] policy)
      let learned := { st with cache := st.cache.learn checked }
      match checked.value with
      | .error why => (learned,{ op := req.op, app := st.app, laws := readLaws ++ expLaws, ok := false,
          result := editRefusalJson d.session.app.signature (some d.session.sketch.program) why,
          error := some "the atomic edit is refused", id := req.id })
      | .ok (next,receipt) =>
        let step := receipt.steps.headD ⟨.fill req.path expected,some expected,.unchanged⟩
        ({ (learned.withDoc next) with journal := step :: st.journal },
          { op := req.op, app := st.app, laws := readLaws ++ expLaws ++ [``Doc.commit_sound], ok := true,
            result := Json.mkObj [("doc",docIdJson next.id),("revision",toJson next.revision),
              ("delta",deltaJson step.delta),("view",viewJson next.session)], id := req.id })

'''+s[z:]
s=s.replace('let d := Doc.open app { program, holes } docId','let opened := Doc.open_ ⟨docId,app,{ program,holes }⟩\n      let d := opened.value')
s=s.replace('({ source := some d.session, journal := [], app := appName app,','({ document := some d, source := some d.session, journal := [], app := appName app,')
s=s.replace('live := st.live, cache := st.cache, fills :=','live := st.live, cache := st.cache.learn opened, fills :=')
# Inspection is a direct observation; it does not restore a free Doc constructor.
s=s.replace('match d.inspect req.path with','match (Node.eff l.sketch.program).at_ req.path with').replace('| some ins =>\n          let result','| some (.eff expected) =>\n          let entry := l.table.find? fun e => decide (e.path = req.path)\n          let refusal := entry.bind fun e => e.result.bind Checker.refusal\n          let result')
s=s.replace('targetJson ins.target req.hex','targetJson d.snap req.path expected req.hex').replace('focusJson ins.focus req.hex','focusJson (l.focusAt req.path) req.hex').replace('match ins.entry with','match entry with').replace('match ins.refusal with','match refusal with')
# Add the non-program case alongside the old none branch.
s=s.replace('| none => none\' "no part of the sketch at the address"\n        | some (.eff expected)', '| none => none\' "no part of the sketch at the address"\n        | some (.stmt _) | some (.stmts _) | some (.effs _) | some (.action _) | some (.layer _) | some (.layers _) => none\' "no program at the address"\n        | some (.eff expected)')
s=s.replace('let d\' := d.fork newId','let opened := Doc.open_ ⟨newId,d.session.app,d.session.sketch⟩\n        let d\' := opened.value')
s=s.replace('generation := st.generation + 1, fills := some (FillSet.ofDoc d\')','generation := st.generation + 1, cache := st.cache.learn opened, fills := some (FillSet.ofDoc d\')')
a=s.index('      | "undo" =>');z=s.index('      | "journal" =>',a)
s=s[:a]+'''      | "undo" =>
        if d.history.isEmpty then none' "the history is empty"
        else
          let checked := d.step (st.cache.oracle (Check.HitRule.exact.or Check.extension)) d.snap
            (.revert (d.history.length - 1))
          let learned := { st with cache := st.cache.learn checked }
          match checked.value with
          | .error why => (learned, { op := op, app := st.app, ok := false,
              result := editRefusalJson sig (some l.sketch.program) why,
              error := some "the revert is refused", id := req.id })
          | .ok (next,receipt) =>
            ({ (learned.withDoc next) with journal := receipt.steps.reverse ++ st.journal },
              Answer.mk op st.app [``Doc.revert_program] true
                (Json.mkObj [("doc",docIdJson next.id),("revision",toJson next.revision),
                  ("view",viewJson next.session)]) none req.id)
'''+s[z:]
put(Path('tools/Tools/Session.lean'),s)
old=(p/'src/Effect4/Program/Typing/FillSet.lean').read_text();a=old.index('    let s\' ← fs.materializeSketch');z=old.index('\nend FillSet',a)
old=old[:a]+'''    let _ ← fs.materializeSketch
    let items := (ordered fs.base fs.entries).filterMap fun (path,q) =>
      match (Node.eff fs.base.program).at_ path with
      | some (.eff expected) => some (Place.at_ path expected,Change.fill q)
      | _ => none
    match (d.step Check.Oracle.uncached d.snap (.commit items .keepExact)).value with
    | .ok (next,_) => .ok next
    | .error _ => .error .notApplicable
'''+old[z:]
put(Path('src/Effect4/Program/Typing/FillSet.lean'),old)
print(out)

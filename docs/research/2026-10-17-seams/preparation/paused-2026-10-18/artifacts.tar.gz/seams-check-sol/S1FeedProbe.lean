import CheckProbe
import Effect4.Program.Typing.FillSet

/-!
S1 executable proposal. The production tree is unchanged.

Placement for the planned feed laws:
1. Concept: initial-algebras-folds, source-session-coherent and typed-replacement.
2. Question: feed_keepExact and feed_root, compatibility claims under R14.
3. Reach: coherent source tables, candidate expansion, exact focus type, and the whole-expansion guard.
4. Exclusions: arbitrary reference edits, program admission, progress, and a native cost claim.
5. Consumer: Doc.step and FillSet.add. The finite controls do not prove these laws.
-/
set_option autoImplicit false
set_option maxRecDepth 20000
namespace SeamsS1Scout
open Effect4 Effect4.Program
open SeamsCheckScout (Input Verdict run deps combine place)

structure Oracle where
  ask : Input → Verdict
  agrees : ∀ i, ask i = run i

def Oracle.uncached : Oracle := ⟨run, fun _ => rfl⟩

def TraceValid (trace : List (Input × Verdict)) : Prop := ∀ p ∈ trace, p.2 = run p.1

structure Checked (α : Type) where
  private mk ::
  value : α
  trace : List (Input × Verdict)
  valid : TraceValid trace

def Checked.pure {α : Type} (a : α) : Checked α :=
  ⟨a, [], fun _ h => nomatch h⟩

def Checked.bind {α β : Type} (x : Checked α) (f : α → Checked β) : Checked β :=
  ⟨(f x.value).value, x.trace ++ (f x.value).trace, fun p hp => by
    cases List.mem_append.mp hp with
    | inl h => exact x.valid p h
    | inr h => exact (f x.value).valid p h⟩

instance : Monad Checked where
  pure := Checked.pure
  bind := Checked.bind

def Checked.ask (o : Oracle) (i : Input) : Checked Verdict :=
  match i with
  | .part .. => ⟨o.ask i, [(i, o.ask i)], fun p hp => by
      have he := List.mem_singleton.mp hp
      subst p
      exact o.agrees i⟩
  | .module .. =>
    let trace := (deps i).map fun d => (d.input, o.ask d.input)
    ⟨combine i (trace.map Prod.snd), trace, fun p hp => by
      obtain ⟨d, _hd, he⟩ := List.mem_map.mp hp
      subst p
      exact o.agrees d.input⟩

structure SourceSession where
  app : SigApp
  sketch : Sketch
  table : List Table.Entry

namespace SourceSession

def Coherent (s : SourceSession) : Prop := s.table = s.sketch.sourceTable s.app

def shown (s : SourceSession) : EditSession := ⟨s.app, s.sketch, s.table⟩
def view (s : SourceSession) : EditSession.View := s.shown.view

def focusAt (s : SourceSession) (path : List Nat) : Option (Focus NativeOp) :=
  match (Node.eff s.sketch.program).at_ path, Table.typedAt s.table path with
  | some (.eff q), some (env, ty) => some ⟨q, env, ty⟩
  | _, _ => none

def open_ (o : Oracle) (app : SigApp) (sketch : Sketch) : Checked SourceSession := do
  let v ← Checked.ask o (.module app sketch.holes sketch.program)
  pure ⟨app, sketch, v.table⟩

def candidatePartKey (s : SourceSession) (path : List Nat) (candidate : Sketch) : Option Input :=
  match path, s.focusAt path, (Node.eff candidate.expand.program).at_ path with
  | _ :: _, some old, some (.eff q) =>
      some (.part (sketchSigData candidate.expand s.app path) old.env q)
  | _, _, _ => none

def partKey (s : SourceSession) (path : List Nat) (q : NativeEff) : Option Input :=
  (s.sketch.fillAt path q).bind (s.candidatePartKey path)

def expandedEditAgrees (s : SourceSession) (candidate : Sketch) (edit : Edit) : Bool :=
  let expanded := candidate.expand
  match Edit.expanded expanded edit with
  | some expandedEdit =>
      decide ((s.sketch.expand.edit s.app expandedEdit).map (fun y => (y.program, y.holes)) =
        some (expanded.program, expanded.holes))
  | none => false

end SourceSession

inductive FeedPolicy where
  | draft | keepExact | recheck
deriving DecidableEq

inductive FeedRefusal where
  | noProgram (path : List Nat)
  | noFocus (path : List Nat)
  | notKept (focus : TyEnv × EffTy) (verdict : Except TypeRefusal EffTy)
  | refused (why : List TypeRefusal)
  | typeChanged (old : Option EffTy) (new : EffTy)
  | localChanged (old new : Option (TyEnv × EffTy))

namespace SourceSession

def finish (policy : FeedPolicy) (s next : SourceSession) (edit : Edit)
    (step : Edit.Step) (v : Verdict) : Except FeedRefusal (SourceSession × Edit.Step) :=
  match policy, v.result with
  | .draft, _ => .ok (next, step)
  | _, .error _ => .error (.refused next.view.refusals)
  | .recheck, .ok _ => .ok (next, step)
  | .keepExact, .ok ty =>
      if s.view.type != some ty then .error (.typeChanged s.view.type ty)
      else if edit.path != [] && Table.typedAt s.table edit.path != Table.typedAt next.table edit.path
      then .error (.localChanged (Table.typedAt s.table edit.path) (Table.typedAt next.table edit.path))
      else .ok (next, step)

def recheck (o : Oracle) (policy : FeedPolicy) (s : SourceSession) (candidate : Sketch)
    (edit : Edit) (old : NativeEff) : Checked (Except FeedRefusal (SourceSession × Edit.Step)) := do
  let v ← Checked.ask o (.module s.app candidate.holes candidate.program)
  let next : SourceSession := ⟨s.app, candidate, v.table⟩
  pure (finish policy s next edit ⟨edit, some old, .rechecked⟩ v)

def splice (s : SourceSession) (candidate : Sketch) (edit : Edit) (old : NativeEff)
    (part : Verdict) : SourceSession × Edit.Step :=
  let sub := Table.atSource candidate.sites candidate.program.firstRefFault (place edit.path part).table
  let next : SourceSession := ⟨s.app, candidate, Table.splice s.table edit.path sub⟩
  (next, ⟨edit, some old, .spliced (sub.map (·.path))⟩)

def draftOmitAllows (edit : Edit) (ty : EffTy) : Bool :=
  match edit with
  | .fill .. => true
  | .omitAt _ row =>
      decide (row = Row.hole row.name ty.answer ty.error ty.requires.elems) &&
        ty.answer.closed && ty.error.closed && decide (ty.answer.normalize = ty.answer) &&
        decide (ty.error.normalize = ty.error) &&
        (Formation.check (Formation.instantiatedSites row.normalizeTypes [])).isNone

def feed (o : Oracle) (policy : FeedPolicy) (s : SourceSession) (edit : Edit) :
    Checked (Except FeedRefusal (SourceSession × Edit.Step)) := do
  match (Node.eff s.sketch.program).at_ edit.path, s.sketch.edit s.app edit with
  | some (.eff old), some candidate =>
      match edit.path with
      | [] => s.recheck o policy candidate edit old
      | _ :: _ =>
          match policy with
          | .recheck => s.recheck o policy candidate edit old
          | .draft =>
              match s.focusAt edit.path, s.view.type with
              | some focus, some _ =>
                  if !s.expandedEditAgrees candidate edit || !draftOmitAllows edit focus.ty then
                    s.recheck o policy candidate edit old
                  else
                    match s.candidatePartKey edit.path candidate with
                    | none => s.recheck o policy candidate edit old
                    | some key =>
                        let part ← Checked.ask o key
                        match part.result with
                        | .ok ty =>
                            if ty = focus.ty then pure (.ok (s.splice candidate edit old part))
                            else s.recheck o policy candidate edit old
                        | .error _ => s.recheck o policy candidate edit old
              | _, _ => s.recheck o policy candidate edit old
          | .keepExact =>
              match s.focusAt edit.path with
              | none => pure (.error (.noFocus edit.path))
              | some focus =>
                  match s.candidatePartKey edit.path candidate with
                  | none => pure (.error (.noFocus edit.path))
                  | some key =>
                      let part ← Checked.ask o key
                      match part.result with
                      | .error _ => pure (.error (.notKept (focus.env, focus.ty) part.result))
                      | .ok ty =>
                          if ty != focus.ty then pure (.error (.notKept (focus.env, focus.ty) part.result))
                          else if s.expandedEditAgrees candidate edit then
                            pure (.ok (s.splice candidate edit old part))
                          else s.recheck o policy candidate edit old
  | _, _ =>
      match policy with
      | .draft => pure (.ok (s, ⟨edit, none, .unchanged⟩))
      | _ => pure (.error (.noProgram edit.path))

end SourceSession

namespace FeedControls
open SeamsCheckScout (n1 bad checkedModule)
def n7 : NativeEff := .succeed (.lit (.nat 7))
def str : NativeEff := .succeed (.lit (.str "a"))
def opened (s : Sketch) : SourceSession := (SourceSession.open_ Oracle.uncached {} s).value

def base : Sketch := ⟨.bind n1 (Sketch.hole {} 0), [Row.hole "h" .nat]⟩
def old : SourceSession := opened base
def exactFill := old.feed Oracle.uncached .keepExact (.fill [1] (.succeed (.var 0)))
#guard exactFill.value.toOption.map (fun r => (r.1.view.type, r.2.delta)) =
  some (some (.pure .nat), .spliced [[1]])
#guard exactFill.trace.length = 1
#guard exactFill.value.toOption.map (fun r => decide (r.1.table = r.1.sketch.sourceAnnotate {})) = some true
#guard match (old.feed Oracle.uncached .keepExact (.fill [0] str)).value with
  | .error (.notKept _ _) => true
  | _ => false
#guard (old.feed Oracle.uncached .keepExact (.fill [0] str)).trace.length = 1
#guard match (old.feed Oracle.uncached .keepExact (.fill [9] n7)).value with
  | .error (.noProgram [9]) => true
  | _ => false
#guard ((old.feed Oracle.uncached .draft (.fill [9] n7)).value.toOption.map (·.2.delta)) = some .unchanged
#guard match ((opened ⟨.bind bad n1, []⟩).feed Oracle.uncached .keepExact (.fill [1] n7)).value with
  | .error (.noFocus [1]) => true
  | _ => false
#guard ((old.feed Oracle.uncached .recheck (.fill [0] str)).value.toOption.map (·.1.view.type)) =
  some (some (.pure .nat))
#guard ((old.feed Oracle.uncached .draft (.fill [0] bad)).value.toOption.map (·.1.view.type)) = some none
#guard match (old.feed Oracle.uncached .recheck (.fill [0] bad)).value with
  | .error (.refused _) => true
  | _ => false

/-! Exact local typing can stand beside an unrelated whole-program error. -/
def brokenElsewhere := opened ⟨.bind n1 (.succeed (.var 2)), []⟩
#guard brokenElsewhere.table = brokenElsewhere.sketch.sourceTable {}
#guard (brokenElsewhere.feed Oracle.uncached .keepExact (.fill [0] n7)).value.toOption.map
  (fun r => decide (Table.typedAt r.1.table [0] = Table.typedAt brokenElsewhere.table [0])) = some true
#guard (brokenElsewhere.feed Oracle.uncached .keepExact (.fill [0] n7)).value.toOption.map
  (fun r => (r.1.view.type, r.2.delta, decide (r.1.table = r.1.sketch.sourceAnnotate {}))) =
    some (none, .spliced [[0]], true)

/-! The root control accepts a module block that refuses as a part. -/
def rootEdit := (opened ⟨n1, []⟩).feed Oracle.uncached .keepExact (.fill [] checkedModule)
#guard rootEdit.value.toOption.map (fun r => (r.1.view.type, r.2.delta)) =
  some (some (.pure .nat), .rechecked)
#guard (SeamsCheckScout.run (.part ⟨{}, [], .root⟩ [] checkedModule)).result.toBool = false
#guard rootEdit.value.toOption.map (fun r => decide (r.1.table = r.1.sketch.sourceAnnotate {})) = some true
#guard (opened ⟨n1, []⟩).partKey [] checkedModule = none

/-! Reference contexts and the whole-expansion guard. -/
def besideRef : Sketch :=
  ⟨.provideLayer (.effectDiscard n1) false
    (.bind (.provideLayer (.ref [0]) false n1) (Sketch.hole {} 0)), [Row.hole "h" .nat]⟩
def refBase : Sketch := ⟨.bind (.provideLayer (.effectDiscard n1) false n1) n7, []⟩
def refFilling : NativeEff := .provideLayer (.ref [0, 0]) false n7
def referencedBody : Sketch := ⟨.provideLayer (.effectDiscard n1) false
  (.provideLayer (.ref [0]) false n1), []⟩
def larger : NativeEff := .bind n1 n7
#guard (besideRef.focusAt {} [1, 1]).isNone
#guard ((opened besideRef).feed Oracle.uncached .keepExact (.fill [1, 1] (.succeed (.var 0)))).value.toOption.isSome
#guard ((opened refBase).feed Oracle.uncached .keepExact (.fill [1] refFilling)).value.toOption.isSome
#guard ((opened refBase).feed Oracle.uncached .keepExact (.fill [1] refFilling)).value.toOption.map
  (fun r => decide (r.1.table = r.1.sketch.sourceAnnotate {})) = some true
#guard ((opened referencedBody).feed Oracle.uncached .keepExact (.fill [0, 0] larger)).value.toOption.map
  (fun r => (r.2.delta, decide (r.1.table = r.1.sketch.sourceAnnotate {}))) = some (.rechecked, true)
#guard !((opened referencedBody).expandedEditAgrees
  ((referencedBody.fillAt [0, 0] larger).getD referencedBody) (.fill [0, 0] larger))

/-! Draft compatibility includes the old omission gate and invalid paths. -/
def edits : List Edit := [.fill [0] n7, .fill [0] str, .fill [0] bad, .fill [9] n7,
  .omitAt [0] (Row.hole "g" .nat), .omitAt [0] (Row.hole "g" .string)]
#guard edits.all fun e =>
  let before := Effect4.Program.SourceSession.open {} base
  let legacy := before.feedStep e
  match (old.feed Oracle.uncached .draft e).value with
  | .ok (next, step) => decide (next.sketch = legacy.1.sketch) &&
      decide (next.table = legacy.1.table) && decide (step.edit.path = legacy.2.edit.path) &&
      decide (step.replaced = legacy.2.replaced) && decide (step.delta = legacy.2.delta)
  | .error _ => false
end FeedControls
end SeamsS1Scout
#eval IO.println "S1 scout: source-table feed and root/reference controls pass"

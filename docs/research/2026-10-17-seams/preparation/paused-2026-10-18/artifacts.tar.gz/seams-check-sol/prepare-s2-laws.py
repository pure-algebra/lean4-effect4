from pathlib import Path
import re
b=Path('/private/tmp/seams-check-sol');p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');out=b/'s2-laws/Effect4/Laws/Program';out.mkdir(parents=True,exist_ok=True)
old=(p/'src/Effect4/Program/Typing/FillSet.lean').read_text();laws=(p/'src/Effect4/Laws/Program/FillSet.lean').read_text()
cert=old[old.index('def certifiedB'):old.index('/-! ## Applying fills')]
mat=old[old.index('/-- Why a fill set does not materialize.'):old.index('/-! ## `FillSet`')]
certified=laws[laws.index('def Certified'):laws.index('/-- `certifiedB` soundness')]
reference='''import Effect4.Program.Typing.FillSet
import Effect4.Laws.Program.Typing.Sound
/-!
Reference observations for the retired raw certification and materialization algorithms.
These definitions retain their old bodies and refusal order for D1-D9's fragment proofs.
They are Laws-only observations. The production feed owns certification and publication.
-/
namespace Effect4.Program.FillReference
open Effect4 Effect4.Program
'''+cert+mat+certified+'\nend Effect4.Program.FillReference\n'
(out/'FillReference.lean').write_text(reference)
keep=laws[:laws.index('namespace FillSet')]
# Retain D1-D9's exact original premises and bodies, with their observations now Laws-owned.
keep=keep.replace('import Effect4.Program.Typing.FillSet','import Effect4.Laws.Program.FillReference')
keep=keep.replace(certified,'')
for name in ['Certified','certifiedB','materialize','MaterializeRefusal','conflictAt']:
 keep=re.sub(r'(?<![\w.])'+name+r'\b','FillReference.'+name,keep)
# Existing theorem names remain unchanged; only referenced data-observation owners move.
keep=keep.replace('theorem FillReference.materialize_congr','theorem materialize_congr').replace('theorem FillReference.materialize_refFree','theorem materialize_refFree')
keep+='''
/-!
Placement: initial-algebras-folds, typed-replacement and source-session-coherent, R14.
Question: the new add_wf construction claim and the reference-fragment connectors below.
Reach: the sealed anchor, exact source-session feed, non-root edits, and explicit reference-free premises.
Exclusions: arbitrary reference composition, admission, progress, and native execution.
Consumers: ordered publication, the tool's pending set, and the D1-D9 reference battery.
-/
open Check

def FeedCertified (s : SourceSession) (x : List Nat × NativeEff) : Prop :=
  x.1 ≠ [] ∧ ∃ next step,
    (s.feed Oracle.uncached .keepExact (.fill x.1 x.2)).value = .ok (next,step)

@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal kept_eq_certified (s : SourceSession) (hc : s.Coherent)
    (p : List Nat) (q : NativeEff) (hp : p ≠ [])
    (hb : s.sketch.program.refSites [] = []) (hq : q.refSites [] = []) :
    FeedCertified s (p,q) ↔ FillReference.certifiedB s.sketch s.app p q = true

namespace FillSet
structure WellFormed (fs : FillSet) : Prop where
  conflictFree : ConflictFree fs.entries
  incomparable : ∀ x ∈ fs.entries, ∀ y ∈ fs.entries, x.1 ≠ y.1 → Incomparable x.1 y.1
  certified : ∀ x ∈ fs.entries, FeedCertified fs.source x

@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal add_wf (o : Oracle) (fs : FillSet) (submissions : List (List Nat × NativeEff)) :
    ((fs.add o submissions).value.1).WellFormed

@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal publish_eq_materialize {o : Oracle} {fs : FillSet} {d next : Doc} {action : DocAction}
    {receipt : Receipt} {T : EffTy} (ha : fs.anchor = d.snap) (hs : fs.source = d.session)
    (hc : d.session.Coherent) (hpositive : fs.base.sourceCheck fs.app = .ok T)
    (hb : fs.base.program.refSites [] = [])
    (hq : ∀ x ∈ fs.entries, x.2.refSites [] = [])
    (hpublication : fs.publication = .ok action)
    (hstep : (d.step o fs.anchor action).value = .ok (next,receipt)) :
    FillReference.materialize fs.app fs.base fs.entries = .ok next.session.sketch
end FillSet
end Effect4.Program
'''
(out/'FillSet.lean').write_text('import Effect4.Laws.Auto.Obligations\n'+keep)
print(out)

from pathlib import Path
import subprocess
root = Path('/private/tmp/seams-check-scout')
failed = False
for name in ['CheckProbe', 'SupportProbe', 'ContextProbe']:
    with (root / (name + '.checked.log')).open('w') as log:
        result = subprocess.run(['lake', 'env', 'lean', '-DwarningAsError=true', str(root / (name + '.lean'))], stdout=log, stderr=subprocess.STDOUT)
    print(name + ': exit ' + str(result.returncode), flush=True)
    failed |= result.returncode != 0
raise SystemExit(1 if failed else 0)

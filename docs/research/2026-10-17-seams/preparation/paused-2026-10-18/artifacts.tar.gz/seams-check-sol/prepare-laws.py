from pathlib import Path
import re
p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');o=Path('/private/tmp/seams-check-sol/v1-laws')
def read(rel):return (p/'src'/rel).read_text()
def put(rel,s):
 f=o/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
def remove(s,name):
 m=re.search(r'^(?:theorem|def) '+re.escape(name)+r'\b',s,re.M)
 if not m:raise Exception(name)
 candidates=[s.find(marker,m.end()) for marker in ['\n/-','\nnamespace ','\nend ']]
 end=min(x for x in candidates if x>=0)
 start=s.rfind('/--',0,m.start())
 if start<0:start=m.start()
 return s[:start]+s[end:]
s=read('Effect4/Laws/Program/Signature.lean')
a=s.index('section Congr');b=s.index('end SigExtends',a)+len('end SigExtends');s=s[:a]+s[b:]
s=remove(s,'rows_append')
# second rows_append is the SigApp member
s=remove(s,'rows_append')
a=s.index('section FoldCongr');b=s.index('theorem check_alg_agreeOn',a)
# remove full preceding docstring and preserve attribute, if any, on remaining theorem
b=s.rfind('/--',a,b);s=s[:a]+s[b:]
s='import Effect4.Program.Typing.SignatureSupport\n'+s
put('Effect4/Laws/Program/Signature.lean',s)
s=read('Effect4/Laws/Program/Definitions.lean')
for name in ['Signature.withDefs_dom_of_none','Signature.withDefs_rowOf_of_none','Signature.withDefs_dom_call','Signature.withDefs_rowOf_call','SigExtends.withDefs','SigExtends.withParams']:s=remove(s,name)
put('Effect4/Laws/Program/Definitions.lean',s)
s=read('Effect4/Laws/Program/Sketch.lean');s=remove(s,'SigApp.withHoles_extends');s=s.replace('namespace Effect4.Program','namespace Effect4.Program\nattribute [semantics "initial-algebras-folds" (requirement := R14)] SigApp.withHoles_extends',1)
put('Effect4/Laws/Program/Sketch.lean',s)
s=read('Effect4/Laws/Program/Typing/Annotate.lean').replace('fold_of Effect4.Program.Annotate.check','');s='import Effect4.Program.Typing.AnnotateFold\n'+s
put('Effect4/Laws/Program/Typing/Annotate.lean',s)
s=read('Effect4/Laws/Program/Typing/Restrict.lean');s=remove(s,'Annotate.check_alg_agreeOn');s=remove(s,'Annotate.check_restrict');s=s.replace('namespace Effect4.Program','namespace Effect4.Program\nattribute [semantics "initial-algebras-folds" (requirement := R14)] Annotate.check_alg_agreeOn Annotate.check_restrict',1)
put('Effect4/Laws/Program/Typing/Restrict.lean',s)
s=read('Effect4/Laws/Program/Typing/CheckCache.lean');s=s[:s.index('/-- The decidable',s.index('theorem sketchSigData_signature'))] if False else s[:s.index('theorem SigData.extends_of_extendsB')]
# Strip the last unfinished docstring and semantics attribute attached to the moved theorem.
s=s[:s.rfind('/--')]+ '\nend Effect4.Program\n'
put('Effect4/Laws/Program/Typing/CheckCache.lean',s)
print(o)

from pathlib import Path
import difflib
root=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');base=Path('/private/tmp/seams-check-sol')
for dirname,name,prefix in [('overlay','V1-core.patch','src/'),('s1-overlay','S1-core.patch','src/'),('s2-overlay','S2-core.patch','src/'),('caller-overlay','V1-callers.patch','')]:
 chunks=[]
 for p in sorted((base/dirname).rglob('*.lean')):
  rel=prefix+str(p.relative_to(base/dirname));old=root/rel
  chunks.extend(difflib.unified_diff(old.read_text().splitlines(keepends=True) if old.exists() else [],p.read_text().splitlines(keepends=True),fromfile='a/'+rel if old.exists() else '/dev/null',tofile='b/'+rel))
 (base/name).write_text(''.join(chunks));print(name,len(chunks))

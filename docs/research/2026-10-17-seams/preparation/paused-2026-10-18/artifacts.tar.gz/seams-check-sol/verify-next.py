import subprocess,sys
for cmd in [['python3','/private/tmp/seams-check-sol/audit-stage.py','s1'],['python3','/private/tmp/seams-check-sol/build-stage.py','s2']]:
 r=subprocess.run(cmd)
 if r.returncode:raise SystemExit(r.returncode)

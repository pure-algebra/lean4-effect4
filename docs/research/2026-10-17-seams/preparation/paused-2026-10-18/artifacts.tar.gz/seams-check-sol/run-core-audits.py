from pathlib import Path
import os
import subprocess
root = Path('/private/tmp/seams-check-scout')
env = {**os.environ, 'LEAN_PATH': str(root) + (':' + os.environ['LEAN_PATH'] if os.environ.get('LEAN_PATH') else '')}
failed = False
for name in ['CheckProbe', 'SupportProbe', 'ContextProbe', 'CoreFactsProbe']:
    with (root / (name + '.compiled.log')).open('w') as log:
        result = subprocess.run(['lake', 'env', 'lean', '-DwarningAsError=true', '--root=' + str(root), '-o', str(root / (name + '.olean')), str(root / (name + '.lean'))], stdout=log, stderr=subprocess.STDOUT, env=env)
    print(name + ': exit ' + str(result.returncode), flush=True)
    failed |= result.returncode != 0
for name in ['AuditLaws', 'AuditCore']:
    with (root / (name + '.log')).open('w') as log:
        result = subprocess.run(['lake', 'env', 'lean', '-DwarningAsError=true', str(root / (name + '.lean'))], stdout=log, stderr=subprocess.STDOUT, env=env)
    print(name + ': exit ' + str(result.returncode), flush=True)
    failed |= result.returncode != 0
raise SystemExit(1 if failed else 0)

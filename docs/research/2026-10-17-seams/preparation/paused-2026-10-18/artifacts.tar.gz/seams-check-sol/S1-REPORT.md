# S1 source-session and document proposal

The local `keepExact` rule can accept an edit while the root still refuses.
Do not carry the old unconditional positive-root conclusion into the new document law.
Keep the plan's full local rule and exact table observation.

The scout changes no production source and makes no commit.
All proposal files live in `/private/tmp/seams-check-scout`.

## Current evidence

| Artifact | Status | Scope |
| --- | --- | --- |
| `S1FeedProbe.lean` | Compiled and axiom-gated | Source-table storage, all policies, root module checking, reference contexts, and draft compatibility |
| `S1DocProbe.lean` | Compiled and axiom-gated | One action interpreter, sealed history, atomic batches, and reverse revert |
| `S1DocControls.lean` | Compiled and axiom-gated | The exact first loop and every S1 acceptance case |

The final command exits 0:

```text
python3 /private/tmp/seams-lean-one.py python3 /private/tmp/seams-check-scout/run-s1-probes.py
```

The script invokes `lake env lean -DwarningAsError=true` for each file serially.
The strict guard enters `scratch/lean-slot.sh` with `LEAN_NUM_THREADS=3`.
All four file commands exit 0: the feed, document, acceptance controls, and axiom gate.

```text
#axiom_audit: 604 declarations within [propext, Quot.sound], 0 of them modulo planned goals; 0 planned goals
```

`S1FeedProbe.compiled.log`, `S1DocProbe.compiled.log`, `S1DocControls.compiled.log`, and `AuditS1.compiled.log` hold the results.
`python3 scripts/check-language.py --strict /private/tmp/seams-check-scout/S1-REPORT.md` passes.
These are isolated Lean probes, not the landing's narrow build, battery gate, or OCaml gate.
The first feed run failed because the test compared `Edit.Step`, which has no equality instance.
The retained `S1FeedProbe.first.log` records that failure.
The first document run rejected the helper name `seal`, which Lean reserves.
The retained `S1DocProbe.first.log` records that failure.

## Storage and part keys

Store `app`, the source `sketch`, and its source `table` in `SourceSession`.
The module checker already returns that source table.
The old field `expanded.table` instead stores entries below copied references.
Assigning the new module verdict there violates the old invariant.

The production `.expanded` field has no caller outside `SourceSession.lean`.
The representation-dependent proofs are in `src/Effect4/Laws/Program/SourceTable.lean`.
`SourceSession.Coherent` becomes `table = sketch.sourceTable app`.
`table_eq`, `view_type`, `view_refusals`, and `focusAt_typed` retain their observations.
`Coherent.ext` becomes equality of the three stored fields.

Build a candidate before selecting its part key.
Read the part from the candidate's whole expansion at the original address.
Use the old source focus's environment.
Use `sketchSigData` from the candidate, including its new hole table.
Return no part key at the root.

The internal candidate-key helper serves both fills and omissions.
The public `partKey` creates a filling candidate and calls that helper.
The whole-expansion guard compares both programs and hole tables.
A reference elsewhere can copy an edited target, so a local address guard cannot replace it.

## Policy boundaries

`draft` retains the old invalid-path no-op.
The strict policies refuse `noProgram` there.
The old omission guard remains part of draft compatibility.

A non-root `keepExact` feed asks one candidate part.
A refusal or changed type gives `notKept` without a module check.
A kept part splices when the whole-expansion guard succeeds.
Otherwise it checks the module and compares the root and local types.
No old-positive-root test belongs before that splice.

An edit at the root always asks the module and never splices.
The root control replaces a literal with a valid definition block.
That block accepts as a module and refuses as a part.
A trace containing only actual part asks still represents this module check.

## The positive-root correction

The old theorem is `Doc.commit_sound` in `src/Effect4/Laws/Program/SourceDocument.lean`.
Its exact statement is:

```lean
theorem Doc.commit_sound {d d' : Doc} {t : EditTarget} {c : Change} {policy : Policy}
    (hc : d.session.Coherent) (h : d.commit t c policy = .ok d') :
    t.doc = d.id ∧ t.revision = d.revision ∧ d'.id = d.id ∧ d'.revision = d.revision + 1 ∧
      d'.session.Coherent ∧ d'.session.app = d.session.app ∧
      (∃ e, d.editOf t c = some e ∧ d.session.sketch.edit d.session.app e = some d'.session.sketch) ∧
      ∃ T', d'.session.sketch.sourceCheck d.session.app = .ok T' ∧
        (policy = .keepExactType →
          d.session.sketch.sourceCheck d.session.app = .ok T' ∧
          Table.typedAt d'.session.table t.path = Table.typedAt d.session.table t.path)
```

That theorem describes the old algorithm, which checks the root before accepting every commit.
The new plan checks a kept local part and can splice without checking the module.
The old theorem stays true about its old algorithm.
Its unconditional positive-root conclusion does not transfer to the new algorithm.

The counterexample uses this source program:

```lean
.bind (.succeed (.lit (.nat 1))) (.succeed (.var 2))
```

The second child refuses because its environment contains one variable.
The first child has type `nat!never` in the empty environment.
Replacing the first child with `7` keeps that exact local type.
The new feed accepts and splices `[[0]]`.
The root remains `none`, and the new table equals `sourceAnnotate`.
The original table equals `sourceTable`.
The old and new typed entries at `[0]` are equal.

Preserve the full `feed_keepExact` law from `interfaces.md`.
It keeps the root observation and local type, and splices when the whole expansion agrees.
Its root observation is an `Option EffTy`, so keeping `none` is meaningful.
Keep `feed_root` and exact source-table coherence unchanged.

State a positive-root corollary with an explicit old-positive-root premise for `keepExact`.
State a separate positive-root corollary for an accepted `recheck` feed.
For a batch, transport the positive-root premise through every accepted `keepExact` item.
A draft policy carries neither corollary.
None of these statements establishes `admitProgram`.

### Semantics registry changes

No current entry in `Registry.lean`, `generated/semantics.md`, or `semantics.md` names `checked-edit-atomic`.
The old law's placement describes it only as a proposed claim.
Do not report a registered `Doc.commit_sound` pointer as though one already exists.

The live pointer `source-session-coherent` names `SourceSession.reached_view`.
Update its text to describe the source table and the policy feed.
Retain its table, refusal, and root-type observations.
Its current text describes splicing inside an expanded session, which the new representation removes.

The live pointer `source-session-undo` names `SourceSession.feed_undo`.
Retain its immediate fill-and-inverse observation on coherent sessions.
Place `revert_program` separately for a document entry and its immediate revert.
An omission restores the program while keeping its appended row.
An intervening unrelated edit prevents a whole-program equality claim against the pre-entry document.

The `typed-replacement` pointer remains `NodeHasTy.replace` with its typed-node premise unchanged.
The `source-annotation-agrees` pointer remains `Sketch.sourceAnnotate_eq_sourceTable` unchanged.
Propose an S1 claim for source-table equality and root typing, with explicit policy and positivity hypotheses.
Regenerate `generated/semantics.md`; never hand-edit it.

## One document interpreter

`DocInternal.apply` interprets each `DocAction`.
Both replay and `Doc.step` use it.
`Doc` stores only its origin, accepted history, session, and replay proof.
Its revision is the history length.

Replay temporarily holds each entry's policy and undo items.
An undo item holds its address, replaced program, and immediate product.
These items are derived during replay; they are not serialized state.
A new commit or draft uses the current session without replaying older actions.
A revert reconstructs earlier receipts through the same interpreter and the supplied oracle.

The batch resolves each place against the prior item's temporary result.
Place refusal precedes feed refusal.
A late refusal returns no replacement document and retains its check trace for memo learning.
An empty batch refuses before any feed.

Revert visits the selected entry's items in reverse order.
Each inverse first checks the current program against that item's immediate product.
It then runs the inverse through the policy feed under the entry's original policy.
It records its own products, so a later revert can also revert that revert.

A draft no-op records no inverse item because it replaced no program.
Its later revert is a no-op action with a new revision.
The finite controls also cover that case and a revert of a revert.


### The exact append law

The plan abbreviates `step_replay` as a fold over `SourceSession`.
A bare source session cannot interpret `revert`, because it does not contain the earlier entry.
The exact implementation law folds a temporary replay state and then projects its session.

```lean
replayDoc origin (history ++ [action]) =
  ((DocInternal.replayStep Oracle.uncached
    (DocInternal.replayState origin history) action).value).map (·.session)
```

`DocInternal.replayState_snoc` proves the unprojected equation with `List.foldl_append`.
`Doc.sealReplay` uses it to construct the document's proof field.
`Doc.sealFresh` avoids replaying previous entries for a new commit or draft.
`Doc.past_valid` supplies the full replay state when a revert needs earlier receipts.
Every helper compiles without a planned goal.

The control uses one origin and two histories with equal current sessions and equal revisions.
One history writes `7`, then `1`.
The other writes a string, then `1`.
Reverting entry 1 produces `7` in the first history and the string in the second.
This corrects the abbreviated law's state type while keeping the exact validating replay contract.


## Integration ownership

| Owner | Input from the proposal | Dependencies |
| --- | --- | --- |
| `Program/Typing/SourceSession.lean` | The policy feed, source-table representation, `partKey`, and observations from `S1FeedProbe` | The V1 `Check` owner, extracted signature data, source annotation, and existing edit data |
| `Program/Typing/SourceDocument.lean` | `Place`, `Snap`, `DocAction`, the one action interpreter, replay, sealed `Doc`, and its core constructor proofs | The new source session; existing `DocId` and `Change` move before its declaration |
| `Laws/Program/SourceTable.lean` | Coherence, view, focus, draft agreement, and the two new policy laws | Existing table and typed-replacement laws; exact V1 `combine_deps` |
| `Laws/Program/SourceDocument.lean` | The public append, refusal, and revert laws; policy-specific root typing | The core replay helpers and source-session laws |
| `Test/Program/SeamsS1.lean` | `S1DocControls`, feed root/reference controls, and the two plan-correction controls | The new public owners and their Laws readers |
| `tools/ProofGraph/Registry.lean` and `docs/core/semantics.md` | The S1 placements described above | The slice's placement anchor; generated semantics follows its producer |

The temporary checked package is scaffolding for the proposal, not another production owner.
Use S0's `Check.Oracle`, `Check.Checked`, and `Check.Oracle.eq_uncached` when integrating.
Rename the probe's `Input` to `Check.CheckInput`.
S0 names the writer methods `Checked.bind'` and `Checked.pure'`; adapt the proof unfold lists to those names.
Use the V1 module decomposition in `Checked.ask`.
The source-session file must not import the old `CheckCache`, which would create a dependency cycle.
The document file must not import Laws.

The core replay constructors already have full proofs.
The finite feed controls do not prove `feed_draft`, `feed_keepExact`, or whole source-table coherence.
Keep those exact statements in Laws, proved or placed as allowed planned goals.
Keep existing table, refusal, root-type, and immediate-fill inverse observations after migrating their session parameters.

## Caller migration

`S1-callers.txt` records the current search results.
The following callers must move in S1 even when their final replacement lands later.

| Caller | S1 movement |
| --- | --- |
| `FillSet.materializeDoc` | Stop constructing a free `Doc`; submit one ordered `commit` through `Doc.step` until S2 removes this old surface |
| `Tools.Session.atomic` and edit handlers | Build a `Snap` and `DocAction`, then call `Doc.step` |
| `Tools.Session` open, draft, undo, and fork handlers | Use the sealed open and history; remove arbitrary revisions and direct document updates |
| `Test/Program/SourceDocumentControls.lean` | Keep the old observation controls through the new interface; add the exact S1 acceptance cases |
| `Test/Program/FillSetControls.lean` | Open a sealed document and use its snapshot |
| `Test/Program/CheckCacheControls.lean` | Open a sealed document; move cache observations as assigned in V1 and S2 |
| `Laws/Program/SourceDocument.lean` | Replace the old surface law with the law for policy-specific document typing |
| `Laws/Program/SourceTable.lean` | Move representation proofs and retain the same table, refusal, type, and immediate inverse observations |

The old tool state has its own revision and snapshot fields until S3b removes them.
During S1, derive those observations from the sealed document rather than constructing a document from them.
Do not retain `Doc.undo`, `Doc.fork`, or the free revision field as forwarding aliases.

import subprocess,os,sys
from pathlib import Path
base=Path('/private/tmp/seams-check-sol');lib=base/'lib/lean';src=base/'src'
production=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4/.lake/build/lib/lean')
for p in production.rglob('*'):
 if p.is_file():
  dst=lib/p.relative_to(production);dst.parent.mkdir(parents=True,exist_ok=True)
  if not dst.exists() and not dst.is_symlink():dst.symlink_to(p)
modules=[]
for directory in ['overlay','s1-overlay','s2-overlay','controls']:
 for p in (base/directory).rglob('*.lean'):
  rel=p.relative_to(base/directory);dst=src/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(p.read_text())
  modules.append(str(rel.with_suffix('')).replace('/','.'))
order=['Effect4.Program.Typing.SigData','Effect4.Program.Typing.AnnotateFold','Effect4.Program.Typing.SignatureSupport','Effect4.Program.Typing.Support','Effect4.Program.Check','Effect4.Program.Typing.SourceSession','Effect4.Program.Typing.SourceDocument','Effect4.Program.Typing.FillSet','V1Controls','S1FeedControls','S1DocControls','S2Controls','AuditFresh']
if len(sys.argv)>1:order=order[order.index(sys.argv[1]):]
for name in order:
 rel=Path(*name.split('.'));p=src/rel.with_suffix('.lean');output=lib/rel.with_suffix('.olean');output.parent.mkdir(parents=True,exist_ok=True)
 # Compilation targets and their sidecars are private; never write through dependency links.
 for suffix in ['.olean','.olean.private','.olean.server','.ir','.ir.sig']:
  target=lib/rel.with_suffix(suffix)
  if target.is_symlink():target.unlink()
 r=subprocess.run(['lean','-DwarningAsError=true',f'--root={src}','-o',str(output),str(p)],env={**os.environ,'LEAN_PATH':str(lib)+':'+os.environ.get('LEAN_PATH','')},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (base/f'{rel.name}.fresh.log').write_text(r.stdout)
 print(name,r.returncode,r.stdout[-7000:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)

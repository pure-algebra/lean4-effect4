from pathlib import Path
import os,subprocess,sys
base=Path('/private/tmp/seams-check-sol');stage=sys.argv[1];work=base/(stage+'-full');lib=work/'lib/lean';src=work/'src'
modules=['Effect4.Program.Typing.SourceSession','Effect4.Program.Typing.SourceDocument','Effect4.Program.Typing.FillSet','Effect4.Program.Typing.CheckCache','Effect4.Laws.Program.SourceTable','Effect4.Laws.Program.SourceDocument','Test.Program.SourceFeedControls','Test.Program.SourceDocumentControls','Test.Program.CheckCacheControls']
if stage=='s2':modules+=['Effect4.Laws.Program.FillReference','Effect4.Laws.Program.FillSet','Test.Program.FillSetControls']
p=src/'AuditStage.lean';p.write_text('\n'.join('import '+n for n in modules)+'\nimport ProofGraph.AxiomAudit\n#axiom_audit '+' '.join(modules)+'\n')
r=subprocess.run(['lean','-DwarningAsError=true',f'--root={src}',str(p)],env={**os.environ,'LEAN_PATH':str(lib)+':'+os.environ['LEAN_PATH']},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(work/'audit.log').write_text(r.stdout);print(r.stdout,flush=True);raise SystemExit(r.returncode)

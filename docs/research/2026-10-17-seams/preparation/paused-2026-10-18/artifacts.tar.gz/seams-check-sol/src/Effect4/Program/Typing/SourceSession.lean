import Effect4.Program.Check
import Effect4.Program.Edit
set_option autoImplicit false
set_option maxRecDepth 20000
namespace Effect4.Program
open Check
def Sketch.edit (s : Sketch) (app : SigApp) : Edit → Option Sketch
  | .fill a q => s.fillAt a q
  | .omitAt a row => s.omitAt app a row

/-- **The edit of an expansion at the same address**: a filling by the new expansion's
sub-program there, and an omission as it is. `none` where the new expansion holds no program at
the address. -/
def Edit.expanded (x : Sketch) : Edit → Option Edit
  | .fill a _ =>
    match (Node.eff x.program).at_ a with
    | some (.eff q) => some (.fill a q)
    | _ => none
  | .omitAt a row => some (.omitAt a row)

/-- **What a delta shows, at the source's addresses**: the addresses of a copy are dropped. -/
def Edit.Delta.atSource (sites : List (List Nat)) : Edit.Delta → Edit.Delta
  | .spliced shown => .spliced (shown.filter fun a => !Table.belowSite sites a)
  | d => d

structure SourceSession where
  app : SigApp
  sketch : Sketch
  table : List Table.Entry

namespace SourceSession

def Coherent (s : SourceSession) : Prop := s.table = s.sketch.sourceTable s.app

def shown (s : SourceSession) : EditSession := ⟨s.app, s.sketch, s.table⟩
def view (s : SourceSession) : EditSession.View := s.shown.view

def focusAt (s : SourceSession) (path : List Nat) : Option (Focus NativeOp) :=
  match (Node.eff s.sketch.program).at_ path, Table.typedAt s.table path with
  | some (.eff q), some (env, ty) => some ⟨q, env, ty⟩
  | _, _ => none

def «open» (o : Oracle) (app : SigApp) (sketch : Sketch) : Checked SourceSession := do
  let v ← Checked.ask o (.module app sketch.holes sketch.program)
  pure ⟨app, sketch, v.table⟩

def candidatePartKey (s : SourceSession) (path : List Nat) (candidate : Sketch) : Option CheckInput :=
  match path, s.focusAt path, (Node.eff candidate.expand.program).at_ path with
  | _ :: _, some old, some (.eff q) =>
      some (.part (sketchSigData candidate.expand s.app path) old.env q)
  | _, _, _ => none

def partKey (s : SourceSession) (path : List Nat) (q : NativeEff) : Option CheckInput :=
  (s.sketch.fillAt path q).bind (s.candidatePartKey path)

def expandedEditAgrees (s : SourceSession) (candidate : Sketch) (edit : Edit) : Bool :=
  let expanded := candidate.expand
  match Edit.expanded expanded edit with
  | some expandedEdit =>
      decide ((s.sketch.expand.edit s.app expandedEdit).map (fun y => (y.program, y.holes)) =
        some (expanded.program, expanded.holes))
  | none => false

end SourceSession

inductive FeedPolicy where
  | draft | keepExact | recheck
deriving DecidableEq

inductive FeedRefusal where
  | noProgram (path : List Nat)
  | noFocus (path : List Nat)
  | notKept (focus : TyEnv × EffTy) (verdict : Except TypeRefusal EffTy)
  | refused (why : List TypeRefusal)
  | typeChanged (old : Option EffTy) (new : EffTy)
  | localChanged (old new : Option (TyEnv × EffTy))

namespace SourceSession

def finish (policy : FeedPolicy) (s next : SourceSession) (edit : Edit)
    (step : Edit.Step) (v : Verdict) : Except FeedRefusal (SourceSession × Edit.Step) :=
  match policy, v.result with
  | .draft, _ => .ok (next, step)
  | _, .error _ => .error (.refused next.view.refusals)
  | .recheck, .ok _ => .ok (next, step)
  | .keepExact, .ok ty =>
      if s.view.type != some ty then .error (.typeChanged s.view.type ty)
      else if edit.path != [] && Table.typedAt s.table edit.path != Table.typedAt next.table edit.path
      then .error (.localChanged (Table.typedAt s.table edit.path) (Table.typedAt next.table edit.path))
      else .ok (next, step)

def recheck (o : Oracle) (policy : FeedPolicy) (s : SourceSession) (candidate : Sketch)
    (edit : Edit) (old : NativeEff) : Checked (Except FeedRefusal (SourceSession × Edit.Step)) := do
  let v ← Checked.ask o (.module s.app candidate.holes candidate.program)
  let next : SourceSession := ⟨s.app, candidate, v.table⟩
  pure (finish policy s next edit ⟨edit, some old, .rechecked⟩ v)

def splice (s : SourceSession) (candidate : Sketch) (edit : Edit) (old : NativeEff)
    (part : Verdict) : SourceSession × Edit.Step :=
  let sub := Table.atSource candidate.sites candidate.program.firstRefFault (place edit.path part).table
  let next : SourceSession := ⟨s.app, candidate, Table.splice s.table edit.path sub⟩
  (next, ⟨edit, some old, .spliced (sub.map (·.path))⟩)

def draftOmitAllows (edit : Edit) (ty : EffTy) : Bool :=
  match edit with
  | .fill .. => true
  | .omitAt _ row =>
      decide (row = Row.hole row.name ty.answer ty.error ty.requires.elems) &&
        ty.answer.closed && ty.error.closed && decide (ty.answer.normalize = ty.answer) &&
        decide (ty.error.normalize = ty.error) &&
        (Formation.check (Formation.instantiatedSites row.normalizeTypes [])).isNone

def feed (o : Oracle) (policy : FeedPolicy) (s : SourceSession) (edit : Edit) :
    Checked (Except FeedRefusal (SourceSession × Edit.Step)) := do
  match (Node.eff s.sketch.program).at_ edit.path, s.sketch.edit s.app edit with
  | some (.eff old), some candidate =>
      match edit.path with
      | [] => s.recheck o policy candidate edit old
      | _ :: _ =>
          match policy with
          | .recheck => s.recheck o policy candidate edit old
          | .draft =>
              match s.focusAt edit.path, s.view.type with
              | some focus, some _ =>
                  if !s.expandedEditAgrees candidate edit || !draftOmitAllows edit focus.ty then
                    s.recheck o policy candidate edit old
                  else
                    match s.candidatePartKey edit.path candidate with
                    | none => s.recheck o policy candidate edit old
                    | some key =>
                        let part ← Checked.ask o key
                        match part.result with
                        | .ok ty =>
                            if ty = focus.ty then pure (.ok (s.splice candidate edit old part))
                            else s.recheck o policy candidate edit old
                        | .error _ => s.recheck o policy candidate edit old
              | _, _ => s.recheck o policy candidate edit old
          | .keepExact =>
              match s.focusAt edit.path with
              | none => pure (.error (.noFocus edit.path))
              | some focus =>
                  match s.candidatePartKey edit.path candidate with
                  | none => pure (.error (.noFocus edit.path))
                  | some key =>
                      let part ← Checked.ask o key
                      match part.result with
                      | .error _ => pure (.error (.notKept (focus.env, focus.ty) part.result))
                      | .ok ty =>
                          if ty != focus.ty then pure (.error (.notKept (focus.env, focus.ty) part.result))
                          else if s.expandedEditAgrees candidate edit then
                            pure (.ok (s.splice candidate edit old part))
                          else s.recheck o policy candidate edit old
  | _, _ =>
      match policy with
      | .draft => pure (.ok (s, ⟨edit, none, .unchanged⟩))
      | _ => pure (.error (.noProgram edit.path))

end SourceSession


end Effect4.Program

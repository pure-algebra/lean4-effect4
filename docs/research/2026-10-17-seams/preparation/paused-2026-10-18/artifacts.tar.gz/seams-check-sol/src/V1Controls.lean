import Effect4.Program.Check
set_option autoImplicit false
namespace SeamsV1Controls
open Effect4 Effect4.Program Check
deriving instance DecidableEq for Verdict
def composed (i : CheckInput) := combine i ((deps i).map fun d => run d.input)
def n1 : NativeEff := .succeed (.lit (.nat 1))
def bad : NativeEff := .succeed (.var 0)
def idDecl : DefDecl := { name := "id", request := .nat, answer := .nat }
def idBody : NativeEff := .succeed (.var 0)
def invokeId : NativeEff := .perform (.call 0) (.lit (.nat 5))
def checkedModule : NativeEff := .defs [idDecl] (.cons idBody .nil) invokeId .nil
def badLayers : LayerTerms NativeOp := .cons (.effectDiscard bad) .nil
def withLayers : NativeEff := .defs [] .nil n1 badLayers
def faultMismatch : NativeEff := .defs [idDecl] .nil
  (.provideLayer (.ref [9]) false n1) .nil
def besideRef : NativeEff := .provideLayer (.effectDiscard n1) false
  (.bind (.provideLayer (.ref [0]) false n1) n1)
def controls : List NativeEff :=
  [n1, bad, checkedModule, .defs [] .nil n1 .nil, withLayers,
    .defs [idDecl] .nil invokeId .nil,
    .defs [] (.cons n1 .nil) n1 .nil,
    .defs [{ idDecl with answer := .var 0 }] (.cons idBody .nil) invokeId .nil,
    .defs [idDecl] (.cons (.succeed (.lit (.str "a"))) .nil) invokeId .nil,
    faultMismatch, besideRef]

#guard controls.all fun p => decide (composed (.module {} [] p) = run (.module {} [] p))
#guard (deps (.module {} [] (.defs [] .nil n1 .nil))).length = 1
#guard (run (.part ⟨{}, [], .root⟩ [] (Part.layersProgram .nil))).result.toBool = false
#guard (run (.module {} [] (.defs [] .nil n1 .nil))).result.toBool = true
#guard ((run (.module {} [] withLayers)).result.toOption).isNone
#guard ((Checker.refusal (composed (.module {} [] withLayers)).result).map (·.path)) =
  some [2, 0, 0]
#guard ((Checker.refusal (composed (.module {} [] faultMismatch)).result).map (·.reason.head)) =
  some "referenceIllFormed"
#guard ((Checker.refusal (Checker.checkModule ({} : SigApp).signature faultMismatch.expandRefs)).map
  (·.reason.head)) = some "definitionsMismatch"
#guard combine (.module {} [] checkedModule) [] = run (.module {} [] checkedModule)

def oneRow : SigData := ⟨{ rows := [Row.hole "a" .nat] }, [], .root⟩
def twoRows : SigData := ⟨{ rows := [Row.hole "a" .nat, Row.hole "b" .string] }, [], .root⟩
def extCall : NativeEff := .perform (.external 0) (.lit .unit)
def nextCall : NativeEff := .perform (.external 1) (.lit .unit)
#guard oneRow.extendsB twoRows
#guard run (.part oneRow [] extCall) = run (.part twoRows [] extCall)
#guard run (.part oneRow [] nextCall) != run (.part twoRows [] nextCall)


#guard (Checked.ask Oracle.uncached (.part oneRow [] extCall)).trace.length = 1
#guard (Checked.ask Oracle.uncached (.module {} [] n1)).trace.length = 1
#guard (Checked.ask Oracle.uncached (.module {} [] (.defs [] .nil n1 .nil))).trace.length = 1
def moduleTrace := Checked.ask Oracle.uncached (.module {} [] checkedModule)
def learned := Memo.empty.learn moduleTrace
#guard learned.entries.length = (deps (.module {} [] checkedModule)).length
#guard (deps (.module {} [] checkedModule)).all fun d =>
  learned.entries.any (HitRule.exact.hit d.input)
end SeamsV1Controls

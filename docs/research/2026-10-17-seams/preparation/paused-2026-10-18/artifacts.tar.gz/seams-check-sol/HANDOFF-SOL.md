# Check and FillSet scout handoff

The S2 connector laws need explicit fragment hypotheses.
A reference-free base alone does not establish `kept_eq_certified`.
Publication agreement also needs a positive base-check premise.
The finite controls below establish both boundaries without restricting the new feed.

The parent requests a GPT-6.1 Sol agent for all further work.
This agent stops after writing this handoff.
It changes no production source and makes no commit.

## Runtime state

The production worktree is `/Users/pooks/.codex/worktrees/seams/lean4-effect4`, on `codex/seams`.
The last observed HEAD is `faa7d0122bd550186e4c622517509ac001763a35`.
The parent and the S0 agent own its current edits.
Recheck their state before integrating any proposal.

All proposal files and logs live in `/private/tmp/seams-check-scout`.
No command or tool session remains active for this scout.
The last session, `70998`, exits 0.
The earlier S1 batch session, `88267`, also exits 0.

Tell the parent before queueing Lean.
Run every Lean command from the production worktree through this strict wrapper:

```text
python3 /private/tmp/seams-lean-one.py <command>
```

The wrapper acquires `/private/tmp/effect4-seams-single-lean.lock`.
It invokes the main checkout's `scratch/lean-slot.sh` with `LEAN_NUM_THREADS=3`.
Batch scripts inside that wrapper invoke raw, sequential Lake commands.
They must not reacquire the wrapper's lock.
Worktree commands require the existing sandbox escalation mechanism.

## Saved V1 and S1 work

`REPORT.md` records V1 decomposition, trace choices, core proof extraction, and exact extension hits.
`S1-REPORT.md` records the source-table representation, document interpreter, caller ownership, and checked controls.
Both reports distinguish proof results from finite evidence.
The S1 report passes the strict language check.

| Files | Checked evidence |
| --- | --- |
| `CheckProbe.lean` | Exact `run_placed` and full-verdict `run_part_extends`; finite module-decomposition controls |
| `CoreFactsProbe.lean`, `ContextProbe.lean`, `AnnotateFoldProbe.lean`, `CoreSupportProbe.lean` | Core proof extraction and a certified extension hit without running the checker again |
| `SupportProbe.lean`, `HitProbe.lean` | Positive support guards preserve every planned positive extension hit |
| `S1FeedProbe.lean` | Source-table storage, candidate part keys, policy feed, root checking, and whole-expansion guards |
| `S1DocProbe.lean` | One action interpreter, sealed history, replay, atomic batches, and reverse revert |
| `S1DocControls.lean` | The exact first loop and every S1 acceptance case |

`combine_deps` remains a universal proof obligation.
The finite decomposition controls do not prove it.
Existing `Annotate.check_restrict` already proves full table equality for extension.
The plan incorrectly describes that table half as fresh work.

The extracted core proof audit reports 584 declarations within `[propext, Quot.sound]`.
The hit audit reports 32 declarations under that ceiling.
The Laws audit reports 247 declarations under that ceiling.
Each audit reports zero planned goals and zero declarations modulo goals.
Their logs are `AuditCore.log`, `AuditHit.log`, and `AuditLaws.log`.

The final S1 batch compiles all four inputs and reports:

```text
#axiom_audit: 604 declarations within [propext, Quot.sound], 0 of them modulo planned goals; 0 planned goals
```

Its script is `run-s1-probes.py`.
Its logs are `S1FeedProbe.compiled.log`, `S1DocProbe.compiled.log`, `S1DocControls.compiled.log`, and `AuditS1.compiled.log`.
First failures remain beside the successful logs.
These runs do not replace a slice's narrow build, battery gate, or OCaml gate.

### S1 integration boundaries

Move `S1FeedProbe` into `Program/Typing/SourceSession.lean`.
Move `S1DocProbe` into `Program/Typing/SourceDocument.lean`.
Place public source-table laws in `Laws/Program/SourceTable.lean`.
Place public document laws in `Laws/Program/SourceDocument.lean`.
Move the controls into the slice's battery and migrate the callers listed in `S1-callers.txt`.

Use S0's `Check.Oracle`, `Check.Checked`, and `Check.Oracle.eq_uncached`.
Its methods are `Checked.bind'` and `Checked.pure'`.
Remove the temporary checked scaffolding during integration.
The production source session must not import old `CheckCache`.
The production document must not import Laws.

The core replay constructors have full proofs.
Universal `feed_draft`, `feed_keepExact`, and source-table coherence remain Laws obligations.
Retain their exact statements, proved or placed as legitimate planned goals.

The S1 report preserves the old `Doc.commit_sound` statement verbatim.
It also records the accepted local edit on an invalid root.
The new `keepExact` law retains exact root and local observations, including a root observation of `none`.
A positive-root corollary requires an old-positive-root premise for that policy.
No accepted-commit-implies-admission claim follows.

Replay needs temporary history receipts to interpret `revert`.
`DocInternal.replayState_snoc` proves the corrected append equation before projecting the session.
The report retains a same-origin, same-revision, same-session control with different revert results.

## S2 finite controls

`S2BoundaryProbe.lean` imports `S1DocControls` and the existing FillSet laws.
Its placement serves `kept_eq_certified` and `publish_eq_materialize` under `initial-algebras-folds`, R14.
It proves neither universal connector.

The final command exits 0:

```text
python3 /private/tmp/seams-lean-one.py env LEAN_PATH=/private/tmp/seams-check-scout lake env lean -DwarningAsError=true --root=/private/tmp/seams-check-scout -o /private/tmp/seams-check-scout/S2BoundaryProbe.olean /private/tmp/seams-check-scout/S2BoundaryProbe.lean
```

The retained `S2BoundaryProbe.first.log` reports:

```text
S2 boundaries: filling references, positive-base materialization, joint refusal, and root exclusion pass
```

### Filling references

`SeamsS2BoundaryScout.base` is reference-free.
Its first child contains a string service layer at `[0, 0]`.
`withRef` provides that layer through a reference and returns a natural number.

Old `certifiedB base appA [1] withRef` returns false.
The new `keepExact` feed accepts that filling at `[1]`.
Its resulting table equals `sourceTable`.
Therefore, reference freedom of the base alone cannot support the planned certification connector.
Require reference freedom of the filling too, or an equally strong expansion-inert premise.
Keep the new feed's reference support unchanged.

Replacing the first child with a natural-number literal also accepts separately.
Publishing both edits in address order refuses after the first edit removes the referenced layer.
Old `materialize` refuses the same pair.
This control retains the need for D9's reference-free filling premise.

### Positive base observation

`broken` is `.bind n1 (.succeed (.var 2))`.
Both the base and the filling `n7` are reference-free.
Old `certifiedB broken {} [0] n7` returns true.
The new document commits that filling and retains a refused root.
Its source table remains exact.
Old `materialize` refuses because it checks the whole resulting root.

Therefore, `publish_eq_materialize` needs a positive base-check premise.
Reference freedom alone does not establish its observation.
This does not require positivity for the local certification connector.

### Root exclusion

Old certification refuses a root address, including reference-free literals.
The new root feed can accept the same replacement through a module check.
Retain the non-root premise in `kept_eq_certified`.

## Existing D1–D9 premises

Read these owners before changing any statement:

- `src/Effect4/Program/Typing/FillSet.lean`
- `src/Effect4/Laws/Program/FillSet.lean`
- `Test/Program/FillSetControls.lean`
- `docs/research/2026-10-17-seams/interfaces.md`, sections 4.2, 5, and 6
- `docs/research/2026-10-17-seams/interface-probe/SeamsInterfaces.lean`, `FillSpec`
- `docs/research/2026-10-17-session-composition/plan.md`, sections 3 and 4

| Law | Premises or observation that must remain |
| --- | --- |
| D1 `Table.typedAt_splice_outside` | The observed address lies outside the replaced subtree |
| D2 `at_replaceAt_incomparable` | The two addresses are incomparable |
| D3 `sigAt_fillAt` | The edited address is non-root |
| D4 `focusAt_fill_incomparable` | A checked base, non-root edit, raw focus, exact `HasTy`, successful replacement, and incomparable observed focus |
| D5 `fills_compose` | A checked base, pairwise incomparable addresses, and old `Certified` for each filling |
| D6 `materialize_congr` | Equal membership and no conflicts on both lists; the observation is canonical materialization |
| D7 `ordered_compose` | A checked base, conflict freedom, incomparability, and certification |
| D8 `refSites_replaceAt_nil` | Both base and filling are reference-free |
| D9 `materialize_refFree` | A checked base, conflict freedom, pairwise incomparability, certification, and reference-free base and fillings |

Old `Certified` combines a non-root address, raw `focusAt`, and exact `HasTy` at the original signature.
New certification must describe acceptance by the source-session feed.
The reference control prevents identifying those predicates globally.
Bridge them only on their stated fragment.

## Next implementation steps

No S2 implementation or S2 axiom gate exists yet.
Continue in the isolated directory until the parent authorizes production integration.

Implement the private FillSet with its anchor, base, application, entries, and constructed witness.
Open it only from a sealed document.
Certify each candidate through the anchor source session's `keepExact` feed.
Discard the returned session while retaining the checked trace.

Retain outcome precedence: root, unknown address, duplicate or conflict, overlap, then certification.
Publish one ordered `.commit` under `keepExact`, using expected subprograms from the base.
Keep snapshot validation and pending reset in the tool wrapper.
The FillSet itself receives no current document during `add`.

For the constructed witness, consider a pure canonical `addRaw` and a checked fold over the same step.
Use `Checked.fold_value`, `Oracle.eq_uncached`, and `List.foldl_append` to extend its existential submission witness.
Core constructors cannot rely on planned goals.
The witness need not retain prior submissions at runtime.

Preserve the second loop's three holes at `[0]`, `[1, 0]`, and `[1, 1]`.
Good, bad, good submissions must yield applied, not-certified, applied.
Publication must produce one revision and reset pending entries.
Retain duplicate, conflict, overlap, root, unknown, foreign, stale, empty-follow, reference, and omission controls.

Check the full-anchor boundary before choosing its theorem statement.
Old controls compare identity, revision, base, and application.
The new snapshot is scoped to its resolved state.
Separately opened documents may share identity and revision while differing elsewhere.
Whether the tool's state scope excludes that case remains unverified.
Read the session-composition review's R3 boundary before proposing a correction.

The plan eventually deletes the old `Program.materialize` surface.
Decide how Laws retains its reference observation without keeping a production forwarding alias.
No replacement owner or name has been selected.

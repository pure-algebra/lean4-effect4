# V1 and S1 scout

The existing laws prove both halves of positive part extension, including the whole annotation table.
The proposed support guard makes that law usable by a core hit rule without a checker call on a hit.

The scout changes no production file and creates no commit.
The inspected worktree has base `c752e565b4e1afac95d1258b0a4a570b81bcdf81` on `codex/seams`.
The parent owns its uncommitted changes.

## Evidence

| Artifact | Evidence status | Scope |
| --- | --- | --- |
| `CheckProbe.lean` and `CheckProbe.checked.log` | Lean-checked with warnings treated as errors | Exact `run_placed`, exact `run_part_extends`, and finite decomposition controls |
| `SupportProbe.lean` and `SupportProbe.checked.log` | Lean-checked with warnings treated as errors | The executable support fold, its connector, positive-answer support, and guarded annotated equality |
| `CoreFactsProbe.lean` and `CoreFactsProbe.compiled.log` | Lean-checked and axiom-gated | The exact pure proof owners, with no Laws import |
| `ContextProbe.lean` and `ContextProbe.compiled.log` | Lean-checked and axiom-gated | The existing context loop proof under core imports |
| `HitProbe.lean` and `AuditHit.log` | Lean-checked and axiom-gated | The actual certified extension rule, positive-hit retention, and finite controls |
| `AuditLaws.lean` and `AuditLaws.log` | Axiom-gated | `CheckProbe` and `SupportProbe` at `[propext, Quot.sound]` |
| `CoreSupportProbe.lean` and `AuditCore.log` | Lean-checked and axiom-gated | The core restriction proof and support-guard constructor |

All artifacts live in `/private/tmp/seams-check-scout`.
The files named `*.first.log` retain the first failures.
`CheckProbe.first.log` records an unused argument and a `.str` spelling error for `Ty.string`.
`SupportProbe.first.log` records mechanical generation errors and unused simplification arguments.
Neither first failure refutes a planned law.

The commands run from `/Users/pooks/.codex/worktrees/seams/lean4-effect4`.
The first outer command is `python3 /private/tmp/seams-lean-one.py python3 /private/tmp/seams-check-scout/run-probes.py`.
That script runs these commands serially:

```text
lake env lean -DwarningAsError=true /private/tmp/seams-check-scout/CheckProbe.lean
lake env lean -DwarningAsError=true /private/tmp/seams-check-scout/SupportProbe.lean
lake env lean -DwarningAsError=true /private/tmp/seams-check-scout/ContextProbe.lean
```

The outer guard acquires one file lock before entering the required shared launcher with `LEAN_NUM_THREADS=3`.
The inner script does not acquire the lock again.
The final command is `python3 /private/tmp/seams-lean-one.py python3 /private/tmp/seams-check-scout/run-final-probes.py`.
Its script names every compiled file and every axiom-gate command.
Its log files contain the current checked results.

## Exact extension without a checker call

`Annotate.check_restrict` already proves equality of the whole annotated answer under signature support.
Its owner is `src/Effect4/Laws/Program/Typing/Restrict.lean`.
`hasTy_sigProgram` in that file derives support from typing.
`check_sound` in `src/Effect4/Laws/Program/Typing/CheckSound.lean` derives typing from a positive checker answer.

The checked proof in `CheckProbe.lean` composes those declarations with `SigData.extends_of_extendsB`.
That declaration lives in `src/Effect4/Laws/Program/Typing/CheckCache.lean`.
The plan labels the table half as new work.
The existing restriction theorem already proves the required property.
The exact full-verdict law remains unchanged.

```mermaid
flowchart LR
  P[Positive old part answer] --> T[check_sound]
  T --> S[hasTy_sigProgram]
  S --> B[Executable support guard succeeds]
  B --> A[Annotate.check_restrict]
  E[SigData.extendsB succeeds] --> X[SigData.extends_of_extendsB]
  X --> A
  A --> V[Equal full part verdicts]
```

`supportB` folds the existing program signature into `Bool`.
It tests operation membership, declared service keys, and declared definitions.
It conjoins those tests over every child.
It does not call `Checker.check`, `Annotate.check`, or `Check.run`.

`readsBoolHom` uses the generated `EffHom` interface.
`hom_eq_cata_eff` proves `(supportB s q = true) = SigProgram s q`.
This uses the existing fold owner instead of a second traversal induction.

The proposed hit predicate retains the old checks and adds the support guard:

```lean
match input, entry.1 with
| .part newer env p, .part older oldEnv oldP =>
    decide (oldP = p) && decide (oldEnv = env) && older.extendsB newer &&
      entry.2.result.toBool && supportB older.signature oldP
| _, _ => false
```

The core `sound` field needs only the support connector and guarded annotated equality.
The Laws theorem `support_of_positive` proves that every planned positive hit passes the added guard.
A negative answer cannot transfer merely because its signature extends.
The finite control uses an absent external row that the larger signature adds.

### Pure proof owners

Moving whole Laws modules into core imports Aesop through `CheckSound` and `CheckInversion`.
Move only the following existing declarations, with their names and statements unchanged.

| Existing owner | Declarations needed by core |
| --- | --- |
| `src/Effect4/Laws/Program/Signature.lean` | `argTy_congr`, `argsTy_congr`, `termTy_congr`, `causeTy_congr`, `SigExtends`, its pure methods, `rows_append`, `SigApp.rows_append` |
| Same owner | `EffAlgebra.AgreeOn`, `readsAlg`, the seven `cata_*_congr_on` declarations, `SigOkOp`, `SigOkKey`, `SigOkDef`, `SigProgram` |
| Same owner | `termDiagnostic_ext`, `termRefusal_ext`, `term?_ext`, `cause?_ext` |
| `src/Effect4/Laws/Program/Definitions.lean` | `Signature.withDefs_dom_of_none`, `Signature.withDefs_rowOf_of_none`, `Signature.withDefs_dom_call`, `Signature.withDefs_rowOf_call`, `SigExtends.withDefs`, `SigExtends.withParams` |
| `src/Effect4/Laws/Program/Sketch.lean` | `SigApp.withHoles_extends` |
| `src/Effect4/Laws/Program/Typing/CheckCache.lean` | `SigData.extends_of_extendsB` |
| `src/Effect4/Laws/Program/Typing/Annotate.lean` | The `fold_of Effect4.Program.Annotate.check` invocation |
| `src/Effect4/Laws/Program/Typing/CheckInversion.lean` | `Checker.context_keys_eq_ok`, without its Aesop attribute |
| `src/Effect4/Laws/Program/Typing/Restrict.lean` | `Annotate.check_alg_agreeOn`, `Annotate.check_restrict` |

`Annotate.check_alg_agreeOn` has one branch that calls `checkAction_complete`.
Replace only that call with the existing context loop proof.
`ContextProbe.lean` supplies the resulting direct checker equation.

Reapply the existing semantics and Aesop attributes in the importing Laws modules.
That keeps their metadata without making core import Laws.
`CoreFactsProbe.lean` contains the extraction and the rewritten context branch.
Its production import must use the extracted `SigData` owner instead of the old `CheckCache` owner.
Keep the `fold_of` invocation in a separate imported module.
The same-file probe triggers a Lean constant-realization error.

The signature-data owners must stay non-module under the row-202 exception.
Their dependency is `SigApp` through `Columns` to `Program.Typed`.
`CoreFactsProbe.module-control.log` records Lean refusing a module import of the existing non-module owner.
The annotated-fold and context-loop owners use `module`, `public import`, and `@[expose] public section`.

`PartSig`, `SigData`, `bodyIndex`, `partSigAt`, and `sketchSigData` must leave `CheckCache` first.
The existing import order reaches `SourceDocument` before defining them.
A new `Check` imported by `SourceSession` would otherwise form a cycle.

### Placement

| Obligation | Concept and question | Reach | Exclusion | Consumer |
| --- | --- | --- | --- | --- |
| `supportB_eq` | `initial-algebras-folds`; helper of `run_part_extends` | Every program and signature | Typing and positive answers | Core extension rule, R14 |
| `support_of_positive` | Same concept; helper of `run_part_extends` | A positive uncached part answer | Module admission and runtime cost | Positive extension-hit retention, R14 |
| `run_placed` | Same concept; checker-base naturality | Full annotated part verdict at every base | Source/module projection | Internal dependency placement, R14 |
| `run_part_extends` | Same concept; signature extension | Equal full verdicts after a positive old answer and `extendsB` | Negative extension hits | Extension rule, R14 |
| `combine_deps` | Same concept; source checking | Exact source verdict from every canonical dependency answer | Cost and host behavior | Module ask, R14 |
| `explain_replays` | Same concept; located checking | A canonical local dependency reproduces the placed refusal | Aggregate failures | Explanation consumer, R14 |

Keep `combine_deps` exact if it remains a planned goal.
A properly placed goal in Laws may support `Checked.ask_value`.
No core constructor may use that goal.

## Module decomposition and traces

`CheckProbe.lean` contains executable `deps`, `joinBodies`, `joinModule`, and `combine` proposals.
It handles matched bodies, unmatched body tails, the main program, and a nonempty layer spine.
Its wrong-count fallback is lazy.
Do not use `Option.getD (run input)`, which evaluates the fallback before selection.

| Case | Required behavior | Control |
| --- | --- | --- |
| Nonempty layers | Project `[0,0] ++ p` to `[2] ++ p`; discard wrapper entries | Bad layer refusal reaches `[2,0,0]` |
| Empty layers | Emit the direct empty-spine entry; ask no synthetic layer part | Synthetic empty `mergeAll` refuses while the module accepts |
| Reference fault | Override structural module refusal before returning | A bad reference wins over `definitionsMismatch` |
| Mismatched body count | Reconstruct the table and refuse the root mismatch | Missing and extra body controls |
| Aggregate body error | Keep `Explanation.part = none` | Every part accepts, while the module refuses `bodyNotDeclared` |
| Source references | Filter copied addresses using the original source sites | The composed source table equals the existing source table |
| Root program block | Ask the module key | The same block refuses as a part |
| Wrong dependency count | Return `run input` | Empty supplied answers for a nonempty dependency list |

The complete `combine_deps` theorem remains open in this scout.
The finite controls do not prove it.

A module ask can record only its actual part asks.
The plan requires learning those parts and does not require a synthetic module entry.
`Checked.valid` constrains the trace, not the returned value.
The probe's downstream consumers use the trace only in `bind` and `Memo.learn`.
Thus core trace validity needs no module-combination law.

The module arm can construct its trace with `(deps input).map (fun d => (d.input, oracle.ask d.input))`.
Its value combines the second projections.
`List.mem_map` and `oracle.agrees` prove every trace entry valid.
The public `ask_value` law then follows from `combine_deps` in Laws.
A root control must distinguish a valid block module from the same block checked as a part.
It must not require a synthetic module trace entry.

Use these trace controls when landing V1:

1. Check that a part ask records its one part entry.
2. Check that a plain module asks its expanded program as one part.
3. Check that an empty layer spine adds no layer dependency.
4. Learn a module trace, then show its part requests hit the memo.
5. Check that the module result remains `combine` of those answers.

## S1 source-session corrections

`SourceSession.expanded.table` stores the whole expanded table.
`Check.run (.module app holes source)` returns the filtered source table.
Assigning the latter to the former violates the existing coherence statement when references create copies.

The proposed correction stores the source table directly beside the application and source sketch.
`SourceSession.Coherent` then states equality with `Sketch.sourceTable`.
The current production `.expanded` field has no callers outside `SourceSession.lean`.
Its proofs live in `src/Effect4/Laws/Program/SourceTable.lean` and need the corresponding migration.

The whole-expansion guard still compares both expanded programs and hole tables.
Compute expansions as data, without running the checker.
A reference elsewhere can change its copy when the target body changes.
The existing `referencedBody` control in `review-probes/SeamsCheckingControls.lean` requires `.rechecked` in that case.

`partKey` must inspect the candidate's whole expansion.
Expanding a filling alone loses references to surrounding source addresses.
The existing `refBase` and `refFilling` control proves that distinction.
Use the source session's focus environment, not the raw source sketch's focus.
The existing `besideRef` control has a source focus while its raw focus is absent.

Use one internal candidate-key helper for fills and omissions.
An omission's candidate has the appended hole row.
A filling's public `partKey` can call that helper after constructing its candidate.
At `[]`, return no part key and route the edit through a module ask.

`draft` currently returns an unchanged session and `.unchanged` step for an invalid path.
The plan explicitly retains today's `feedStep` behavior for draft.
Apply `noProgram` to strict policies while keeping this draft behavior.
Record the correction with the invalid-path control in `HitProbe.lean`.

For `keepExact` below the root, a refused or different part answer yields `notKept` without a module ask.
A kept part splices only when the whole-expansion guard succeeds.
Otherwise a module ask precedes root-type and local-type comparisons.
A root edit always asks the module key and never splices.

## Caller migration

`CheckCache.lookup` must disappear in V1.
Its direct implementation caller is `CheckCache.evaluateCandidate`.
The old tool driver stores `List CheckCache.Entry`, and `SuggestResult` returns that cache.
Move that caller to `Memo.oracle` and learning while the remaining suggestion surface survives until its assigned cut.
Do not retain an alias named `lookup`.

`Run.Kit.check` currently calls `Api.check` and projects the accepted type.
Make it the named empty-hole restriction of `Check.run`.
The tools' `Sketch.check` calls also move in V1.
Avoid silently replacing unrelated raw-checking theorem premises with source checking.
`Tools.Query.fillPremises` and `omitPremises` remain scheduled for deletion in S3a.

## Remaining work

The parent must implement and build the landed modules after S0.
The scout does not certify the full dependency graph, OCaml lowering, or the behavior gates.
The landing must add the new semantics registry placement and its receipt.
The landing must delete each assigned old owner after its callers move.

from pathlib import Path
b=Path('/private/tmp/seams-check-sol');s=(b/'caller-overlay/src/Effect4/Program/Typing/CheckCache.lean').read_text()
s=s.replace('  | differentEnv (sourceEnv targetEnv : TyEnv)','  | feedRefused (why : FeedRefusal)\n  | differentEnv (sourceEnv targetEnv : TyEnv)')
a=s.index('def evaluateCandidate');z=s.index('/-- Harvest local',a)
s=s[:a]+'''def suggestOne (o : Oracle) (d : Doc) (focus : Focus NativeOp)
    (path : List Nat) (sourcePath : Option (List Nat)) (sourceEnv : TyEnv)
    (program : NativeEff) : Checked Suggestion := do
  let candidate := (d.session.sketch.fillAt path program).getD d.session.sketch
  let key := (d.session.partKey path program).getD
    (.module d.session.app candidate.holes candidate.program)
  if sourceEnv ≠ focus.env then
    return ⟨program,sourcePath,key,.differentEnv sourceEnv focus.env⟩
  match ← d.session.feed o .keepExact (.fill path program) with
  | .ok _ => return ⟨program,sourcePath,key,.exactFit focus.ty⟩
  | .error (.notKept _ verdict) =>
    let evidence := match verdict with
      | .ok actual => Evidence.typeMismatch focus.ty actual
      | .error why => .refused ⟨path ++ why.path,why.reason⟩
    return ⟨program,sourcePath,key,evidence⟩
  | .error why => return ⟨program,sourcePath,key,.feedRefused why⟩

def suggestPage (o : Oracle) (d : Doc) (focus : Focus NativeOp) (path : List Nat) :
    List (Option (List Nat) × TyEnv × NativeEff) → Checked (List Suggestion)
  | [] => pure []
  | (sourcePath,sourceEnv,program) :: rest => do
    let item ← suggestOne o d focus path sourcePath sourceEnv program
    let later ← suggestPage o d focus path rest
    pure (item :: later)

'''+s[z:]
s=s.replace('evaluateCandidates o sig focus.env focus.ty path page','suggestPage o d focus path page')
out=b/'s2-callers/src/Effect4/Program/Typing/CheckCache.lean';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
p=b/'s1-overlay/Effect4/Program/Typing/SourceSession.lean';t=p.read_text().replace('  | localChanged (old new : Option (TyEnv × EffTy))','  | localChanged (old new : Option (TyEnv × EffTy))\nderiving DecidableEq');p.write_text(t)
p=b/'s2-callers/tools/Tools/Session.lean';t=p.read_text().replace('  | .differentEnv sourceEnv targetEnv =>','  | .feedRefused _ => Json.mkObj [("kind",.str "feedRefused")]\n  | .differentEnv sourceEnv targetEnv =>');p.write_text(t)

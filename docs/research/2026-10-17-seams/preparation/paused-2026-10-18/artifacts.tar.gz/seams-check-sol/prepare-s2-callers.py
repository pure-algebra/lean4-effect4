from pathlib import Path
import re
b=Path('/private/tmp/seams-check-sol');out=b/'s2-callers/tools/Tools/Session.lean';out.parent.mkdir(parents=True,exist_ok=True)
s=(b/'s1-callers/tools/Tools/Session.lean').read_text()
s=s.replace('FillSet.ofDoc','FillSet.open_')
for name in ['fs0','fs','fresh',"fs'"]:
 s=s.replace(name+'.doc',name+'.anchor.doc').replace(name+'.revision',name+'.anchor.revision').replace(name+'.view',name+'.pending')
s=s.replace('fs.anchor.doc != d.id || fs.anchor.revision != d.revision','fs.anchor.doc != d.id || fs.anchor.revision != d.revision || fs.base != d.session.sketch || fs.app != d.session.app')
s=s.replace("let (fs', outs) := fs0.add items", "let checked := fs0.add (st.cache.oracle (Check.HitRule.exact.or Check.extension)) items\n          let (fs',outs) := checked.value")
s=s.replace("let st' := { st with fills := some fs' }", "let st' := { st with fills := some fs', cache := st.cache.learn checked }")
a=s.index('/-- A materialization refusal');z=s.index('/-- Parse a call selector',a);s=s[:a]+s[z:]
a=s.index('      | "fills.materialize" =>');z=s.index('      | "replace"',a)
s=s[:a]+'''      | "fills.materialize" =>
        let fs := st.fillsFor d
        match d.check fs.anchor with
        | .error why => (st, { op := op, app := st.app, ok := false,
            result := editRefusalJson sig (some l.sketch.program) why,
            error := some "the fill anchor is stale", id := req.id })
        | .ok () =>
          if fs.base != d.session.sketch || fs.app != d.session.app then
            none' "the fill anchor holds another base or application"
          else
            match fs.publication with
            | .error .empty => none' "the fill set holds no fill"
            | .ok action =>
              let checked := d.step (st.cache.oracle (Check.HitRule.exact.or Check.extension)) fs.anchor action
              let learned := { st with cache := st.cache.learn checked }
              match checked.value with
              | .error why => (learned, { op := op, app := st.app, ok := false,
                  result := editRefusalJson sig (some l.sketch.program) why,
                  error := some "the publication is refused", id := req.id })
              | .ok (next,receipt) =>
                let updated := { (learned.withDoc next) with journal := receipt.steps.reverse ++ st.journal,
                  fills := some (FillSet.open_ next) }
                (updated,Answer.mk op st.app [``FillSet.add_wf,``SourceSession.reached_view] true
                  (Json.mkObj [("doc",docIdJson next.id),("revision",toJson next.revision),
                    ("view",viewJson next.session)]) none req.id)
'''+s[z:]
out.write_text(s)

import Effect4.Program.Typing.FillSet
import S1DocControls
set_option autoImplicit false
namespace SeamsS2Controls
open Effect4 Effect4.Program Check
open SeamsV1Controls (n1)
open SeamsS1Controls.FeedControls (n7 str)
def h : Row := Row.hole "nat" .nat
def base : Sketch := ⟨.bind (Sketch.hole {} 0)
  (.bind (Sketch.hole {} 1) (Sketch.hole {} 2)), [h,h,h]⟩
def doc : Doc := (Doc.open_ ⟨⟨"fills",0⟩,{},base⟩).value
def start : FillSet := FillSet.open_ doc
def added := start.add Oracle.uncached [([0],n1),([1,0],str),([1,1],n7)]
#guard added.value.2 = [.applied [0],.refused [1,0] .notCertified,.applied [1,1]]
def pending := added.value.1
#guard pending.pending = [([0],n1),([1,1],n7)]
#guard pending.anchor.revision = 0
#guard match pending.publication with
  | .ok (.commit items .keepExact) => items.length = 2
  | _ => false
def action : DocAction := pending.publication.toOption.getD (.commit [] .keepExact)
def published := doc.step Oracle.uncached pending.anchor action
def next : Doc := (published.value.toOption.map Prod.fst).getD doc
#guard next.snap.revision = 1
#guard next.history.length = 1
#guard (FillSet.open_ next).pending = []
#guard match next.check pending.anchor with | .error (.stale _) => true | _ => false
#guard (start.add Oracle.uncached [([],n1),([9],n1)]).value.2 =
  [.refused [] .root,.refused [9] .unknownAddress]
#guard (pending.add Oracle.uncached [([0],n1),([0],n7)]).value.2 =
  [.collapsed [0],.refused [0] .conflict]
#guard (pending.add Oracle.uncached [([1],.bind n1 n7)]).value.2 =
  [.refused [1] (.overlap [1,1])]
#guard match start.publication with | .error .empty => true | _ => false
#guard match doc.check ⟨⟨"foreign",0⟩,0⟩ with | .error (.foreign _) => true | _ => false
-- References certify at the whole anchor expansion; publication rechecks dependencies.
def key : ServiceKey := ⟨⟨127⟩,⟨127⟩⟩
def app : SigApp := { services := [(key,.string)] }
def referenceBase : Sketch := ⟨.bind (.provideLayer (.effect key str) false n1) n7,[]⟩
def referenceFill : NativeEff := .provideLayer (.ref [0,0]) false n7
def refDoc : Doc := (Doc.open_ ⟨⟨"refs",0⟩,app,referenceBase⟩).value
def refSet := (FillSet.open_ refDoc).add Oracle.uncached [([1],referenceFill),([0],n7)]
#guard refSet.value.2 = [.applied [1],.applied [0]]
def refAction := refSet.value.1.publication.toOption.getD (.commit [] .keepExact)
#guard (refDoc.step Oracle.uncached refSet.value.1.anchor refAction).value.toOption.isNone
end SeamsS2Controls

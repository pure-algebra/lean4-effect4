import os, subprocess, pathlib, sys
root=pathlib.Path('/private/tmp/seams-check-scout')
env=dict(os.environ)
env['LEAN_PATH']=str(root)+(':'+env['LEAN_PATH'] if env.get('LEAN_PATH') else '')
for name in ['S1FeedProbe', 'S1DocProbe', 'S1DocControls', 'AuditS1']:
    with (root/(name+'.compiled.log')).open('w') as log:
        p=subprocess.run(['lake','env','lean','-DwarningAsError=true','--root='+str(root),'-o',str(root/(name+'.olean')),str(root/(name+'.lean'))],env=env,stdout=log,stderr=subprocess.STDOUT)
    print(name,p.returncode,flush=True)
    if p.returncode: sys.exit(p.returncode)

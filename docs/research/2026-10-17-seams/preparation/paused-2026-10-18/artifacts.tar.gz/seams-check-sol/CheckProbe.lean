import Effect4.Program.Typing.CheckCache
import Effect4.Laws.Program.Typing.CheckCache
import Effect4.Laws.Program.Typing.Restrict
import Effect4.Laws.Program.Typing.Rebase

/-!
V1 scout only. The production tree is unchanged.

Placement for both connector proofs:
1. Concept: initial-algebras-folds; checker-base-natural and signature extension.
2. Question: Check's proposed run_placed and run_part_extends compatibility claims.
3. Reach: an annotated part, including its table. Extension requires a positive old answer.
4. Exclusions: module admission, negative extension hits, cost, and native translation.
5. Consumer: Check.Internal.combine and Check.extension. Requirement R14.

The combinator below is an executable draft. Its universal agreement remains an obligation.
The guards are finite controls, not that proof.
-/

set_option autoImplicit false
set_option maxRecDepth 20000

namespace SeamsCheckScout
open Effect4 Effect4.Program
open Conform.Effect4.Typing

inductive Input where
  | module (app : SigApp) (holes : RowTable) (program : NativeEff)
  | part (sig : SigData) (env : TyEnv) (program : NativeEff)
deriving DecidableEq

structure Verdict where
  result : Except TypeRefusal EffTy
  table : List Table.Entry
deriving DecidableEq

def run : Input → Verdict
  | .module app holes p =>
    let s : Sketch := ⟨p, holes⟩
    ⟨s.sourceCheck app, s.sourceAnnotate app⟩
  | .part d env q =>
    let out := Annotate.check d.signature env [] q
    ⟨out.2, out.1⟩

def place (base : List Nat) (v : Verdict) : Verdict :=
  ⟨v.result.mapError (TypeRefusal.rebase base), v.table.map (Table.Entry.rebase base)⟩

theorem run_placed (d : SigData) (env : TyEnv) (q : NativeEff) (base : List Nat) :
    place base (run (.part d env q)) =
      ⟨(Annotate.check d.signature env base q).2,
        (Annotate.check d.signature env base q).1⟩ := by
  simp only [place, run, Annotate.check_eq]
  have ht := tableAt_rebase d.signature (some (.env env)) (.eff q) base []
  have hr := Checker.check_rebase d.signature base env [] q
  simp only [List.append_nil] at ht hr
  rw [← ht, ← hr]

theorem run_part_extends {a b : SigData} (env : TyEnv) (q : NativeEff) (t : EffTy)
    (he : a.extendsB b = true) (hp : (run (.part a env q)).result = .ok t) :
    run (.part a env q) = run (.part b env q) := by
  have hc : Checker.check a.signature env [] q = .ok t := by
    simpa only [run, Annotate.check_eq] using hp
  have support := hasTy_sigProgram (check_sound a.signature q env [] t hc)
  have same := Annotate.check_restrict (SigData.extends_of_extendsB he) support env []
  exact (congrArg (fun out : List Table.Entry × Except TypeRefusal EffTy =>
    (⟨out.2, out.1⟩ : Verdict)) same).symm

inductive Role where
  | body (index : Nat) | main | layers
deriving DecidableEq

structure Dep where
  role : Role
  base : List Nat
  input : Input

def bodyDeps (app : SigApp) (holes : RowTable) (allDecls : List DefDecl) :
    List DefDecl → Effs NativeOp → Nat → List Nat → List Dep
  | d :: ds, .cons b bs, index, base =>
    ⟨.body index, base ++ [0],
      .part ⟨app, holes, .body allDecls d.params⟩ [d.request.normalize] b⟩ ::
      bodyDeps app holes allDecls ds bs (index + 1) (base ++ [1])
  | _, _, _, _ => []

def deps : Input → List Dep
  | .part .. => []
  | .module app holes p =>
    match p.expandRefs with
    | .defs decls bodies main layers =>
      bodyDeps app holes decls decls bodies 0 [0] ++
        [⟨.main, [1], .part ⟨app, holes, .block decls⟩ [] main⟩] ++
        match layers with
        | .nil => []
        | .cons _ _ =>
          [⟨.layers, [2], .part ⟨app, holes, .block decls⟩ [] (Part.layersProgram layers)⟩]
    | expanded => [⟨.main, [], .part ⟨app, holes, .root⟩ [] expanded⟩]

def layerPath : List Nat → List Nat
  | 0 :: 0 :: rest => 2 :: rest
  | p => p

def layerRefusal (r : TypeRefusal) : TypeRefusal := ⟨layerPath r.path, r.reason⟩

def layerTable (v : Verdict) : List Table.Entry :=
  v.table.filterMap fun e =>
    match e.path with
    | 0 :: 0 :: rest =>
      some ⟨2 :: rest, e.env, e.result.map fun r => r.mapError layerRefusal⟩
    | _ => none

def joinBodies : List DefDecl → Effs NativeOp → List Nat → List Verdict →
    Option (List Table.Entry × Except TypeRefusal Unit × List Verdict)
  | d :: ds, .cons _body rest, base, v :: vs => do
    let (tail, checked, unused) ← joinBodies ds rest (base ++ [1]) vs
    let placed := place (base ++ [0]) v
    let result : Except TypeRefusal Unit := do
      unless d.formed do throw ⟨base ++ [0], .definitionColumns d.name⟩
      let t ← placed.result
      unless d.admits t do throw ⟨base ++ [0], .bodyNotDeclared d.name t⟩
      checked
    pure (⟨base, none, none⟩ :: (placed.table ++ tail), result, unused)
  | [], .cons body rest, base, vs => do
    let (tail, _, unused) ← joinBodies [] rest (base ++ [1]) vs
    let bodyEntries := (Node.addresses (.eff body)).map fun p => ⟨base ++ 0 :: p, none, none⟩
    pure (⟨base, none, none⟩ :: (bodyEntries ++ tail), .ok (), unused)
  | _, .nil, base, vs => some ([⟨base, none, none⟩], .ok (), vs)
  | _ :: _, .cons _ _, _, [] => none

def joinModule (_app : SigApp) (holes : RowTable) (p : NativeEff)
    (vs : List Verdict) : Option Verdict := do
  let s : Sketch := ⟨p, holes⟩
  let (root, table) ←
    match p.expandRefs with
    | .defs decls bodies _main layers => do
      let (bodyTable, bodyResult, remaining) ← joinBodies decls bodies [0] vs
      match remaining with
      | mainVerdict :: rest =>
        let mainPlaced := place [1] mainVerdict
        let (layerResult, layerEntries) ←
          match layers, rest with
          | .nil, [] => some ((.ok () : Except TypeRefusal Unit), [⟨[2], none, none⟩])
          | .cons _ _, [v] => some (v.result.map (fun _ => ()) |>.mapError layerRefusal, layerTable v)
          | _, _ => none
        let root : Except TypeRefusal EffTy := do
          unless decls.length = bodies.toList.length do
            throw ⟨[], .definitionsMismatch decls.length bodies.toList.length⟩
          bodyResult
          let t ← mainPlaced.result
          layerResult
          pure t
        some (root, ⟨[], some (.env []), some root⟩ ::
          (bodyTable ++ (mainPlaced.table ++ layerEntries)))
      | [] => none
    | _ =>
      match vs with
      | [v] => some (v.result, v.table)
      | _ => none
  let sourceRoot := match p.firstRefFault with
    | some (site, target, why) => .error ⟨site, .referenceIllFormed target why⟩
    | none => root
  pure ⟨sourceRoot, Table.atSource s.sites p.firstRefFault table⟩

def combine (i : Input) (vs : List Verdict) : Verdict :=
  if vs.length != (deps i).length then run i
  else match i with
    | .part .. => run i
    | .module app holes p =>
      match joinModule app holes p vs with
      | some v => v
      | none => run i

def composed (i : Input) : Verdict := combine i ((deps i).map fun d => run d.input)

def n1 : NativeEff := .succeed (.lit (.nat 1))
def bad : NativeEff := .succeed (.var 0)
def idDecl : DefDecl := { name := "id", request := .nat, answer := .nat }
def idBody : NativeEff := .succeed (.var 0)
def invokeId : NativeEff := .perform (.call 0) (.lit (.nat 5))
def checkedModule : NativeEff := .defs [idDecl] (.cons idBody .nil) invokeId .nil
def badLayers : LayerTerms NativeOp := .cons (.effectDiscard bad) .nil
def withLayers : NativeEff := .defs [] .nil n1 badLayers
def faultMismatch : NativeEff := .defs [idDecl] .nil
  (.provideLayer (.ref [9]) false n1) .nil
def besideRef : NativeEff := .provideLayer (.effectDiscard n1) false
  (.bind (.provideLayer (.ref [0]) false n1) n1)
def controls : List NativeEff :=
  [n1, bad, checkedModule, .defs [] .nil n1 .nil, withLayers,
    .defs [idDecl] .nil invokeId .nil,
    .defs [] (.cons n1 .nil) n1 .nil,
    .defs [{ idDecl with answer := .var 0 }] (.cons idBody .nil) invokeId .nil,
    .defs [idDecl] (.cons (.succeed (.lit (.str "a"))) .nil) invokeId .nil,
    faultMismatch, besideRef]

#guard controls.all fun p => decide (composed (.module {} [] p) = run (.module {} [] p))
#guard (deps (.module {} [] (.defs [] .nil n1 .nil))).length = 1
#guard (run (.part ⟨{}, [], .root⟩ [] (Part.layersProgram .nil))).result.toBool = false
#guard (run (.module {} [] (.defs [] .nil n1 .nil))).result.toBool = true
#guard ((run (.module {} [] withLayers)).result.toOption).isNone
#guard ((Checker.refusal (composed (.module {} [] withLayers)).result).map (·.path)) =
  some [2, 0, 0]
#guard ((Checker.refusal (composed (.module {} [] faultMismatch)).result).map (·.reason.head)) =
  some "referenceIllFormed"
#guard ((Checker.refusal (Checker.checkModule ({} : SigApp).signature faultMismatch.expandRefs)).map
  (·.reason.head)) = some "definitionsMismatch"
#guard combine (.module {} [] checkedModule) [] = run (.module {} [] checkedModule)

def oneRow : SigData := ⟨{ rows := [Row.hole "a" .nat] }, [], .root⟩
def twoRows : SigData := ⟨{ rows := [Row.hole "a" .nat, Row.hole "b" .string] }, [], .root⟩
def extCall : NativeEff := .perform (.external 0) (.lit .unit)
def nextCall : NativeEff := .perform (.external 1) (.lit .unit)
#guard oneRow.extendsB twoRows
#guard run (.part oneRow [] extCall) = run (.part twoRows [] extCall)
#guard run (.part oneRow [] nextCall) != run (.part twoRows [] nextCall)

end SeamsCheckScout

#eval IO.println "V1 scout: connectors compile; finite decomposition controls pass"

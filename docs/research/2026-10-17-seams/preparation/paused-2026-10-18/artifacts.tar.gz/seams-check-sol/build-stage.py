from pathlib import Path
import os,re,subprocess,sys,json
base=Path('/private/tmp/seams-check-sol');prod=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4')
stage=sys.argv[1] if len(sys.argv)>1 else 's1';work=base/(stage+'-full');src=work/'src';lib=work/'lib/lean';changed={}
def ingest(directory,strip=False):
 for p in (base/directory).rglob('*.lean'):
  rel=p.relative_to(base/directory)
  if strip:rel=Path(*rel.parts[1:])
  changed[str(rel.with_suffix('')).replace('/','.')]=p.read_text()
for d in ['overlay','v1-laws','v1-tests']:ingest(d)
ingest('caller-overlay',True)
v1sources=dict(changed)
for d in ['s1-overlay','s1-laws','s1-tests']:ingest(d)
ingest('s1-callers',True)
if stage=='s2':
 for d in ['s2-overlay','s2-laws','s2-tests']:ingest(d)
 ingest('s2-callers',True)
files={}
for root in [prod/'src',prod/'tools',prod/'Test']:
 for p in root.rglob('*.lean'):
  name=str(p.relative_to(root).with_suffix('')).replace('/','.')
  if root.name=='Test':name='Test.'+name
  files[name]=p.read_text()
original=dict(files)
files.update(changed)
phaseChanged={n for n,text in changed.items() if text != v1sources.get(n,original.get(n))}
phaseNeeds={}
def phaseAffected(n):
 if n not in files:return False
 if n in phaseNeeds:return phaseNeeds[n]
 phaseNeeds[n]=n in phaseChanged or any(phaseAffected(d) for d in imports(files[n]))
 return phaseNeeds[n]
imports=lambda s:re.findall(r'^(?:public )?import\s+([\w.]+)',s,re.M)
needs={};active=set();seen=set();order=[]
def affected(n):
 if n not in files:return False
 if n in needs:return needs[n]
 if n in active:raise Exception('cycle '+n)
 active.add(n);hit=n in changed
 for d in imports(files[n]):hit=affected(d) or hit
 active.remove(n);needs[n]=hit;return hit

def visit(n):
 if n in seen or n not in files:return
 seen.add(n)
 for d in imports(files[n]):visit(d)
 if affected(n) or not ((lib/Path(*n.split("."))).with_suffix(".olean").exists() or (prod/".lake/build/lib/lean"/Path(*n.split("."))).with_suffix(".olean").exists()):order.append(n)
for n in sys.argv[2:] or ['Effect4.Laws.Program.SourceDocument','Effect4.Laws.Program.FillSet','Tools.Session','Test.Program.CheckCacheControls','Test.Program.SourceDocumentControls','Test.Program.FillSetControls']:visit(n)
work.mkdir(parents=True,exist_ok=True);(work/'order.json').write_text(json.dumps(order,indent=2));print(stage,'compile count',len(order),flush=True)
# Read dependency artifacts by links. Every target output is unlinked before compilation.
for origin in [base/'v1-full/lib/lean',prod/'.lake/build/lib/lean']:
 if not origin.exists():continue
 for p in origin.rglob('*'):
  if p.is_file():
   dst=lib/p.relative_to(origin);dst.parent.mkdir(parents=True,exist_ok=True)
   if not dst.exists() and not dst.is_symlink():dst.symlink_to(p)
resume=os.environ.get('SEAMS_RESUME')
if resume:order=order[order.index(resume):]
for n in order:
 if not phaseAffected(n) and (base/'v1-full/lib/lean'/Path(*n.split('.')).with_suffix('.olean')).exists():
  print(n,'reuse V1',flush=True);continue
 rel=Path(*n.split('.'));p=src/rel.with_suffix('.lean');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(files[n]);output=lib/rel.with_suffix('.olean');output.parent.mkdir(parents=True,exist_ok=True)
 for suf in ['.olean','.olean.private','.olean.server','.ir','.ir.sig']:
  f=lib/rel.with_suffix(suf)
  if f.is_symlink():f.unlink()
 result=subprocess.run(['lean','-DwarningAsError=true',f'--root={src}','-o',str(output),str(p)],env={**os.environ,'LEAN_PATH':str(lib)+':'+os.environ['LEAN_PATH']},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 log=work/'logs'/rel.with_suffix('.log');log.parent.mkdir(parents=True,exist_ok=True);log.write_text(result.stdout)
 print(n,result.returncode,result.stdout[-7000:] if result.returncode else '',flush=True)
 if result.returncode:raise SystemExit(result.returncode)

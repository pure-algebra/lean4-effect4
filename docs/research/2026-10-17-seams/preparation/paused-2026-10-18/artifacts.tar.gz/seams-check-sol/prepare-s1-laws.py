from pathlib import Path
b=Path('/private/tmp/seams-check-sol');p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');old=(p/'src/Effect4/Laws/Program/SourceTable.lean').read_text();prefix=old[:old.index('namespace SourceSession')]
new='''
/-!
Placement: initial-algebras-folds; source-session-coherent and typed-replacement, R14.
Question: source-session-coherent names reached_view; feed_coherent serves that claim.
Reach: coherent source tables and the exact feed policy; the root and local observations remain distinct.
Exclusions: admission, progress, arbitrary reference splicing, and native execution.
Consumers: Doc.step, FillSet.add, and the tool's edit and observation wrappers.
-/
namespace SourceSession
open Check

@[semantics "initial-algebras-folds" (requirement := R14)]
theorem open_coherent (o : Oracle) (app : SigApp) (s : Sketch) :
    (SourceSession.open o app s).value.Coherent := by
  change (Checked.ask o (.module app s.holes s.program)).value.table = s.sourceTable app
  rw [Checked.ask_value]
  exact Sketch.sourceAnnotate_eq_sourceTable s app

@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal feed_coherent {o : Oracle} {policy : FeedPolicy} {s next : SourceSession}
    {e : Edit} {step : Edit.Step} (hc : s.Coherent)
    (h : (s.feed o policy e).value = .ok (next,step)) : next.Coherent

@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal feed_keeps {o : Oracle} {policy : FeedPolicy} {s next : SourceSession}
    {e : Edit} {step : Edit.Step}
    (h : (s.feed o policy e).value = .ok (next,step)) :
    next.app = s.app ∧ step.edit = e ∧
      (s.sketch.edit s.app e = none → next = s) ∧
      (∀ candidate, s.sketch.edit s.app e = some candidate → next.sketch = candidate)

@[semantics "initial-algebras-folds" (requirement := R14)]
theorem table_eq {s : SourceSession} (hc : s.Coherent) : s.table = s.sketch.sourceTable s.app := hc

'''
# Keep existing view and focus proofs exactly; their premises and observations do not change.
a=old.index('/-- **A coherent session shows');z=old.index('/-- **What a session shows',a);new+=old[a:z]
a=old.index('/-- **The focus at a source address');z=old.index('/-! ## Undo',a);new+=old[a:z]
new+='''
@[semantics "initial-algebras-folds" (requirement := R14)]
theorem reached_view {s : SourceSession} (hc : s.Coherent) :
    s.view.table = s.sketch.sourceTable s.app ∧
    s.view.refusals = s.sketch.sourceRefusals s.app ∧
    s.view.type = (s.sketch.sourceCheck s.app).toOption :=
  ⟨table_eq hc,view_refusals hc,view_type hc⟩

@[semantics "initial-algebras-folds" (requirement := R14)]
theorem Coherent.ext {a b : SourceSession} (ha : a.Coherent) (hb : b.Coherent)
    (happ : a.app = b.app) (hsketch : a.sketch = b.sketch) : a = b := by
  have htable : a.table = b.table := by rw [ha,hb,happ,hsketch]
  cases a
  cases b
  cases happ
  cases hsketch
  cases htable
  rfl

@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal feed_keepExact {o : Oracle} {s next : SourceSession} {e : Edit} {step : Edit.Step}
    (hc : s.Coherent) (hne : e.path ≠ [])
    (h : (s.feed o .keepExact e).value = .ok (next,step)) :
    next.view.type = s.view.type ∧
      Table.typedAt next.table e.path = Table.typedAt s.table e.path ∧
      (s.expandedEditAgrees next.sketch e = true → step.delta = .spliced [e.path])

/-- Root edits ask only through the module route and never produce a splice. -/
@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal feed_root {o : Oracle} {policy : FeedPolicy} {s next : SourceSession}
    {e : Edit} {step : Edit.Step} (hp : e.path = [])
    (h : (s.feed o policy e).value = .ok (next,step))
    (hedit : ∃ candidate, s.sketch.edit s.app e = some candidate) :
    step.delta = .rechecked

@[semantics "initial-algebras-folds" (requirement := R14)]
proof_goal feed_undo {o : Oracle} {s next : SourceSession} {a : List Nat} {q old : NativeEff}
    {candidate : Sketch} {step : Edit.Step} (hc : s.Coherent)
    (hat : (Node.eff s.sketch.program).at_ a = some (.eff old))
    (hfill : s.sketch.fillAt a q = some candidate)
    (hnext : (s.feed o .draft (.fill a q)).value = .ok (next,step)) :
    ∃ back, (next.feed o .draft (.fill a old)).value = .ok (s,back)

end SourceSession
end Effect4.Program
'''
new=new.replace('SourceSession.open o','SourceSession.«open» o')
(b/'s1-laws/Effect4/Laws/Program/SourceTable.lean').write_text('import Effect4.Laws.Program.CheckAgreement\n'+prefix+new)

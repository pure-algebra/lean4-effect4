from pathlib import Path
p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');out=Path('/private/tmp/seams-check-sol/caller-overlay')
def put(rel,s):
 f=out/rel;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
old=(p/'src/Effect4/Program/Typing/CheckCache.lean').read_text()
s='import Effect4.Program.Check\nimport Effect4.Program.Typing.SourceDocument\nset_option autoImplicit false\nnamespace Effect4.Program.CheckCache\nopen Effect4 Effect4.Program Check\n'
ev=old[old.index('/-- The contextual evidence'):old.index('/-- Evaluate one candidate')]
ev=ev.replace(' (fromCache : Bool)','').replace('key : CheckKey','key : CheckInput')
s+=ev+'''def evaluateCandidate (o : Oracle) (sig : SigData) (targetEnv : TyEnv) (expected : EffTy)
    (targetPath : List Nat) (sourcePath : Option (List Nat)) (sourceEnv : TyEnv)
    (prog : NativeEff) : Checked Suggestion := do
  let key := CheckInput.part sig targetEnv prog
  if sourceEnv = targetEnv then
    let answer ← Checked.ask o key
    let verdict := answer.result.mapError (TypeRefusal.rebase targetPath)
    let evidence := match verdict with
      | .ok ty => if ty = expected then Evidence.exactFit ty else .typeMismatch expected ty
      | .error why => .refused why
    pure ⟨prog, sourcePath, key, evidence⟩
  else pure ⟨prog, sourcePath, key, .differentEnv sourceEnv targetEnv⟩

def evaluateCandidates (o : Oracle) (sig : SigData) (targetEnv : TyEnv) (expected : EffTy)
    (targetPath : List Nat) : List (Option (List Nat) × TyEnv × NativeEff) → Checked (List Suggestion)
  | [] => pure []
  | (sp, sourceEnv, prog) :: rest => do
    let suggestion ← evaluateCandidate o sig targetEnv expected targetPath sp sourceEnv prog
    let later ← evaluateCandidates o sig targetEnv expected targetPath rest
    pure (suggestion :: later)
'''
local=old[old.index('/-- Harvest local'):old.index('/-- **Bounded local candidate search')]
local=local.replace('  cache : List Entry\n','')
s+=local+'''def suggest (o : Oracle) (d : Doc) (path : List Nat) (limit : Nat := 16)
    (cursor : Nat := 0) (supplied : List NativeEff := []) : Checked (Option SuggestResult) := do
  match d.session.focusAt path with
  | none => pure none
  | some focus =>
    let sig := sketchSigData d.session.sketch d.session.app path
    let all := localCandidates d path focus supplied
    let total := all.length
    let page := (all.drop cursor).take limit
    let nextCursor := if cursor + limit < total then some (cursor + limit) else none
    let suggestions ← evaluateCandidates o sig focus.env focus.ty path page
    pure (some { doc := d.id, revision := d.revision, path := path,
      cursor := cursor, limit := limit, total := total, nextCursor := nextCursor,
      sig := sig, env := focus.env, expected := focus.ty, suggestions := suggestions })
end Effect4.Program.CheckCache
'''
put(Path('src/Effect4/Program/Typing/CheckCache.lean'),s)
t=(p/'tools/Tools/Session.lean').read_text().replace('cache : List CheckCache.Entry := []','cache : Check.Memo := Check.Memo.empty')
t=t.replace('.exactFit ty fromCache','.exactFit ty').replace('.typeMismatch expected actual fromCache','.typeMismatch expected actual').replace('.refused why fromCache','.refused why')
t=t.replace(', ("fromCache", toJson fromCache)','').replace(',\n      ("fromCache", toJson fromCache)','')
t=t.replace('printJson s.key.env','printJson (match s.key with | .part _ env _ => env | .module .. => [])')
t=t.replace('    ("cacheEntries", toJson res.cache.length),\n','')
t=t.replace('          match CheckCache.suggest d st.cache req.path req.limit req.cursor supplied with','          let checked := CheckCache.suggest (st.cache.oracle (Check.HitRule.exact.or Check.extension))\n            d req.path req.limit req.cursor supplied\n          let learned := st.cache.learn checked\n          match checked.value with')
t=t.replace('let st\' := { st with cache := res.cache }','let st\' := { st with cache := learned }')
t=t.replace('``CheckCache.lookup_sound,\n                ``CheckCache.evaluateCandidate_valid_and_sound','``Check.Oracle.eq_uncached')
put(Path('tools/Tools/Session.lean'),t)
k=(p/'src/Effect4/Run/Kit.lean').read_text();k='import Effect4.Program.Check\n'+k
k=k.replace('(Api.check program app).map (·.certificate.ty)','(Check.run (.module app [] program)).result')
put(Path('src/Effect4/Run/Kit.lean'),k)
print(out)

import Effect4.Program.Typing.SourceSession
import Effect4.Program.Typing.SourceDocument
import Effect4.Program.Typing.FillSet
import Effect4.Program.Typing.CheckCache
import Effect4.Laws.Program.SourceTable
import Effect4.Laws.Program.SourceDocument
import Test.Program.SourceFeedControls
import Test.Program.SourceDocumentControls
import Test.Program.CheckCacheControls
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Program.Typing.SourceSession Effect4.Program.Typing.SourceDocument Effect4.Program.Typing.FillSet Effect4.Program.Typing.CheckCache Effect4.Laws.Program.SourceTable Effect4.Laws.Program.SourceDocument Test.Program.SourceFeedControls Test.Program.SourceDocumentControls Test.Program.CheckCacheControls

from pathlib import Path
s=Path('/private/tmp/seams-check-sol');o=s/'s1-overlay'
def put(name,text):
 p=o/'Effect4/Program/Typing'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
f=(s/'S1FeedProbe.lean').read_text();f=f[f.index('structure SourceSession'):f.index('namespace FeedControls')]
f=f.replace('Option Input','Option CheckInput').replace('open_','«open»')
legacy=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4/src/Effect4/Program/Typing/SourceSession.lean').read_text()
f=legacy[legacy.index('def Sketch.edit'):legacy.index('/-- **The edit session of a sketch as written**')]+f
put('SourceSession.lean','import Effect4.Program.Check\nimport Effect4.Program.Edit\nset_option autoImplicit false\nset_option maxRecDepth 20000\nnamespace Effect4.Program\nopen Check\n'+f+'\nend Effect4.Program\n')
d=(s/'S1DocProbe.lean').read_text();d=d[d.index('/-- The checked fold'):d.index('end SeamsS1Scout')]
d=d.replace('.bind fun', ".bind' fun").replace('initial.bind','initial.bind\'').replace('current.bind','current.bind\'').replace('Checked.bind, Checked.pure','Checked.bind\', Checked.pure\'').replace('SourceSession.open_','SourceSession.«open»')
types='''structure DocId where
  name : String := "default"
  generation : Nat := 0
deriving DecidableEq, Repr
inductive Change where
  | fill (q : NativeEff)
  | omitHole (name : String)
deriving DecidableEq
'''
put('SourceDocument.lean','import Effect4.Program.Typing.SourceSession\nset_option autoImplicit false\nset_option maxRecDepth 20000\nnamespace Effect4.Program\nopen Check\n'+types+d+'\nend Effect4.Program\n')
print(o)

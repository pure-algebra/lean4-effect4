from pathlib import Path
import os,subprocess
base=Path('/private/tmp/seams-check-sol');work=base/'v1-full';lib=work/'lib/lean';src=work/'src'
modules=['Effect4.Program.Typing.SigData','Effect4.Program.Typing.AnnotateFold','Effect4.Program.Typing.SignatureSupport','Effect4.Program.Typing.Support','Effect4.Program.Check','Effect4.Program.Typing.CheckCache','Effect4.Laws.Program.Signature','Effect4.Laws.Program.Definitions','Effect4.Laws.Program.Sketch','Effect4.Laws.Program.Typing.Annotate','Effect4.Laws.Program.Typing.Restrict','Effect4.Laws.Program.Typing.CheckCache','Effect4.Laws.Program.CheckAgreement','Test.Program.CheckCacheControls']
p=src/'AuditV1.lean';p.write_text('\n'.join('import '+n for n in modules)+'\nimport ProofGraph.AxiomAudit\n#axiom_audit '+' '.join(modules)+'\n')
r=subprocess.run(['lean','-DwarningAsError=true',f'--root={src}',str(p)],env={**os.environ,'LEAN_PATH':str(lib)+':'+os.environ['LEAN_PATH']},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(work/'audit.log').write_text(r.stdout);print(r.stdout,flush=True);raise SystemExit(r.returncode)

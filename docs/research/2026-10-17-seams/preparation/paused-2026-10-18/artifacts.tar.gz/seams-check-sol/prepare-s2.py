from pathlib import Path
s=Path('/private/tmp/seams-check-sol');p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');o=s/'s2-overlay/Effect4/Program/Typing/FillSet.lean'
old=(p/'src/Effect4/Program/Typing/FillSet.lean').read_text()
ops=old[old.index('/-- Two addresses'):old.index('/-- Decidable check that a fill')]+old[old.index('/-- Apply fills in order.'):old.index('/-- Why a fill set does not materialize.')]
ops+=old[old.index('/-- Why a single fill submission'):old.index('/-- A fixed-base set of certified')]
body='''
namespace FillSetInternal
/-- Placement: R14, initial-algebras-folds; helper of kept_eq_certified.
The anchor feed certifies candidates; this establishes no admission or progress claim. -/
def addEntry (o : Oracle) (anchor : SourceSession) (entries : List (List Nat × NativeEff))
    (p : List Nat) (q : NativeEff) : Checked (List (List Nat × NativeEff) × AddOutcome) := do
  if p.isEmpty then return (entries, .refused p .root)
  if !holdsProgram anchor.sketch p then return (entries, .refused p .unknownAddress)
  match entries.find? (fun x => decide (x.1 = p)) with
  | some (_, q0) =>
    if q0 = q then return (entries, .collapsed p)
    else return (entries, .refused p .conflict)
  | none =>
    match entries.find? (fun x => !incomparableB p x.1) with
    | some (other, _) => return (entries, .refused p (.overlap other))
    | none =>
      match ← anchor.feed o .keepExact (.fill p q) with
      | .error _ => return (entries, .refused p .notCertified)
      | .ok _ => return ((p,q) :: entries, .applied p)

def addRaw (anchor : SourceSession) (submissions : List (List Nat × NativeEff)) :
    List (List Nat × NativeEff) :=
  submissions.foldl (fun entries x => (addEntry Oracle.uncached anchor entries x.1 x.2).value.1) []
end FillSetInternal

/-- Sealed pending fills, certified at the opened document's source session. -/
structure FillSet where
  private mk ::
  anchor : Snap
  source : SourceSession
  entries : List (List Nat × NativeEff)
  constructed : ∃ submissions, FillSetInternal.addRaw source submissions = entries

namespace FillSet

def open_ (d : Doc) : FillSet := ⟨d.snap, d.session, [], ⟨[], rfl⟩⟩

def base (fs : FillSet) : Sketch := fs.source.sketch
def app (fs : FillSet) : SigApp := fs.source.app
def pending (fs : FillSet) : List (List Nat × NativeEff) := ordered fs.base fs.entries

/-- Placement: R14, initial-algebras-folds; add_wf's constructor helper.
Every witness extends an uncached submission fold. This proves no host behavior. -/
def addOne (o : Oracle) (fs : FillSet) (p : List Nat) (q : NativeEff) :
    Checked (FillSet × AddOutcome) :=
  let c := FillSetInternal.addEntry o fs.source fs.entries p q
  let next : FillSet := ⟨fs.anchor, fs.source, c.value.1, by
    obtain ⟨submissions, hs⟩ := fs.constructed
    refine ⟨submissions ++ [(p,q)], ?_⟩
    simp only [FillSetInternal.addRaw, List.foldl_append, List.foldl_cons, List.foldl_nil]
    change (FillSetInternal.addEntry Oracle.uncached fs.source
      (FillSetInternal.addRaw fs.source submissions) p q).value.1 = _
    rw [hs]
    dsimp only [c]
    rw [Oracle.eq_uncached o]⟩
  c.bind' fun _ => pure (next, c.value.2)

def add (o : Oracle) (fs : FillSet) : List (List Nat × NativeEff) →
    Checked (FillSet × List AddOutcome)
  | [] => pure (fs, [])
  | (p,q) :: rest => do
    let (next, outcome) ← fs.addOne o p q
    let (last, outcomes) ← next.add o rest
    pure (last, outcome :: outcomes)

inductive PublishRefusal where
  | empty
  | unknownAddress

def publication (fs : FillSet) : Except PublishRefusal DocAction := do
  if fs.entries.isEmpty then throw .empty
  let items ← fs.pending.mapM fun (p,q) =>
    match (Node.eff fs.base.program).at_ p with
    | some (.eff expected) => .ok (Place.at_ p expected, Change.fill q)
    | _ => .error PublishRefusal.unknownAddress
  pure (.commit items .keepExact)
end FillSet
'''
o.parent.mkdir(parents=True,exist_ok=True);o.write_text('import Effect4.Program.Typing.SourceDocument\nset_option autoImplicit false\nnamespace Effect4.Program\nopen Effect4 Check\n'+ops+body+'\nend Effect4.Program\n')
print(o)

module

public import Effect4.Program.Checker
public import Init.Data.List.Monadic

@[expose] public section

/-!
Pure core probe. Placement: initial-algebras-folds, R14; helper for the proposed
Check.run_part_extends compatibility claim. The statement covers a context action
whose keys all exist. It establishes its checker answer, not arbitrary program typing.
The consumer is Annotate.check_alg_agreeOn after the proof-owner move.
-/

set_option autoImplicit false
namespace SeamsContextScout
open Effect4 Effect4.Program
open Effect4.Program.Checker
variable {Op : Type}

theorem contextKeysEqOk (sig : Signature Op) (p : List Nat) (keys : List ServiceKey) :
    keys.foldlM (fun (_ : PUnit) key =>
      (fun _ => PUnit.unit) <$> expect ⟨p, .serviceUnknown key⟩ (sig.serviceTy key)) PUnit.unit =
      .ok PUnit.unit ↔ ∀ key ∈ keys, ∃ carrier, sig.serviceTy key = some carrier := by
  induction keys with
  | nil => simp only [List.foldlM_nil, pure, Except.pure, List.not_mem_nil, false_implies, implies_true]
  | cons key keys ih =>
    rw [List.foldlM_cons]
    cases hs : sig.serviceTy key with
    | none => simp only [expect, hs, Functor.map, Except.map, bind, Except.bind,
        reduceCtorEq, List.mem_cons, forall_eq_or_imp, exists_false, false_and]
    | some carrier =>
      change (_ >>= fun result => keys.foldlM _ result) = _ ↔ _
      simp only [expect, Functor.map, Except.map, bind, Except.bind] at ih ⊢
      rw [ih]
      simp only [List.mem_cons, forall_eq_or_imp, hs, Option.some.injEq]
      exact ⟨fun h => ⟨⟨carrier, rfl⟩, h⟩, fun h => h.2⟩

theorem checkActionContext (sig : Signature Op) (env : TyEnv) (p : List Nat)
    (keys : Effect4.Machine.Env.Requirement)
    (hk : ∀ key ∈ keys.elems, ∃ carrier, sig.serviceTy key = some carrier) :
    checkAction sig env p (.context keys) = .ok ⟨.contextOf keys, .never, keys⟩ := by
  have loop := (contextKeysEqOk sig p keys.elems).mpr hk
  simp only [checkAction, bind_pure_comp, List.forIn_yield_eq_foldlM]
  rw [loop]
  rfl

end SeamsContextScout

#eval IO.println "V1 scout: context loop proof needs core imports only"

import subprocess, os
from pathlib import Path
root=Path('/private/tmp/seams-check-sol/overlay')
for mod in ['SigData','AnnotateFold','SignatureSupport','Support','../Check']:
 p=(root/'Effect4/Program/Typing'/f'{mod}.lean').resolve()
 cmd=['lake','env','lean','-DwarningAsError=true',f'--root={root}','-o',str(p.with_suffix('.olean')),str(p)]
 r=subprocess.run(cmd,env={**os.environ,'LEAN_PATH':str(root)},stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (Path('/private/tmp/seams-check-sol')/f'{p.stem}.log').write_text(r.stdout)
 print(p.stem,r.returncode,r.stdout[-5000:],flush=True)
 if r.returncode: raise SystemExit(r.returncode)

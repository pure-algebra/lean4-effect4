# Temporary implementation overlay

The final V1 closure is under compilation. S1 and S2 remain unverified drafts.
No production file changes here.

## V1

1. Install `overlay/Effect4/Program/Typing/SigData.lean` at the same path below `src/`.
2. Remove its declarations from `Program/Typing/CheckCache.lean` and import the new owner there.
3. Install `AnnotateFold.lean`, `SignatureSupport.lean`, and `Support.lean` from the same overlay.
4. Remove the unplaced moved declarations from their Laws owners.
Retain the three placed Laws statements as exact wrappers over pure core helpers.
5. Install `overlay/Effect4/Program/Check.lean` after S0 lands.
6. Place `combine_deps` in Laws before using it for the unchanged `Checked.ask_value` statement.
7. Migrate the old suggestion driver and Run.Kit callers before removing the old cache surface.

`SignatureSupport.lean` contains existing pure proofs from Signature, Definitions, Sketch, CheckCache, and Restrict Laws owners.
`AnnotateFold.lean` contains the old `fold_of Annotate.check` invocation.
The new context helpers replace the old Restrict branch's dependency on `checkAction_complete`.
The files import no Laws module.

The Check overlay retains S0's oracle, trace, memo, and rule packages.
It adds part decomposition, address projection, lazy fallback, and the certified extension rule.
The module ask's result uses `combine` over actual part answers.
The module trace contains only those actual part answers.
Its validity proof uses `Oracle.agrees`, independently of `combine_deps`.

`Check.Internal.deps`, `combine`, and projection helpers have internal names for fixtures.
Their namespace is `Check.Internal`; Laws imports that namespace explicitly.
No core module uses `combine_deps` or any planned goal.

## S1

Install the two `s1-overlay` files after V1.
They replace SourceSession and SourceDocument, rather than adding parallel representations.
The source session stores its source table and uses S0's actual Checked package.
The document uses one action interpreter and a temporary history ledger during replay.
`DocId` and `Change` retain their old types in the new document owner.
No alias preserves `Doc.commit`, `Doc.undo`, `Doc.fork`, or the old free revision field.

The caller movements remain those recorded in `S1-callers.txt` and `S1-REPORT.md`.
The old representation-dependent Laws require migration in this slice.
The exact source-session laws remain open until proved or placed as goals in Laws.
Core document constructors use complete proofs, never planned goals.

## S2

Install `s2-overlay/Effect4/Program/Typing/FillSet.lean` after S1.
Its private constructor carries an existential submission witness.
The `addOne` constructor extends that witness through `List.foldl_append`.
It certifies through the anchor's keepExact feed and discards the returned session.
Publication creates one address-ordered commit using expected programs from the base.

The drafted tool wrapper validates snapshots and the full anchor, then resets pending fills after successful publication.
The FillSet receives no current document during add.
Its open factory takes only a sealed Doc.

D1-D9 must retain the premises documented in HANDOFF-SOL.md.
A reference-free base and filling bound kept_eq_certified.
A positive base-check premise additionally bounds publish_eq_materialize.
Neither premise belongs as a new refusal in the operational feed.
The previous materialization observation must move to Laws under an explicitly named reference owner.
The S2 draft moves the old observation into `s2-laws/Effect4/Laws/Program/FillReference.lean`.

## Verification

Run every Lean command from the production worktree through the shared wrapper.
The V1 runner compiles the affected closure sequentially into `v1-full/lib/lean`.
It unlinks each output before compiling and writes no output through production dependency links.

```text
python3 /private/tmp/seams-lean-one.py lake env python3 /private/tmp/seams-check-sol/build-v1.py
python3 /private/tmp/seams-lean-one.py lake env python3 /private/tmp/seams-check-sol/build-stage.py s1
python3 /private/tmp/seams-lean-one.py lake env python3 /private/tmp/seams-check-sol/build-stage.py s2
```

The stage runners compile cumulative source overlays.
Old scout results establish only the old probes.
The final receipt must identify fresh logs and the exact audited modules.
The coordinator owns production gates, root imports, central placement, regeneration, and commits.

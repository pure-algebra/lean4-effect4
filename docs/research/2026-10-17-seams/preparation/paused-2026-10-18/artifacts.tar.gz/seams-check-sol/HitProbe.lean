import CheckProbe
import SupportProbe
import Effect4.Program.Typing.FillSet

/-!
Placement for extension_hit_retains_positive:
1. Concept: initial-algebras-folds; signature support and extension.
2. Question: helper of the proposed Check.run_part_extends compatibility claim.
3. Reach: equal part programs and environments, a positive answer, and SigData.extendsB.
4. Exclusions: negative extension hits, module hits, native behavior, and a measured cost bound.
5. Consumer: Check.extension. R14. The theorem proves that the support guard loses no planned hit.

The finite controls below exercise decomposition and source-session boundaries.
-/
set_option autoImplicit false
namespace SeamsHitScout
open Effect4 Effect4.Program
open SeamsCheckScout SeamsSupportScout

structure HitRule where
  hit : Input → Input × Verdict → Bool
  sound : ∀ i e, hit i e = true → e.2 = run e.1 → e.2 = run i

def extensionHit (i : Input) (e : Input × Verdict) : Bool :=
  match i, e.1 with
  | .part newer env p, .part older oldEnv oldP =>
      decide (oldP = p) && decide (oldEnv = env) && older.extendsB newer &&
        e.2.result.toBool && supportB older.signature oldP
  | _, _ => false

def extension : HitRule where
  hit := extensionHit
  sound := by
    intro i e hh hv
    obtain ⟨old, verdict⟩ := e
    cases i with
    | module app holes p =>
      cases old <;> cases hh
    | part newer env p =>
      cases old with
      | module app holes q => cases hh
      | part older oldEnv oldP =>
        simp only [extensionHit, Bool.and_eq_true, decide_eq_true_eq] at hh
        obtain ⟨⟨⟨⟨hq, henv⟩, he⟩, _positive⟩, hs⟩ := hh
        subst oldP
        subst oldEnv
        exact hv.trans (congrArg (fun out : List Table.Entry × Except TypeRefusal EffTy =>
          (⟨out.2, out.1⟩ : Verdict)) (guarded_extends p env he hs))

theorem extension_hit_retains_positive (a b : SigData) (env : TyEnv) (q : NativeEff) (t : EffTy)
    (he : a.extendsB b = true) (hp : (run (.part a env q)).result = .ok t) :
    extension.hit (.part b env q) (.part a env q, run (.part a env q)) = true := by
  have hc : Checker.check a.signature env [] q = .ok t := by
    simpa only [run, Annotate.check_eq] using hp
  have hs := support_of_positive a.signature q env t hc
  have pos : (run (.part a env q)).result.toBool = true := by rw [hp]; rfl
  simp only [extension, extensionHit, Bool.and_eq_true, decide_eq_true_eq]
  exact ⟨⟨⟨⟨True.intro, True.intro⟩, he⟩, pos⟩, hs⟩

#guard extension.hit (.part twoRows [] extCall) (.part oneRow [] extCall, run (.part oneRow [] extCall))
#guard !extension.hit (.part twoRows [] nextCall) (.part oneRow [] nextCall, run (.part oneRow [] nextCall))
#guard !extension.hit (.module {} [] n1) (.module {} [] n1, run (.module {} [] n1))
#guard !extension.hit (.part twoRows [.string, .nat] bad)
  (.part oneRow [.nat, .string] bad, run (.part oneRow [.nat, .string] bad))
#guard supportB oneRow.signature bad
#guard (run (.part oneRow [] bad)).result.toBool = false
#guard (run (.part ⟨{}, [], .root⟩ [] checkedModule)).result.toBool = false
#guard (run (.module {} [] checkedModule)).result.toBool

def aggregateMismatch : NativeEff :=
  .defs [idDecl] (.cons (.succeed (.lit (.str "a"))) .nil) invokeId .nil
#guard (deps (.module {} [] aggregateMismatch)).all fun d => (run d.input).result.toBool
#guard ((Checker.refusal (composed (.module {} [] aggregateMismatch)).result).map (·.reason.head)) =
  some "bodyNotDeclared"
#guard (SourceSession.open {} ⟨besideRef, []⟩).expanded.table != (run (.module {} [] besideRef)).table
#guard (SourceSession.open {} ⟨besideRef, []⟩).table = (run (.module {} [] besideRef)).table
#guard ((SourceSession.open {} ⟨n1, []⟩).feedStep (.fill [9] n1)).2.delta = .unchanged
#guard ((SourceSession.open {} ⟨n1, []⟩).feedStep (.fill [9] n1)).1.sketch.program = n1

end SeamsHitScout
#eval IO.println "V1 scout: support-guard extension retains every planned positive hit; finite controls pass"

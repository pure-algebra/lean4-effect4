# S6 preparation: native request and host owners

Status: source-grounded inventory, with no implementation or completed equivalence claim.
The files beside this note list actual callers and retain current source hashes.

The product request interpreter becomes generated Tool.serve and Exchange.apply.
JSON parsing, method-version selection, transport framing, and native IO stay outside the semantic state.
The existing Kit_serve request match and E4_host.serve copy must leave the product path.
The native shell retains explicit faults and its numeric profile checks.

The old E4_host header already records observations different from Run.driveFrom.
It stops immediately at refused replies, numeric-profile crossings, stuck states, and fuel frontiers.
Run.driveFrom advances through some of those phases and retains its reactor state differently.
A replacement cannot silently claim equal observations from shared entry-point names.
Retain the actual host controls and explain any changed observation with a red case.
The exact accepted Tool request and reply transcripts remain the required cross-driver observation.
Native provider callbacks remain external input, never stored program syntax or persisted session state.

The ENGINE functor has stand-in test consumers as well as actual engines.
Do not introduce a second production action or run interpreter to keep those stand-ins.
Prefer the actual generated core operations and distinguish finite adapter controls from a universal translation claim.

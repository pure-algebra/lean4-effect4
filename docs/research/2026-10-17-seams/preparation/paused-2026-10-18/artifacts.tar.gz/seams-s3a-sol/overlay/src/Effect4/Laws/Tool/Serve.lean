import Effect4.Tool.Serve
import Effect4.Laws.Auto.Obligations
/-! Placement: host-session-protocol, tool transitions, R6 and R13.
The registry questions and complete scopes are fixed in S3a PLACEMENT.md before these goals.
These observations establish no native execution or host progress claim. -/
set_option autoImplicit false
namespace Effect4.Tool
open Effect4.Program.Check

@[semantics "host-session-protocol" (requirement := R6)]
proof_goal serve_appends : ∀ o s a,
    (serve o s (.act a)).value.2.result.isOk = true →
    (serve o s (.act a)).value.1.transcript = s.transcript ++ [a]

@[semantics "host-session-protocol" (requirement := R6)]
proof_goal serve_query : ∀ o s q, (serve o s (.ask q)).value.1 = s

@[semantics "host-session-protocol" (requirement := R6)]
proof_goal serve_refuses : ∀ o s r,
    (serve o s r).value.2.result.isOk = false → (serve o s r).value.1 = s

@[semantics "host-session-protocol" (requirement := R6)]
proof_goal serve_transparent (o : Oracle) : serve o = serve Oracle.uncached

@[semantics "host-session-protocol" (requirement := R13)]
proof_goal transcript_replays (s : State) : replayAccepted {} s.transcript = .ok s.raw
end Effect4.Tool

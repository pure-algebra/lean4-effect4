import Effect4.Tool.Actions
set_option autoImplicit false
namespace Effect4.Tool
open Effect4.Program.Check
namespace Internal

def replayStep (current : Except (Nat × Refusal) (Nat × Raw)) (a : Action) :
    Except (Nat × Refusal) (Nat × Raw) := do
  let (index,raw) ← current
  match (action Oracle.uncached raw a).value with
  | .error why => .error (index,why)
  | .ok (next,_) => .ok (index+1,next)

def replayCursor (initial : Raw) (actions : List Action) :
    Except (Nat × Refusal) (Nat × Raw) :=
  actions.foldl replayStep (.ok (0,initial))

/-- Helper of transcript_replays; replay extends the same action fold. -/
theorem replayCursor_snoc (initial : Raw) (actions : List Action) (a : Action) :
    replayCursor initial (actions ++ [a]) = replayStep (replayCursor initial actions) a := by
  unfold replayCursor
  rw [List.foldl_append]
  rfl
end Internal

def replayAccepted (initial : Internal.Raw) (actions : List Action) :
    Except (Nat × Refusal) Internal.Raw :=
  (Internal.replayCursor initial actions).map Prod.snd

/-- Accepted actions and the raw state reached by their sole validating interpreter. -/
structure State where
  private mk ::
  transcript : List Action
  raw : Internal.Raw
  replayed : Internal.replayCursor {} transcript = .ok (transcript.length,raw)

def empty : State := ⟨[],{},rfl⟩
end Effect4.Tool

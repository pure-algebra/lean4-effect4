import Effect4.Tool.Origin
import Effect4.Program.Typing.FillSet
import Effect4.Program.Typing.CheckCache
import Effect4.Run.LiveRecord
import Effect4.Run.Preview

/-! Tool requests and replies are data. The dispatcher owns their interpretation.
This stays non-module through the program specialization-site imports. -/
set_option autoImplicit false
namespace Effect4.Tool
open Effect4 Effect4.Program
structure RunId where
  n : Nat

inductive RunForm where
  | view | record | journal

inductive PreviewQuery where
  | settle (tape : List Machine.ExitV) (limit : Nat)
  | frames (tape : List Machine.ExitV) (limit : Nat)
  | explore (budget width : Nat)

inductive Action where
  | open_ (name : String) (app : SigApp) (sketch : Sketch)
  | edit (at_ : Program.Snap) (a : Program.DocAction)
  /-- pending additions: per-item outcomes inside a successful answer -/
  | fill (at_ : Program.Snap) (batch : List (List Nat × NativeEff))
  | publish (at_ : Program.Snap)
  | reset
  | start (at_ : Program.Snap) (budget : Api.Budget)
  | restore (record : LiveRecord)
  /-- events folded over a temporary run; an unresolved selector refuses the whole request -/
  | play (run : RunId) (events : List Run.Event)

inductive Query where
  | doc (at_ : Option (List Nat))
  | history
  | fills
  | suggest (at_ : Program.Snap) (place : Program.Place) (supplied : List NativeEff) (cursor limit : Nat)
  | run (id : RunId) (form : RunForm)
  | preview (q : PreviewQuery)
  | dry (a : Action)
  /-- the supported method versions; selection is the connection's, outside the state -/
  | discover

inductive Request where
  | act (a : Action)
  | ask (q : Query)

structure HoleView where
  index : Nat
  row : Row
  path : List Nat
  focus : Option (TyEnv × EffTy)

structure Inspection where
  path : List Nat
  expected : NativeEff
  context : SigData
  focus : Option (Focus NativeOp)
  entry : Option Table.Entry
  refusal : Option TypeRefusal

structure DocView where
  snap : Program.Snap
  type : Option EffTy
  refusals : List TypeRefusal
  holes : List HoleView
  inspection : Option Inspection

/-- In this order: `noDocument`, then the document's own (`foreign`, `stale`, …), then the action's. -/
inductive Refusal where
  | noDocument
  | doc (why : Program.DocRefusal)
  | fillsStale (anchor now : Program.Snap)
  | fillsEmpty
  | admission (why : AdmitRefusal)
  | restore (why : LiveRecord.Refusal)
  | preview (why : Run.Preview.Refusal)
  | noRun (id : RunId)
  | unresolved (id : RunId) (event : Nat) (sel : Run.Sel)
  | suggest (why : Program.FeedRefusal)
  | place (why : Program.PlaceRefusal)
  | noProgram (path : List Nat)

/-- An action's answer; also the payload of a `dry` query. -/
inductive ActionAnswer where
  | opened (view : DocView)
  | edited (view : DocView) (receipt : Program.Receipt)
  | filled (outcomes : List AddOutcome)
  | published (view : DocView) (receipt : Program.Receipt)
  | reset (discarded : List (List Nat × NativeEff))
  | started (run : RunId) (origin : Origin) (view : Live.View)
  | played (run : RunId) (verdicts : List Run.Verdict) (view : Live.View)
  | restored (run : RunId) (view : Live.View)

structure Candidate where
  program : NativeEff
  sourcePath : Option (List Nat)
  key : Check.CheckInput
  evidence : Program.CheckCache.Evidence

inductive RunAnswer where
  | view (v : Live.View)
  | record (r : LiveRecord)
  | journal (commands : List Api.Runner.Command)

inductive PreviewAnswer where
  | settled (result : Option (Nat × Run.Tree.Outcome (List Machine.ExitV)))
  | frames (results : List (Run.Tree.Outcome (List Machine.ExitV)))
  | explored (paths : List Run.Tree.Path)

inductive Answer where
  | acted (a : ActionAnswer)
  | doc (view : DocView)
  | history (actions : List Program.DocAction)
  | fills (anchor : Option Program.Snap) (pending : List (List Nat × NativeEff))
  | suggested (candidates : List Candidate) (nextCursor : Option Nat)
  | run (id : RunId) (a : RunAnswer)
  | preview (result : PreviewAnswer)
  | dry (result : Except Refusal ActionAnswer)
  | methods (supported : List (String × List Nat))

structure Reply where
  result : Except Refusal Answer
  now : Option Program.Snap


def Request.method : Request → String
  | .act (.open_ ..) => "open"
  | .act (.edit ..) => "edit"
  | .act (.fill ..) => "fill"
  | .act (.publish ..) => "publish"
  | .act .reset => "reset"
  | .act (.start ..) => "start"
  | .act (.restore ..) => "restore"
  | .act (.play ..) => "play"
  | .ask (.doc ..) => "doc"
  | .ask .history => "history"
  | .ask .fills => "fills"
  | .ask (.suggest ..) => "suggest"
  | .ask (.run ..) => "run"
  | .ask (.preview ..) => "preview"
  | .ask (.dry ..) => "dry"
  | .ask .discover => "discover"

def supportedMethods : List (String × List Nat) :=
  ["open","edit","fill","publish","reset","start","restore","play",
    "doc","history","fills","suggest","run","preview","dry","discover"].map
    fun name => (name,[1])
end Effect4.Tool

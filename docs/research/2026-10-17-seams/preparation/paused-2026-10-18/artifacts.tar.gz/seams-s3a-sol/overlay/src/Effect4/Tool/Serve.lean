import Effect4.Tool.Replay
import Effect4.Tool.Queries
set_option autoImplicit false
namespace Effect4.Tool
open Effect4.Program.Check

/-- Helper of serve_appends and transcript_replays; an accepted action extends the retained fold. -/
def State.accept (s : State) (a : Action) (next : Internal.Raw) (answer : ActionAnswer)
    (h : (Internal.action Oracle.uncached s.raw a).value = .ok (next,answer)) : State :=
  ⟨s.transcript ++ [a],next,by
    rw [Internal.replayCursor_snoc, s.replayed]
    simp only [Internal.replayStep, Except.bind, h, List.length_append, List.length_singleton]
    rfl⟩

def serve (o : Oracle) (s : State) : Request → Checked (State × Reply)
  | .act a =>
    let c := Internal.action o s.raw a
    match h : c.value with
    | .error why => c.bind' fun _ => pure (s,⟨.error why,Internal.current s.raw⟩)
    | .ok (next,answer) =>
      let accepted := State.accept s a next answer (by
        have hc : (Internal.action o s.raw a).value = .ok (next,answer) := h
        rw [Oracle.eq_uncached o] at hc
        exact hc)
      c.bind' fun _ => pure (accepted,⟨.ok (.acted answer),Internal.current next⟩)
  | .ask q => do
    let result ← Internal.query o s.raw q
    pure (s,⟨result,Internal.current s.raw⟩)
end Effect4.Tool

import subprocess,sys
from pathlib import Path
r=Path('/private/tmp/seams-s3a-sol')
for m in ['Effect4.Tool.Protocol','Effect4.Tool.Actions','Effect4.Tool.Replay','Effect4.Tool.Queries','Effect4.Tool.Serve']:
 print('S3A TRAIN',m,flush=True)
 x=subprocess.run(['python3',str(r/'compile.py'),m])
 if x.returncode:sys.exit(x.returncode)

import Effect4.Program.Typing.SourceDocument

/-! Pending finite controls for the actual fresh S1/S2 packet.
A root candidate uses its real module query; a below-root missing focus has no query key.
These controls remain uncompiled until the owner supplies current S1 artifacts. -/
namespace Test.SeamsSuggestionKeyControls
open Effect4 Effect4.Program Effect4.Program.Check

def rootProgram : NativeEff := .succeed (.lit (.nat 0))
def rootCandidate : NativeEff := .succeed (.lit (.nat 1))
def rootSource : SourceSession :=
  (SourceSession.open Oracle.uncached {} { program := rootProgram }).value

#guard rootSource.partKey [] rootCandidate = none
#guard (rootSource.feed Oracle.uncached .keepExact (.fill [] rootCandidate)).value.isOk
#guard ((rootSource.feed Oracle.uncached .keepExact (.fill [] rootCandidate)).trace.map Prod.fst) =
  ((Checked.ask Oracle.uncached (.module {} [] rootCandidate)).trace.map Prod.fst)

def badChild : NativeEff := .succeed (.var 0)
def badProgram : NativeEff := .bind badChild (.succeed (.var 0))
def badSource : SourceSession :=
  (SourceSession.open Oracle.uncached {} { program := badProgram }).value

#guard match Place.resolve {} { program := badProgram } (.at_ [0] badChild) with
  | .ok (path, program) => path == [0] && program == badChild
  | .error _ => false
#guard (badSource.focusAt [0]).isNone
#guard badSource.partKey [0] rootCandidate = none
#guard match (badSource.feed Oracle.uncached .keepExact (.fill [0] rootCandidate)).value with
  | .error (.noFocus [0]) => true
  | _ => false
#guard (badSource.feed Oracle.uncached .keepExact (.fill [0] rootCandidate)).trace.isEmpty
end Test.SeamsSuggestionKeyControls

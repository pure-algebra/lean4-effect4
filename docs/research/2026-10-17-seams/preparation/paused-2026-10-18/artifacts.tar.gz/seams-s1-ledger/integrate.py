from pathlib import Path
import hashlib,json,shutil
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');p=Path('/private/tmp/seams-s1-ledger');e=r/'docs/research/2026-10-17-seams/receipts/evidence/S1'
assert (p/'green-status.json').exists() and json.loads((p/'green-status.json').read_text())['exit_status']==0
f=r/'src/Effect4/Program/Typing/SourceDocument.lean';hashes=json.loads((p/'sources.json').read_text());assert hashlib.sha256(f.read_bytes()).hexdigest()==hashes['old'];f.write_bytes((p/'src/Effect4/Program/Typing/SourceDocument.lean').read_bytes())
f=r/'Test/Program/SourceDocumentControls.lean';s=f.read_text();anchor='end Test.Program.SeamsS1.DocControls';assert anchor in s
s=s.replace(anchor,'''-- Revert checks each inverse once, without replaying earlier accepted actions.
#guard reverted.trace.length = 2
-- Missing entries and empty inverses perform no earlier checker asks.
#guard (run d0 (.revert 5)).trace.isEmpty
#guard (run noopDoc (.revert 0)).trace.isEmpty

'''+anchor);f.write_text(s)
dest=e/'runtime-ledger';dest.mkdir(parents=True,exist_ok=True)
for name in ['PLACEMENT.md','SourceDocument-before.lean','LedgerControl.lean','red.log','green.log','green-status.json','sources.json','order.json','run.py']:
 shutil.copyfile(p/name,dest/name)
shutil.copytree(p/'logs',dest/'logs',dirs_exist_ok=True)
(e/'runtime-ledger-source-hashes.json').write_text(json.dumps({name:hashlib.sha256((r/name).read_bytes()).hexdigest() for name in ['src/Effect4/Program/Typing/SourceDocument.lean','Test/Program/SourceDocumentControls.lean']},indent=2)+'\n')
print('Integrated witnessed runtime ledger and the same three red-to-green controls.')

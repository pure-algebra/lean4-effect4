from pathlib import Path
import hashlib,json
p=Path('/private/tmp/seams-s1-ledger'); old=Path('/private/tmp/seams-check-sol/s1-full/src/Effect4/Program/Typing/SourceDocument.lean').read_text()
(p/'SourceDocument-before.lean').write_text(old)
new=old[:old.index('structure Doc where')]+'''/-- A sealed document retains the full state produced by its accepted actions.
Only origin and history persist; replay reconstructs this runtime state. -/
structure Doc where
  private mk ::
  origin : DocOrigin
  history : List DocAction
  runtime : DocInternal.State
  replayedState : DocInternal.replayState origin history = .ok runtime

namespace Doc
open DocInternal

def session (d : Doc) : SourceSession := d.runtime.session

/-- Helper of step_replay: the retained runtime witness gives the same source-session observation. -/
theorem replayed (d : Doc) : replayDoc d.origin d.history = .ok d.session := by
  unfold replayDoc
  rw [d.replayedState]
  rfl

def snap (d : Doc) : Snap := ⟨d.origin.id, d.history.length⟩

def id (d : Doc) : DocId := d.origin.id
def revision (d : Doc) : Nat := d.history.length

def check (d : Doc) (at_ : Snap) : Except DocRefusal Unit :=
  if at_.doc ≠ d.origin.id then .error (.foreign d.origin.id)
  else if at_.revision ≠ d.history.length then .error (.stale d.snap)
  else .ok ()

def open_ (origin : DocOrigin) : Checked Doc :=
  let c := SourceSession.«open» Oracle.uncached origin.app origin.sketch
  let answer : Doc := ⟨origin, [], ⟨c.value, []⟩, rfl⟩
  c.bind' fun _ => pure answer

/-- Helper of step_replay: one action extends the complete replay witness and its undo ledger. -/
theorem sealRuntime {o : Oracle} (d : Doc) {action : DocAction} {fresh : Fresh}
    (ha : (apply o d.runtime action).value = .ok fresh) :
    replayState d.origin (d.history ++ [action]) =
      .ok ⟨fresh.session, d.runtime.entries ++ [fresh.entry]⟩ := by
  rw [Oracle.eq_uncached o] at ha
  rw [replayState_snoc, d.replayedState]
  change advance d.runtime (apply Oracle.uncached d.runtime action).value = _
  rw [ha]
  rfl

/-- One accepted action adds one history entry. A refusal returns no replacement document.
Every action reads the retained runtime ledger and calls the sole interpreter once. -/
def step (o : Oracle) (d : Doc) (at_ : Snap) (action : DocAction) :
    Checked (Except DocRefusal (Doc × Receipt)) := do
  match d.check at_ with
  | .error why => pure (.error why)
  | .ok () =>
    let c := apply o d.runtime action
    let answer := match h : c.value with
      | .error why => .error why
      | .ok fresh => .ok (⟨d.origin, d.history ++ [action],
          ⟨fresh.session, d.runtime.entries ++ [fresh.entry]⟩,
          sealRuntime d h⟩, fresh.receipt)
    c.bind' fun _ => pure answer

end Doc

end Effect4.Program
'''
f=p/'src/Effect4/Program/Typing/SourceDocument.lean';f.parent.mkdir(parents=True,exist_ok=True);f.write_text(new)
(p/'sources.json').write_text(json.dumps({'old':hashlib.sha256(old.encode()).hexdigest(),'new':hashlib.sha256(new.encode()).hexdigest()},indent=2)+'\n')
control='''import Test.Program.SourceDocumentControls
set_option maxRecDepth 20000
set_option maxHeartbeats 2400000
open Effect4.Program Check
open Test.Program.SeamsS1.DocControls
-- The two inverse items each ask once; prior document actions must not run again.
#guard reverted.trace.length = 2
-- A missing undo entry performs no earlier document checks.
#guard (run d0 (.revert 5)).trace.isEmpty
-- A no-op's empty inverse changes history without replaying the original open.
#guard (run noopDoc (.revert 0)).trace.isEmpty
'''
(p/'LedgerControl.lean').write_text(control)

from pathlib import Path
import subprocess,json,hashlib,shlex
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');e=r/'docs/research/2026-10-17-seams/receipts/evidence/ST2'
base=(e/'base.txt').read_text().strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==base
labels=['versions','narrow','audit','generate-cas','generate-store-rocq','rocq','native-store','batteries','check-ocaml','generate-semantics']
records={label:json.loads((e/(label+'.json')).read_text()) for label in labels}
for label,record in records.items():assert record['exit_status']==0,(label,record)
assert not git('diff','--cached','--name-only')
allowed={x['target'] for x in json.loads((e/'source-manifest.json').read_text()) if x['target']!='Test/Store/SeamsRecoveryAudit.lean'}
allowed|={'src/Effect4/Laws.lean','Test/All.lean','tools/ProofGraph/Registry.lean','docs/core/semantics.md','generated/semantics.md','rocq/StoreCode.v'}
paths=sorted(set(git('diff','--name-only','HEAD').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines()))
assert set(paths)<=allowed,set(paths)-allowed
(e/'landed-source-paths.txt').write_text('\n'.join(paths)+'\n')
(e/'landed-source-hashes.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
subprocess.run(['git','add','--',*paths],cwd=r,check=True)
assert git('diff','--cached','--name-only').splitlines()==paths
subprocess.run(['git','commit','-m','ST2: Admit checked disk images and retain published damage'],cwd=r,check=True)
head=git('rev-parse','HEAD')
s=Path('/private/tmp/seams-st2-receipt-draft.md').read_text().replace('BASE_COMMIT','`'+base+'`').replace('HEAD_COMMIT','`'+head+'`')
audit='\n'.join(x for x in (e/'audit.log').read_text().splitlines() if '#axiom_audit:' in x)
assert audit
summary='''`landed-source-paths.txt` lists every implementation path.
`landed-source-hashes.json` pins its bytes at the implementation commit.
The frozen preparation records keep their bounded scope; the production commands below establish this landing.

```text
'''+audit+'''
```

| Check | Exit | Seconds | Exact command |
| --- | --- | --- | --- |'''
for label,a in records.items():
 summary+='\n| ['+label+'](evidence/ST2/'+label+'.json) | '+str(a['exit_status'])+' | '+str(a['elapsed_seconds'])+' | `'+shlex.join(a['command'])+'` |'
s=s.replace('PENDING_COMMANDS',summary+'\n');(r/'docs/research/2026-10-17-seams/receipts/ST2.md').write_text(s.rstrip()+'\n')
p=r/'docs/research/2026-10-17-seams/receipts/README.md';s=p.read_text()
s=s.replace('| ST2 | Pending | Pending | Open |','| ST2 | `'+head+'` | [ST2](ST2.md) | Required checks pass; all three recovery claims are proved. |')
s=s.replace('\n## Proposed decisions rows\n',"""
| ST2 | Recovery validates an image with exact legacy generations instead of inventing a transaction journal. |
| ST2 | Native bytes enter one generated refusal adapter before semantic admission; decoded Val order stays unchanged. |
| ST2 | Missing published bytes and sealed damage refuse without evidence loss; only writable uncommitted tails truncate. |
| ST2 | The empty boundary sentinel normalizes without changing root generations; the vacuous R4 control is removed. |
| ST2 | The golden printer handles the two recovery refusals; native CI installs the tested STM dependencies. |

## Proposed decisions rows
""")
s=s.replace('\nThe individual receipts retain commands, exit statuses, audit output, red controls, and evidence limits.',"""
| ST2 | Admit empty-store checked images, retaining exact roots and shared node admission without historical ancestry claims. |
| ST2 | Keep Capacity and Fault separate; expose frozen images through one owned writer. |
| ST2 | Preserve published and sealed damage; retain actual-model tables, command comparisons, and real interruption controls. |

The individual receipts retain commands, exit statuses, audit output, red controls, and evidence limits.""")
p.write_text(s)
receipts=[str(p.relative_to(r)) for p in sorted(e.rglob('*')) if p.is_file()]
assert not any(p.is_symlink() for p in e.rglob('*'))
receipts+=['docs/research/2026-10-17-seams/receipts/ST2.md','docs/research/2026-10-17-seams/receipts/README.md']
subprocess.run(['git','add','-f','--',*receipts],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','commit','-m','ST2: Record disk comparison, interruption, and recovery evidence'],cwd=r,check=True)
print(json.dumps({'implementation':head,'receipt':git('rev-parse','HEAD'),'status':git('status','--short')},indent=2))

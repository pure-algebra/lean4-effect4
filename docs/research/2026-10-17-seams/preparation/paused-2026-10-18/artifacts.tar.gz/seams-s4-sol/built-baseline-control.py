from pathlib import Path
import subprocess,json
r=Path('/private/tmp/seams-s4-sol');w=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');e=r/'evidence';e.mkdir(exist_ok=True)
f=e/'forged_built_alias_unadmitted_baseline.ml'
f.write_text('''module A = Effect4_gen.Api_gen
type public_built_alias = A.built
let forged : public_built_alias = {
  app = { rows = []; services = []; types = [] };
  program = Eff_types.Eff.Perform (Eff_types.NativeOp.External 0, Eff_types.Term.Lit Eff_types.Lit.Unit);
  admitted = { answer = Eff_types.Ty.Nat; error = Eff_types.Ty.Never; requires = [] };
  row_names = [] }
''')
c=['opam','exec','--switch=effect4','--','ocamlc','-color','never']
for d in ['gen/.effect4_gen.objs/byte','eff/.effect4_eff.objs/byte','clock/.effect4_clock.objs/byte','lcnf/.effect4_lcnf.objs/byte']:c+=['-I',str(w/'ocaml/_build/default'/d)]
c+=['-c',str(f)]
x=subprocess.run(c,cwd=w,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(e/'forged-built-alias-unadmitted-baseline.log').write_text(x.stdout)
(e/'forged-built-alias-unadmitted-baseline.json').write_text(json.dumps({'command':c,'exit':x.returncode,'expected':0,'scope':'S0 baseline admits forged Built; positive evidence of S4 sealing necessity'},indent=2)+'\n')
print(x.stdout);print('baseline-forged-built exit',x.returncode);assert x.returncode==0

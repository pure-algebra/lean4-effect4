from pathlib import Path
import subprocess,sys,shutil
r=Path('/private/tmp/seams-s4-sol');w=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4')
for name in ['Effect4.Run.Event','Effect4.Run.View']:
 rel=Path('src').joinpath(*name.split('.')).with_suffix('.lean')
 for d in ['baseline','overlay']:
  p=r/d/rel
  if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(w/rel,p)
modules=['Effect4.Api.HostSession','Effect4.Api.Runner','Effect4.Api.Built',
 'Effect4.Run.Basic','Effect4.Run.Event','Effect4.Run.Live','Effect4.Run.View',
 'Effect4.Run.LiveRecord','Effect4.Laws.Api.HostSession','Effect4.Laws.Run',
 'Effect4.Laws.Api.MaskRuns','Effect4.Laws.Api.Live','Effect4.Laws.Api.LiveRecord',
 'Test.Program.SeamsS0','Test.Program.SeamsS4','Test.Api.HostSessionContract',
 'Test.Api.TypedReplies','Test.Api.RunnerContract','Test.Run.RunContract',
 'Test.Run.LiveContract','Test.Program.QueueScenariosData','Test.Codegen.TermRows',
 'Tools.Session']
start=int(sys.argv[1]) if len(sys.argv)>1 else 0
for i,module in enumerate(modules[start:],start):
 print('S4 TRAIN',i,module,flush=True)
 x=subprocess.run(['python3',str(r/'compile.py'),module])
 if x.returncode:print('S4 TRAIN STOP',i,module,flush=True);sys.exit(x.returncode)
print('S4 TRAIN PASS',len(modules),flush=True)

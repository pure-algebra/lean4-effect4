from pathlib import Path
r=Path('/private/tmp/seams-s4-sol/overlay/src');w=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4/.lake/build/lib/lean')
n=0
for f in [*w.rglob('*.olean*'), *w.rglob('*.ir*')]:
 p=r/f.relative_to(w)
 if p.exists() or p.is_symlink():continue
 p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(f);n+=1
print('linked inherited production olean imports',n)

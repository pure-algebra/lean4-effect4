import Effect4.Api.HostProtocol
import Effect4.Program.Typing.Parts

/-!
A checked, keyed host-reply session over the existing Eff machine. The program and its
application (`SigApp`: the row table and the named types; a row table alone coerces to one) are
indexed by the existing admission certificate. A reply is admitted under the application's named
types (`acceptReply`, decisions row 406 (2)); the machine steps at its rows. Recorder call IDs are distinct
from machine guard tokens; `bindCall` is their checked association. No oracle answers are
loaded. This module owns no JSON decoder, host adequacy theorem or scheduling policy.
Authority: Test/contracts/foundation-wave2.contract.md, S6b host protocol.
-/

set_option autoImplicit false

namespace Effect4.Api.HostSession

open Effect4 Effect4.Machine Effect4.Program

abbrev Answer := Completion Val Err Defect FiberId Ann

abbrev Key := HostProtocol.Key

def version : Nat := HostProtocol.hostProtocol.version

structure Header where
  version : Nat
  session : String
  /-- The host binding the holder selected, matched by equality: `keyed-v3`,
  `serial-root-scalar-v1`. It is no target profile (`ProfileData`); decisions row 326 (4) renamed
  the field. -/
  binding : String
  table : RowTable
deriving DecidableEq, Repr

/-- The header's binding under its former name. Callers outside the files of the session note's
slice DM3 read it: `harness/truth/session/Session.lean` and `step_profile`
(`src/Effect4/Laws/Run.lean`). It goes when they move. -/
abbrev Header.profile (header : Header) : String := header.binding

/-- Actual call-start claims. `fiber` is a recorded semantic fiber ID, not an implicit
conversion from a runtime fiber number. A binding must justify that association. -/
structure Call where
  version : Nat
  session : String
  table : RowTable
  callId : Nat
  fiber : FiberId
  op : NativeOp
  request : Val
deriving DecidableEq

/-- A recorder call paired with the separately checked replay guard. -/
structure BoundCall where
  call : Call
  token : Nat
deriving DecidableEq

structure Reply where
  version : Nat
  session : String
  callId : Nat
  key : Key
  completion : Answer
deriving DecidableEq

def BoundCall.key (bound : BoundCall) : Key := ⟨bound.call.fiber, bound.token⟩

/-- Slots are created in binding order, so receipt changes a value without reordering
storage. The finite representation contains no function-valued map. -/
structure ReplySlot where
  key : Key
  reply : Option Reply
 deriving DecidableEq

def readReply : List ReplySlot → Key → Option Reply
  | [], _ => none
  | slot :: rest, key => if slot.key = key then slot.reply else readReply rest key

def storeReply (slots : List ReplySlot) (reply : Reply) : List ReplySlot :=
  slots.map fun slot => if slot.key = reply.key then { slot with reply := some reply } else slot

/-- The recorded claims come from the call record, not from the machine's expected call. -/
def BoundCall.record (bound : BoundCall) (reply : Reply) : RecordedReply :=
  ⟨bound.call.table, bound.call.fiber, bound.token, bound.call.op,
    bound.call.request, reply.completion⟩

/-- Retiring a cancelled association preserves any accepted but unapplied completion.
A resource binding must account for its cleanup; this record does not perform host cleanup. -/
structure RetiredCall where
  bound : BoundCall
  pending : Option Reply
deriving DecidableEq

structure Session (program : Api.Program) (app : SigApp) where
  admitted : AdmittedProgram program app
  header : Header
  machine : Api.Machine
  nextCall : Nat := 0
  applied : Nat := 0
  active : List BoundCall := []
  pending : List ReplySlot := []
  consumed : List Nat := []
  retired : List RetiredCall := []
  /-- The program's checked call table (`Program.programCalls`), made once by `start`, so that no
  reply runs the checker (decisions row 323; the session note's slice DM5). Empty, a session
  admits replies at the rows' own columns alone. -/
  calls : List (List Nat × CallInstance NativeOp) := []
  /-- No reply application of the session was cut by its command fuel (decisions row 326 (4);
  the session note's slice DM4). A control reports its fuel in its verdict (`frontier`), but an
  application answers `applied` as soon as its call's guard is gone, so the session keeps the
  bit (`applyReply`). -/
  funded : Bool := true

inductive Refusal
  | version
  | session
  /-- The header names a binding other than the one the holder selected. The refusal keeps its
  name until slice DM6 renames it with the refusals it deletes. -/
  | profile
  | table
  | program (reason : AdmitRefusal)
  | duplicateCall
  | protocol
  | selectionRequired
  | pendingReply
  | callOrder
  | noCall
  | staleCall
  | envelope
  | directAnswer
  | pendingControl
  | stuck
  deriving DecidableEq, Repr

inductive Phase
  | bound
  | preflight
  | applied
  | progressed
  | frontier
  | refused (reason : Refusal)
  deriving DecidableEq, Repr

structure Result (program : Api.Program) (app : SigApp) where
  phase : Phase
  session : Session program app

/-- **The program's checked call table**, at the signature that admits it (`app.signature`), on
the program with its layer references expanded, as the module check types it
(`Program.programCalls`): a call in a definition's body or in a block's main program has its
instance at the block's signature (decisions rows 323 and 333). `Run.open` makes it
once (the session note's slice DM5). -/
def callTable (program : Api.Program) (app : SigApp) :
    List (List Nat × CallInstance NativeOp) :=
  Program.programCalls app.signature [] program.expandRefs

def outstanding {program : Api.Program} {app : SigApp} (s : Session program app) :
    List Await := awaits s.machine

/-- Associate exactly the claims recorded at call start with an outstanding guard. The
next call ID is allocated here; completion application has a separate counter. -/
def bindCall {program : Api.Program} {app : SigApp} (s : Session program app)
    (call : Call) (token : Nat) : Result program app :=
  let refuse := fun why => ⟨.refused why, s⟩
  if call.version ≠ version then refuse .version
  else if call.session ≠ s.header.session then refuse .session
  else if call.table ≠ app.rows then refuse .table
  else if s.active.any (fun bound => bound.key == ⟨call.fiber, token⟩) then refuse .duplicateCall
  else if call.callId ≠ s.nextCall then refuse .callOrder
  else if requestOf s.machine call.fiber token ≠ some (call.op, call.request) then
    refuse .staleCall
  else ⟨.bound, { s with
    active := s.active ++ [⟨call, token⟩]
    pending := s.pending ++ [⟨⟨call.fiber, token⟩, none⟩]
    nextCall := s.nextCall + 1 }⟩

/-- **The checked instance at a call's address** in the session's program (`programCallAt`), at
the signature that admitted it (`app.signature`), on the program with its layer references
expanded, as the module check types it. `none` where no call stands at the address; on an
admitted program it answers at every call (`instanceAt_complete`). It is the specification of
the session's table: a canonical open reads it (`Run.reached_callInstance`). -/
def instanceAt (program : Api.Program) (app : SigApp) :
    List Nat → Option (CallInstance NativeOp) :=
  programCallAt app.signature [] program.expandRefs

/-- The session's checked instance at an address: a lookup in the table that `Run.open` makes. -/
def Session.callInstance {program : Api.Program} {app : SigApp} (s : Session program app)
    (origin : List Nat) : Option (CallInstance NativeOp) :=
  s.calls.lookup origin

/-- Pure preflight. Success establishes the existing `Envelope`, or, where the row's own
columns refuse the completion, the envelope at the call's checked instance
(`InstanceEnvelope`, decisions row 183). It returns only the recorded answer decision. It
neither applies a decision nor consumes a reply. -/
def preflight {program : Api.Program} {app : SigApp} (s : Session program app)
    (reply : Reply) : Except Refusal NativeDecision :=
  if reply.version ≠ version then .error .version
  else if reply.session ≠ s.header.session then .error .session
  else match s.active.find? (fun bound => bound.key == reply.key) with
    | none => .error .noCall
    | some bound =>
      if reply.callId ≠ bound.call.callId then .error .callOrder
      else if requestOf s.machine bound.call.fiber bound.token = none then .error .staleCall
      else match acceptReply app s.machine (bound.record reply) with
        | some decision => .ok decision
        | none =>
          match acceptAtInstance app s.callInstance s.machine (bound.record reply) with
          | some decision => .ok decision
          | none => .error .envelope

/-- Pending completions in binding order; no application policy is inferred from this list. -/
def pendingReplies {program : Api.Program} {app : SigApp} (s : Session program app) : List Reply :=
  s.pending.filterMap ReplySlot.reply

/-- Receipt stores only. Another key may already have a pending completion. -/
def submit {program : Api.Program} {app : SigApp} (s : Session program app)
    (reply : Reply) : Result program app :=
  if (readReply s.pending reply.key).isSome then ⟨.refused .pendingReply, s⟩
  else match preflight s reply with
    | .error why => ⟨.refused why, s⟩
    | .ok _ =>
      if !(s.pending.any fun slot => slot.key == reply.key) then ⟨.refused .noCall, s⟩
      else if !HostProtocol.allows (HostProtocol.observe s.machine) (.submit reply.key)
          (HostProtocol.observe s.machine) then ⟨.refused .protocol, s⟩
      else ⟨.preflight, { s with pending := storeReply s.pending reply }⟩

/-- Retire every association whose exact guard was removed by a machine step. Shared
cancellation may retire more than the selected key. Accepted but unapplied payloads remain
available to the host cleanup driver, without consuming a machine allocation or a call. -/
def retire {program : Api.Program} {app : SigApp} (s : Session program app) : Session program app :=
  let dead := s.active.filter fun bound => (requestOf s.machine bound.call.fiber bound.token).isNone
  { s with
    active := s.active.filter fun bound => (requestOf s.machine bound.call.fiber bound.token).isSome
    pending := s.pending.filter fun slot => !(dead.any fun bound => bound.key == slot.key)
    retired := s.retired ++ dead.map (fun bound => ⟨bound, readReply s.pending bound.key⟩) }

/-- Execute one explicitly selected key. Zero fuel changes nothing. Consumption is counted
only after its exact guard disappears. The remaining continuations run in the tape's order;
this function is deliberately absent from the receipt commutation law.

The step is taken once, as `advance` takes it, and an applied step keeps whether it had enough
command fuel at a live machine (`funded`, decisions row 326 (4)). The verdict stays `applied`, so
the wire does not change. -/
def applyReply {program : Api.Program} {app : SigApp} (s : Session program app)
    (key : Key) : Nat → Result program app
  | 0 => ⟨.frontier, s⟩
  | fuel + 1 =>
    match s.active.find? (fun bound => bound.key == key), readReply s.pending key with
    | some bound, some reply =>
      match preflight s reply with
      | .error why => ⟨.refused why, s⟩
      | .ok decision =>
        let step := (letI := evaluatorFor program app.rows
          stepDecisionState (interpOf program app.rows) (fuel + 1) s.machine decision)
        let machine := step.1
        if !HostProtocol.allows (HostProtocol.observe s.machine) (.answer key)
            (HostProtocol.observe machine) then ⟨.refused .protocol, s⟩
        else if requestOf machine bound.call.fiber bound.token = none then
          let next := { s with
            machine := machine
            active := s.active.filter (fun b => b.key != key)
            pending := s.pending.filter (fun slot => slot.key != key)
            applied := s.applied + 1
            consumed := s.consumed ++ [bound.call.callId]
            funded := s.funded && (s.machine.stuck.isNone && step.2) }
          ⟨.applied, retire next⟩
        else ⟨.frontier, { s with machine }⟩
    | _, _ => ⟨.refused .noCall, s⟩

/-- Explicit compatibility convenience for a single pending completion. More than one
pending reply requires a key; arrival or binding order is never an implicit scheduler. -/
def applyPending {program : Api.Program} {app : SigApp} (s : Session program app) :
    Nat → Result program app
  | 0 => ⟨.frontier, s⟩
  | fuel + 1 => match pendingReplies s with
    | [reply] => applyReply s reply.key (fuel + 1)
    | [] => ⟨.refused .noCall, s⟩
    | _ => ⟨.refused .selectionRequired, s⟩

/-- Controls and reply applications are separate tape records. Pending replies do not
forbid scheduling other fibers. After any control, all removed associations are retired. -/
def advance {program : Api.Program} {app : SigApp} (s : Session program app)
    (fuel : Nat) (decision : NativeDecision) : Result program app :=
  match decision with
  | .answerAsync _ _ _ => ⟨.refused .directAnswer, s⟩
  | _ =>
    if s.machine.stuck.isSome then ⟨.refused .stuck, s⟩
    else
      letI := evaluatorFor program app.rows
      let (machine, enough) := stepDecisionState (interpOf program app.rows) fuel s.machine decision
      if !HostProtocol.allows (HostProtocol.observe s.machine) (HostProtocol.controlLabel decision)
          (HostProtocol.observe machine) then ⟨.refused .protocol, s⟩
      else ⟨if enough then .progressed else .frontier, retire { s with machine }⟩

/-- Reading a frontier does not execute pending replies or discard the session ledger. -/
def inspect {program : Api.Program} {app : SigApp} (s : Session program app) :
    Api.Inspection :=
  letI := evaluatorFor program app.rows
  match replayEval (interpOf program app.rows) 0 [] s.machine with
  | .finished m => ⟨.finished, m, []⟩
  | .frontier why m => ⟨.frontier, m, Api.frontierReasons why m⟩
  | .stuck why m => ⟨.stuck why, m, []⟩

end Effect4.Api.HostSession

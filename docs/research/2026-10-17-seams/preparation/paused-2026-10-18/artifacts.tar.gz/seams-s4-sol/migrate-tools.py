from pathlib import Path
r=Path('/private/tmp/seams-s4-sol/overlay')
p=r/'tools/Tools/Session.lean';s=p.read_text();a=s.index('      | "start" =>');b=s.index('      | "settle" | "frames" | "explore" =>',a);part=s[a:b]
part=part.replace('let app := l.app.withHoles l.sketch.holes','let app := l.app')
part=part.replace('match Effect4.Program.admitProgram l.sketch.program app with','match Effect4.Api.Built.ofSketch app l.sketch with')
part=part.replace('| .ok admitted =>','| .ok b =>')
part=part.replace('          let rowNames := app.rows.zipIdx.map fun (r, i) => (r.spelling, i)\n          let b : Effect4.Api.Built := { app, program := l.sketch.program, admitted, rowNames }\n','')
part=part.replace('            let b : Effect4.Api.Built := { app, program := l.sketch.program, admitted }\n','')
s=s[:a]+part+s[b:];p.write_text(s)
p=r/'src/Effect4/Laws/Api/MaskRuns.lean';s=p.read_text()
for a,b in [('/-- **The entry `HostSession.start`','/-- A binding writes'),('/-- **The entry `Runner.load`','/-- **The entry `Runner.step`')]:
 i=s.index(a);j=s.index(b,i);s=s[:i]+s[j:]
p.write_text(s)

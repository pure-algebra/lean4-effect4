from pathlib import Path
import re,json
r=Path('/private/tmp/seams-s4-sol');b=r/'baseline';o=r/'overlay';checks=[]
p='src/Effect4/Laws/Api/LiveRecord.lean'
for n in ['restore_save','restore_unsupportedVersion','ofTuple_toTuple','decode_encode']:
 def statement(f):
  s=f.read_text();i=s.index('theorem '+n);j=s.index(':=',i);return s[i:j]
 assert statement(b/p)==statement(o/p),n
 checks.append('unchanged statement '+n)
for p,name in [('src/Effect4/Api/HostSession.lean','start'),('src/Effect4/Api/Runner.lean','load'),('src/Effect4/Run/Basic.lean','runPure'),('src/Effect4/Run/Live.lean','start'),('src/Effect4/Run/Live.lean','replay')]:
 assert not re.search(r'^def '+name+r'\b',(o/p).read_text(),re.M),(p,name)
 checks.append('retired '+p+' '+name)
d=json.loads((o/'ocaml/gen/roots.json').read_text());a=next(a for a in d['artefacts'] if a['out']=='ocaml/gen/api_gen.ml')
for k in ['roots','nominal']:
 for n in ['Effect4.Api.Built.ofSketch','Effect4.Live.open']:assert a[k].count(n)==1,(k,n)
 assert 'Effect4.Live.start' not in a[k]
assert a['abstract'].count('Effect4.Api.Built')==1
checks.append('explicit builder/open roots and nominal ascriptions once; Built abstract')
s=(o/'tools/Tools/Session.lean').read_text();i=s.index('      | "start" =>');j=s.index('      | "settle" |',i);part=s[i:j]
assert part.count('Effect4.Api.Built.ofSketch app l.sketch')==2
assert 'withHoles' not in part and 'Api.Built :=' not in part
checks.append('both dispatcher paths use application-only builder')
(r/'evidence/static-controls.json').write_text(json.dumps({'exit':0,'scope':'source comparisons only, no Lean/native correctness claim','checks':checks},indent=2)+'\n')
print('\n'.join('PASS '+c for c in checks))

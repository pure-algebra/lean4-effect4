from pathlib import Path
import difflib,json,hashlib
r=Path('/private/tmp/seams-s4-sol');b=r/'baseline';o=r/'overlay'
files=sorted(p.relative_to(o) for p in o.rglob('*') if p.is_file() and p.suffix in ['.lean','.py','.ml','.json'])
changed=[];patch=[]
for rel in files:
 old=(b/rel).read_text() if (b/rel).exists() else '';new=(o/rel).read_text()
 if old==new:continue
 changed.append({'path':str(rel),'new':not (b/rel).exists(),'baseline_sha256':hashlib.sha256(old.encode()).hexdigest() if (b/rel).exists() else None,'sha256':hashlib.sha256(new.encode()).hexdigest()})
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+str(rel) if (b/rel).exists() else '/dev/null',tofile='b/'+str(rel)))
(r/'draft.patch').write_text(''.join(patch));(r/'draft-paths.json').write_text(json.dumps(changed,indent=2)+'\n');print(len(changed),'draft paths')

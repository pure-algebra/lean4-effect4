import subprocess,sys
for m in ['Effect4.Api.Author','Effect4.Api','Test.Program.InvocationContract']:
 print('S4 EXTRA',m,flush=True)
 x=subprocess.run(['python3','/private/tmp/seams-s4-sol/compile.py',m])
 if x.returncode:sys.exit(x.returncode)

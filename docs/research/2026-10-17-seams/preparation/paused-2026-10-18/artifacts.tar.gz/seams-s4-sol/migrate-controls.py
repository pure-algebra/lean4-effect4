from pathlib import Path
import json
r=Path('/private/tmp/seams-s4-sol/overlay')
p=r/'ocaml/gen/roots.json';d=json.loads(p.read_text())
# Only api_gen owns this admitted opening interface.
for a in d['artifacts'] if 'artifacts' in d else []:
 if a['out']=='ocaml/gen/api_gen.ml':
  for k in ('roots','nominal'):
   v=a[k]; i=v.index('Effect4.Live.start');v[i:i+1]=['Effect4.Api.Built.ofSketch','Effect4.Live.open']
  a['abstract'].append('Effect4.Api.Built')
# Preserve format until recipe schema is confirmed below.
p.write_text(json.dumps(d,indent=2)+'\n')
p=r/'Test/Program/SeamsS0.lean';s=p.read_text();s=s.replace('match Live.start program {} "test" header budget with','match Api.Built.ofSketch {} { program } with').replace('| .ok live =>\n    let record','| .ok built =>\n    let live := Live.open built header.session budget "test"\n    let record').replace('!(Live.start malformed {} "test" header budget).isOk','!(Api.Built.ofSketch {} { program := malformed }).isOk');p.write_text(s)
p=r/'Test/Run/RunContract.lean';s=p.read_text().replace('Run.runPure twice','(Run.open twice "run").play (Rows.start ++ Rows.flush)');p.write_text(s)
for name in ['Test/Program/QueueScenariosData.lean','Test/Codegen/TermRows.lean']:
 p=r/name;s=p.read_text().replace('Run.runPure b "q" { fuel := fuel, compileFuel := fuel }','(Run.open b "q" { fuel := fuel, compileFuel := fuel }).play (Rows.start ++ Rows.flush)');p.write_text(s)
p=r/'ocaml/gen/test_seams_s0.ml';s=p.read_text();s=s.replace('let header : A.header = { version = 3; session = "seams-s0"; binding = "test"; table = [] }\n','');s=s.replace('let live = get (A.live_start program app "test" header budget) in','let built = get (A.api_built_of_sketch app { program; holes = [] }) in\n  let live = A.live_open built "seams-s0" budget "test" in');s=s.replace('refused (A.live_start malformed app "test" header budget)','refused (A.api_built_of_sketch app { program = malformed; holes = [] })');p.write_text(s)
p=r/'scripts/check-lcnf-sealing.py';s=p.read_text().replace("    'memo-public-alias':", "    'built-literal': (2, \"let forged : A.built = { app = { rows = []; services = []; types = [] }; program = Eff_types.Eff.Succeed (Eff_types.Term.Lit (Eff_types.Lit.Nat 7)); row_names = [] }\\n\"),\n    'memo-public-alias':");s=s.replace('six hostile','seven hostile');p.write_text(s)

from pathlib import Path
r=Path('/private/tmp/seams-s4-sol/overlay')
p=r/'Test/Api/TypedReplies.lean';s=p.read_text().replace('match start program table "profile" header 100 with\n  | .ok s => some s','match admitProgram program table with\n  | .ok admitted => some { admitted, header, machine := Api.load program 100,\n      calls := callTable program table }');p.write_text(s)
p=r/'Test/Api/HostSessionContract.lean';s=p.read_text();a=s.index('#guard match start ');b=s.index('#guard outstanding parked',a);s=s[:a]+'''-- Canonical headers use the current version; message-level version controls remain below.
#guard initial.header.version = version
'''+s[b:];p.write_text(s)
p=r/'Test/Api/RunnerContract.lean';s=p.read_text().replace('import Effect4.Laws.Api.Runner\n','import Effect4.Laws.Api.Runner\nimport Effect4.Run.Basic\n');s=s.replace('match load program table "serial-root-scalar-v1" header 100 100 with\n  | .ok p => some p','match Api.Built.ofSketch table { program } with\n  | .ok b => some (Run.open b header.session { fuel := 100, compileFuel := 100 }\n      "serial-root-scalar-v1").runner');s=s.replace('#guard (load program table "serial-root-scalar-v1" { header with version := 99 } 100 100 matches .error .version)','#guard runner.map (·.session.header.version) = some Api.HostSession.version');p.write_text(s)
p=r/'Test/Run/LiveContract.lean';s=p.read_text();a=s.index('-- Green: the session admits');b=s.index('/-! ## The view',a);s=s[:a]+'''-- Full admission supplies the only package that opening needs.
#guard match Api.Built.ofSketch twice.app { program := twice.program } with
  | .ok b => (Live.open b header.session {} "serial-root-scalar-v1").run.journal.isEmpty
  | .error _ => false
-- An empty name is valid for opening and restoration.
#guard (Live.open twice "").run.id = ""

'''+s[b:]
a=s.index('/-- The program of row 183');b=s.index('/-- A session\'s journal',a);s=s[:a]+'''/-- Full admission of row 183's program at its application. -/
def builtFirst : Except AdmitRefusal Api.Built :=
  Api.Built.ofSketch Test.Api.TypedReplies.table { program := Test.Api.TypedReplies.program }

'''+s[b:]
a=s.index('/-- The typed replay of that journal');b=s.index('/-- `some 1` answered:',a);s=s[:a]+'''/-- Open an admitted program and feed its journal in order. -/
def replayed (completion : Api.HostSession.Answer) :
    Option (Except AdmitRefusal Live) :=
  some (builtFirst.map fun b => (Live.open b "session-R" {} "profile").feedAll
    ((answeredWith completion).map .wire))

'''+s[b:]
a=s.index('-- `Live.replay_recorded`,');b=s.index('end Test.Run.LiveContract',a);s=s[:a]+'''-- Restoration retains the whole run, including its row names.
example := LiveRecord.restore_save finished

'''+s[b:]
if 'import Effect4.Laws.Api.LiveRecord' not in s:s='import Effect4.Laws.Api.LiveRecord\n'+s
p.write_text(s)

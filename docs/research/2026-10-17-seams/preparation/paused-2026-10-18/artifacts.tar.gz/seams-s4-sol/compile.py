import json, os, pathlib, subprocess, sys, time, hashlib
w=pathlib.Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4')
o=pathlib.Path('/private/tmp/seams-s4-sol/overlay/src')
e=pathlib.Path('/private/tmp/seams-s4-sol/evidence');e.mkdir(exist_ok=True)
module=sys.argv[1]; label=module.replace('.','-')+'-'+str(len(list(e.glob(module.replace('.','-')+'-*.json')))+1)
source_root=o if module.startswith('Effect4.') else o.parent if module.startswith('Test.') else o.parent/'tools'
p=source_root.joinpath(*module.split('.')).with_suffix('.lean')
target=o.joinpath(*module.split('.')).with_suffix('.olean');target.parent.mkdir(parents=True,exist_ok=True)
lp=':'.join([str(o),*[str(w/'.lake/packages'/n/'.lake/build/lib/lean') for n in ['batteries','effects','typescript','hash','whatwg','aesop']],str(w/'.lake/build/lib/lean')])
c=['python3','/private/tmp/seams-lean-one.py','lake','env','env','LEAN_PATH='+lp,'lean','--root='+str(source_root),'-DwarningAsError=true','-o',str(target),str(p)]
for artifact in target.parent.glob(target.stem+'.olean*'):
 if artifact.is_symlink():artifact.unlink()
source=p.read_bytes()
(e/(label+'.source.lean')).write_bytes(source)
t=time.time()
with (e/(label+'.log')).open('w') as f:r=subprocess.run(c,cwd=w,stdout=f,stderr=subprocess.STDOUT)
(e/(label+'.json')).write_text(json.dumps({'command':c,'exit':r.returncode,'seconds':time.time()-t,'source_sha256':hashlib.sha256(source).hexdigest()},indent=2)+'\n')
print((e/(label+'.log')).read_text());sys.exit(r.returncode)

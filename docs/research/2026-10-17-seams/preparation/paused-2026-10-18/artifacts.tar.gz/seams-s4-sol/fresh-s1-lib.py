from pathlib import Path
import json
r=Path('/private/tmp/seams-s4-sol');lib=r/'fresh-s1-lib';lib.mkdir(exist_ok=True)
# Lean resolves an entire namespace from its first root. Populate that root fully.
s1=Path('/private/tmp/seams-check-sol/s1-full/lib/lean')
for f in [*s1.rglob('*.olean*'), *s1.rglob('*.ir*')]:
 p=lib/f.relative_to(s1)
 if p.exists() or p.is_symlink():continue
 p.parent.mkdir(parents=True,exist_ok=True);p.symlink_to(f)
# Override inherited entries only with successful current S4 outputs.
selected={}
for f in sorted((r/'evidence').glob('*.json'),key=lambda p:p.stat().st_mtime):
 try:m=json.loads(f.read_text())
 except json.JSONDecodeError:continue
 c=m.get('command',[])
 if m.get('exit')!=0 or '-o' not in c:continue
 target=Path(c[c.index('-o')+1])
 if not target.exists() or target.is_symlink():continue
 try:rel=target.relative_to(r/'overlay/src')
 except ValueError:continue
 selected[str(rel)]=target
for rel,target in selected.items():
 p=lib/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if p.is_symlink():p.unlink()
 if not p.exists():p.symlink_to(target)
print('current successful S4 outputs',len(selected))
(r/'evidence/fresh-s1-lib.json').write_text(json.dumps({'scope':'S4 outputs precede check_sol fresh S1 core lib; inherited S0 artifact links excluded','s1_lib':'/private/tmp/seams-check-sol/s1-full/lib/lean','outputs':{k:str(v) for k,v in selected.items()}},indent=2)+'\n')

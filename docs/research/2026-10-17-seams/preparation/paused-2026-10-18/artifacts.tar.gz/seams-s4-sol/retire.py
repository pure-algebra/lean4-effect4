from pathlib import Path
r=Path('/private/tmp/seams-s4-sol/overlay')
def edit(p, old, new):
 f=r/p;s=f.read_text();assert old in s,(p,old);f.write_text(s.replace(old,new))
def cut(p,a,b):
 f=r/p;s=f.read_text();i=s.index(a);j=s.index(b,i);f.write_text(s[:i]+s[j:])
cut('src/Effect4/Api/HostSession.lean','/-- Validate an explicit header','def outstanding')
cut('src/Effect4/Api/Runner.lean','/-- A runner from a program','/-- The checked transition')
cut('src/Effect4/Run/Basic.lean','/-- The ordinary run:','/-- The run under the test clock:')
cut('src/Effect4/Run/Live.lean','/-- **Start a program','/-- Step of `feed`:')
cut('src/Effect4/Run/Live.lean','namespace Api.Typed','end Effect4')
cut('src/Effect4/Laws/Api/HostSession.lean','/-- **A session that `start` made reads','/-- A session whose table')
cut('src/Effect4/Laws/Api/HostSession.lean','/-- **A session that `start` made has','/-- Successful preflight')
cut('src/Effect4/Laws/Api/Live.lean','/-- **Starting refuses','/-- **The view projects')
cut('src/Effect4/Laws/Api/Live.lean','/-- **A session\'s own journal replays through the typed replay**','end Effect4.Live')
cut('src/Effect4/Laws/Run.lean','/-- **O-1.** Opening cannot refuse.','/-! ## Small facts')
edit('src/Effect4/Laws/Run.lean','Run.runPure b id budget','(Run.open b id budget).play (Rows.start ++ Rows.flush)')
# Retain the observation theorem under its current name until the caller census is migrated.

from pathlib import Path
r=Path('/private/tmp/seams-s4-sol/overlay')
def block(path,start,end,new):
 p=r/path;s=p.read_text();i=s.index(start);j=s.index(end,i);p.write_text(s[:i]+new+s[j:])
block('src/Effect4/Run/Live.lean','/-!','set_option autoImplicit false','''/-!
# Live — an admitted run reached from an open

`Api.Built.ofSketch` checks full program admission before `Live.open` constructs a run.
`Live.feed` and `Live.feedAll` feed ordered commands through that run.
The proof field connects every `Live` to `Run.open` and `Run.play`.
`Live.reached` in `src/Effect4/Laws/Api/Live.lean` supplies the existing reached-run predicate.
`LiveRecord.restore` repeats admission and feeds the stored journal.
This file stays outside the module form because it imports the specialization sites.
-/

''')
block('Test/Run/LiveContract.lean','/-!','set_option autoImplicit false','''/-!
Finite controls for live commands and call-instance reply admission.
Readers apply the existing Live laws to reached runs.
Controls distinguish admitted replies from raw unchecked tape replay.
Opening receives a fully admitted Built; restoration owns saved-record admission.
-/

''')
p=r/'src/Effect4/Laws/Api/Live.lean';s=p.read_text();s=s.replace('''* **Starting is the session's start** (`start_error`, `start_ok`): `Live.start` refuses exactly
  where `Api.HostSession.start` refuses, with its reason, and opens the admitted program
  otherwise.
''','');s=s.replace('''  call's checked instance, and it fits there. `Api.Typed.replay` answers a `Live`, so the law reads
  every run that it replays.
* **A session's own journal replays through the typed replay** (`replay_recorded`): it answers the
  session's run, its row spellings dropped, so it refuses no run command that the session accepted.
''','''  call's checked instance, and it fits there. The law reads every admitted live run.
''');s=s.replace('`Api.Typed.replay` (`src/Effect4/Run/Live.lean`) starts the certified program and feeds a journal','`Live.open` opens the admitted program and `Live.feedAll` feeds a journal');s=s.replace('`Api.Typed.replay` answers a `Live`, so this holds','`Live.feedAll` answers a `Live`, so this holds');s=s.replace('`Api.Typed.replay`, then the OCaml checked session','`Live.feedAll`, then the OCaml checked session');s=s.replace('Step of `replay_recorded`: feeding','Step of `LiveRecord.restore_save`: feeding').replace('Step of `replay_recorded`: a run','A run');p.write_text(s)
p=r/'src/Effect4/Laws/Run.lean';s=p.read_text();a=s.index('* **Opening cannot refuse**');b=s.index('\n* ',a+3);s=s[:a]+s[b+1:];s=s.replace('This is the fact `HostSession.start`','This is the fact full admission');p.write_text(s)
p=r/'src/Effect4/Api/HostSession.lean';s=p.read_text().replace('`start` and `Run.open` make it','`Run.open` makes it').replace('which makes the table as `start` does','which makes the table').replace('a session that `start` made answers it (`start_callInstance`)','a canonical open reads it (`Run.reached_callInstance`)').replace("the table that `start` made","the table that `Run.open` makes");p.write_text(s)
p=r/'src/Effect4/Laws/Api/HostSession.lean';s=p.read_text().replace('which makes the table as `start` does','which makes the table');p.write_text(s)
p=r/'src/Effect4/Laws/Api/MaskRuns.lean';s=p.read_text().replace('(`HostSession.start_maskRuns`)','(`Run.open_maskRuns`)').replace('`Run.runPure` and','Opening followed by control rows and');p.write_text(s)

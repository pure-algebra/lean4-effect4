from pathlib import Path
import hashlib,json,subprocess,sys,time
r=Path('/private/tmp/seams-s4-sol');w=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');lib=r/'fresh-s2-lib';e=r/'evidence'
module=sys.argv[1];source=Path(sys.argv[2]) if len(sys.argv)>2 else r/'overlay/src'/Path(*module.split('.')).with_suffix('.lean')
source_root=Path(sys.argv[3]) if len(sys.argv)>3 else r/'overlay/src'
target=lib/Path(*module.split('.')).with_suffix('.olean');target.parent.mkdir(parents=True,exist_ok=True)
for a in target.parent.glob(target.stem+'.olean*'):
 if a.is_symlink():a.unlink()
label='fresh-s2-'+module.replace('.','-')+'-'+str(len(list(e.glob('fresh-s2-'+module.replace('.','-')+'-*.json')))+1)
lp=':'.join([str(lib),'/private/tmp/seams-check-sol/s2-full/lib/lean',*[str(w/'.lake/packages'/n/'.lake/build/lib/lean') for n in ['batteries','effects','typescript','hash','whatwg','aesop']],str(w/'.lake/build/lib/lean')])
c=['python3','/private/tmp/seams-lean-one.py','lake','env','env','LEAN_PATH='+lp,'lean','--root='+str(source_root),'-DwarningAsError=true','-o',str(target),str(source)]
raw=source.read_bytes();(e/(label+'.source.lean')).write_bytes(raw);start=time.time()
with (e/(label+'.log')).open('w') as f:x=subprocess.run(c,cwd=w,stdout=f,stderr=subprocess.STDOUT)
(e/(label+'.json')).write_text(json.dumps({'command':c,'exit':x.returncode,'seconds':time.time()-start,'source_sha256':hashlib.sha256(raw).hexdigest(),'scope':'actual frozen cumulative S2 imports'},indent=2)+'\n')
print((e/(label+'.log')).read_text());sys.exit(x.returncode)

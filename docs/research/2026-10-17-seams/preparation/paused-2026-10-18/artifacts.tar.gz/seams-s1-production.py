from pathlib import Path
import subprocess,json
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');e=r/'docs/research/2026-10-17-seams/receipts/evidence/S1'
base=(e/'base.txt').read_text().strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==base
def run(label,args):
 subprocess.run(['python3','/private/tmp/seams-run.py','S1',label,'python3','/private/tmp/seams-lean-one.py',*args],cwd=r,check=True)
run('versions',['python3','/private/tmp/seams-runtime-versions.py'])
order=json.loads((e/'preparation-order.json').read_text());assert 'Test' not in order and 'Effect4' not in order
run('narrow',['lake','build',*order])
run('audit',['lake','env','lean','-DwarningAsError=true','/private/tmp/seams-s1-audit.lean'])
run('batteries',['make','batteries-touched','BASE='+base])
run('check-ocaml',['make','check-ocaml'])
run('generate-semantics',['make','gen-semantics'])

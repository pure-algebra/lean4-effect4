# S2 receipt: pending fills and one publication action

Publication agreement retains its explicit positive-base and reference-free premises.
The original D1–D9 laws remain proved at their original observations.
Three new connections remain placed goals; the finite controls do not prove them.

## Commits and implementation

- Base: BASE_COMMIT.
- Implementation: HEAD_COMMIT.
- Branch: `codex/seams`.

`FillSet.open_` opens a sealed pending set from a document.
Its anchor retains the exact snapshot, application, and source sketch.
Its private constructor carries the submission-fold witness.
Adding a fill uses that source's keepExact feed and discards the resulting source session.
Publication produces one address-ordered document commit.
The tool checks the complete anchor and resets pending fills only after successful publication.

Suggestions use the same feed.
A candidate carries its actual checker key.
A root candidate carries the module key; missing nonroot focus refuses before candidate construction.
That refusal invents neither a module key nor a commit-item index.

## Acceptance and red controls

| Plan row | Positive observation | Red control |
| --- | --- | --- |
| Loop 2, row 1 | Good, bad, and good submissions retain the two accepted pending fills. | The bad fill returns its certification refusal without discarding accepted entries. |
| Loop 2, row 2 | The pending list contains exactly the two accepted fills at the unchanged anchor. | The refused middle item is absent; identical duplicates collapse and distinct conflicts refuse. |
| Loop 2, row 3 | One publication creates one document action, advances revision once, and resets pending fills. | An empty set refuses publication; failed joint dependencies retain the old document. |
| Revert and root boundaries | Revert restores the prior program and retains its hole rows. | Root pending fills refuse; root edits remain ordinary document actions. |
| Filling beside a reference | Whole-anchor expansion certifies a filling using an existing reference. | Two separately accepted fills can invalidate their joint reference dependency; publication refuses. |
| Stale anchor | The exact current anchor publishes. | Foreign snapshots, changed revisions, and equal identity/revision with another base refuse. |
| Reset | Successful tool publication opens a fresh pending set at the new document. | Failed publication retains both the prior document and pending entries. |
| `kept_eq_certified` | D1–D9 retain their exact reference observations and original premises. | Reference-bearing fills refute the unrestricted certification comparison; the new goal states its reference-free premises. |
| Pending entry distinctions | Identical duplicates collapse without a new entry. | Distinct conflicts, overlapping addresses, unknown addresses, and root addresses remain separate refusals. |
| Suggestion keys | A root suggestion records the genuine candidate module key and actual dependency trace. | A resolved nonroot address without a typed focus refuses with an empty trace and no candidate. |

`Test/Program/FillSetControls.lean` contains these finite observations.
The retained S1 and V1 batteries check the callers this slice reaches.
The preparation boundary probes and their failed unrestricted statements remain in the evidence directory.

## Deleted owners and moved callers

The old `FillSet.empty`, `FillSet.ofDoc`, and `materializeDoc` entrances are deleted.
The production `certifiedB`, `Certified`, `Program.materialize`, and candidate evaluator are deleted.
The same feed owns certification, and publication uses `Doc.step`.
The old certification and materialization observations move into `Effect4.Laws.Program.FillReference` for D1–D9.
Their original algorithms, refusal order, and proof premises remain there.
No production caller imports that reference owner.

## Proof placement

`S2-PLACEMENT.md` gives each obligation's concept, question, reach, exclusions, and consumer.
All three new claims serve R14 under `initial-algebras-folds`.

| Claim | Pointer | Reach and status |
| --- | --- | --- |
| `kept-fill-reference` | `kept_eq_certified` | Planned goal: coherent source, nonroot address, and reference-free base and filling. |
| `pending-fill-construction` | `FillSet.add_wf` | Planned goal: sealed sets have conflict-free, incomparable, feed-certified entries. |
| `pending-fill-publication` | `FillSet.publish_eq_materialize` | Planned goal: exact coherent anchor, positive base, reference-free inputs, and successful publication. |

The goals live in `src/Effect4/Laws/Program/FillSet.lean` with placement attributes.
The registry and semantics authority register them in this slice.
The core imports no Laws module and uses none of these goals.
The original D1–D9 proofs remain separate from the new connections.
The generated report measures their current proof status.

## Departures and proposed decisions

| Correction | Evidence and control | Proposed decision |
| --- | --- | --- |
| Old raw certification differs at references. | The retained reference boundary distinguishes local checking from whole-anchor checking. | State certification agreement on the explicit reference-free fragment. |
| Publication comparison needs a positive base. | A local kept edit can retain an existing root failure. | Keep initial positivity in the comparison theorem without adding an operational refusal. |
| Snapshot identity and revision do not identify the entire anchor. | Equal identity/revision with a changed base refuses. | Check the base sketch and application before publication. |
| Missing focus has no actual candidate checker key. | The nonroot suggestion control returns `noFocus` before construction and records no ask. | Return the feed refusal directly; invent no key or item index. |
| Original algorithms remain needed as proof observations. | D1–D9 compile against their unchanged bodies in the Laws-only reference owner. | Delete production ownership while retaining the exact reference statements. |

The checks establish finite Lean observations and the named proofs at their explicit premises.
They establish no native translation theorem, arbitrary reference-composition law, or progress claim.
This slice introduces no native pending-set export.

## Current commands and trust evidence

PENDING_COMMANDS

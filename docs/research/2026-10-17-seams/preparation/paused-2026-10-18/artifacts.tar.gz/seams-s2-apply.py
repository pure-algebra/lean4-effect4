from pathlib import Path
import subprocess,sys,json,hashlib,shutil
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');p=Path('/private/tmp/seams-check-sol');base=sys.argv[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==base and git('branch','--show-current')=='codex/seams'
assert not git('status','--porcelain')
patch=p/'S2-package.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()=='c489d0c8c73344c3da86c062f7bf7aa9bccf5a659dcbeabbf64e8e530ed72277'
subprocess.run(['git','apply','--check',str(patch)],cwd=r,check=True);subprocess.run(['git','apply',str(patch)],cwd=r,check=True)
manifest=json.loads((p/'S2-manifest.json').read_text())
for row in manifest:assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256'],row
f=r/'src/Effect4/Laws/Program/FillSet.lean';s=f.read_text();old='''* Construction invariant (`FillSet.WellFormed`, `FillSet.empty_wf`, `FillSet.addOne_wf`,
  `FillSet.add_wf`, `FillSet.conflictAt_eq_none`): every `FillSet` built from `FillSet.empty` by
  `FillSet.add` is `ConflictFree`, pairwise `Incomparable`, and `FillReference.Certified` at its base.'''
assert old in s;s=s.replace(old,'''* Construction invariant (`FillSet.add_wf`): every sealed set opened from a document has conflict-free, incomparable entries.
  Each entry satisfies the anchor's keepExact feed observation.
  This remains a placed goal.
* `kept_eq_certified` and `FillSet.publish_eq_materialize` connect the new operations to the retained D1–D9 reference observations.
  Their positive-base and reference-free premises remain explicit.''');f.write_text(s)
f=r/'src/Effect4/Laws/Program/FillReference.lean';s=f.read_text().replace('an ordinary `Doc.commit` replaces','an ordinary document commit replaces');f.write_text(s)
claims=json.loads(Path('/private/tmp/seams-s2-claims.json').read_text())
f=r/'tools/ProofGraph/Registry.lean';s=f.read_text();anchor='    { id := "source-session-coherent"';assert anchor in s
rows=''.join('    { id := "'+id+'", concept := "initial-algebras-folds", role := .'+role+'\n      title := "'+title+'; no admission, progress, or native execution claim (seams S2, R14)"\n      pointer := .witness `Effect4.Program.'+name+' },\n' for id,name,role,title in claims)
f.write_text(s.replace(anchor,rows+anchor))
f=r/'docs/core/semantics.md';s=f.read_text();anchor='- **The replacement law (`typed-replacement`)**:';assert anchor in s
rows=''.join('- **`'+id+'`**: '+title+'.\n  The pointer is `'+name+'` in `src/Effect4/Laws/Program/FillSet.lean`.\n' for id,name,role,title in claims)
rows+='  These R14 properties establish no admission, progress, or native execution.\n'
f.write_text(s.replace(anchor,rows+anchor))
new=[row['path'] for row in manifest if not git('ls-files','--',row['path'])]
if new:subprocess.run(['git','add','-N','--',*new],cwd=r,check=True)
e=r/'docs/research/2026-10-17-seams/receipts/evidence/S2';e.mkdir(parents=True,exist_ok=True);(e/'base.txt').write_text(base+'\n')
for name in ['S2-RECEIPT-SOL.md','S2-PLACEMENT.md','RETIREMENTS.md','S2-manifest.json','S2-frozen-inputs.json']:
 shutil.copyfile(p/name,e/name)
shutil.copyfile('/private/tmp/seams-s2-claims.json',e/'claims.json')
for file in (p/'s2-full/logs').glob('*'):
 if file.is_file():
  dest=e/'preparation'/file.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,dest)
for name in ['audit.log','order.json']:shutil.copyfile(p/'s2-full'/name,e/('preparation-'+name))
for file in p.rglob('*Boundary*'):
 if file.is_file() and file.suffix in ['.lean','.log','.md']:
  dest=e/'boundary'/file.relative_to(p);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,dest)
modules=[row['path'].removeprefix('src/').removeprefix('tools/').removesuffix('.lean').replace('/','.') for row in manifest if row['path'].endswith('.lean')]
core=[m for m in modules if m.startswith(('Effect4.','Test.'))]
audit='\n'.join('import '+m for m in core)+'\nimport ProofGraph.AxiomAudit\n#axiom_audit '+' '.join(core)+'\n'
(e/'audit.lean').write_text(audit);Path('/private/tmp/seams-s2-audit.lean').write_text(audit)
(e/'integration-source-hashes.json').write_text(json.dumps({row['path']:hashlib.sha256((r/row['path']).read_bytes()).hexdigest() for row in manifest},indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('Applied frozen S2 source, exact proof placement, and current construction-goal description.')

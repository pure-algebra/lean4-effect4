# S3b paused preparation

This is a partial preparation packet, not a landing packet.
The owner asks for a stopping place before S3b integration.
No production file changes and no commit belong to this agent.
Do not apply `S3b-DRAFT.patch` as a complete slice.

## Frozen prior packets

The prior packets live in `/private/tmp/seams-check-sol`.

| Packet | Patch SHA-256 | Checked preparation |
| --- | --- | --- |
| V1 | `53d59a115021e327eb7b9d91a944aedde55957601c77fa5228c5789edb91e651` | Full affected closure, callers, battery; audit 1801 declarations, one modulo, two goals |
| S1 | `b78ae2b78b443ac0d50e1befdfdf89c721f4c7e796fe19a19f4c47e776f6e718` | Full stage closure and batteries; audit 1203 declarations, two modulo, thirteen goals |
| S2 | `c489d0c8c73344c3da86c062f7bf7aa9bccf5a659dcbeabbf64e8e530ed72277` | Full stage closure and batteries; audit 1428 declarations, two modulo, sixteen goals |

Each has a manifest, frozen source hashes, placement notes, and a receipt in that directory.
The incremental S1 and S2 patches apply in its temporary `patch-check` tree.
All thirteen cumulative target source hashes match their manifests after application.
The root owns subsequent integration changes and production gates.

The root prepares S1's runtime-ledger supplement in `/private/tmp/seams-s1-ledger`.
It checks thirteen affected modules and retains the public Doc observations and exact Laws.
The supplement stores an exact replay-state witness in memory and calls the sole action interpreter once per step.
This corrects the frozen draft's repeated history reconstruction during revert.
It persists no derived state.
Use the root's final landed SourceDocument when resuming dependent work.

## S3b source status

`FROZEN-DRAFT-MANIFEST.json` records the exact source hashes and production HEAD at freeze.
`S3b-DRAFT.patch` is a reviewable source draft only.
The canonical sources are under `overlay`; fixtures are under `controls`.
No final Tool codec group or driver migration has been completed.

| Source | Status and evidence |
| --- | --- |
| `overlay/tools/Effect4Gen/Main.lean` | Compiles; opt-in qualified names deconflict generated declaration namespaces and shape names |
| `RepeatedHeadDefault.lean` | Expected red control: default mode duplicates `ExceptC` declarations; log `logs/default-repeated-red.log` |
| `RepeatedHead.lean` | Qualified mode compiles for `Except Nat Nat` and `Except String Nat`; logs `qualified-generator.log`, `qualified-generated.log` |
| `overlay/src/Effect4/Tool/CheckDerived.lean` | Generated and compiled from the actual V1 checker data; logs `Check-generator.log`, `Effect4.Tool.CheckDerived.log` |
| `overlay/src/Effect4/Tool/CodecProfile.lean` | Compiles; no Laws import |
| `controls/CodecProfileControls.lean` | Passes: both Option Unit values and JSON null refuse the profile; rounded natural refuses writing; ordinary natural retains its read |
| `overlay/src/Effect4/Laws/Tool/CodecProfile.lean` | Compiles; successful JSON-write retraction proved |
| `controls/CheckCodecControls.lean` | Passes: unknown tags, missing fields, real key round trip, duplicate-text-key normalization; audit 337 declarations, zero modulo, zero goals |
| `overlay/src/Effect4/Tool/WireTypes.lean` | Uncompiled draft: explicit connection versions and framing outside semantic state |
| `overlay/src/Effect4/Tool/Wire.lean` | Uncompiled draft; awaits ToolDerived, Responds, and compiled actual S3a types |
| `overlay/tools/Tools/View/Build.lean` | Uncompiled draft: existing program plan, real Reply.now threading, typed edit actions, actual source projection |
| `overlay/tools/Tools/View/Live.lean` | Uncompiled draft: Tool State/Reply and serve; drawing engine retained |
| `pairing.json`, `DescribeProtocol.lean`, `generate-pairing.py` | Uncompiled generation preparation; no protocol census or Responds output yet |

The generator flag defaults to false.
Existing groups should retain their output, but a direct original-versus-modified default-output byte check remains owed.
The current red/green test establishes the repeated-head fix only.
The proposed Check group encodes public data only: signature data, keys, verdicts, locations, and explanations.
It serializes no Oracle, Checked, Memo, HitRule, or proof package.

## Last active command

Session `24862` completes successfully:

```text
python3 /private/tmp/seams-lean-one.py lake env python3 /private/tmp/seams-s3b-sol/verify-codecs.py
```

The write/read connector and CheckCodecControls compile.
The audit reports 337 declarations within `[propext, Quot.sound]`, zero modulo and zero planned goals.
There is no active or queued Lean command from this agent.
Earlier failed connector logs retain the let-reduction and match-reduction controls.
`STOP-RESULT.md` records the final result.

## Actual protocol authority and corrections

The S3a owner is the sibling agent `s0_sol`.
Its source packet is `/private/tmp/seams-s3a-sol/overlay/src/Effect4/Tool`.
Its frozen manifest and resume notes are `/private/tmp/seams-s3a-sol/FROZEN-DRAFT-MANIFEST.json` and `RESUME.md`.
S3a remains uncompiled at this stopping point.
Consume its final actual types; do not rebuild a competing interpreter.

- `Candidate` has program, optional sourcePath, concrete CheckInput key, and actual CheckCache.Evidence in that order.
- Preserve all Evidence cases: exactFit, typeMismatch, refused, feedRefused, and differentEnv.
- Refusal appends suggest FeedRefusal, place PlaceRefusal, and noProgram path to the original version-2 order.
- PreviewAnswer retains actual Tree settled/frames/explored data and tape state; it does not fabricate Live.View values.
- DocView appends optional Inspection with path, expected program, SigData context, optional Focus, entry, and refusal.
- Query.doc distinguishes the whole document from an actual program-path inspection.
- Protocol owns the one Request.method mapping and supportedMethods; all currently support version 1.
- The response pairing observes output constructor kinds and requested run identifiers, including dry and preview variants.
- Its generator must check the compiled constructor census against the explicit pairing map before emitting Responds.

Root keys and traces are distinct observations.
A root suggestion carries the genuine module key.
Its checked trace contains the module ask's actual part dependencies, without a synthetic module result.
Missing typed focus below the root refuses before candidate construction and produces no ask.
Full Oracle transparency includes the semantic trace; cost/hit metadata is absent.
Any invocation-count comparison remains separate finite host evidence.

## JSON boundary scope

Canonical Val and byte exactness retain their existing owners.
The JSON profile refuses an option whose item can print null.
The profile also refuses unresolved option items and generic untyped references conservatively.
ST3's future raw-value shape falls through to refusal; it must not become generic JSON reconstruction.
Each successful JSON write checks that reading its print retains the original canonical value.
A rounded natural therefore refuses rather than silently changing its value.
The new write/read theorem states only successful-write retraction, not total writing.

Lean's JSON parser normalizes object keys into a TreeMap, keeping the last duplicate textual key.
The root approves explicit parsed-JSON normalization scope.
No raw-text exactness is claimed.
The duplicate-key control records that actual parser behavior.
Shape ordering retains unknown and missing fields, so the generated readers can refuse them.

The draft Wire adapter calls Tool.serve once and contains no action interpreter.
It checks selected method versions before serving.
Its output-profile refusal retains the original pure state.
That transport-domain restriction requires review against the final driver contract before integration.
The semantic Tool transition and the wire refusal remain distinct.

## Remaining S3b implementation

1. Finish the current narrow check and record its exact result; queue nothing while the owner pauses.
2. After the owner resumes, consume compiled S3a and root-ledger artifacts.
3. Describe the actual carriers and generate the complete Tool codec group in dependency order.
4. Include every actual wire carrier and applied Except needed by Request, Reply, LiveRecord, PreviewAnswer, and Inspection.
5. Pin new wire tags without altering existing assignments or canonical bytes.
6. Prove or place serve_answers through the generated response pairing, with the five placement facts.
7. Compile WireTypes/Wire and test supported, unselected, wrong-version, wrong-method, malformed, and output-profile controls.
8. Complete the thin Lean driver and its generated refusal framing.
9. Migrate the view Build/Live callers and drivers; consume each Reply.now rather than guessing revisions or expected holes.
10. Migrate old Test callers before deleting Tools.Session, Tools.Query as protocol source, Snapshot, and JsonBridge.valueFrom?.
11. Retain old meaningful controls at their new owners, including preview, restore, contextual suggestions, and framing failures.
12. Compare bounded native and Lean driver transcripts through the same typed requests; keep host evidence separate from Lean proof.
13. Run the new module closure, audit, root-directed generation, touched batteries, and reached native gates.
14. Freeze a complete S3b packet only after those checks and physical retirements pass.

The old dispatcher and view tests remain in production.
They are not claimed deleted or migrated by this partial draft.
The native S6 Kit_serve and host-loop replacements remain assigned to S6.

## Commands and ownership

All Lean commands run from `/Users/pooks/.codex/worktrees/seams/lean4-effect4` through the shared wrapper.
The temporary runners unlink each output target before compilation and write no output through dependency links.
Never run lake build Test, make build, or make check-full.
Run OCaml only through opam exec --switch=effect4.
The root retains production writes, root imports, central claims, tag integration, generation, gates, and commits.

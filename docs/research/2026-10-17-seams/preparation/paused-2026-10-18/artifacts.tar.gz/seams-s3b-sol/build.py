from pathlib import Path
import os,subprocess,sys
b=Path('/private/tmp/seams-s3b-sol');prod=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');src=b/'src';lib=b/'lib/lean';logs=b/'logs';logs.mkdir(exist_ok=True)
for origin in [Path('/private/tmp/seams-check-sol/s2-full/lib/lean'),prod/'.lake/build/lib/lean']:
 for p in origin.rglob('*'):
  if p.is_file():
   q=lib/p.relative_to(origin);q.parent.mkdir(parents=True,exist_ok=True)
   if not q.exists() and not q.is_symlink():q.symlink_to(p)
env={**os.environ,'LEAN_PATH':str(lib)+':'+os.environ['LEAN_PATH']}
def run(args,name):
 r=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(logs/(name+'.log')).write_text(r.stdout);print(name,r.returncode,r.stdout[-10000:],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
def compile(n,p):
 q=src.joinpath(*n.split('.')).with_suffix('.lean');q.parent.mkdir(parents=True,exist_ok=True);q.write_text(p.read_text());out=lib.joinpath(*n.split('.')).with_suffix('.olean');out.parent.mkdir(parents=True,exist_ok=True)
 for suffix in ['.olean','.olean.private','.olean.server','.ir','.ir.sig']:
  f=out.with_suffix(suffix)
  if f.is_symlink():f.unlink()
 run(['lean','-DwarningAsError=true',f'--root={src}','-o',str(out),str(q)],n)
compile('Effect4Gen.Main',b/'overlay/tools/Effect4Gen/Main.lean')
compile('Effect4.Tool.CodecProfile',b/'overlay/src/Effect4/Tool/CodecProfile.lean')
run(['lean','-DwarningAsError=true',str(b/'controls/CodecProfileControls.lean')],'CodecProfileControls')
args=['--group','RepeatedHead','--qualified-names','--imports','Effect4.Store.Domain.Canonical','--out',str(b/'RepeatedHead.lean'),'Except@Nat@Nat','Except@String@Nat']
run(['lean','--run',str(b/'MainDriver.lean'),*args],'qualified-generator')
run(['lean','-DwarningAsError=true',str(b/'RepeatedHead.lean')],'qualified-generated')

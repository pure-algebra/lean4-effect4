import Effect4.Tool.ToolDerived
import Effect4.Tool.Responds
import Effect4.Tool.Serve
import Effect4.Tool.WireTypes
set_option autoImplicit false
namespace Effect4.Tool.Wire
open Effect4.Store Effect4.Program.Check

/-- Decode at the connection's chosen method version before calling the semantic tool. -/
def decode (connection : Connection) (json : Effect4.Json) : Except Refusal (Envelope Request) := do
  if !connection.valid then throw .connection
  let envelope ← (CodecProfile.read (α := Envelope Request) json).mapError Refusal.codec
  let actual := envelope.payload.method
  if envelope.method != actual then throw (.method envelope.method actual)
  match connection.selected.lookup actual with
  | none => throw (.unselected actual)
  | some selected =>
    if !(((supportedMethods.lookup actual).getD []).contains selected) then throw (.unselected actual)
    if envelope.version != selected then throw (.version actual selected envelope.version)
    pure envelope

/-- The adapter publishes its next pure state only after its response passes the JSON write guard. -/
def serveJson (oracle : Oracle) (connection : Connection) (state : State) (json : Effect4.Json) :
    Checked (State × Except Refusal Effect4.Json) := do
  match decode connection json with
  | .error why => pure (state,.error why)
  | .ok envelope =>
    let (next,answer) ← serve oracle state envelope.payload
    if !responds envelope.payload answer then pure (state,.error .response)
    else
      match CodecProfile.write (⟨envelope.method,envelope.version,answer⟩ : Envelope Reply) with
      | .error why => pure (state,.error (.codec why))
      | .ok json => pure (next,.ok json)
end Effect4.Tool.Wire

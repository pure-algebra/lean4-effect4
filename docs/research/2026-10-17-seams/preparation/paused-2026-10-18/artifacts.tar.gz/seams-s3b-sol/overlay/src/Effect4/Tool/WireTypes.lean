import Effect4.Tool.Protocol
import Effect4.Tool.CodecProfile
set_option autoImplicit false
namespace Effect4.Tool.Wire

/-- Connection framing stays outside the semantic tool state. -/
structure Envelope (α : Type) where
  method : String
  version : Nat
  payload : α

inductive Refusal where
  | codec (why : CodecProfile.Refusal)
  | unselected (method : String)
  | version (method : String) (selected received : Nat)
  | method (declared actual : String)
  | response
  | connection

structure Connection where
  selected : List (String × Nat)

def Connection.valid (connection : Connection) : Bool :=
  connection.selected.all (fun (method,version) =>
    ((supportedMethods.lookup method).getD []).contains version) &&
  decide ((connection.selected.map Prod.fst).eraseDups.length = connection.selected.length)

def Connection.v1 : Connection :=
  ⟨supportedMethods.map fun entry => (entry.1,1)⟩

end Effect4.Tool.Wire

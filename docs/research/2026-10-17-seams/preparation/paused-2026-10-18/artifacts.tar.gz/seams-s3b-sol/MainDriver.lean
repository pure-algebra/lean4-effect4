import Effect4Gen.Main
def main (args : List String) : IO Unit := Effect4Gen.Main.cli args

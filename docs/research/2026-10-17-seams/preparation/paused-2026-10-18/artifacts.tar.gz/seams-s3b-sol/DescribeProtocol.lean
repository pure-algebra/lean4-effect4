import Effect4.Tool.Protocol
import Lean
open Lean in
def main : IO Unit := do
  let env ← importModules #[{module := `Effect4.Tool.Protocol}] {} 0
  let names := [`Effect4.Tool.Action,`Effect4.Tool.Query,`Effect4.Tool.PreviewQuery,`Effect4.Tool.RunForm,
    `Effect4.Tool.ActionAnswer,`Effect4.Tool.Answer,`Effect4.Tool.PreviewAnswer,`Effect4.Tool.Refusal,
    `Effect4.Program.CheckCache.Evidence]
  let rows ← names.mapM fun name => do
    let some (.inductInfo info) := env.find? name | throw (IO.userError s!"missing inductive {name}")
    let constructors ← info.ctors.mapM fun ctor => do
      let some (.ctorInfo ci) := env.find? ctor | throw (IO.userError s!"missing constructor {ctor}")
      pure (Json.mkObj [("name",Json.str ctor.getString!), ("fields",toJson ci.numFields)])
    pure (name.toString, Json.arr constructors.toArray)
  IO.println (Json.mkObj rows).compress

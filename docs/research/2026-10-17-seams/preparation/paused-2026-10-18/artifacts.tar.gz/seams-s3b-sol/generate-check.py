exec(compile(open('/private/tmp/seams-s3b-sol/build.py').read().split("compile('Effect4Gen.Main'")[0],'<setup>','exec'))
# A negative control retains the old short-head collision in the default mode.
args=['--group','RepeatedHeadDefault','--imports','Effect4.Store.Domain.Canonical','--out',str(b/'RepeatedHeadDefault.lean'),'Except@Nat@Nat','Except@String@Nat']
run(['lean','--run',str(b/'MainDriver.lean'),*args],'default-repeated-generator')
r=subprocess.run(['lean','-DwarningAsError=true',str(b/'RepeatedHeadDefault.lean')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(logs/'default-repeated-red.log').write_text(r.stdout);print('default-repeated-red',r.returncode,r.stdout[-1500:],flush=True)
if r.returncode==0:raise SystemExit('expected repeated short-head namespace refusal')
args=['--group','Check','--qualified-names','--imports','Effect4.Program.Check,Effect4.Api.RefusalsDerived','--out',str(b/'overlay/src/Effect4/Tool/CheckDerived.lean'),
'Effect4.Program.SigApp','Effect4.Program.PartSig','Effect4.Program.SigData','Effect4.Program.Check.CheckInput','Effect4.Program.NodeEnv','Except@Effect4.Program.TypeRefusal@Effect4.Program.EffTy','Effect4.Program.Table.Entry','Effect4.Program.Check.Verdict','Effect4.Program.Check.Site','Effect4.Program.Check.Explanation']
run(['lean','--run',str(b/'MainDriver.lean'),*args],'Check-generator')
compile('Effect4.Tool.CheckDerived',b/'overlay/src/Effect4/Tool/CheckDerived.lean')

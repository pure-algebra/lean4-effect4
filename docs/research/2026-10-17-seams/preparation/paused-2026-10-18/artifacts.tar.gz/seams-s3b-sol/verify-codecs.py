exec(compile(open('/private/tmp/seams-s3b-sol/build.py').read().split("compile('Effect4Gen.Main'")[0],'<setup>','exec'))
compile('Effect4.Laws.Tool.CodecProfile',b/'overlay/src/Effect4/Laws/Tool/CodecProfile.lean')
run(['lean','-DwarningAsError=true',str(b/'controls/CheckCodecControls.lean')],'CheckCodecControls')

import Effect4.Tool.CheckDerived
import Effect4.Tool.CodecProfile
import Effect4.Laws.Tool.CodecProfile
import Tools.JsonBridge
import ProofGraph.AxiomAudit
namespace Test.SeamsS3bCheckCodec
open Effect4 Effect4.Program Effect4.Program.Check Effect4.Store

def program : NativeEff := .succeed (.lit (.nat 7))
def input : CheckInput := .module {} [] program
#guard Canonical.ofVal (Canonical.toVal input) = some input
#guard Canonical.ofVal (α := CheckInput) (.ctor 99 []) = none
#guard Canonical.ofVal (α := CheckInput) (.ctor 0 []) = none
#guard match Tool.CodecProfile.read (α := CheckInput) (.obj [("_tag",.str "unknown")]) with
  | .error .unreadable => true | _ => false
#guard match Tool.CodecProfile.read (α := CheckInput) (.obj [("_tag",.str "module")]) with
  | .error .unreadable => true | _ => false
#guard match Tool.CodecProfile.write input with
  | .ok j => (Tool.CodecProfile.read (α := CheckInput) j).toOption = some input
  | .error _ => false

-- Lean's text parser has a named last-key normalisation; raw-text exactness is not claimed.
#guard (Lean.Json.parse "{\"field\":0,\"field\":1}").toOption.map
  (fun j => j.getObjValAs? Nat "field") = some (.ok 1)
end Test.SeamsS3bCheckCodec
#axiom_audit Effect4.Tool.CodecProfile Effect4.Laws.Tool.CodecProfile Effect4.Tool.CheckDerived

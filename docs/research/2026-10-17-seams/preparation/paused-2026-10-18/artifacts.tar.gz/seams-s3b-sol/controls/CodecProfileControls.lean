import Effect4.Tool.CodecProfile
namespace Test.SeamsS3bCodecProfile
open Effect4 Effect4.Store Effect4.Tool.CodecProfile
#guard supports (Canonical.shape (Option Unit)) = false
#guard match write (some () : Option Unit) with
  | .error .unsupportedProfile => true | _ => false
#guard match write (none : Option Unit) with
  | .error .unsupportedProfile => true | _ => false
#guard match read (α := Option Unit) .null with
  | .error .unsupportedProfile => true | _ => false
#guard match write (9007199254740993 : Nat) with
  | .error .unprintable => true | _ => false
#guard match write (7 : Nat) with
  | .ok j => (read (α := Nat) j).toOption = some 7 | _ => false
end Test.SeamsS3bCodecProfile

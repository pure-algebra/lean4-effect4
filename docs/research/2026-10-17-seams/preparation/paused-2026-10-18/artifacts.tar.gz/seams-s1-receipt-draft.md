# S1 receipt: policy feeds and accepted document histories

The source-table and document claims retain their full observations as explicit planned goals.
The finite controls pass; they do not replace the open universal obligations.
The generated report records every changed proof status.

## Commits and source ownership

- Base: BASE_COMMIT.
- Implementation: HEAD_COMMIT.
- Branch: `codex/seams`.
- The source manifest and command records appear below.
- This slice creates no native Doc export; the current translation recipe reaches none.

`SourceSession.feed` owns policy checking through the certified oracle.
A source session stores its source table without a second expanded table.
`Doc.step` owns accepted commit, draft, and revert actions.
The same action interpreter handles history replay, including its undo ledger.
The sealed in-memory document retains that complete runtime state with its replay equation.
Persistence still contains accepted actions; loading rebuilds the ledger.
A document's revision is its accepted history length.
Refused actions return no replacement document.

## Acceptance rows and controls

| Plan row | Positive evidence | Red control |
| --- | --- | --- |
| Loop 1, row 1 | `SourceDocumentControls` opens the source and reads the actual binder environment. | The repeated-hole and absent-hole cases distinguish row membership from an editable occurrence. |
| Loop 1, row 2 | The local checker returns the exact located refusal and leaves the document unchanged. | A variable outside the binder environment refuses with one actual dependency answer. |
| Loop 1, row 3 | A valid fill keeps the exact type, removes the hole occurrence, and appends one action. | The refused fill publishes no document and leaves revision zero. |
| Loop 1, row 4 | The current snapshot names the accepted history length. | An old snapshot refuses before the empty action; a foreign document refuses before revision checking. |
| Absent and repeated holes | `Place.resolve` reports the actual source addresses. | Distinct controls exercise out-of-range rows, absent occurrences, and repeated occurrences. |
| Empty batch | Ordinary nonempty commits append one action. | An empty commit returns `DocRefusal.empty`. |
| Late rollback | A two-item accepted batch produces one replacement document. | A second-item failure returns no replacement after the first item succeeds. |
| Nested revert | Reverse-order inverses restore a nested batch's original program. | A moved product refuses the old inverse; missing entries refuse independently. |
| Root module key | A root edit accepts a valid definitions block through the module route. | The same block refuses as a part; actual module decomposition defines its trace. |
| `noFocus` | A typed source address accepts a local replacement. | A resolvable address after an earlier refusal has no typed focus and refuses. |
| Policy and omission boundaries | Draft revert restores its entry's prior type; omission rows remain after revert. | A kept root change refuses a changed type; retained old root failure prevents an unconditional positivity claim. |
| Replay ledger | Reverting a revert acts as redo through the same interpreter. | Equal source sessions with different histories produce different selected inverses. |
| One action traversal | A nested inverse asks once per inverse item. | The old reconstruction repeats earlier checks for missing entries and empty inverses; the identical guards pass after retaining the witnessed ledger. |

These controls live in `Test/Program/SourceDocumentControls.lean` and `Test/Program/SourceFeedControls.lean`.
`CheckCacheControls` and `FillSetControls` retain the callers reached by this slice.
They establish finite Lean observations, without a native execution claim.

## Cuts and callers

The free revision field, old `Doc.commit` checks, `Doc.undo`, and `Doc.fork` are deleted.
Revision derives from history; revert is an action; a fresh open supplies a new origin.
The tool stores the sealed document and learns checked traces.
The temporary FillSet caller publishes through `Doc.step`; S2 replaces that temporary surface.
The old preview Snapshot remains until S3b and is not document persistence.
`RETIREMENTS.md` records the remaining owners for every planned cut.

## Proof placement and status

`S1-PLACEMENT.md` supplies concept, question, reach, exclusions, and consumer for each obligation.
Every listed property serves R14 under `initial-algebras-folds`.
The registry and `docs/core/semantics.md` place the new claims in this slice.

The thirteen planned goals are:

- `SourceSession.feed_coherent`, `feed_keeps`, `feed_draft`, `feed_keepExact`, `feed_root`, and `feed_undo`.
- `Doc.coherent` and `SourceSession.replay_drafts_view`.
- `Doc.step_coherent`, `commit_sound`, `commit_one_keepExact`, `commit_single_sound`, and `revert_program`.

`Doc.step_replay` and `Doc.step_refuses` are proved at their stated observations.
`runtime-ledger/PLACEMENT.md` places the projection and witness-extension helpers before their proofs.
`Doc.replayed` retains the old source-session equation; `Doc.sealRuntime` extends the complete runtime witness through the sole interpreter.
`SourceSession.open_coherent` uses V1's exact ask-value law and therefore depends on its decomposition goal.
`SourceSession.reached_view` uses the placed `Doc.coherent` goal.
`REACHED-VIEW-TRANSPORT.md` retains the old statement, exact observation, and explicit proof-status change.
The separate draft-transport goal retains every old application, sketch, and edit list without an added coherence premise.
No core module depends on a planned goal.

## Departures and proposed decisions

| Correction | Evidence and control | Proposed decision |
| --- | --- | --- |
| A local keepExact edit may retain an already refused root. | The source-feed control keeps a local type beside a prior root failure. | Positive commit claims require initial root positivity for keepExact; execution adds no new refusal. |
| Source state alone cannot interpret every revert. | Equal sessions with different accepted histories require different inverses. | Replay retains its history ledger and uses the same action interpreter. |
| Reached-state claims retain full scope but change proof status. | The exact old statement and draft transport appear in `REACHED-VIEW-TRANSPORT.md`. | Keep explicit placed goals; do not replace reach with a conditional observation helper. |
| A root module ask records actual dependency asks. | The definitions-block control compares module and part behavior. | Retain the genuine module key without inventing a synthetic module trace entry. |
| The initial preparation reconstructs earlier actions for every revert. | The same three trace controls fail before the supplement and pass after it; `runtime-ledger` retains both runs. | Retain the derived undo ledger in sealed runtime state; persist only actions and rebuild the ledger on load. |
| Native Doc sealing has no current exported subject. | The current `ocaml/gen/roots.json` has no Doc or source-session root. | Add sealing controls when S3a exports the actual protocol closure. |

## Current commands and trust evidence

PENDING_COMMANDS

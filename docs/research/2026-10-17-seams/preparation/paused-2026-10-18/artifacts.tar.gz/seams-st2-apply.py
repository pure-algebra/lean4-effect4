from pathlib import Path
import subprocess,sys,json,hashlib,shutil,re
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');p=Path('/private/tmp/seams-st2-sol');base=sys.argv[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==base and git('branch','--show-current')=='codex/seams' and not git('status','--porcelain')
manifest=json.loads((p/'source-manifest.json').read_text());excluded={'Test/Store/SeamsRecoveryAudit.lean'}
for row in manifest:
 path=r/row['target'];assert (hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None)==row['pre_sha256'],row['target']
args=['--exclude='+x for x in excluded];patch=p/'st2-all.patch'
subprocess.run(['git','apply','--check',*args,str(patch)],cwd=r,check=True);subprocess.run(['git','apply',*args,str(patch)],cwd=r,check=True)
for row in manifest:
 if row['target'] not in excluded:assert hashlib.sha256((r/row['target']).read_bytes()).hexdigest()==row['sha256'],row['target']
def replace(path,old,new):
 f=r/path;s=f.read_text();assert old in s,(path,old);f.write_text(s.replace(old,new))
replace('src/Effect4/Laws.lean','import Effect4.Laws.Store.CanonicalSpec\n','import Effect4.Laws.Store.CanonicalSpec\nimport Effect4.Laws.Store.Recovery\n')
replace('Test/All.lean','import Test.Store.SeamsTransactions\n','import Test.Store.SeamsTransactions\nimport Test.Store.SeamsRecovery\n')
replace('tools/ProofGraph/Registry.lean','        `Effect4.Laws.Program.Agreement.Machine,','        `Effect4.Laws.Program.Agreement.Machine,\n        `Effect4.Laws.Store.Recovery,')
claims=[('cas-restore-roots','restore_roots','compatibility','Checked empty-store restoration retains the exact root table, including legacy generations'),('cas-restore-closed','restore_closed','preservation','Checked empty-store restoration establishes node closure through shared admission'),('cas-restore-targets','restore_targets','preservation','Every restored root resolves to a durable resident of its fixed kind')]
rows=''.join('    { id := "'+id+'", concept := "translation-simulation", role := .'+role+'\n      title := "'+title+'; no historical ancestry, generation provenance, hash injectivity, filesystem correctness, or host progress claim (seams ST2, R13)"\n      pointer := .witness `Effect4.Store.'+name+' },\n' for id,name,role,title in claims)
replace('tools/ProofGraph/Registry.lean','    { id := "cas-node-read-exact"',rows+'    { id := "cas-node-read-exact"')
f=r/'docs/core/semantics.md';s=f.read_text();start=s.index('### 2.10 Concept 10:');index=s.index('#### 4. Required Properties and Obligations',start)+len('#### 4. Required Properties and Obligations')
addition='\n\n- **Checked disk-image recovery (seams ST2, R13)**: Recovery starts at the empty store and uses shared node admission.\n'
for id,name,role,title in claims:addition+='  `'+name+'` states '+title[0].lower()+title[1:]+'.\n'
addition+='  Their owner is `src/Effect4/Laws/Store/Recovery.lean`.\n  The claims are `cas-restore-roots`, `cas-restore-closed`, and `cas-restore-targets`.\n  They establish no historical ancestry, generation provenance, hash injectivity, filesystem correctness, or host progress.\n'
f.write_text(s[:index]+addition+s[index:])
new=[row['target'] for row in manifest if row['target'] not in excluded and row['pre_sha256'] is None]
if new:subprocess.run(['git','add','-N','--',*new],cwd=r,check=True)
e=r/'docs/research/2026-10-17-seams/receipts/evidence/ST2';e.mkdir(parents=True,exist_ok=True);(e/'base.txt').write_text(base+'\n')
(e/'patch-sha256.txt').write_text(hashlib.sha256(patch.read_bytes()).hexdigest()+'\n');shutil.copyfile(p/'source-manifest.json',e/'source-manifest.json')
for name in ['REPORT.md','RESTORE-PLACEMENT.md','opam-before.txt','opam-after.txt','opam-compare.txt','opam-install.log']:
 if (p/name).exists():shutil.copyfile(p/name,e/name)
for f in p.glob('*.log'):shutil.copyfile(f,e/f.name)
for f in p.glob('*.json'):
 if f.name!='source-manifest.json':shutil.copyfile(f,e/f.name)
if (p/'retained-controls').exists():shutil.copytree(p/'retained-controls',e/'retained-controls',dirs_exist_ok=True)
shutil.copyfile(p/'src/Test/Store/SeamsRecoveryAudit.lean',e/'audit.lean');shutil.copyfile(e/'audit.lean','/private/tmp/seams-st2-audit.lean')
modules={row['target'].removeprefix('src/').removeprefix('tools/').removesuffix('.lean').replace('/','.') for row in manifest if row['target'].endswith('.lean') and row['target'] not in excluded}
files={}
for root in [r/'src',r/'tools',r/'Test']:
 for f in root.rglob('*.lean'):
  name=str(f.relative_to(root).with_suffix('')).replace('/','.')
  if root.name=='Test':name='Test.'+name
  files[name]=f.read_text()
direct={name for name,source in files.items() if any(x in modules for x in re.findall(r'^(?:public )?import\s+([\w.]+)',source,re.M))}
order=sorted((modules|direct)-{'Test.All','Test','Effect4','Effect4.Laws'})
(e/'narrow-modules.json').write_text(json.dumps(order,indent=2)+'\n')
(e/'claims.json').write_text(json.dumps(claims,indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('Applied ST2 source and exact recovery placements; standalone audit remains receipt evidence.')

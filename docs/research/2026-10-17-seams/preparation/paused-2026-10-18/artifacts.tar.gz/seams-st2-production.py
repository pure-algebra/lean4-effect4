from pathlib import Path
import subprocess,json
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');e=r/'docs/research/2026-10-17-seams/receipts/evidence/ST2';base=(e/'base.txt').read_text().strip()
def run(label,args,lean=True):
 if lean:args=['python3','/private/tmp/seams-lean-one.py',*args]
 subprocess.run(['python3','/private/tmp/seams-run.py','ST2',label,*args],cwd=r,check=True)
run('versions',['python3','/private/tmp/seams-runtime-versions.py'])
run('narrow',['lake','build',*json.loads((e/'narrow-modules.json').read_text())])
run('audit',['lake','env','lean','-DwarningAsError=true','/private/tmp/seams-st2-audit.lean'])
run('generate-cas',['python3','scripts/generate.py','--only','cas'])
run('generate-store-rocq',['python3','scripts/generate.py','--only','store-rocq'])
run('rocq',['python3','/private/tmp/seams-st2-rocq-production.py'],False)
run('native-store',['opam','exec','--switch=effect4','--','dune','runtest','--force','--root','ocaml','engine/cas/test'],False)
run('batteries',['make','batteries-touched','BASE='+base])
run('check-ocaml',['make','check-ocaml'])
run('generate-semantics',['make','gen-semantics'])

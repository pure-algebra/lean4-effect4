from pathlib import Path
import subprocess,json,hashlib,shlex
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');e=r/'docs/research/2026-10-17-seams/receipts/evidence/S1'
base=(e/'base.txt').read_text().strip()
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==base
labels=['versions','narrow','audit','batteries','check-ocaml','generate-semantics']
records={label:json.loads((e/(label+'.json')).read_text()) for label in labels}
for label,record in records.items():assert record['exit_status']==0,(label,record)
assert not git('diff','--cached','--name-only')
allowed={x['path'] for x in json.loads((e/'S1-manifest.json').read_text())}
allowed|={'tools/ProofGraph/Registry.lean','docs/core/semantics.md','generated/semantics.md'}
paths=sorted(set(git('diff','--name-only','HEAD').splitlines())|set(git('ls-files','--others','--exclude-standard').splitlines()))
assert set(paths)<=allowed,set(paths)-allowed
(e/'landed-source-paths.txt').write_text('\n'.join(paths)+'\n')
(e/'landed-source-hashes.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in paths},indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
subprocess.run(['git','add','--',*paths],cwd=r,check=True)
assert git('diff','--cached','--name-only').splitlines()==paths
subprocess.run(['git','commit','-m','S1: Replay document actions through one checked edit interpreter'],cwd=r,check=True)
head=git('rev-parse','HEAD')
s=Path('/private/tmp/seams-s1-receipt-draft.md').read_text().replace('BASE_COMMIT','`'+base+'`').replace('HEAD_COMMIT','`'+head+'`')
audit='\n'.join(x for x in (e/'audit.log').read_text().splitlines() if '#axiom_audit:' in x)
assert audit
summary='''`landed-source-paths.txt` lists every implementation path.
`landed-source-hashes.json` pins its bytes at the implementation commit.
The frozen preparation records keep their bounded scope; the production commands below establish this landing.

```text
'''+audit+'''
```

| Check | Exit | Seconds | Exact command |
| --- | --- | --- | --- |'''
for label,a in records.items():
 summary+='\n| ['+label+'](evidence/S1/'+label+'.json) | '+str(a['exit_status'])+' | '+str(a['elapsed_seconds'])+' | `'+shlex.join(a['command'])+'` |'
s=s.replace('PENDING_COMMANDS',summary+'\n');(r/'docs/research/2026-10-17-seams/receipts/S1.md').write_text(s.rstrip()+'\n')
p=r/'docs/research/2026-10-17-seams/receipts/README.md';s=p.read_text()
s=s.replace('| S1 | Pending | Pending | Open |','| S1 | `'+head+'` | [S1](S1.md) | Required checks pass; thirteen placed goals remain. |')
v1=git('log','-1','--format=%H','--','docs/research/2026-10-17-seams/receipts/V1.md')
s=s.replace('| [V1](V1.md) |','; receipt `'+v1+'` | [V1](V1.md) |',1)
s=s.replace('\n## Proposed decisions rows\n',"""
| S1 | Initial root positivity is required only by positive keepExact commit claims; the local-edit counterexample remains. |
| S1 | Replay retains the undo ledger; equal source sessions can require different selected inverses. |
| S1 | Sealed runtime state retains that ledger with its replay equation; revert performs no earlier action again. |
| S1 | Reached-state observations retain their exact scope through placed goals and explicit proof-status changes. |
| S1 | Module asks retain actual dependency traces; native Doc sealing waits for the actual exported protocol closure. |

## Proposed decisions rows
""")
s=s.replace('\nThe individual receipts retain commands, exit statuses, audit output, red controls, and evidence limits.',"""
| S1 | Adopt one policy feed and one accepted-action interpreter for commit, draft, revert, and document replay. |
| S1 | Derive revision from history; preserve atomic refusal and exact snapshot checks. |
| S1 | Retain derived undo entries only in sealed memory; reconstruct them from accepted actions on load. |
| S1 | Retain initial-positive premises and full reached-state goals, with proof status measured by the report. |

The individual receipts retain commands, exit statuses, audit output, red controls, and evidence limits.""")
p.write_text(s)
receipts=[str(p.relative_to(r)) for p in sorted(e.rglob('*')) if p.is_file()]
assert not any(p.is_symlink() for p in e.rglob('*'))
receipts+=['docs/research/2026-10-17-seams/receipts/S1.md','docs/research/2026-10-17-seams/receipts/README.md']
subprocess.run(['git','add','-f','--',*receipts],cwd=r,check=True)
subprocess.run(['git','diff','--cached','--check'],cwd=r,check=True)
subprocess.run(['git','commit','-m','S1: Record document controls and placed obligations'],cwd=r,check=True)
print(json.dumps({'implementation':head,'receipt':git('rev-parse','HEAD'),'status':git('status','--short')},indent=2))

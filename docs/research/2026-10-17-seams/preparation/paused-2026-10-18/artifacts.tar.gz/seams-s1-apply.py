from pathlib import Path
import subprocess,sys,json,hashlib,shutil,re
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4');p=Path('/private/tmp/seams-check-sol');base=sys.argv[1]
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==base and git('branch','--show-current')=='codex/seams'
assert not git('status','--porcelain')
patch=p/'S1-package.patch'
assert hashlib.sha256(patch.read_bytes()).hexdigest()=='b78ae2b78b443ac0d50e1befdfdf89c721f4c7e796fe19a19f4c47e776f6e718'
subprocess.run(['git','apply','--check',str(patch)],cwd=r,check=True)
subprocess.run(['git','apply',str(patch)],cwd=r,check=True)
manifest=json.loads((p/'S1-manifest.json').read_text())
for row in manifest:assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256'],row
f=r/'src/Effect4/Laws/Program/SourceTable.lean';s=f.read_text()
s='\n'.join(line for line in s.split('\n') if not line.startswith('| `SourceSession.open_shown_of_refSites_nil` |'))
s=s.replace('| `SourceSession.reached_view` | after an open and any edits, a session shows the table at the source\'s addresses, its refusals and the type through the references | `EditSession.feed_coherent` at the expansion |','| `SourceSession.reached_view` | every sealed document shows its source table, refusals, and root type | the placed `Doc.coherent` goal |\n| `SourceSession.replay_drafts_view` | every old application, sketch, and edit list retains its exact observation through canonical draft replay | placed transport goal |')
old='''- **`source-session-coherent`** (proposed claim, role preservation; pointer
  `SourceSession.reached_view`). Reach: one application; every sketch; every list of edits. An
  edit splices where the expansion of the edited sketch is the expansion's own edit at the same
  address; any other edit opens the expansion's edit session again. Not established: that an
  edit inside a referenced layer splices; a run; the cost. Consumer: the session tool.'''
new='''- **`source-session-coherent`** (role preservation; pointer `SourceSession.reached_view`).
  Reach: every sealed document, without a separate coherence premise; exact source table, refusals, and root type.
  The proof uses the placed `Doc.coherent` goal.
  `SourceSession.replay_drafts_view` retains every old application, initial sketch, and edit list through canonical replay.
  Its exact observation remains a placed goal.
  Neither claim establishes reference splicing, execution, progress, or cost.
  Consumer: the session tool.'''
assert old in s;s=s.replace(old,new);f.write_text(s)
claims=json.loads(Path('/private/tmp/seams-s1-claims.json').read_text())
f=r/'tools/ProofGraph/Registry.lean';s=f.read_text();anchor='    { id := "source-session-coherent"';assert anchor in s
rows=''.join('    { id := "'+id+'", concept := "initial-algebras-folds", role := .'+role+'\n      title := "'+title+'; no admission, progress, or native execution claim (seams S1, R14)"\n      pointer := .witness `Effect4.Program.'+name+' },\n' for id,name,role,title in claims)
s=s.replace(anchor,rows+anchor)
pattern=r'(\{ id := "source-session-coherent"[^\n]*\n      title := ")[^"]*(")'
s,n=re.subn(pattern,r'\g<1>Every sealed document shows its exact source table, refusals, and root type without a separate coherence premise; source-session-draft-transport retains the old application, sketch, and edit-list scope; no native execution, progress, or cost claim (seams S1, R14)\2',s);assert n==1
f.write_text(s)
f=r/'docs/core/semantics.md';s=f.read_text();anchor='- **The replacement law (`typed-replacement`)**:';assert anchor in s
rows='- **Source sessions and accepted document actions (seams S1)**: The following properties serve R14.\n  Every conditional property retains its stated premises.\n  They establish no admission, progress, liveness, or native execution.\n'
for id,name,role,title in claims:
 owner='SourceDocument' if name.startswith('Doc.') and name!='Doc.coherent' else 'SourceTable'
 rows+='- **`'+id+'`**: '+title+'.\n  The pointer is `'+name+'` in `src/Effect4/Laws/Program/'+owner+'.lean`.\n'
f.write_text(s.replace(anchor,rows+anchor))
new=[row['path'] for row in manifest if not git('ls-files','--',row['path'])]
if new:subprocess.run(['git','add','-N','--',*new],cwd=r,check=True)
e=r/'docs/research/2026-10-17-seams/receipts/evidence/S1';e.mkdir(parents=True,exist_ok=True);(e/'base.txt').write_text(base+'\n')
for name in ['S1-RECEIPT-SOL.md','S1-PLACEMENT.md','REACHED-VIEW-TRANSPORT.md','RETIREMENTS.md','S1-manifest.json','S1-frozen-inputs.json']:
 shutil.copyfile(p/name,e/name)
shutil.copyfile('/private/tmp/seams-s1-claims.json',e/'claims.json')
for file in (p/'s1-full/logs').glob('*'):
 if file.is_file():
  dest=e/'preparation'/file.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,dest)
for name in ['audit.log','order.json']:shutil.copyfile(p/'s1-full'/name,e/('preparation-'+name))
modules=[row['path'].removeprefix('src/').removeprefix('tools/').removesuffix('.lean').replace('/','.') for row in manifest if row['path'].endswith('.lean')]
core=[m for m in modules if m.startswith(('Effect4.','Test.'))]
audit='\n'.join('import '+m for m in core)+'\nimport ProofGraph.AxiomAudit\n#axiom_audit '+' '.join(core)+'\n'
(e/'audit.lean').write_text(audit);Path('/private/tmp/seams-s1-audit.lean').write_text(audit)
(e/'integration-source-hashes.json').write_text(json.dumps({row['path']:hashlib.sha256((r/row['path']).read_bytes()).hexdigest() for row in manifest},indent=2)+'\n')
subprocess.run(['git','diff','--check'],cwd=r,check=True)
print('Applied frozen S1 source, exact placements, and corrected current proof-owner descriptions.')

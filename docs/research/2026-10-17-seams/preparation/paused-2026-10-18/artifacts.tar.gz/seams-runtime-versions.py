import subprocess,json,sys
commands=[['lake','env','lean','--version'],['opam','exec','--switch=effect4','--','ocamlc','-version'],['opam','exec','--switch=effect4','--','dune','--version'],[sys.executable,'--version']]
for command in commands:
 result=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 print(json.dumps({'command':command,'exit_status':result.returncode,'output':result.stdout.strip()}),flush=True)
 if result.returncode:raise SystemExit(result.returncode)

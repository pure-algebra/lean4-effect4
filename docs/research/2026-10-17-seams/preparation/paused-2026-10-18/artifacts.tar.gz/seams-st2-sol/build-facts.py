import subprocess
from pathlib import Path
p=Path('/private/tmp/seams-st2-sol')
for script,args in [('build_overlay.py',['OCaml5.Store.Facts']),('run_facts.py',[])]:
 r=subprocess.run(['python3',str(p/script),*args])
 if r.returncode:raise SystemExit(r.returncode)

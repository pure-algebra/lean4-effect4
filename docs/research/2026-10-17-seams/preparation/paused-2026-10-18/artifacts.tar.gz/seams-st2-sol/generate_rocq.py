from pathlib import Path
import os,subprocess,json
out=Path('/private/tmp/seams-st2-sol');env=dict(os.environ)
env['LEAN_PATH']=str(out/'lib/lean')+':'+env.get('LEAN_PATH','')
command=['lean','-M4096','-DwarningAsError=true','--run',str(out/'src/OCaml5/Tools/GallinaGen.lean'),str(out/'rocq/Skeleton.v'),str(out/'rocq/StoreCode.v')]
with (out/'generate-rocq.log').open('w') as log:
 log.write(json.dumps(command)+'\n');log.flush();result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 log.write('exit_status='+str(result.returncode)+'\n')
print('Rocq generator: exit',result.returncode)
raise SystemExit(result.returncode)

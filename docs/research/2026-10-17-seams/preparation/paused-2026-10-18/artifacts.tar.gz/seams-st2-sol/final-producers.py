import subprocess
from pathlib import Path
out=Path('/private/tmp/seams-st2-sol')
for name in ['generate-goldens.py','run-oracles.py','generate_rocq.py']:
 r=subprocess.run(['python3',str(out/name)])
 if r.returncode:raise SystemExit(r.returncode)

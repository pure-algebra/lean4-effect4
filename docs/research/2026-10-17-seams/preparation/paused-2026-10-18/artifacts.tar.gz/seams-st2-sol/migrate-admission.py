from pathlib import Path
out=Path('/private/tmp/seams-st2-sol');p=out/'ocaml/engine/cas/e4_cas.ml';s=p.read_text();a=s.index('type admission =');b=s.index('\ntype verify_error',a);s=s[:a]+'''type admission = E4_admission.t =
  | Model of E4_admission.model
  | Capacity of string
  | Fault of E4_fault.t
'''+s[b:];a=s.index('let admission_word =');b=s.index('\nlet verify_error_word',a);s=s[:a]+'''let admission_word = function
  | Model model -> (match model with
    | E4_admission.Oversize -> "oversize"
    | E4_admission.Unknown_tag tag -> "unknownTag " ^ string_of_int tag
    | E4_admission.Bad_version -> "badVersion"
    | E4_admission.Malformed_ref -> "malformedRef"
    | E4_admission.Handle_in_content -> "handleInContent"
    | E4_admission.Dangling addr -> "dangling " ^ E4_addr.Addr.hex addr
    | E4_admission.Wrong_kind _ -> "wrongKind"
    | E4_admission.Short_spec -> "shortSpec"
    | E4_admission.Unregistered_kind byte -> "unregisteredKind " ^ string_of_int byte
    | E4_admission.Bad_frame -> "badFrame"
    | E4_admission.Trailing -> "trailing"
    | E4_admission.Conflict _ -> "conflict")
  | Capacity reason -> "capacity " ^ reason
  | Fault fault -> E4_fault.word fault
'''+s[b:]
s=s.replace('Some (Bad_version n.E4_node.version)','Some (Model E4_admission.Bad_version)').replace('Some Malformed_ref','Some (Model E4_admission.Malformed_ref)').replace('Some Handle_in_content','Some (Model E4_admission.Handle_in_content)')
s=s.replace('  | Error E4_node.Host_limit -> Error (Host_limit host_limit_why)\n  | Error (E4_node.Unknown_tag t) -> Error (Unknown_tag t)\n  | Error _ -> Error Oversize','  | Error why -> Error (E4_admission.of_decode why)')
s=s.replace('Error (Dangling e.E4_addr.Ref.addr)','Error (Model (E4_admission.Dangling e.E4_addr.Ref.addr))').replace('Error (Wrong_kind { at = e.E4_addr.Ref.addr; expected = e.E4_addr.Ref.kind; actual = k })','Error (Model (E4_admission.Wrong_kind (e.E4_addr.Ref.addr, e.E4_addr.Ref.kind, k)))')
s=s.replace('  | Error (E4_node.Bad_version b) -> Error (Bad_version b)\n  | Error why -> Error (E4_admission.of_decode why)','  | Error why -> Error (E4_admission.of_decode why)')
a=s.index('               | Error E4_node.Host_limit ->',s.index('let readmit_tail'));b=s.index('               | Ok n ->',a);s=s[:a]+'''               | Error why ->
                 stop := Refused { seg; off; addr = a; why = E4_admission.of_decode why };
                 raise Exit
'''+s[b:]
s=s.replace('let host_limit_why = "a frame length at or above 2^62 (amendment M9)"\n\n','');p.write_text(s)
p=out/'ocaml/engine/cas/e4_cas.mli';s=p.read_text();a=s.index('type admission =');b=s.index('\n',s.index('  | Wrong_kind',a));s=s[:a]+'''type admission = E4_admission.t =
  | Model of E4_admission.model
  | Capacity of string
  | Fault of E4_fault.t'''+s[b:];p.write_text(s)

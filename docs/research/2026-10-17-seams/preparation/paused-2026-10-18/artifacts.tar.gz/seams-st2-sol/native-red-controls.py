from pathlib import Path
import subprocess,os,json,hashlib,shutil
out=Path('/private/tmp/seams-st2-sol');fixtures=out/'red-fixtures';fixtures.mkdir(exist_ok=True)
baseenv={**os.environ,'E4_CAS_GOLDENS':str(out/'ocaml/engine/cas/goldens'),'E4_DISK_TMP':str(fixtures)}
source=out/'ocaml/engine/cas/goldens/disk-oracle.tsv';lines=source.read_text().splitlines(keepends=True)
index=next(i for i,line in enumerate(lines) if not line.startswith('#'));missing=out/'retained-controls/disk-oracle-missing.tsv';missing.write_text(''.join(lines[:index]+lines[index+1:]))
def run(name,root,test,env,needle):
 command=['opam','exec','--switch=effect4','--','dune','exec','--root',str(root),'engine/cas/test/'+test+'.exe']
 with (out/(name+'.log')).open('w') as log:
  log.write(json.dumps({'command':command})+'\n');log.flush();p=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env);log.write('exit_status='+str(p.returncode)+'\n')
 text=(out/(name+'.log')).read_text();assert p.returncode==2,(name,p.returncode,text);assert needle in text,(name,text)
 print(name+': expected red detected',flush=True)
run('oracle-missing-red',out/'ocaml','test_disk_stm',{**baseenv,'E4_DISK_ORACLE':str(missing)},'missing oracle transition')
assert list(fixtures.iterdir())==[],'incomplete oracle reached writer initialization'
red=out/'writer-red-native';assert not red.exists();subprocess.run(['cp','-c','-R',str(out/'ocaml'),str(red)],check=True)
p=red/'engine/cas/e4_cas.ml';before=p.read_text();needle='''    | Ok prepared ->
      let call point''';after=before.replace(needle,'''    | Ok prepared ->
      view.v_control <- prepared.prepared_control;
      write_control view;
      let call point''');assert before!=after;p.write_text(after)
(out/'writer-mutation.json').write_text(json.dumps({'original_sha256':hashlib.sha256(before.encode()).hexdigest(),'mutated_sha256':hashlib.sha256(after.encode()).hexdigest(),'mutation':'publish prepared roots before writing fresh nodes'},indent=2)+'\n')
run('writer-publication-red',red,'test_disk_kill',baseenv,'accepted cut before-write0 reopen fault')
shutil.rmtree(fixtures)

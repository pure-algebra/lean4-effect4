# Next work after the pause

ST2 is the stopping point.
Do not begin ST3 before the coordinator resumes the goal.

The coordinator freezes envelope preparation at `/private/tmp/seams-st3-scout`.
Its Shape.value, OfShape, Document relocation, Action, and Result modules compile.
The coordinator reports an audit of 570 declarations within `[propext, Quot.sound]`, with zero goals or modulo declarations.
ActionControls and ShapeProfileControls pass in that preparation.
Raw-value JSON reconstruction refuses in its profile control.
This packet does not independently rerun those ST3 results.

`Action.resultQuery_payload` identifies the designated query in the common envelope.
`Action.resultQuery_mem_checkedEdges` connects that query to existing checked edges.
The existing edge checker therefore resolves its kind-eight query without another lookup.
The Result none-iff, subset, and append helpers cover every node binding, including shadowed bindings.
See the coordinator's `PLACEMENT.md` and `query-edge-prep-2.log` there.

The assigned next work is Store, Word, Cas, and native result admission.
That integration has not started and has not compiled in this ST2 packet.
Preserve the exact old wf_apply, apply_idempotent, and closure statements.
Keep the Read face unchanged.
Prove the admission invariant over all node bindings, because conflict scans inspect them all.
Use the central ST2 byte entrance before shared semantic admission.
Generate the concrete common spec from its Lean owner rather than inventing bytes.
The coordinator owns Action, Result helpers, registry placement, and production integration.

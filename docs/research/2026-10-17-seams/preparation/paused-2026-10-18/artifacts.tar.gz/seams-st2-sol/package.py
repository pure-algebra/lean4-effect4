from pathlib import Path
import difflib,json,hashlib,subprocess
r=Path('/private/tmp/seams-st2-sol'); b=Path('/private/tmp/seams-st1b-sol');p=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4')
paths=[]
for tree in ['src','ocaml']:
 for f in sorted((r/tree).rglob('*')):
  if not f.is_file() or f.is_symlink() or '_build' in f.parts:continue
  old=b/f.relative_to(r)
  if not old.exists() or f.read_bytes()!=old.read_bytes():paths.append(f.relative_to(r).as_posix())
paths += ['scripts/generate.py','Makefile','docs/GENERATED.md','.github/actions/ocaml/action.yml']
rows=[];patch=[]
for rel in paths:
 target=rel.removeprefix('src/') if rel.startswith('src/Test/') else rel
 f=r/rel; old=p/target
 before=old.read_text() if old.exists() else ''
 after=f.read_text()
 if before==after:continue
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+target if old.exists() else '/dev/null',tofile='b/'+target))
 rows.append({'source':rel,'target':target,'pre_sha256':hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else None,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(r/'st2-all.patch').write_text(''.join(patch));(r/'source-manifest.json').write_text(json.dumps(rows,indent=2)+'\n')
q=subprocess.run(['git','apply','--check',str(r/'st2-all.patch')],cwd=p,capture_output=True,text=True)
(r/'patch-check.log').write_text(q.stdout+q.stderr+'exit_status='+str(q.returncode)+'\n');print(len(rows),'paths; apply check',q.returncode)
raise SystemExit(q.returncode)

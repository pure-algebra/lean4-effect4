from pathlib import Path
out=Path('/private/tmp/seams-st2-sol');base=out/'ocaml/engine/cas'
for ext in ['ml','mli']:
 p=base/('e4_fault.'+ext);s=p.read_text().replace('  | Pack of string','  | Record of { seg : int; off : int; reason : string }\n  | Root of { name : string; reason : string }\n  | Pack of string')
 if ext=='ml':s=s.replace('  | Pack reason ->','  | Record {seg; off; reason} -> Printf.sprintf "record %d:%d %s" seg off reason\n  | Root {name; reason} -> "root " ^ name ^ " " ^ reason\n  | Pack reason ->')
 p.write_text(s)
p=base/'e4_cas.ml';s=p.read_text();a=s.index('(* ============================================================ 5. put');s=s[:a]+'''
(* A snapshot contains values only: no mutable view, index, or pack handle. *)
type image = {
  image_nodes : (E4_addr.Addr.t * string) list;
  image_roots : E4_control.root list;
  image_boundary : int * int;
}

let empty_admission_view view =
  {view with v_index = Some (E4_index.create ~slots:8); v_cids = None;
    v_end = E4_index.from_start; v_staged = Hashtbl.create 16; v_order = [];
    v_control = E4_control.initial}

let checked_image view =
  let shadow = empty_admission_view view in
  let bytes = ref [] and ending = ref E4_index.from_start in
  let exception Refused_image of admission in
  let refuse why = raise (Refused_image why) in
  let record_fault (seg, off) reason = Fault (E4_fault.Record {seg; off; reason}) in
  try
    let stop =
      if not (pos_lt E4_index.from_start view.v_end) then E4_pack.Eof else
      walk_records view ~from:E4_index.from_start ~upto:view.v_end ~f:(fun ((seg, off) as position) record ->
        let address = record.E4_pack.r_addr in
        let raw = match E4_pack.read_at view.v_reader ~seg ~off with
          | None -> refuse (record_fault position "record checksum or framing")
          | Some (_, raw) -> raw in
        if not (String.equal (E4_sha256.digest raw) (key_of address)) then
          refuse (Fault (E4_fault.Corrupt address));
        let node = match E4_node.decode raw with
          | Error why -> refuse (E4_admission.of_decode why)
          | Ok node -> node in
        (match admissible shadow node with Error why -> refuse why | Ok () -> ());
        (match Hashtbl.find_opt shadow.v_staged (key_of address) with
         | Some old when not (String.equal old.st_bytes raw) ->
           (match E4_node.decode old.st_bytes with
            | Ok occupant -> refuse (Model (E4_admission.Conflict (address, occupant)))
            | Error why -> refuse (E4_admission.of_decode why))
         | Some _ -> ()
         | None -> Hashtbl.add shadow.v_staged (key_of address)
             {st_bytes = raw; st_seg = seg; st_off = off; st_kind = node.E4_node.kind});
        bytes := (address, String.sub raw 0 (String.length raw)) :: !bytes;
        ending := record_end position record.E4_pack.r_len)
    in
    if !ending <> view.v_end then
      refuse (record_fault !ending ("durable boundary: " ^ E4_pack.scan_stop_to_string stop));
    let rec roots names = function
      | [] -> ()
      | (root : E4_control.root) :: rest ->
        if List.exists (String.equal root.name) names then
          refuse (Fault (E4_fault.Root {name = root.name; reason = "duplicate name"}));
        (match get_kind shadow root.head.digest with
         | None -> refuse (Fault (E4_fault.Root {name = root.name; reason = "target absent from durable image"}))
         | Some kind when not (E4_kind.equal kind root.kind) ->
           refuse (Fault (E4_fault.Root {name = root.name; reason = "target kind"}))
         | Some _ -> ());
        roots (root.name :: names) rest in
    let image_roots = E4_control.roots view.v_control in
    roots [] image_roots;
    Ok {image_nodes = List.rev !bytes; image_roots; image_boundary = view.v_end}
  with Refused_image why -> Error why

'''+s[a:];p.write_text(s)
p=base/'e4_cas.mli';s=p.read_text();at=s.index('(* ---------------------------------------------------------------- opening *)');s=s[:at]+'''(** Frozen checked values. Node bytes pass the exact reader and ordered admission.
    Root targets lie within image_boundary; generations remain exact. *)
type image = {
  image_nodes : (E4_addr.Addr.t * string) list;
  image_roots : E4_control.root list;
  image_boundary : int * int;
}
val checked_image : ro -> (image, admission) result

'''+s[at:];p.write_text(s)

from pathlib import Path
import os, subprocess, json, sys
out=Path('/private/tmp/seams-st2-sol')
lib=out/'lib/lean'
lib.mkdir(parents=True,exist_ok=True)
env=dict(os.environ)
env['LEAN_PATH']=str(lib)+':'+env.get('LEAN_PATH','')
env['LEAN_NUM_THREADS']='3'
names=sys.argv[1:] or ['Effect4.Store.Carrier.Kind','Effect4.Store.Domain.Node','Effect4.Store.Domain.NodeRead','Effect4.Store.Domain.Store','Effect4.Store.Domain.Word','OCaml5.Lcnf.Gallina']
logpath=out/'build-overlay.log'
with logpath.open('a') as log:
    for name in names:
        rel=Path(*name.split('.'))
        src=out/'src'/rel.with_suffix('.lean')
        obj=lib/rel.with_suffix('.olean')
        obj.parent.mkdir(parents=True,exist_ok=True)
        for output in obj.parent.glob(obj.stem+'.*'):
            if output.is_symlink():
                output.unlink()
        cmd=['lean','-M6144','-DwarningAsError=true','--root='+str(out/'src'),'-o',str(obj),str(src)]
        log.write(json.dumps({'command':cmd,'LEAN_PATH':env['LEAN_PATH']})+'\n');log.flush()
        p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        log.write(f'exit_status={p.returncode}\n');log.flush()
        print(name+': exit '+str(p.returncode),flush=True)
        if p.returncode:
            print(logpath,flush=True)
            raise SystemExit(p.returncode)

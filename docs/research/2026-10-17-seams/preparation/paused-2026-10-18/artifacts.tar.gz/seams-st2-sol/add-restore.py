from pathlib import Path
out=Path('/private/tmp/seams-st2-sol');store=out/'src/Effect4/Store/Domain/Store.lean';s=store.read_text();a=s.index('/-- A root fixes');b=s.index('/-- The store:',a);root=s[a:b];store.write_text(s[:a]+s[b:])
p=out/'src/Effect4/Store/Domain/Transaction.lean';s=p.read_text();a=s.index('/-- Create a root,');s=s[:a]+root+'''/-- A decoded image. Raw bytes must pass Node.read before constructing its nodes. -/
structure Image where
  nodes : List Node
  roots : List Root
  deriving DecidableEq, Repr

'''+s[a:];s=s.replace('  | interrupt (transaction : Txn) (cut : Cut)','  | interrupt (transaction : Txn) (cut : Cut)\n  | restore (image : Image)');p.write_text(s)
p=out/'src/Effect4/Store/Domain/Cas.lean';s=p.read_text();s=s.replace('  | fork (name : String) (head target : Digest)','  | fork (name : String) (head target : Digest)\n  | restoreNonempty\n  | duplicateRoot (name : String)');a=s.index('/-- The one store event interpreter. -/');s=s[:a]+'''/-- Read every raw image item before shared semantic admission. -/
def Image.readNodes : Nat → List Bytes → Except TxnRefusal (List Node)
  | _, [] => .ok []
  | index, bytes :: rest => match Node.read bytes with
    | .error why => .error (.node index (.ofRead why))
    | .ok node => match Image.readNodes (index + 1) rest with
      | .error why => .error why
      | .ok nodes => .ok (node :: nodes)

/-- The raw byte entrance constructs no decoded image on refusal. -/
def Image.read (nodes : List Bytes) (roots : List Root) : Except TxnRefusal Image := do
  let nodes ← Image.readNodes 0 nodes
  pure ⟨nodes, roots⟩

/-- Check root names and each durable target without changing policy or generation. -/
def Store.checkImageRoots (store : Store) : List String → List Root → Except TxnRefusal Unit
  | _, [] => .ok ()
  | names, root :: rest =>
    if names.contains root.name then .error (.duplicateRoot root.name)
    else match checkEdge store ⟨root.kind, root.head.digest⟩ with
      | .error why => .error (.target root.name why)
      | .ok () => store.checkImageRoots (root.name :: names) rest

/-- Checked recovery starts at empty and retains the exact root table, not an invented history. -/
def Store.restore (store : Store) (image : Image) : Except TxnRefusal Store :=
  if store.nodes.isEmpty && store.roots.isEmpty then
    match Store.empty.stageNodes 0 image.nodes with
    | .error why => .error why
    | .ok (_, staged, _) => match staged.checkImageRoots [] image.roots with
      | .error why => .error why
      | .ok () => .ok {staged with roots := image.roots}
  else .error .restoreNonempty

'''+s[a:];s=s.replace('  | .interrupt transaction cut => store.interrupted transaction cut','  | .interrupt transaction cut => store.interrupted transaction cut\n  | .restore image => store.restore image');a=s.index('/-- Commit extends the reached witness');s=s[:a]+'''/-- A checked image reaches Cas through its explicit canonical recovery event. -/
@[no_expose] def restore (image : Image) : Except TxnRefusal Cas :=
  CasOf.ofReplay replayEvents [.restore image]

/-- Disk and far bytes pass the exact node reader before checked recovery. -/
@[no_expose] def restoreBytes (nodes : List Bytes) (roots : List Root) : Except TxnRefusal Cas := do
  let image ← Image.read nodes roots
  Cas.restore image

'''+s[a:];p.write_text(s)

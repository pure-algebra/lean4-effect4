from pathlib import Path
import subprocess,os,json
out=Path('/private/tmp/seams-st2-sol');env={**os.environ,'LEAN_PATH':str(out/'lib/lean')+':'+os.environ['LEAN_PATH']}
command=['lean','-M4096','-DwarningAsError=true','--run',str(out/'src/OCaml5/Tools/CasGoldens.lean'),str(out/'ocaml/engine/cas/goldens')]
with (out/'generate-goldens.log').open('w') as log:
 log.write(json.dumps(command)+'\n');log.flush();result=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
 log.write('exit_status='+str(result.returncode)+'\n')
print('Actual CasGoldens:',result.returncode)
raise SystemExit(result.returncode)

from pathlib import Path
out=Path('/private/tmp/seams-st2-sol');base=out/'ocaml/engine/cas'
for suffix in ['ml','mli']:
 p=base/('e4_pack.'+suffix);s=p.read_text();at=s.index('\nlet scan_stop_to_string') if suffix=='ml' else s.index('\nval scan_stop_to_string');s=s[:at]+'''\nexception Damaged_sealed of { seg : int; off : int; reason : scan_stop }\n'''+s[at:];
 if suffix=='ml':
  s=s.replace('let refuse_open msg =','let refuse_open ?damage msg =').replace('    raise (Bad_pack msg)\n  in','    match damage with\n    | None -> raise (Bad_pack msg)\n    | Some (seg, off, reason) -> raise (Damaged_sealed {seg; off; reason})\n  in',1)
  s=s.replace('      refuse_open\n        (Printf.sprintf "%s is sealed','      refuse_open ~damage:(cseg, coff, stop)\n        (Printf.sprintf "%s is sealed')
 p.write_text(s)
p=base/'e4_cas.ml';s=p.read_text().replace('let open_rw ~dir opts =','let open_rw_exn ~dir opts =');s=s.replace('    | E4_pack.Bad_pack why -> raise (Store_error ("pack: " ^ why))\n','');a=s.index('\nlet recovery t =');s=s[:a]+'''
(* The disk opening boundary returns faults as values, including sealed damage. *)
let open_rw ~dir opts =
  try Ok (open_rw_exn ~dir opts) with
  | E4_pack.Damaged_sealed {seg; off; reason} ->
    Error (Fault (E4_fault.Sealed_segment {seg; off; reason = E4_pack.scan_stop_to_string reason}))
  | E4_pack.Bad_pack reason -> Error (Fault (E4_fault.Pack reason))
  | Locked directory | E4_pack.Locked directory -> Error (Fault (E4_fault.Locked directory))
  | Store_error reason -> Error (Fault (E4_fault.Pack reason))
  | Sys_error reason -> Error (Fault (E4_fault.Io reason))
  | Unix.Unix_error (error, call, argument) ->
    Error (Fault (E4_fault.Io (call ^ " " ^ argument ^ ": " ^ Unix.error_message error)))
'''+s[a:];p.write_text(s)
p=base/'e4_cas.mli';s=p.read_text().replace('val open_rw : dir:string -> open_opts -> t','val open_rw : dir:string -> open_opts -> (t, admission) result');p.write_text(s)
for p in (base/'test').glob('*.ml'):
 s=p.read_text()
 if 'E4_cas.open_rw' not in s:continue
 s=s.replace('E4_cas.open_rw','open_writer')
 at=s.index('\nlet ',s.index('open Effect4_engine_cas'))
 helper='''
let open_writer ~dir opts =
  match E4_cas.open_rw ~dir opts with
  | Ok writer -> writer
  | Error why -> failwith ("open writer: " ^ E4_cas.admission_word why)
'''
 s=s[:at]+helper+s[at:];p.write_text(s)

from pathlib import Path
import json
r=Path('/Users/pooks/.codex/worktrees/seams/lean4-effect4')
def replace(path,old,new):
 p=r/path;s=p.read_text();assert old in s,(path,old);p.write_text(s.replace(old,new))
replace('src/Effect4.lean','import Effect4.Run.LiveRecord\n','import Effect4.Run.LiveRecord\nimport Effect4.Tool.Origin\n')
replace('src/Effect4/Laws.lean','import Effect4.Laws.Api.HostSession\n','import Effect4.Laws.Api.HostSession\nimport Effect4.Laws.Api.Built\n')
replace('Test/All.lean','import Test.Program.SeamsS0\n','import Test.Program.SeamsS0\nimport Test.Program.SeamsS4\nimport Test.Program.SeamsS4Origin\n')
replace('tools/ProofGraph/Registry.lean','        `Effect4.Laws.Api.HostSession,','        `Effect4.Laws.Api.HostSession,\n        `Effect4.Laws.Api.Built,')
replace('tools/ProofGraph/Registry.lean','    { id := "block-call-instance"','''    { id := "built-admission-exact", concept := "host-session-protocol", role := .compatibility
      title := "Built.ofSketch returns exactly the full program-admission refusal at the application alone; hole metadata never extends execution admission; no native forgery, host execution, or progress claim (seams S4, R6 and R13)"
      pointer := .witness `Effect4.Api.Built.ofSketch_error_iff },
    { id := "live-session-persists", concept := "host-session-protocol", role := .compatibility
      title := "Restoring a live session's own record returns its exact run after full admission and ordered journal replay, retaining recorded row spellings and empty session names; no repeated host effects or host reconnection claim (seams S4, R6 and R13)"
      pointer := .witness `Effect4.LiveRecord.restore_save },
    { id := "block-call-instance"''')
replace('tools/ProofGraph/Registry.lean','so a session that start made has an instance at every call of its admitted program (start_callInstance_complete)','and HostSession.instanceAt_complete supplies an instance at each call of an admitted program; Run.reached_callInstance reads that table in a reached run')
replace('tools/ProofGraph/Registry.lean','Typed.replay answers a Live, so the law reads every replayed run','LiveRecord.restore answers a Live after full admission and journal replay, so the law reads every restored run')
replace('docs/core/semantics.md','''  So a session that `start` made has an instance at every call of its admitted program
  (`start_callInstance_complete`).''','''  `HostSession.instanceAt_complete` supplies an instance at each call of an admitted program.
  `Run.reached_callInstance` reads that table in a reached run.''')
replace('docs/core/semantics.md','''- **Typed replay under session (`typed-replay-session`)**: Public typed replay route under keyed host session
  (decisions row 98).''','''- **Typed replay under session (`typed-replay-session`)**: Opening requires full admission at the application alone.
  `Api.Built.ofSketch_error_iff` states the exact refusal in `src/Effect4/Laws/Api/Built.lean` (`built-admission-exact`, R6 and R13).
  Hole metadata never extends the application admitted for execution.
  Restore replays ordered commands and retains recorded names, including an empty session name.
  `LiveRecord.restore_save` returns the exact saved run in `src/Effect4/Laws/Api/LiveRecord.lean` (`live-session-persists`, R6 and R13).
  Neither property establishes native package integrity, host reconnection, repeated effects, or progress.''')
replace('docs/core/host-boundary.md','`Typed.replay` feeds a','`LiveRecord.restore` admits the program and feeds a')
replace('docs/core/host-boundary.md','''  - `Typed.replay` replays a session's journal through the checked session, and a session's own
    journal replays to that run (`Live.replay_recorded`).''','''  - `LiveRecord.restore` checks full admission, then replays the journal through the checked session.
    A session's own record restores its exact run (`LiveRecord.restore_save`, `src/Effect4/Laws/Api/LiveRecord.lean`).''')
replace('docs/core/host-boundary.md','''| `Typed.replay` | consumes a session header and a `Runner.Command` journal through the checked keyed session, with both budgets and phases that can refuse, checked at each call's instance (rows 98 and 373 (8)) |''','''| `Built.ofSketch`, `Live.open`, `LiveRecord.restore` | Full admission precedes opening. Restore checks record versions and replays ordered commands with both budgets and each call's instance. |''')
replace('docs/core/host-boundary.md','''| The certificate-first `Typed.replay` runs unchecked answers: it is the raw `Api.replay` on the certified program (`src/Effect4/Api.lean`). Row 373 (8) rules the repair: it replays the session's journal, checked at each call's instance. |''','''| The historical certificate-first `Typed.replay` runs unchecked answers. The current `LiveRecord.restore` checks full admission and replays the journal at each call's instance. |''')
replace('docs/core/system-map.md','''  appends on the assembled table; `HostSession.start` refuses another table). The host-row
  protocol entry carries the row's domain bit so that typing is monotone in the table (row 116).''','''  appends on the assembled table).
  `Built.ofSketch` admits the program at that table; `Run.open` constructs its header from the same application.
  Message admission retains its header-table check.
  The host-row protocol entry carries the row's domain bit so that typing is monotone in the table (row 116).''')
p=r/'docs/core/api-surface.md';s=p.read_text();lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('| `Run`, the live session ('):
  lines[i]='| `Run`, the live session (decisions row 373) | `src/Effect4/Run/Live.lean`, `src/Effect4/Run/View.lean`, `src/Effect4/Run/LiveRecord.lean` | `Built.ofSketch` admits before `Live.open`. `Live.feed` and `Live.feedAll` apply commands. `LiveRecord.restore` admits and replays a record. | `Built.ofSketch_error_iff`, `LiveRecord.restore_save`, `Live.view_classifies`, `Live.view_funded`, `Live.replay_at_call_instance` in `src/Effect4/Laws/Api/` |'
s='\n'.join(lines)+'\n';s=s.replace('`Built`, `HostSession.start`, `Run.open` and the soundness statements','`Built`, `Built.ofSketch`, `Run.open` and the admission statements');p.write_text(s)
p=r/'ocaml/gen/roots.json';data=json.loads(p.read_text());art=next(x for x in data['artefacts'] if x['out']=='ocaml/gen/api_gen.ml')
for field in ['roots','nominal']:
 values=art[field];index=values.index('Effect4.Live.start');values[index:index+1]=['Effect4.Api.Built.ofSketch','Effect4.Live.open']
assert 'Effect4.Api.Built' not in art['abstract'];art['abstract'].append('Effect4.Api.Built')
p.write_text(json.dumps(data,indent=2)+'\n')
print('Integrated S4 owners, admitted-opening claims, roots, and native package seal without replacing V1 exports.')

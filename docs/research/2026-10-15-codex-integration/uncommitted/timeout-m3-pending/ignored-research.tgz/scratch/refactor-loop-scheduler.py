p='src/Effect4/Laws/Machine/Lift.lean'
s=open(p).read()
a=s.index('structure FoldLift (o : WorldOrder W)');b=s.index('\nomit [DecidableEq ε]',a)
record=s[a:b]
looprec=record.replace('structure FoldLift (o : WorldOrder W)','structure LoopFoldLift (budget : Nat) (o : WorldOrder W)',1)
looprec=looprec.replace('  step : ∀ ts, StepKeeps o interp (Guarded J I O ts)','''  loop : ∀ ts w m cmds, J w m → (m.stuck = none → I w m cmds ∧ O w m ts) →
    ∃ next, o.le w next ∧ J next (driveState interp budget m cmds).1 ∧
      ((driveState interp budget m cmds).1.stuck = none → O next (driveState interp budget m cmds).1 ts)''',1)
s=s[:b]+'''\n/-- The scheduler consumes one actual fixed-budget loop contract.
Concept: reactive-scheduling R9. Consumer: Timeout's fuel-indexed numeric history.
The loop returns the machine and actual detached snapshot; its discarded queue is outside this contract. -/
'''+looprec+s[b:]
# Insert conversion after existing FoldLift.loop_lift, immediately before the old entry theorem.
a=s.index('/-- A loop entered with no snapshot keeps `J`. -/')
convert='''/-- The existing per-command interface supplies the same scheduler loop contract. -/
def FoldLift.toLoop (h : FoldLift o interp J I O) (budget : Nat) : LoopFoldLift budget o interp J I O where
  loop := by
    intro ts w m cmds hj hi
    obtain ⟨next, later, kept, pending⟩ := h.loop_lift ts budget w m cmds hj hi
    exact ⟨next, later, kept, fun running => (pending running).2⟩
  nil := h.nil
  drain := h.drain
  ran := h.ran
  task := h.task
  skip := h.skip
  clockNone := h.clockNone
  clockSome := h.clockSome

'''
s=s[:a]+convert+s[a:]
a=s.index('/-- A loop entered with no snapshot keeps `J`. -/')
b=s.index('/-! The decision-lift forms below',a)
oldblock=s[a:b]
newblock=oldblock.replace('theorem FoldLift.', 'theorem LoopFoldLift.')
newblock=newblock.replace('(h : FoldLift o interp J I O) (fuel : Nat)', '{fuel : Nat} (h : LoopFoldLift fuel o interp J I O)')
newblock=newblock.replace('loop_lift h [] fuel', 'h.loop []').replace('loop_lift h ts fuel', 'h.loop ts')
newblock=newblock.replace('fireFold_lift h fuel', 'fireFold_lift h').replace('fireState_lift h fuel', 'fireState_lift h')
newblock=newblock.replace('flushAllState_lift h fuel', 'flushAllState_lift h').replace('flushRootState_lift h fuel', 'flushRootState_lift h')
newblock=newblock.replace('advanceState_lift h fuel', 'advanceState_lift h').replace('loop_entry h fuel', 'loop_entry h')
newblock=newblock.replace('(hi₁ hs).2', 'hi₁ hs')
# Preserve every original FoldLift theorem statement as a wrapper over the one existing recursion.
import re
starts=list(re.finditer(r'theorem FoldLift\.(\w+)',oldblock))
wrappers=[]
for i,m in enumerate(starts):
 end=starts[i+1].start() if i+1<len(starts) else len(oldblock)
 chunk=oldblock[m.start():end]
 # The statement ends at :=; all old proofs here use := by or equation clauses.
 # Recursive declarations have no := before their first pattern clause.
 if ' := by' in chunk:
  sig=chunk[:chunk.index(' := by')]
 else:
  sig=chunk[:chunk.index('\n  |')]
 name=m.group(1)
 args={
  'loop_entry':'w m cmds hj hi',
  'fireFold_lift':'owner',
  'fireState_lift':'w m owner hj',
  'flushAllState_lift':'',
  'flushRootState_lift':'root',
  'advanceState_lift':'millis',
 }[name]
 # Remove any following docstring accidentally captured after the theorem body signature.
 wrappers.append(sig+' :=\n  LoopFoldLift.'+name+' (h.toLoop fuel)'+(' '+args if args else '')+'\n\n')
s=s[:a]+newblock+'''/-! The old fold interfaces remain constant-loop instances of the shared scheduler proof. -/\n\n'''+''.join(wrappers)+s[b:]
open(p,'w').write(s)

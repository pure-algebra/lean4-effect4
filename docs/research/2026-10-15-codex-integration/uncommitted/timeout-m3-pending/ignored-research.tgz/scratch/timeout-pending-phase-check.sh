#!/bin/bash
set -e
lake build Test.Dogfood.Proofs.HostTimeoutNumberRetirement Test.Dogfood.Proofs.HostTimeoutNumberCleanupNative Test.Dogfood.Proofs.HostTimeoutNumberInjection
lake env lean scratch/TimeoutPendingPhaseAudit.lean

import Effect4.Laws.Program.OperationBudget
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.OperationBudget

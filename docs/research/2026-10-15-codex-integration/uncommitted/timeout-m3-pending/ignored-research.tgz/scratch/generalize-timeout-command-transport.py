p='Test/Dogfood/Proofs/HostTimeoutNumberQueueInterrupt.lean';s=open(p).read();a=s.index('theorem command_transport (world');b=s.index('/-- The actual admitted interrupt transports',a);old=s[a:b];gen=old.replace('theorem command_transport (world : HostTimeoutNumberConfiguration.World)','theorem command_transport_into (world next : HostTimeoutNumberConfiguration.World)',1).replace('CommandAt world after','CommandAt next after').replace('ReplyAt world after','ReplyAt next after');wrap=old[:old.index(' := by')]+''' :=
  command_transport_into world world before after commands command queued held replies loops finishes afterReturns raceReturns

''';s=s[:a]+gen+'''/-- The existing same-world queue transport remains an instance. -/
'''+wrap+s[b:];open(p,'w').write(s)

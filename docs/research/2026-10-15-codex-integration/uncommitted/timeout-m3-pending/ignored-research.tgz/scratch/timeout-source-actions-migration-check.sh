set -e
export LEAN_NUM_THREADS=3
lake build Test.Dogfood.Proofs.HostTimeoutNumberRetirement Test.Dogfood.Proofs.HostTimeoutNumberCleanupNative Test.Dogfood.Proofs.HostTimeoutNumberInjection
lake env lean scratch/TimeoutSourceActionsAudit.lean

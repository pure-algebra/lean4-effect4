set -e
export LEAN_NUM_THREADS=3
lake build Test.Dogfood.Proofs.HostTimeoutNumberBeforeMask
lake env lean scratch/TimeoutBeforeMaskAudit.lean

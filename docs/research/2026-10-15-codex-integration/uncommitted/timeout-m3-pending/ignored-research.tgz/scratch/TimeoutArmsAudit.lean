import Effect4.Laws.Program.CodeClosure.Arms
import Effect4.Laws.Program.CodeClosure.Family
import Test.Dogfood.Proofs.QueueWorkersNotificationFamily
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.CodeClosure.Arms

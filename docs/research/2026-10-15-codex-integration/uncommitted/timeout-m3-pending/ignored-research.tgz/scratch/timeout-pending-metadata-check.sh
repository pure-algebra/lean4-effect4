#!/bin/bash
set -e
lake build Effect4.Laws.Program.AnswerSlots.AllocationCommandStep Effect4.Laws.Program.AnswerSlots.AllocationDeferredQuiet ProofGraph.AxiomAudit
lake env lean scratch/TimeoutPendingMetadataAudit.lean

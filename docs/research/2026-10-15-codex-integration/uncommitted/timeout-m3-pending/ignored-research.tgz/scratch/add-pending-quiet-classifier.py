p='src/Effect4/Laws/Program/AnswerSlots/AllocationPending.lean'
s=open(p).read().replace('import Effect4.Laws.Program.AnswerSlots.AllocationWaits','import Effect4.Laws.Program.AnswerSlots.AllocationWaits\nimport Effect4.Laws.Program.AnswerSlots.AllocationDeferredQuiet',1)
s=s.replace('theorem pending_ordinary_or_entry','theorem pending_metadata_or_entry',1)
s=s.replace('(∀ thunk, program ≠ .withFiber thunk) ∧ (∀ name signal cancel, program ≠ .async name signal cancel)) ∨','(∀ thunk, program ≠ .withFiber thunk) ∧ (∀ name signal cancel, program ≠ .async name signal cancel) ∧\n      (∀ thunk state value, program = .sync thunk →\n        (interpAt spec.root view spec.table).syncState thunk world.state = some (state, value) →\n        DeferredQuiet world.state.deferreds → DeferredQuiet state.deferreds)) ∨',1)
s=s.replace('all_goals exact .inl ⟨rfl, (by intro thunk equal; cases equal), (by intro name signal cancel equal; cases equal)⟩','all_goals exact .inl ⟨rfl, (by intro thunk equal; cases equal), (by intro name signal cancel equal; cases equal),\n      (by intro thunk state value equal; cases equal)⟩',1)
a=s.index('  | success good | failure phase | allocating')
b=s.index('\nend Effect4.Program.AnswerSlots.AllocationAdapter',a)
s=s[:a]+'''  | @allocating index point small stage =>
    apply Or.inl
    refine ⟨rfl, (by intro thunk equal; cases equal), (by intro name signal cancel equal; cases equal), ?_⟩
    intro thunk state value equal ran quiet
    cases equal
    obtain ⟨key, written⟩ := Initialization.actual spec.initialization index world.state state value ran
    subst state
    exact quiet
  | gateAllocating stage available =>
    apply Or.inl
    refine ⟨rfl, (by intro thunk equal; cases equal), (by intro name signal cancel equal; cases equal), ?_⟩
    intro thunk state value equal ran quiet
    cases equal
    change syncOpStep .deferredMake world.state = some (state, value) at ran
    rw [syncOpStep_deferredMake] at ran
    cases ran
    refine ⟨quiet.1, ?_⟩
    intro cell member
    rcases List.mem_append.mp member with before | fresh
    · exact quiet.2 cell before
    · cases List.mem_singleton.mp fresh
      rfl
  | reading phase refs deferred missing contents entered =>
    apply Or.inl
    refine ⟨rfl, (by intro thunk equal; cases equal), (by intro name signal cancel equal; cases equal), ?_⟩
    intro thunk state value equal ran quiet
    cases equal
    change syncOpStep (.refGet _) world.state = some (state, value) at ran
    cases peek : refPeek world.state.refs _ with
    | none =>
      simp only [syncOpStep, refStep, peek, Option.map_none] at ran
      cases ran
    | some answer =>
      simp only [syncOpStep, refStep, peek, Option.map_some] at ran
      cases ran
      exact quiet
  | success good | failure phase | frontier zero phase
    | yielding phase refs deferred missing contents entered | yieldThen phase next missing =>
    exact .inl ⟨rfl, (by intro thunk equal; cases equal), (by intro name signal cancel equal; cases equal),
      (by intro thunk state value equal; cases equal)⟩

/-- The original ordinary-head interface reads the same actual source classifier. -/
theorem pending_ordinary_or_entry (spec : Spec) (view : List (FiberId × ExitV)) (world : World)
    (kind : Kind spec.stable.Kind) (program : NCode) (owned : CodeAt spec world kind program)
    (pending : world.entered = false) :
    ((interpAt spec.root view spec.table).parkOf program = none ∧
      (∀ thunk, program ≠ .withFiber thunk) ∧ (∀ name signal cancel, program ≠ .async name signal cancel)) ∨
    ∃ point, kind = .stable spec.stable.rootKind ∧ program = resolve spec.root point ∧ Entry spec world point := by
  rcases pending_metadata_or_entry spec view world kind program owned pending with ordinary | entry
  · exact .inl ⟨ordinary.1, ordinary.2.1, ordinary.2.2.1⟩
  · exact .inr entry
'''+s[b:]
open(p,'w').write(s)

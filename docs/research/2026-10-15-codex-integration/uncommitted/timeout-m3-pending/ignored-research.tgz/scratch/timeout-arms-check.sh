set -e
export LEAN_NUM_THREADS=3
lake build Effect4.Laws.Program.CodeClosure.Family Test.Dogfood.Proofs.QueueWorkersNotificationFamily
lake env lean scratch/TimeoutArmsAudit.lean

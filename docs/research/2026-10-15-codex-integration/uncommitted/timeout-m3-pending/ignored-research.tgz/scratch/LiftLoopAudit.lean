import Effect4.Laws.Machine.Lift
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Machine.Lift

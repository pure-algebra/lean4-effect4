p='src/Effect4/Laws/Program/AnswerSlots/AllocationConfiguration.lean';s=open(p).read().replace('import Effect4.Laws.Program.AnswerSlots.AllocationRecorded','import Effect4.Laws.Program.AnswerSlots.AllocationDeferredQuiet',1).replace('  recorded : ∀ fiber ∈ machine.fibers, CleanRecorded fiber.frame','  recorded : ∀ fiber ∈ machine.fibers, CleanRecorded fiber.frame\n  deferred : DeferredQuiet machine.state.deferreds');s=s.replace('    cases present\n','    cases present\n  · exact ⟨rfl, fun _ member => (List.not_mem_nil member).elim⟩\n',1);open(p,'w').write(s)
p='src/Effect4/Laws/Program/AnswerSlots/AllocationNativeCut.lean';s=open(p).read().replace('  recorded : result.fiber.frame.interruptedCause = fiber.frame.interruptedCause','  recorded : result.fiber.frame.interruptedCause = fiber.frame.interruptedCause\n  deferred : DeferredQuiet machine.state.deferreds → DeferredQuiet result.machine.state.deferreds');s=s.replace('rcases pending_ordinary_or_entry spec machine.completedExits','rcases pending_metadata_or_entry spec machine.completedExits',1);s=s.replace('Guard.Interruption.evaluateNative_interruptedCause spec.root spec.table machine fiber yielding⟩','Guard.Interruption.evaluateNative_interruptedCause spec.root spec.table machine fiber yielding, ?_⟩',1);s=s.replace('ordinary.1 ordinary.2.1\n','ordinary.1 ordinary.2.1\n',1)
pos=s.index('/-- The common iteration walk')
s=s[:pos]+'''  · intro quiet
    rw [same]
    apply StatePreservation.primitive_at (interpAt spec.root machine.completedExits spec.table)
      (fun state => DeferredQuiet state.deferreds) machine fiber yielding quiet
    · intro thunk state value current ran
      exact ordinary.2.2.2 thunk state value current ran quiet
    · intro name signal cancel current
      exact (ordinary.2.2.1 name signal cancel current).elim
    · intro thunk action current found
      exact (ordinary.2.1 thunk current).elim

'''+s[pos:]
s=s.replace('(Replies fiber.dispatcher → Replies result.fiber.dispatcher)\n  have admitted','(Replies fiber.dispatcher → Replies result.fiber.dispatcher) ∧\n    (DeferredQuiet machine.state.deferreds → DeferredQuiet result.machine.state.deferreds)\n  have admitted')
s=s.replace('actual.fibers = machine.fibers ∧ actor.dispatcher = fiber.dispatcher)','actual.fibers = machine.fibers ∧ actor.dispatcher = fiber.dispatcher ∧\n        actual.state.deferreds = machine.state.deferreds)')
s=s.replace('fun replies => cut.dispatcher.2 (permission.2.2.2.symm ▸ replies)⟩','fun replies => cut.dispatcher.2 (permission.2.2.2.1.symm ▸ replies),\n        fun quiet => cut.deferred (permission.2.2.2.2.symm ▸ quiet)⟩')
s=s.replace('⟨rfl, admitted, rfl, dispatcher⟩, ⟨rfl, admitted, rfl, dispatcher⟩','⟨rfl, admitted, rfl, dispatcher, rfl⟩, ⟨rfl, admitted, rfl, dispatcher, rfl⟩')
a=s.index('  · exact .inl ⟨result.1, result.2.1,')
b=s.index('  · exact .inr entry',a)
s=s[:a]+'''  · obtain ⟨heap, counter, flows, waits, effects, rows, replies, quiet⟩ := result
    exact .inl ⟨heap, counter, flows, waits,
      Moves.iteration_footprint spec.root spec.table (interpOf spec.root spec.table) machine fiber yielding,
      effects, ⟨rows, replies⟩,
      Guard.Interruption.iteration_interruptedCause spec.root spec.table machine fiber yielding, quiet⟩
'''+s[b:]
s=s.replace('cut.counter.trans before.counter, ?_, ?_⟩','cut.counter.trans before.counter, ?_, ?_, cut.deferred before.deferred⟩')
open(p,'w').write(s)
p='src/Effect4/Laws/Program/AnswerSlots/AllocationSettlement.lean';s=open(p).read().replace('counter.trans held.counter, ?_, ?_⟩','counter.trans held.counter, ?_, ?_, ?_⟩').replace('cut.counter.trans before.counter, ?_, ?_⟩','cut.counter.trans before.counter, ?_, ?_, cut.deferred before.deferred⟩');s=s.replace('/-- Settlement changes', '''  · rw [state]
    exact held.deferred

/-- Settlement changes''');open(p,'w').write(s)
p='src/Effect4/Laws/Program/AnswerSlots/AllocationInterruption.lean';s=open(p).read().replace('before.counter, ?_, ?_⟩','before.counter, ?_, ?_, before.deferred⟩');open(p,'w').write(s)
p='src/Effect4/Laws/Program/AnswerSlots/AllocationFields.lean';s=open(p).read().replace('(rows : ∀ row ∈ after.fibers, ∃ old ∈ before.fibers, SamePendingRow old row) :','(rows : ∀ row ∈ after.fibers, ∃ old ∈ before.fibers, SamePendingRow old row)\n    (quiet : DeferredQuiet after.state.deferreds) :').replace('counter.trans held.counter, ?_, ?_⟩','counter.trans held.counter, ?_, ?_, quiet⟩').replace('(deferred : state.deferreds.cells.length = machine.state.deferreds.cells.length) :','(deferred : state.deferreds.cells.length = machine.state.deferreds.cells.length)\n    (quiet : DeferredQuiet state.deferreds) :').replace('held refs deferred rfl\n','held refs deferred rfl ?_ quiet\n');open(p,'w').write(s)
p='src/Effect4/Laws/Program/AnswerSlots/AllocationDecisionEdits.lean';s=open(p).read().replace('      (Guard.AnswerDecision.prepareAsyncAnswer_shape spec.root spec.table machine id token answer).2.1\n','      (Guard.AnswerDecision.prepareAsyncAnswer_shape spec.root spec.table machine id token answer).2.1\n  · rw [(Guard.AnswerDecision.prepareAsyncAnswer_shape spec.root spec.table machine id token answer).2.1]\n    exact before.deferred\n');s=s.replace('  · rfl\n  · rfl\n','  · rfl\n  · rfl\n  · exact before.deferred\n',1);open(p,'w').write(s)
p='src/Effect4/Laws/Program/AnswerSlots/AllocationFixed.lean';s=open(p).read().replace('before fields.1 fields.2\n    exact PendingConfiguration.drainOwed','before fields.1 fields.2\n      ⟨rfl, before.deferred.2⟩\n    exact PendingConfiguration.drainOwed');s=s.replace('    exact PendingConfiguration.store_fields spec fragment machine _ before fields.1 fields.2\n','''    apply PendingConfiguration.store_fields spec fragment machine _ before fields.1 fields.2
    change DeferredQuiet (machine.state.wakeList list phase).deferreds
    unfold Stores.wakeList
    split
    · rw [before.deferred.wake]
      exact before.deferred
    · exact before.deferred
''');open(p,'w').write(s)

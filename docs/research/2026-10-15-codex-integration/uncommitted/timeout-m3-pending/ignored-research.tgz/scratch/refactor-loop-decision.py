p='src/Effect4/Laws/Machine/Lift.lean';s=open(p).read();a=s.index('/-- **Lift 2, one decision.**');b=s.index('\nend Decision',a);old=s[a:b]
converter='''/-- The original first-resume answer interface supplies the same actual full decision continuation. -/
theorem DecisionLift.toLoop (h : DecisionLift o interp J I O A) (budget : Nat) :
    LoopDecisionLift budget o interp J I O A where
  fold := (FoldLift.ofDecisionLift h).toLoop budget
  evaluate := h.evaluate
  yield := h.yield
  interrupt := h.interrupt
  middleware := h.middleware
  answer := by
    intro w m id token answer hj hs ha
    cases budget with
    | zero => exact ⟨w, o.refl w, hj⟩
    | succ remaining =>
      show ∃ next, o.le w next ∧ J next (driveState interp (remaining + 1)
        {m with state := (prepareAsyncAnswer interp m id token answer).1}
        [Cmd.resume id token (prepareAsyncAnswer interp m id token answer).2, Cmd.drainDue]).1
      rw [driveState_succ_cons, if_neg (not_isSome_of_none hs)]
      obtain ⟨first, later, kept⟩ := h.answer w m id token answer hj hs ha
      obtain ⟨next, further, hjNext, rest⟩ := (FoldLift.ofDecisionLift h).loop_lift [] remaining first _ _ kept.1 kept.2
      exact ⟨next, o.trans later further, hjNext⟩

'''
gen=old.replace('/-- **Lift 2, one decision.** From the command premise and one premise per edit outside the\nloop, every decision keeps `J`, at some later world, when its admission `A` holds. -/','/-- The existing decision split consumes one actual loop contract at the fixed command budget. -/',1)
gen=gen.replace('theorem stepDecisionState_lift (h : DecisionLift o interp J I O A) (fuel : Nat)', 'theorem LoopDecisionLift.stepDecisionState_lift {fuel : Nat} (h : LoopDecisionLift fuel o interp J I O A)',1)
x=gen.index('  | answerAsync id token answer =>');y=gen.index('  | interruptFrom who extra target =>',x)
gen=gen[:x]+'''  | answerAsync id token answer =>
    by_cases hs : m.stuck = none
    · exact h.answer w m id token answer hj hs ha
    · cases fuel with
      | zero => exact ⟨w, o.refl w, hj⟩
      | succ remaining =>
        have unchanged : prepareAsyncAnswer interp m id token answer = (m.state, interp.answerCode answer) := by
          unfold prepareAsyncAnswer
          rw [if_pos (isSome_of_ne_none hs)]
        show ∃ next, o.le w next ∧ J next (driveState interp (remaining + 1)
          {m with state := (prepareAsyncAnswer interp m id token answer).1}
          [Cmd.resume id token (prepareAsyncAnswer interp m id token answer).2, Cmd.drainDue]).1
        rw [unchanged, driveState_stuck interp (remaining + 1) {m with state := m.state} _
          (isSome_of_ne_none (m := {m with state := m.state}) hs)]
        exact ⟨w, o.refl w, hj⟩
'''+gen[y:]
gen=gen.replace('fireState_lift h fuel w m owner hj','h.fold.fireState_lift w m owner hj').replace('flushAllState_lift h fuel fuel w m hj','h.fold.flushAllState_lift fuel w m hj').replace('loop_entry h fuel','h.fold.loop_entry').replace('advanceState_lift h fuel millis fuel w m hj','h.fold.advanceState_lift millis fuel w m hj')
wrapper=old[:old.index(' := by')]+''' :=
  LoopDecisionLift.stepDecisionState_lift (h.toLoop fuel) w m d hj ha
'''
s=s[:a]+converter+gen+'\n'+wrapper+s[b:];open(p,'w').write(s)

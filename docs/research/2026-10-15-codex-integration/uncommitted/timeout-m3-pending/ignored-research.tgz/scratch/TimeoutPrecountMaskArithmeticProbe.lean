import Test.Dogfood.Proofs.HostTimeoutNumberMaskPermission
import Effect4.Laws.Program.CodeClosure.Arms

/-!
Concept: scope-lifetime-finalization R11.
Question: an actual restoring mask cannot expose an installed attempt before its count commits.
Consumer: the existing rooted numeric pop authority retains the pending pre-count mask.
Reach: the same incoming kind, retained finalizer grade, owner count, and actual supplied answer permission.
Limit: the actual pending producer must retain this authority through the existing selected-edge interface.
-/
set_option autoImplicit false
namespace Test.Dogfood.Proofs.HostTimeoutNumberBeforeMask
open Effect4 Effect4.Machine Effect4.Program
open HostTimeoutNumberConfiguration HostTimeoutNumberPhaseFlow

/-- A real early restoring edge cannot supply an answer before its owning count commits. -/
theorem restoring_ne_before (context : CountContext) (state : Stores) (kind : Kind)
    (owner : kind.ownerCount = context.entered.count) (early : kind.grade ≤ 1)
    (restorable : HostTimeoutNumberMaskClass.Restorable kind)
    (permitted : (∃ value, ValueAt state kind value) ∨ ∃ cause, CauseAt state kind cause) :
    ¬ At context.before state := by
  intro heap
  have counts : ∀ phase : HostTimeoutNumberPhase.Phase, At phase state → phase.count = context.before.count := by
    intro phase selected
    exact (HostTimeoutNumberPhase.Phase.heap_fields phase context.before (selected.symm.trans heap)).1
  have impossible : ∀ phase : HostTimeoutNumberPhase.Phase,
      phase.count = context.entered.count → At phase state → False := by
    intro phase anchored selected
    have actual := counts phase selected
    change phase.count = context.before.count + 1 at anchored
    omega
  cases kind with
  | fresh phase =>
    rcases permitted with ⟨value, good⟩ | ⟨cause, good⟩
    · exact impossible phase owner good
    · exact impossible phase owner good.1
  | countUnit phase =>
    rcases permitted with ⟨value, good⟩ | ⟨cause, good⟩
    · exact impossible phase owner good.1
    · exact impossible phase owner good.1
  | before phase =>
    rcases permitted with ⟨value, good⟩ | ⟨cause, good⟩
    · exact impossible phase owner good
    · exact impossible phase owner good
  | read phase => exact False.elim restorable
  | unit phase => exact False.elim restorable
  | paused phase incoming => exact False.elim restorable
  | attempt before entered own => change 5 ≤ 1 at early; omega
  | cleanupExit phase own => change 4 ≤ 1 at early; omega
  | published phase => change 4 ≤ 1 at early; omega

/-- A real failure before count belongs beyond the protected count-answer boundary. -/
theorem cause_high (context : CountContext) (state : Stores) (kind : Kind) (cause : CauseV)
    (owner : kind.ownerCount = context.entered.count) (good : CauseAt state kind cause)
    (heap : At context.before state) : 1 < kind.grade := by
  induction kind with
  | paused phase incoming ih => exact ih owner good
  | read phase => exact False.elim good
  | unit phase => exact False.elim good
  | fresh phase =>
    exact False.elim (restoring_ne_before context state _ owner (by dsimp only [Kind.grade]; decide)
      (by trivial) (Or.inr ⟨cause, good⟩) heap)
  | countUnit phase =>
    exact False.elim (restoring_ne_before context state _ owner (by dsimp only [Kind.grade]; decide)
      (by trivial) (Or.inr ⟨cause, good⟩) heap)
  | before phase =>
    exact False.elim (restoring_ne_before context state _ owner (by dsimp only [Kind.grade]; decide)
      (by trivial) (Or.inr ⟨cause, good⟩) heap)
  | attempt before entered own => dsimp only [Kind.grade]; decide
  | cleanupExit phase own => dsimp only [Kind.grade]; decide
  | published phase => dsimp only [Kind.grade]; decide

/-- An actual callback suffix cannot create an authored finalizer to cross the mask boundary. -/
theorem pushed_high (state : Stores) (input output : Kind) (pushed : List NCode)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output pushed)
    (shapes : ∀ code ∈ pushed, CodeClosure.Arms.PushedFrame code)
    (later : 1 < output.grade) : 1 < input.grade := by
  by_cases early : input.grade ≤ 1
  · obtain ⟨first, last, frame, member, edge, low, high⟩ :=
      path.crossing_member Kind.grade 1 early later
    obtain ⟨body, point, actual⟩ := edge.crossing low high
    have shape := shapes frame member
    rw [actual] at shape
    exact False.elim shape
  · omega

/-- The same actual value callback retains its high-side mask authority after its pushed suffix. -/
theorem value_callback_high (interp : PrimInterp EffName EffThunk Val Err Defect FiberId Ann)
    (state : Stores) (frame next : NCode) (value : Val) (provided : Option ExitV)
    (pushed : List NCode) (input output : Kind)
    (actual : frame.armA interp value provided = some (next, pushed))
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output pushed)
    (later : 1 < output.grade) : 1 < input.grade :=
  pushed_high state input output pushed path (CodeClosure.Arms.value_pushed interp frame value provided next pushed actual) later

end Test.Dogfood.Proofs.HostTimeoutNumberBeforeMask

set -e
export LEAN_NUM_THREADS=3
lake build Test.Dogfood.Proofs.HostTimeoutNumberSourceActions

set -e
export LEAN_NUM_THREADS=3
lake build Effect4.Laws.Program.OperationBudget
lake env lean scratch/OperationBudgetAudit.lean

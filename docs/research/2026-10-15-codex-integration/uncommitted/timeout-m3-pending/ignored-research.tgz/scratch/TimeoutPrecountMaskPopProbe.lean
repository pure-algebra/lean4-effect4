import Test.Dogfood.Proofs.HostTimeoutNumberBeforeMask
import Effect4.Laws.Machine.AnswerFlowFamilyPop
import Effect4.Laws.Machine.MaskRuns
import Test.Dogfood.Proofs.HostTimeoutNumberPhaseFinalizer

/-!
Concept: scope-lifetime-finalization R11 and store-typing R4.
Question: both Timeout endpoint histories retain actual protected cleanup custody through saved value returns.
Consumer: the pending whole-fiber native producer and its joined numeric command history.
Reach: one actual entered heap, owner-anchored uniform path, and permitted incoming value.
Limit: this relative fact supplies no whole-machine history or host failure-origin certificate.
-/
set_option autoImplicit false
namespace Test.Dogfood.Proofs.HostTimeoutNumberPopAuthority
open Effect4 Effect4.Machine Effect4.Program
open HostTimeoutNumberPhaseFlow

/-- One actual running frame keeps its semantic input and unmasked early permission together. -/
def FramePermission (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores) (output : Kind) (frame : HostTimeoutFrames.NativeFrame) : Prop :=
  ∃ input, CodeAt state input frame.current ∧
    Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack ∧
    (At context.entered state → frame.interruptible = true → input.grade ≤ 1) ∧ frame.deferredInterrupt = false

/-- Finished returns retain their actual outer exit; running returns retain one protected current input. -/
def StepPermission (context : HostTimeoutNumberConfiguration.CountContext) (view : HostTimeoutFlow.View) (state : Stores) (output : Kind) :
    FrameStep EffName EffThunk Val Err Defect FiberId Ann → Prop
  | .running frame => FramePermission context state output frame
  | .finished exit => AnswerFlow.ExitAt (model view) state output exit

/-- A hook raises a masked fiber's flag only at the actual restoring-mask instruction. -/
theorem ensure_raises (head : NCode) (scratch : HostTimeoutFrames.NativeFrame)
    (before : scratch.interruptible = false)
    (after : (head.ensure scratch).1.interruptible = true) :
    head = .setInterruptible true := by
  fun_cases Prim.ensure head scratch <;>
    aesop (add norm simp [Prim.ensure]) (rule_sets := [Effect4.CodeClosure])

/-- Actual selected hooks preserve the early-class permission required by finalizer custody. -/
theorem ensure_permitted (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input middle output : Kind) (head : NCode) (rest : List NCode)
    (scratch : HostTimeoutFrames.NativeFrame)
    (heap : At context.entered state)
    (edge : HostTimeoutNumberUniform.Edge state input middle head)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output rest)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (permitted : (∃ value, ValueAt state input value) ∨ ∃ cause, CauseAt state input cause)
    (authority : scratch.interruptible = true → input.grade ≤ 1)
    (unmasked : (head.ensure scratch).1.interruptible = true) : middle.grade ≤ 1 := by
  have anchors := HostTimeoutNumberUniform.anchors state input output (head :: rest) (.cons edge path)
  have early : input.grade ≤ 1 := by
    cases flag : scratch.interruptible with
    | true => exact authority flag
    | false =>
      have actual := ensure_raises head scratch flag unmasked
      have restorable := edge.restores actual
      by_cases low : input.grade ≤ 1
      · exact low
      · have high : 1 < input.grade := by omega
        exact False.elim (HostTimeoutNumberMaskPermission.restoring_late_ne_entered context state input
          (anchors.1.trans owner) (anchors.2 valid) restorable high permitted heap)
  by_cases low : middle.grade ≤ 1
  · exact low
  · have high : 1 < middle.grade := by omega
    obtain ⟨body, point, actual⟩ := edge.crossing early high
    rw [actual, Effect4.Machine.ProtectedFinalizer.ensure_masked] at unmasked
    cases unmasked

/-- Draining the actual pushed restoring mask retains the same early-class authority. -/
theorem drain_permitted (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input middle output : Kind) (head : NCode) (rest : List NCode)
    (scratch : HostTimeoutFrames.NativeFrame) (demand : Effect4.Arm) (skip : Bool)
    (heap : At context.entered state)
    (edge : HostTimeoutNumberUniform.Edge state input middle head)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output rest)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (empty : scratch.stack = [])
    (permitted : (∃ value, ValueAt state input value) ∨ ∃ cause, CauseAt state input cause)
    (nextPermitted : (∃ value, ValueAt state middle value) ∨ ∃ cause, CauseAt state middle cause)
    (authority : scratch.interruptible = true → input.grade ≤ 1)
    (unmasked : (FrameFiber.passPushed demand skip (head.ensure scratch).1).fiber.interruptible = true) :
    middle.grade ≤ 1 := by
  rcases FrameFiber.ensure_stack_cases head scratch with kept | ⟨pushed, _, _⟩
  · rw [FrameFiber.passPushed_nil demand skip _ (kept.trans empty)] at unmasked
    exact ensure_permitted context state input middle output head rest scratch heap edge path owner valid
      permitted authority unmasked
  · have anchors := HostTimeoutNumberUniform.anchors state middle output rest path
    by_cases low : middle.grade ≤ 1
    · exact low
    · have high : 1 < middle.grade := by omega
      exact False.elim (HostTimeoutNumberMaskPermission.restoring_late_ne_entered context state middle
        (anchors.1.trans owner) (anchors.2 valid) (edge.generated scratch pushed) high
        nextPermitted heap)

/-- A retained pre-count mask forbids an actual restoring edge from exposing an early input. -/
theorem ensure_before (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input middle output : Kind) (head : NCode) (rest : List NCode)
    (scratch : HostTimeoutFrames.NativeFrame)
    (heap : At context.before state)
    (edge : HostTimeoutNumberUniform.Edge state input middle head)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output rest)
    (owner : output.ownerCount = context.entered.count)
    (permitted : (∃ value, ValueAt state input value) ∨ ∃ cause, CauseAt state input cause)
    (authority : scratch.interruptible = true → 1 < input.grade)
    (unmasked : (head.ensure scratch).1.interruptible = true) : 1 < middle.grade := by
  have anchors := HostTimeoutNumberUniform.anchors state input output (head :: rest) (.cons edge path)
  have high : 1 < input.grade := by
    cases flag : scratch.interruptible with
    | true => exact authority flag
    | false =>
      have actual := ensure_raises head scratch flag unmasked
      by_cases early : input.grade ≤ 1
      · exact False.elim (HostTimeoutNumberBeforeMask.restoring_ne_before context state input
          (anchors.1.trans owner) early (edge.restores actual) permitted heap)
      · omega
  exact Nat.lt_of_lt_of_le high edge.ordered

/-- Draining an actual generated restoring mask retains the same pre-count authority. -/
theorem drain_before (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input middle output : Kind) (head : NCode) (rest : List NCode)
    (scratch : HostTimeoutFrames.NativeFrame) (demand : Effect4.Arm) (skip : Bool)
    (heap : At context.before state)
    (edge : HostTimeoutNumberUniform.Edge state input middle head)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output rest)
    (owner : output.ownerCount = context.entered.count)
    (empty : scratch.stack = [])
    (permitted : (∃ value, ValueAt state input value) ∨ ∃ cause, CauseAt state input cause)
    (nextPermitted : (∃ value, ValueAt state middle value) ∨ ∃ cause, CauseAt state middle cause)
    (authority : scratch.interruptible = true → 1 < input.grade)
    (unmasked : (FrameFiber.passPushed demand skip (head.ensure scratch).1).fiber.interruptible = true) :
    1 < middle.grade := by
  rcases FrameFiber.ensure_stack_cases head scratch with kept | ⟨pushed, _, _⟩
  · rw [FrameFiber.passPushed_nil demand skip _ (kept.trans empty)] at unmasked
    exact ensure_before context state input middle output head rest scratch heap edge path owner
      permitted authority unmasked
  · have anchors := HostTimeoutNumberUniform.anchors state middle output rest path
    by_cases high : 1 < middle.grade
    · exact high
    · have early : middle.grade ≤ 1 := by omega
      exact False.elim (HostTimeoutNumberBeforeMask.restoring_ne_before context state middle
        (anchors.1.trans owner) early (edge.generated scratch pushed) nextPermitted heap)

/-- Both numeric mask obligations use the same actual selected input class. -/
def Rank (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores) (input : Kind) : Prop :=
  (At context.entered state → input.grade ≤ 1) ∧ (At context.before state → 1 < input.grade)

/-- One actual value selection retains both mask obligations in the same input witness. -/
theorem selected_value_rank (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (value : Val) (selected : NCode)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : ValueAt state input value)
    (authority : frame.interruptible = true → Rank context state input)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contA false).answer = .frame selected) :
    ∃ incoming middle, ValueAt state incoming value ∧
      HostTimeoutNumberUniform.Edge state incoming middle selected ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output
        (frame.getCont .contA false).fiber.stack ∧
      ((frame.getCont .contA false).fiber.interruptible = true → Rank context state middle) := by
  exact AnswerFlow.Contextual.Hooked.getCont_value_selected_with_authority
    (model view) (HostTimeoutFlow.interpreter view).toPrimInterp HostTimeoutNumberUniform.Edge
    HostTimeoutNumberPhaseFinalizer.Allowed
    (AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
      HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed
      (HostTimeoutNumberUniform.family view))
    HostTimeoutNumberUniform.hook_mask
    (fun kind scratch => scratch.interruptible = true → Rank context state kind)
    (fun kind scratch => scratch.interruptible = true → Rank context state kind)
    state input output frame value selected
    (by
      intro incoming middle head rest scratch before after edge tail empty good nextGood early passed drained unmasked
      rw [FrameFiber.passPushed_fiber_cause] at unmasked
      constructor
      · intro heap
        exact drain_permitted context state incoming middle output head rest scratch .contA false heap edge tail owner valid
          empty (Or.inl ⟨value, good⟩) (Or.inl ⟨value, nextGood⟩) (fun raised => (early raised).1 heap) unmasked
      · intro heap
        exact drain_before context state incoming middle output head rest scratch .contA false heap edge tail owner
          empty (Or.inl ⟨value, good⟩) (Or.inl ⟨value, nextGood⟩) (fun raised => (early raised).2 heap) unmasked)
    (by
      intro incoming middle rest scratch edge tail empty good early unmasked
      constructor
      · intro heap
        exact ensure_permitted context state incoming middle output selected rest scratch heap edge tail owner valid
          (Or.inl ⟨value, good⟩) (fun raised => (early raised).1 heap) unmasked
      · intro heap
        exact ensure_before context state incoming middle output selected rest scratch heap edge tail owner
          (Or.inl ⟨value, good⟩) (fun raised => (early raised).2 heap) unmasked)
    good authority path found

/-- The selected value callback retains its actual class and runtime mask authority together. -/
theorem selected_value_early (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (value : Val) (selected : NCode)
    (heap : At context.entered state)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : ValueAt state input value)
    (authority : frame.interruptible = true → input.grade ≤ 1)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contA false).answer = .frame selected) :
    ∃ incoming middle, ValueAt state incoming value ∧
      HostTimeoutNumberUniform.Edge state incoming middle selected ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output
        (frame.getCont .contA false).fiber.stack ∧
      ((frame.getCont .contA false).fiber.interruptible = true → middle.grade ≤ 1) := by
  exact AnswerFlow.Contextual.Hooked.getCont_value_selected_with_authority
    (model view) (HostTimeoutFlow.interpreter view).toPrimInterp HostTimeoutNumberUniform.Edge
    HostTimeoutNumberPhaseFinalizer.Allowed
    (AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
      HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed
      (HostTimeoutNumberUniform.family view))
    HostTimeoutNumberUniform.hook_mask
    (fun kind scratch => scratch.interruptible = true → kind.grade ≤ 1)
    (fun kind scratch => scratch.interruptible = true → kind.grade ≤ 1)
    state input output frame value selected
    (by
      intro incoming middle head rest scratch before after edge tail empty good nextGood early passed drained unmasked
      rw [FrameFiber.passPushed_fiber_cause] at unmasked
      exact drain_permitted context state incoming middle output head rest scratch .contA false heap edge tail owner valid
        empty (Or.inl ⟨value, good⟩) (Or.inl ⟨value, nextGood⟩) early unmasked)
    (by
      intro incoming middle rest scratch edge tail empty good early unmasked
      exact ensure_permitted context state incoming middle output selected rest scratch heap edge tail owner valid
        (Or.inl ⟨value, good⟩) early unmasked)
    good authority path found

/-- The actual selected callback preserves early permission at its new current code and saved path. -/
theorem resume_value_selected_early (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (value : Val)
    (selected next : NCode) (pushed : List NCode) (provided : Option ExitV)
    (heap : At context.entered state)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : ValueAt state input value)
    (authority : frame.interruptible = true → input.grade ≤ 1)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contA false).answer = .frame selected)
    (supplied : ∀ incoming, ValueAt state incoming value → ∀ exit ∈ provided,
      AnswerFlow.ExitAt (model view) state incoming exit)
    (pure : AnswerFlow.programOf (model view) state selected (provided.getD (.success value)) = none)
    (evaluated : selected.armA (HostTimeoutFlow.interpreter view).toPrimInterp value provided = some (next, pushed)) :
    ∃ events current,
      frame.resumeValue (HostTimeoutFlow.interpreter view).toPrimInterp value provided =
        (.running {(frame.getCont .contA false).fiber with
          current := next
          stack := pushed ++ (frame.getCont .contA false).fiber.stack}, events) ∧
      CodeAt state current next ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) current output
        (pushed ++ (frame.getCont .contA false).fiber.stack) ∧
      ((frame.getCont .contA false).fiber.interruptible = true → current.grade ≤ 1) := by
  obtain ⟨incoming, middle, incomingGood, callback, suffix, early⟩ :=
    selected_value_early view context state input output frame value selected heap owner valid good authority path found
  have family := AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
    HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed (HostTimeoutNumberUniform.family view)
  obtain ⟨current, code, callbackPath⟩ := family.answer state incoming middle selected callback state
    ((model view).future_refl state) value provided next pushed incomingGood
    (supplied incoming incomingGood) pure evaluated
  have order : current.grade ≤ middle.grade := Effect4.Contracts.Path.endpoints
    (fun first last : Kind => first.grade ≤ last.grade) (fun _ => Nat.le_refl _)
    (fun _ _ _ first second => Nat.le_trans first second)
    (fun _ _ _ edge => edge.ordered) callbackPath
  exact ⟨_, current, FrameFiber.resumeValue_frame (HostTimeoutFlow.interpreter view).toPrimInterp
    frame value provided selected next pushed found evaluated, code,
    Effect4.Contracts.Path.append callbackPath suffix, fun unmasked => Nat.le_trans order (early unmasked)⟩

/-- The actual value callback carries both mask obligations through its real pushed suffix. -/
theorem resume_value_selected_rank (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (value : Val)
    (selected next : NCode) (pushed : List NCode) (provided : Option ExitV)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : ValueAt state input value)
    (authority : frame.interruptible = true → Rank context state input)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contA false).answer = .frame selected)
    (supplied : ∀ incoming, ValueAt state incoming value → ∀ exit ∈ provided,
      AnswerFlow.ExitAt (model view) state incoming exit)
    (pure : AnswerFlow.programOf (model view) state selected (provided.getD (.success value)) = none)
    (evaluated : selected.armA (HostTimeoutFlow.interpreter view).toPrimInterp value provided = some (next, pushed)) :
    ∃ events current,
      frame.resumeValue (HostTimeoutFlow.interpreter view).toPrimInterp value provided =
        (.running {(frame.getCont .contA false).fiber with
          current := next
          stack := pushed ++ (frame.getCont .contA false).fiber.stack}, events) ∧
      CodeAt state current next ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) current output
        (pushed ++ (frame.getCont .contA false).fiber.stack) ∧
      ((frame.getCont .contA false).fiber.interruptible = true → Rank context state current) := by
  obtain ⟨incoming, middle, incomingGood, callback, suffix, early⟩ :=
    selected_value_rank view context state input output frame value selected owner valid good authority path found
  have family := AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
    HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed (HostTimeoutNumberUniform.family view)
  obtain ⟨current, code, callbackPath⟩ := family.answer state incoming middle selected callback state
    ((model view).future_refl state) value provided next pushed incomingGood
    (supplied incoming incomingGood) pure evaluated
  have order : current.grade ≤ middle.grade := Effect4.Contracts.Path.endpoints
    (fun first last : Kind => first.grade ≤ last.grade) (fun _ => Nat.le_refl _)
    (fun _ _ _ first second => Nat.le_trans first second)
    (fun _ _ _ edge => edge.ordered) callbackPath
  refine ⟨_, current, FrameFiber.resumeValue_frame (HostTimeoutFlow.interpreter view).toPrimInterp
    frame value provided selected next pushed found evaluated, code,
    Effect4.Contracts.Path.append callbackPath suffix, ?_⟩
  intro unmasked
  constructor
  · intro heap
    exact Nat.le_trans order ((early unmasked).1 heap)
  · intro heap
    exact HostTimeoutNumberBeforeMask.value_callback_high (HostTimeoutFlow.interpreter view).toPrimInterp
      state selected next value provided pushed current middle evaluated callbackPath ((early unmasked).2 heap)

/-- One actual failure selection retains both mask obligations with its carried cause. -/
theorem selected_cause_rank (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (cause : CauseV) (selected : NCode)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : CauseAt state input cause)
    (recorded : HostTimeoutNumberPhaseFinalizer.Allowed state frame.interruptedCause)
    (authority : frame.interruptible = true → Rank context state input)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contE true (some cause)).answer = .frame selected) :
    ∃ incoming middle delivered,
      (frame.getCont .contE true (some cause)).carriedCause = some delivered ∧
      CauseAt state incoming delivered ∧ HostTimeoutNumberUniform.Edge state incoming middle selected ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output
        (frame.getCont .contE true (some cause)).fiber.stack ∧
      ((frame.getCont .contE true (some cause)).fiber.interruptible = true → Rank context state middle) := by
  exact AnswerFlow.Contextual.Hooked.getCont_cause_selected_with_authority (admitted := recorded)
    (model view) (HostTimeoutFlow.interpreter view).toPrimInterp HostTimeoutNumberUniform.Edge
    HostTimeoutNumberPhaseFinalizer.Allowed
    (AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
      HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed
      (HostTimeoutNumberUniform.family view))
    HostTimeoutNumberUniform.hook_mask
    (fun kind scratch => scratch.interruptible = true → Rank context state kind)
    (fun kind scratch => scratch.interruptible = true → Rank context state kind)
    state input output frame cause selected
    (by
      intro incoming middle head rest scratch before after edge tail empty good nextGood early passed drained unmasked
      rw [FrameFiber.passPushed_fiber_cause] at unmasked
      constructor
      · intro heap
        exact drain_permitted context state incoming middle output head rest scratch .contE true heap edge tail owner valid
          empty (Or.inr good) (Or.inr nextGood) (fun raised => (early raised).1 heap) unmasked
      · intro heap
        exact drain_before context state incoming middle output head rest scratch .contE true heap edge tail owner
          empty (Or.inr good) (Or.inr nextGood) (fun raised => (early raised).2 heap) unmasked)
    (by
      intro incoming middle rest scratch edge tail empty good early unmasked
      constructor
      · intro heap
        exact ensure_permitted context state incoming middle output selected rest scratch heap edge tail owner valid
          (Or.inr good) (fun raised => (early raised).1 heap) unmasked
      · intro heap
        exact ensure_before context state incoming middle output selected rest scratch heap edge tail owner
          (Or.inr good) (fun raised => (early raised).2 heap) unmasked)
    good (HostTimeoutNumberPhaseFinalizer.absorbs view state frame recorded) authority path found

/-- The selected failure callback retains its actual carried cause, class, and mask authority together. -/
theorem selected_cause_early (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (cause : CauseV) (selected : NCode)
    (heap : At context.entered state)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : CauseAt state input cause)
    (recorded : HostTimeoutNumberPhaseFinalizer.Allowed state frame.interruptedCause)
    (authority : frame.interruptible = true → input.grade ≤ 1)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contE true (some cause)).answer = .frame selected) :
    ∃ incoming middle delivered,
      (frame.getCont .contE true (some cause)).carriedCause = some delivered ∧
      CauseAt state incoming delivered ∧ HostTimeoutNumberUniform.Edge state incoming middle selected ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) middle output
        (frame.getCont .contE true (some cause)).fiber.stack ∧
      ((frame.getCont .contE true (some cause)).fiber.interruptible = true → middle.grade ≤ 1) := by
  exact AnswerFlow.Contextual.Hooked.getCont_cause_selected_with_authority (admitted := recorded)
    (model view) (HostTimeoutFlow.interpreter view).toPrimInterp HostTimeoutNumberUniform.Edge
    HostTimeoutNumberPhaseFinalizer.Allowed
    (AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
      HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed
      (HostTimeoutNumberUniform.family view))
    HostTimeoutNumberUniform.hook_mask
    (fun kind scratch => scratch.interruptible = true → kind.grade ≤ 1)
    (fun kind scratch => scratch.interruptible = true → kind.grade ≤ 1)
    state input output frame cause selected
    (by
      intro incoming middle head rest scratch before after edge tail empty good nextGood early passed drained unmasked
      rw [FrameFiber.passPushed_fiber_cause] at unmasked
      exact drain_permitted context state incoming middle output head rest scratch .contE true heap edge tail owner valid
        empty (Or.inr good) (Or.inr nextGood) early unmasked)
    (by
      intro incoming middle rest scratch edge tail empty good early unmasked
      exact ensure_permitted context state incoming middle output selected rest scratch heap edge tail owner valid
        (Or.inr good) early unmasked)
    good (HostTimeoutNumberPhaseFinalizer.absorbs view state frame recorded) authority path found

/-- The actual failure callback carries both mask obligations at the same selected input. -/
theorem resume_cause_selected_rank (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (cause : CauseV)
    (selected next : NCode) (pushed : List NCode) (provided : Option ExitV)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : CauseAt state input cause)
    (recorded : HostTimeoutNumberPhaseFinalizer.Allowed state frame.interruptedCause)
    (authority : frame.interruptible = true → Rank context state input)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contE true (some cause)).answer = .frame selected)
    (supplied : ∀ incoming delivered,
      (frame.getCont .contE true (some cause)).carriedCause = some delivered →
      CauseAt state incoming delivered →
      ∀ exit ∈ provided.map (frame.getCont .contE true (some cause)).deliveredExit,
        AnswerFlow.ExitAt (model view) state incoming exit)
    (pure : ∀ delivered,
      (frame.getCont .contE true (some cause)).carriedCause = some delivered →
      AnswerFlow.programOf (model view) state selected
        ((provided.map (frame.getCont .contE true (some cause)).deliveredExit).getD (.failure delivered)) = none)
    (evaluated : selected.armE (HostTimeoutFlow.interpreter view).toPrimInterp
      ((frame.getCont .contE true (some cause)).carriedCause.getD cause)
      (provided.map (frame.getCont .contE true (some cause)).deliveredExit) = some (next, pushed)) :
    ∃ events current,
      frame.resumeCause (HostTimeoutFlow.interpreter view).toPrimInterp cause provided =
        (.running {(frame.getCont .contE true (some cause)).fiber with
          current := next
          stack := pushed ++ (frame.getCont .contE true (some cause)).fiber.stack}, events) ∧
      CodeAt state current next ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) current output
        (pushed ++ (frame.getCont .contE true (some cause)).fiber.stack) ∧
      ((frame.getCont .contE true (some cause)).fiber.interruptible = true → Rank context state current) := by
  obtain ⟨incoming, middle, delivered, carried, incomingGood, callback, suffix, early⟩ :=
    selected_cause_rank view context state input output frame cause selected owner valid good recorded authority path found
  have equation := FrameFiber.resumeCause_frame (HostTimeoutFlow.interpreter view).toPrimInterp
    frame cause provided selected next pushed found evaluated
  simp only [carried, Option.getD_some] at evaluated
  have family := AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
    HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed (HostTimeoutNumberUniform.family view)
  obtain ⟨current, code, callbackPath⟩ := family.cause state incoming middle selected callback state
    ((model view).future_refl state) delivered _ next pushed incomingGood
    (supplied incoming delivered carried incomingGood) (pure delivered carried) evaluated
  have order : current.grade ≤ middle.grade := Effect4.Contracts.Path.endpoints
    (fun first last : Kind => first.grade ≤ last.grade) (fun _ => Nat.le_refl _)
    (fun _ _ _ first second => Nat.le_trans first second)
    (fun _ _ _ edge => edge.ordered) callbackPath
  refine ⟨_, current, equation, code, Effect4.Contracts.Path.append callbackPath suffix, ?_⟩
  intro unmasked
  constructor
  · intro heap
    exact Nat.le_trans order ((early unmasked).1 heap)
  · intro heap
    have empty := FrameFiber.armE_pushes_nothing (HostTimeoutFlow.interpreter view).toPrimInterp
      selected delivered _ next pushed evaluated
    have same : current = middle := by
      rw [empty] at callbackPath
      cases callbackPath
      rfl
    rw [same]
    exact (early unmasked).2 heap

/-- The actual failure callback retains its new current class and runtime mask permission. -/
theorem resume_cause_selected_early (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (input output : Kind) (frame : HostTimeoutFrames.NativeFrame) (cause : CauseV)
    (selected next : NCode) (pushed : List NCode) (provided : Option ExitV)
    (heap : At context.entered state)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (good : CauseAt state input cause)
    (recorded : HostTimeoutNumberPhaseFinalizer.Allowed state frame.interruptedCause)
    (authority : frame.interruptible = true → input.grade ≤ 1)
    (path : Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack)
    (found : (frame.getCont .contE true (some cause)).answer = .frame selected)
    (supplied : ∀ incoming delivered,
      (frame.getCont .contE true (some cause)).carriedCause = some delivered →
      CauseAt state incoming delivered →
      ∀ exit ∈ provided.map (frame.getCont .contE true (some cause)).deliveredExit,
        AnswerFlow.ExitAt (model view) state incoming exit)
    (pure : ∀ delivered,
      (frame.getCont .contE true (some cause)).carriedCause = some delivered →
      AnswerFlow.programOf (model view) state selected
        ((provided.map (frame.getCont .contE true (some cause)).deliveredExit).getD (.failure delivered)) = none)
    (evaluated : selected.armE (HostTimeoutFlow.interpreter view).toPrimInterp
      ((frame.getCont .contE true (some cause)).carriedCause.getD cause)
      (provided.map (frame.getCont .contE true (some cause)).deliveredExit) = some (next, pushed)) :
    ∃ events current,
      frame.resumeCause (HostTimeoutFlow.interpreter view).toPrimInterp cause provided =
        (.running {(frame.getCont .contE true (some cause)).fiber with
          current := next
          stack := pushed ++ (frame.getCont .contE true (some cause)).fiber.stack}, events) ∧
      CodeAt state current next ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) current output
        (pushed ++ (frame.getCont .contE true (some cause)).fiber.stack) ∧
      ((frame.getCont .contE true (some cause)).fiber.interruptible = true → current.grade ≤ 1) := by
  obtain ⟨incoming, middle, delivered, carried, incomingGood, callback, suffix, early⟩ :=
    selected_cause_early view context state input output frame cause selected heap owner valid good recorded authority path found
  have equation := FrameFiber.resumeCause_frame (HostTimeoutFlow.interpreter view).toPrimInterp
    frame cause provided selected next pushed found evaluated
  simp only [carried, Option.getD_some] at evaluated
  have family := AnswerFlow.SavedFamily.contextual (model view) (HostTimeoutFlow.interpreter view).toPrimInterp
    HostTimeoutNumberUniform.Edge HostTimeoutNumberPhaseFinalizer.Allowed (HostTimeoutNumberUniform.family view)
  obtain ⟨current, code, callbackPath⟩ := family.cause state incoming middle selected callback state
    ((model view).future_refl state) delivered _ next pushed incomingGood
    (supplied incoming delivered carried incomingGood) (pure delivered carried) evaluated
  have order : current.grade ≤ middle.grade := Effect4.Contracts.Path.endpoints
    (fun first last : Kind => first.grade ≤ last.grade) (fun _ => Nat.le_refl _)
    (fun _ _ _ first second => Nat.le_trans first second)
    (fun _ _ _ edge => edge.ordered) callbackPath
  exact ⟨_, current, equation, code, Effect4.Contracts.Path.append callbackPath suffix,
    fun unmasked => Nat.le_trans order (early unmasked)⟩

/-- An actual failure permission at the unclean entered heap belongs to an early numeric class. -/
theorem cause_early (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (kind : Kind) (cause : CauseV) (heap : At context.entered state)
    (owner : kind.ownerCount = context.entered.count) (valid : kind.Valid)
    (good : CauseAt state kind cause) : kind.grade ≤ 1 := by
  induction kind with
  | fresh phase => dsimp only [Kind.grade]; decide
  | countUnit phase => dsimp only [Kind.grade]; decide
  | before phase => dsimp only [Kind.grade]; decide
  | read phase => exact False.elim good
  | unit phase => exact False.elim good
  | paused phase incoming ih => exact ih owner valid good
  | published phase => exact False.elim valid
  | attempt prior entered own =>
    exact False.elim (HostTimeoutNumberMaskPermission.restoring_late_ne_entered context state _ owner valid
      (by trivial) (by dsimp only [Kind.grade]; decide) (Or.inr ⟨cause, good⟩) heap)
  | cleanupExit phase own =>
    exact False.elim (HostTimeoutNumberMaskPermission.restoring_late_ne_entered context state _ owner valid
      (by trivial) (by dsimp only [Kind.grade]; decide) (Or.inr ⟨cause, good⟩) heap)

/-- The existing semantic head producer supplies early authority for an actual replacement failure. -/
theorem failure_frame_early (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (output : Kind) (frame : HostTimeoutFrames.NativeFrame) (cause : CauseV)
    (heap : At context.entered state)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (held : HostTimeoutNumberUniform.FrameAt state output {frame with current := .failure cause}) :
    ∃ input, CodeAt state input (.failure cause) ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack ∧ input.grade ≤ 1 := by
  obtain ⟨input, code, path⟩ := held
  have anchors := HostTimeoutNumberUniform.anchors state input output frame.stack path
  have head := HostTimeoutNumberUniform.head view state input (.failure cause) code
    (by intro thunk impossible; cases impossible) (by intro thunk impossible; cases impossible)
  cases head with
  | failure actual permitted =>
    exact ⟨input, code, path, cause_early context state input cause heap
      (anchors.1.trans owner) (anchors.2 valid) permitted⟩

/-- An actual replacement failure retains both heap-relative mask obligations at one input. -/
theorem failure_frame_rank (view : HostTimeoutFlow.View)
    (context : HostTimeoutNumberConfiguration.CountContext) (state : Stores)
    (output : Kind) (frame : HostTimeoutFrames.NativeFrame) (cause : CauseV)
    (owner : output.ownerCount = context.entered.count) (valid : output.Valid)
    (held : HostTimeoutNumberUniform.FrameAt state output {frame with current := .failure cause}) :
    ∃ input, CodeAt state input (.failure cause) ∧
      Effect4.Contracts.Path (HostTimeoutNumberUniform.Edge state) input output frame.stack ∧ Rank context state input := by
  obtain ⟨input, code, path⟩ := held
  have anchors := HostTimeoutNumberUniform.anchors state input output frame.stack path
  have head := HostTimeoutNumberUniform.head view state input (.failure cause) code
    (by intro thunk impossible; cases impossible) (by intro thunk impossible; cases impossible)
  cases head with
  | failure actual permitted =>
    refine ⟨input, code, path, ?_, ?_⟩
    · intro heap
      exact cause_early context state input cause heap (anchors.1.trans owner) (anchors.2 valid) permitted
    · intro heap
      exact HostTimeoutNumberBeforeMask.cause_high context state input cause (anchors.1.trans owner) permitted heap

end Test.Dogfood.Proofs.HostTimeoutNumberPopAuthority

#!/bin/bash
set -e
lake build Effect4.Laws.Machine.Lift Effect4.Laws.Machine.LiftCoupledFact
lake env lean scratch/LiftLoopAudit.lean

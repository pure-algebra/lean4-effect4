import Effect4.Laws.Program.PlaceFunding.Commands
import Effect4.Laws.Program.Footprint
import Effect4.Laws.Program.Interference
import Effect4.Laws.Machine.Handshake
import Effect4.Laws.Machine.Lift
import Effect4.Laws.Machine.Clauses

/-!
Concept: reactive-scheduling R9 and scope-lifetime-finalization R11.
Question: Timeout's fixed command budget bounds the actual charged count prefix.
Consumer: the pending numeric command producer of cleanup_keeps and retries_declared.
One per-owner ledger reads operation growth above an explicit baseline.
The existing place-funding command producer supplies the command census.
This relative bound supplies no source assignment, queue admission, or complete history by itself.
-/
set_option autoImplicit false
namespace Effect4.Program.OperationBudget
open Effect4 Effect4.Machine Effect4.Program
open Effect4.Program.Moves
open Effect4.Machine.ForkLedger.Invariant

/-- Only the selected owner's operations above its explicit entry baseline carry weight. -/
def weight (owner : FiberId) (baseline : Nat) (fiber : NFiber) : Nat :=
  if fiber.id = owner then fiber.currentOpCount - baseline else 0

/-- Operation credit uses the existing place ledger with every other place read as zero. -/
def ledger (owner : FiberId) (baseline : Nat) : PlaceFunding.Ledger where
  fiber := weight owner baseline
  race := fun _ => 0
  state := fun _ => 0
  command := fun _ => 0
  task := fun _ => 0
  consumed := fun _ => 0
  produced := fun _ => 0

/-- Omitting the selected owner leaves no operation weight. -/
theorem outside_zero (owner : FiberId) (baseline : Nat) (machine : NativeMachine) :
    FiberSum.outside (weight owner baseline) owner machine = 0 := by
  unfold FiberSum.outside
  have same : machine.fibers.map (ControlWeights.omitted RunFiber.id (weight owner baseline) owner) =
      machine.fibers.map (fun _ => 0) := by
    apply List.map_congr_left
    intro fiber member
    by_cases actual : fiber.id = owner
    · simp only [ControlWeights.omitted, actual, ↓reduceIte]
    · simp only [ControlWeights.omitted, weight, actual, ↓reduceIte]
  rw [same, PlaceLedger.zero_sum]

/-- A stored selected owner accounts for the entire operation weight. -/
theorem total_found (owner : FiberId) (baseline : Nat) (machine : NativeMachine) (fiber : NFiber)
    (unique : (machine.fibers.map (·.id)).Nodup) (found : machine.fiber? owner = some fiber) :
    FiberSum.total (weight owner baseline) machine = fiber.currentOpCount - baseline := by
  have key := RunMachine.id_of_fiber? found
  have split := FiberSum.split (weight owner baseline) machine fiber unique (RunMachine.mem_of_fiber? found)
  rw [key, outside_zero] at split
  simpa only [weight, key, ↓reduceIte, Nat.zero_add] using split.symm

/-- A missing selected owner contributes no operation weight. -/
theorem total_missing (owner : FiberId) (baseline : Nat) (machine : NativeMachine)
    (found : machine.fiber? owner = none) : FiberSum.total (weight owner baseline) machine = 0 := by
  have same : machine.fibers.map (weight owner baseline) = machine.fibers.map (fun _ => 0) := by
    apply List.map_congr_left
    intro fiber member
    have absent := List.find?_eq_none.mp found fiber member
    have different : fiber.id ≠ owner := fun equal => absent (decide_eq_true equal)
    simp only [weight, different, ↓reduceIte]
  change (machine.fibers.map (weight owner baseline)).sum = 0
  rw [same, PlaceLedger.zero_sum]

/-- Existing environment interference never increases the selected operation count. -/
theorem interference (owner : FiberId) (baseline : Nat) (before after : NativeMachine)
    (oldUnique : (before.fibers.map (·.id)).Nodup) (newUnique : (after.fibers.map (·.id)).Nodup)
    (changes : Moves.Interferes before after) :
    FiberSum.total (weight owner baseline) after ≤ FiberSum.total (weight owner baseline) before := by
  cases found : after.fiber? owner with
  | none => rw [total_missing owner baseline after found]; exact Nat.zero_le _
  | some fiber =>
    rw [total_found owner baseline after fiber newUnique found]
    rcases changes.fibers fiber (RunMachine.mem_of_fiber? found) with ⟨old, member, word⟩ |
        ⟨fresh, program, flag, budget, context, word⟩
    · have key : old.id = owner := word.id.symm.trans (RunMachine.id_of_fiber? found)
      have lookup := Effect4.Machine.fiber_lookup_of_mem_nodup before oldUnique old member
      rw [key] at lookup
      rw [total_found owner baseline before old oldUnique lookup, word.currentOpCount]
      exact Nat.le_refl _
    · have zero := word.currentOpCount
      change fiber.currentOpCount = 0 at zero
      rw [zero, Nat.zero_sub]
      exact Nat.zero_le _

/-- The zero places identify the original ledger's funding with this operation sum. -/
theorem funded (owner : FiberId) (baseline cap : Nat) (machine : NativeMachine) :
    (ledger owner baseline).Funded cap machine [] [] ↔
      FiberSum.total (weight owner baseline) machine ≤ cap := by
  simp only [PlaceLedger.Funded, PlaceLedger.spent, PlaceLedger.held, PlaceLedger.issued,
    ledger, PlaceLedger.zero_sum, List.map_nil, List.sum_nil, Nat.zero_add, Nat.add_zero]

/-- Native owner installation charges only the supplied actual operation increment. -/
theorem installed (owner : FiberId) (baseline allowance : Nat) (before : NativeMachine)
    (fiber : NFiber) (result : Moves.NIteration)
    (oldUnique : (before.fibers.map (·.id)).Nodup)
    (newUnique : (result.machine.fibers.map (·.id)).Nodup)
    (found : before.fiber? fiber.id = some fiber)
    (changes : Moves.Interferes before result.machine)
    (key : result.fiber.id = fiber.id)
    (count : result.fiber.currentOpCount ≤ fiber.currentOpCount + allowance) :
    FiberSum.total (weight owner baseline) (result.machine.update result.fiber) ≤
      FiberSum.total (weight owner baseline) before + allowance := by
  by_cases same : fiber.id = owner
  · have bounded := FiberSum.install_le (weight owner baseline) result.machine owner result.fiber
      (key.trans same) newUnique
    rw [outside_zero] at bounded
    have lookup : before.fiber? owner = some fiber := same ▸ found
    rw [total_found owner baseline before fiber oldUnique lookup]
    simp only [weight, key, same, ↓reduceIte, Nat.zero_add] at bounded
    omega
  · have bounded := FiberSum.update_bound (weight owner baseline) result.machine result.fiber newUnique
    have lighter := interference owner baseline before result.machine oldUnique newUnique changes
    have other : result.fiber.id ≠ owner := fun equal => same (key.symm.trans equal)
    simp only [weight, other, ↓reduceIte, Nat.add_zero] at bounded
    omega

/-- Every fixed administrative update satisfies the existing operation ledger contract. -/
theorem control (owner : FiberId) (baseline : Nat) : PlaceFunding.Control (ledger owner baseline) (fun _ => True) where
  metadata old next key active saved count := by
    change weight owner baseline next ≤ weight owner baseline old
    simp only [weight, key]
    split
    · exact Nat.sub_le_sub_right count baseline
    · exact Nat.le_refl _
  interruption cause fiber := by
    have stable := (Moves.OtherEdit.interruptCause fiber cause).currentOpCount
    have key := (Moves.OtherEdit.interruptCause fiber cause).id
    change weight owner baseline (interruptWithCause cause fiber).1 ≤ weight owner baseline fiber
    simp only [weight, key, stable, Nat.le_refl]
  replace fiber code permission := Nat.le_refl _
  entry id code flag budget context permission := by
    change (if id = owner then 0 - baseline else 0) = 0
    simp only [Nat.zero_sub, ite_self]
  clear fiber := Nat.le_refl _

/-- No other ledger place or event contributes to operation growth. -/
theorem quiet (owner : FiberId) (baseline : Nat) : PlaceFunding.NoQueue (ledger owner baseline) :=
  ⟨fun _ => rfl, fun _ => rfl, fun _ => rfl⟩

theorem events (owner : FiberId) (baseline : Nat) : PlaceFunding.Events (ledger owner baseline) :=
  ⟨fun _ _ => Nat.le_refl _⟩

theorem stores (owner : FiberId) (baseline : Nat) (interp : Moves.NInterp) :
    PlaceFunding.StoreHooks (ledger owner baseline) interp :=
  ⟨by intros; exact Nat.le_refl _, by intros; exact Nat.le_refl _,
    by intros; exact Nat.le_refl _, by intros; exact Nat.le_refl _⟩

theorem administration (owner : FiberId) (baseline : Nat) (interp : Moves.NInterp) :
    PlaceFunding.Administration (ledger owner baseline) (fun _ => True) interp :=
  ⟨by intros; trivial, by intros; trivial, by intros; trivial, by intros; trivial,
    by intros; exact Nat.le_refl _, by intros; exact Nat.le_refl _⟩

/-- Native evaluation keeps the counter; the actual loop charges exactly one operation. -/
theorem evaluation (owner : FiberId) (baseline : Nat) (root : NativeEff) (table : RowTable) :
    PlaceFunding.Evaluation (ledger owner baseline) (fun _ => True) root table (fun _ _ _ => 1) where
  native machine fiber yielding ok permission found := by
    have bounded := installed owner baseline 0 machine fiber (evaluateNative root machine fiber yielding table)
      ok.idsUnique (Native.evaluateNative_ok root table machine fiber yielding ok).idsUnique found
      (Moves.evaluateNative_interferes root table machine fiber yielding)
      (Moves.evaluateNative_footprint root table machine fiber yielding).id
      (by simpa only [Nat.add_zero] using
        Nat.le_of_eq (Moves.evaluateNative_evaluationFootprint root table machine fiber yielding).counter)
    simpa only [PlaceLedger.Balanced, PlaceLedger.spent, PlaceLedger.held, PlaceLedger.issued,
      ledger, PlaceLedger.zero_sum, List.map_nil, List.sum_nil, Nat.zero_add, Nat.add_zero] using bounded
  iteration machine fiber yielding ok permission found := by
    letI := evaluatorFor root table
    have bounded := installed owner baseline 1 machine fiber (Machine.iteration (interpOf root table) machine fiber yielding)
      ok.idsUnique (Native.iteration_ok root table machine fiber yielding ok).idsUnique found
      (Moves.iteration_interferes root table (interpOf root table) machine fiber yielding)
      (Moves.iteration_footprint root table (interpOf root table) machine fiber yielding).id
      (Nat.le_of_eq (Moves.iteration_currentOpCount root table (interpOf root table) machine fiber yielding))
    simpa only [PlaceLedger.Charged, PlaceLedger.spent, PlaceLedger.held, PlaceLedger.issued,
      ledger, PlaceLedger.zero_sum, List.map_nil, List.sum_nil, Nat.zero_add, Nat.add_zero] using bounded

/-- The existing command producer charges the selected operation ledger only for a loop command. -/
theorem command (owner : FiberId) (baseline cap : Nat) (root : NativeEff) (table : RowTable)
    (machine : NativeMachine) (head : Native.NCmd) (rest : List Native.NCmd)
    (ok : Ok machine) (held : FiberSum.total (weight owner baseline) machine ≤ cap) :
    letI := evaluatorFor root table
    FiberSum.total (weight owner baseline) (driveStep (interpOf root table) machine head rest).1 ≤
      cap + PlaceFunding.commandAllowance (fun _ _ _ => 1) machine head := by
  letI := evaluatorFor root table
  exact (funded owner baseline _ _).mp
    (PlaceFunding.command_funded root table (control owner baseline) (quiet owner baseline) (events owner baseline)
      (stores owner baseline (interpOf root table)) (administration owner baseline (interpOf root table))
      (fun _ => True) (fun _ _ _ => 1) (evaluation owner baseline root table)
      machine head rest ok True.intro ⟨by intros; trivial, by intros; trivial⟩
      ((funded owner baseline cap machine).mpr held))

/-- The existing remaining-fuel fold bounds operation growth by consumed driver commands. -/
theorem drive (owner : FiberId) (baseline cap fuel : Nat) (root : NativeEff) (table : RowTable)
    (machine : NativeMachine) (commands : List Native.NCmd)
    (ok : Ok machine) (held : FiberSum.total (weight owner baseline) machine ≤ cap) :
    letI := evaluatorFor root table
    Ok (driveState (interpOf root table) fuel machine commands).1 ∧
      FiberSum.total (weight owner baseline) (driveState (interpOf root table) fuel machine commands).1 ≤ cap + fuel := by
  letI := evaluatorFor root table
  let I := fun remaining (_ : Unit) (next : NativeMachine) (_ : List Native.NCmd) =>
    Ok next ∧ FiberSum.total (weight owner baseline) next + remaining ≤ cap + fuel
  have step : Lift.FuelStepKeeps Lift.unitOrder (interpOf root table) I := by
    intro remaining world before head rest active prior
    have bounded := command owner baseline (FiberSum.total (weight owner baseline) before)
      root table before head rest prior.1 (Nat.le_refl _)
    have charge : PlaceFunding.commandAllowance (fun _ _ _ => 1) before head ≤ 1 := by
      unfold PlaceFunding.commandAllowance
      split <;> decide
    refine ⟨(), True.intro, Native.driveStep_ok root table before head rest prior.1, ?_⟩
    dsimp only [I] at prior ⊢
    omega
  obtain ⟨world, moved, result⟩ := Lift.driveState_lift_fuel Lift.unitOrder (interpOf root table) I
    (by intro remaining world next pending prior; exact ⟨prior.1, by dsimp only [I] at prior ⊢; omega⟩)
    step fuel () machine commands ⟨ok, by omega⟩
  exact ⟨result.1, by dsimp only [I] at result; omega⟩

/-- A previously absent actor starts at zero and cannot exceed the command budget. -/
theorem fresh_count (owner : FiberId) (fuel : Nat) (root : NativeEff) (table : RowTable)
    (machine : NativeMachine) (commands : List Native.NCmd) (fiber : NFiber)
    (ok : Ok machine) (absent : machine.fiber? owner = none)
    (found :
      letI := evaluatorFor root table
      (driveState (interpOf root table) fuel machine commands).1.fiber? owner = some fiber) :
    fiber.currentOpCount ≤ fuel := by
  letI := evaluatorFor root table
  have held := drive owner 0 0 fuel root table machine commands ok
    (Nat.le_of_eq (total_missing owner 0 machine absent))
  rw [total_found owner 0 _ fiber held.1.idsUnique found] at held
  simpa only [Nat.sub_zero, Nat.zero_add] using held.2

/-- A reset actor satisfies the same fixed-budget bound as an actually fresh actor. -/
theorem zero_count (owner : FiberId) (fuel : Nat) (root : NativeEff) (table : RowTable)
    (machine : NativeMachine) (commands : List Native.NCmd) (initial fiber : NFiber)
    (ok : Ok machine) (start : machine.fiber? owner = some initial) (zero : initial.currentOpCount = 0)
    (found :
      letI := evaluatorFor root table
      (driveState (interpOf root table) fuel machine commands).1.fiber? owner = some fiber) :
    fiber.currentOpCount ≤ fuel := by
  letI := evaluatorFor root table
  have beginning : FiberSum.total (weight owner 0) machine ≤ 0 := by
    rw [total_found owner 0 machine initial ok.idsUnique start, zero, Nat.sub_zero]
    exact Nat.le_refl _
  have held := drive owner 0 0 fuel root table machine commands ok beginning
  rw [total_found owner 0 _ fiber held.1.idsUnique found] at held
  simpa only [Nat.sub_zero, Nat.zero_add] using held.2

/-- Actual evaluate resets the operation counter before its remaining command budget runs. -/
theorem evaluate_count (owner : FiberId) (fuel : Nat) (root : NativeEff) (table : RowTable)
    (machine : NativeMachine) (rest : List Native.NCmd) (initial fiber : NFiber)
    (ok : Ok machine) (active : machine.stuck = none) (start : machine.fiber? owner = some initial)
    (live : initial.exit = none) (idle : initial.running = false) (unparked : initial.parked = .notParked)
    (found :
      letI := evaluatorFor root table
      (driveState (interpOf root table) (fuel + 1) machine (.evaluate owner :: rest)).1.fiber? owner = some fiber) :
    fiber.currentOpCount ≤ fuel := by
  letI := evaluatorFor root table
  let entered : NFiber := {initial with running := true, currentOpCount := 0, parked := .notParked}
  let next : NativeMachine := (machine.update entered).emit [.started owner]
  have enteredOk : Ok next := emit_ok (update_ok ok entered) _
  have self : next.fiber? owner = some entered := by
    change (machine.update entered).fiber? owner = some entered
    have key : entered.id = owner := RunMachine.id_of_fiber? start
    rw [← key]
    exact RunMachine.fiber?_update_self entered machine ⟨initial, RunMachine.mem_of_fiber? start, rfl⟩
  have equation := Effect4.Machine.drive_evaluate_enters (interpOf root table) fuel machine owner initial rest
    active start live idle unparked
  change (Machine.drive (interpOf root table) (fuel + 1) machine (.evaluate owner :: rest)).fiber? owner = some fiber at found
  rw [equation] at found
  exact zero_count owner fuel root table next (.loop owner false :: rest) entered fiber enteredOk self rfl found

end Effect4.Program.OperationBudget

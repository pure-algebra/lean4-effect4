#!/bin/bash
set -e
lake build Effect4.Laws.Program.NativeFrameRows Test.Dogfood.Proofs.HostTimeoutNumberTerminalFiber Test.Dogfood.Proofs.HostTimeoutNumberInjection Test.Dogfood.Proofs.HostTimeoutNumberRootLoop
lake env lean scratch/TimeoutProtectedReturnAudit.lean

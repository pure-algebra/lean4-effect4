p='Test/Dogfood/Proofs/HostTimeoutNumberPendingInstall.lean'
s=open(p).read()
a=s.index('/-- The actual installed protected callback')
b=s.index('  have lookup :',a)
c=s.index('  exact ⟨config, queue, snapshot_replies',b)
d=s.index('\n\nend ',c)
body=s[b:d]
body=body.replace('next.machine','afterMachine').replace('next.fiber','afterFiber')
old='''      exact HostTimeoutNumberPendingFinalizer.installed context view machine fiber yielding exit body name flag program
        classified live heap current chosen hook'''
body=body.replace(old,'      exact provided')
body=body.replace('(parked.trans unparked)','unparked')
body=body.replace('    (snapshot_fields world machine afterMachine tasks fibers state completed detached), nested, edits, outcome⟩','    (snapshot_fields world machine afterMachine tasks fibers state completed detached)⟩')
header='''/-- One actual read-only native replacement retains the joined numeric machine, queue, and detached tasks.
Consumers: protected finalizer installation and ordinary running native steps. -/
theorem readonly_update (world : HostTimeoutNumberConfiguration.World) (context : CountContext)
    (machine afterMachine : NativeMachine) (fiber afterFiber : SourceScope.SourceFiber)
    (pending : List Guard.NCmd) (tasks : List NTask)
    (found : machine.fiber? fiber.id = some fiber) (ids : (machine.fibers.map (·.id)).Nodup)
    (assigned : (fiber.id, Role.pending context) ∈ world.roles)
    (held : Configuration world machine) (queued : Commands world machine pending)
    (detached : Snapshot world machine tasks) (saved : fiber.frame.stack ≠ [])
    (heap : At context.entered machine.state)
    (state : afterMachine.state = machine.state) (fibers : afterMachine.fibers = machine.fibers)
    (completed : afterMachine.completedExits = machine.completedExits)
    (key : afterFiber.id = fiber.id) (dispatcher : afterFiber.dispatcher = fiber.dispatcher)
    (exitSame : afterFiber.exit = fiber.exit) (unparked : afterFiber.parked = .notParked)
    (provided : FiberAt afterMachine (.pending context) afterFiber) :
    Configuration world (afterMachine.update afterFiber) ∧
      Commands world (afterMachine.update afterFiber) pending ∧
      Snapshot world (afterMachine.update afterFiber) tasks := by
'''
replacement='''  have provided := HostTimeoutNumberPendingFinalizer.installed context view machine fiber yielding exit body name flag program
    classified live heap current chosen hook
  obtain ⟨config, queue, snapshot⟩ := readonly_update world context machine next.machine fiber next.fiber pending tasks
    found ids assigned held queued detached saved heap state fibers completed key dispatcher exitSame
    (parked.trans unparked) provided
  exact ⟨config, queue, snapshot, nested, edits, outcome⟩'''
s=s[:a]+header+body+'\n\n'+s[a:b]+replacement+s[d:]
open(p,'w').write(s)

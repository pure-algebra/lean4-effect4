p='Test/Dogfood/Proofs/HostTimeoutNumberOrdinary.lean';s=open(p).read()
s=s.replace('theorem fiber (context : CountContext)', 'theorem fiber_running (context : CountContext)',1)
s=s.replace('(live : row.exit = none) (heap : At context.entered machine.state)\n    (noSuccess', '(live : row.exit = none)\n    (noSuccess',1)
s=s.replace('''  · intro next same before installed
    cases same
    exact False.elim (HostTimeoutNumberCountMachine.counted_heap_ne context (heap.symm.trans before))''','''  · intro next same before installed
    exact running''',1)
s=s.replace('held.pendingCustody context rfl heap (shape.1.symm.trans interruptible)', 'held.pendingCustody context rfl entered (shape.1.symm.trans interruptible)',1)
marker='/-- The actual ordinary running native step retains the same joined numeric world. -/'
idx=s.index(marker)
s=s[:idx]+'''/-- The earlier entered-heap interface remains an instance of actual running authority. -/
theorem fiber (context : CountContext) (view : HostTimeoutFlow.View) (machine : NativeMachine)
    (row : SourceScope.SourceFiber) (yielding : Bool)
    (held : FiberAt machine (.pending context) row) (running : row.running = true)
    (live : row.exit = none) (_heap : At context.entered machine.state)
    (noSuccess : ∀ value, row.frame.current ≠ .success value)
    (noFailure : ∀ cause, row.frame.current ≠ .failure cause)
    (noSync : ∀ thunk, row.frame.current ≠ .sync thunk)
    (ordinary : ∀ thunk, row.frame.current = .withFiber thunk →
      (HostTimeoutFlow.interpreter view).withFiberOf thunk = none) :
    let next := evaluatePrim.stepFrame (HostTimeoutFlow.interpreter view) machine row yielding
    FiberAt next.machine (.pending context) next.fiber :=
  fiber_running context view machine row yielding held running live noSuccess noFailure noSync ordinary

/-- Actual native evaluation may charge a local fiber before installing its returned row.
The resident lookup and local frame assertion stay separate until the shared update producer. -/
theorem joint_local (world : HostTimeoutNumberConfiguration.World) (context : CountContext)
    (view : HostTimeoutFlow.View) (machine : NativeMachine)
    (resident local : SourceScope.SourceFiber) (yielding : Bool)
    (pending : List Guard.NCmd) (tasks : List NTask)
    (found : machine.fiber? resident.id = some resident) (ids : (machine.fibers.map (·.id)).Nodup)
    (assigned : (resident.id, Role.pending context) ∈ world.roles)
    (held : Configuration world machine) (queued : Commands world machine pending)
    (detached : Snapshot world machine tasks) (provided : FiberAt machine (.pending context) local)
    (key : local.id = resident.id) (dispatcher : local.dispatcher = resident.dispatcher)
    (exitSame : local.exit = resident.exit) (running : local.running = true)
    (live : local.exit = none) (unparked : local.parked = .notParked)
    (finishes : ∀ exit, .finish resident.id exit ∉ pending)
    (loopEntered : ∀ latch, .loop resident.id latch ∈ pending → At context.entered machine.state)
    (noSuccess : ∀ value, local.frame.current ≠ .success value)
    (noFailure : ∀ cause, local.frame.current ≠ .failure cause)
    (noSync : ∀ thunk, local.frame.current ≠ .sync thunk)
    (ordinary : ∀ thunk, local.frame.current = .withFiber thunk →
      (HostTimeoutFlow.interpreter view).withFiberOf thunk = none) :
    let next := evaluatePrim.stepFrame (HostTimeoutFlow.interpreter view) machine local yielding
    Configuration world (next.machine.update next.fiber) ∧
      Commands world (next.machine.update next.fiber) pending ∧
      Snapshot world (next.machine.update next.fiber) tasks ∧
      next.nested = [] ∧ next.edits = [] ∧ next.outcome = .continue_ := by
  obtain ⟨frame, events, actual, _typed⟩ := HostTimeoutNumberPhaseHead.ordinary_running_over
    HostTimeoutNumberUniform.Edge HostTimeoutNumberUniform.head_edges view machine.state _ local.frame provided.frame.2
    noSuccess noFailure noSync ordinary
  have retained := fiber_running context view machine local yielding provided running live
    noSuccess noFailure noSync ordinary
  simp only [evaluatePrim.stepFrame, actual, evaluatePrim.finishFrame] at retained ⊢
  obtain ⟨config, queue, snapshot⟩ := HostTimeoutNumberPendingInstall.readonly_update world context machine
    (machine.emit (events.map (RunEvent.frame local.id))) resident {local with frame := frame} pending tasks
    found ids assigned held queued detached finishes loopEntered rfl rfl rfl key dispatcher exitSame unparked retained
  exact ⟨config, queue, snapshot, True.intro, True.intro, True.intro⟩

''' +s[idx:];open(p,'w').write(s)

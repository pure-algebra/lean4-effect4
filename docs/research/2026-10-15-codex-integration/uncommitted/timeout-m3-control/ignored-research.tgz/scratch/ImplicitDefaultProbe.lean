import Effect4.Laws.Program.CodeClosure.Slots
set_option autoImplicit false
def probe {P : Nat → Prop := fun _ => True} (n : Nat) : Prop := P n
example : probe 1 := trivial
example : probe (P := fun n => n = 1) 1 := rfl

from pathlib import Path
import re
base=Path('src/Effect4/Laws/Program/CodeClosure')
mods=['Slots','Stored','Callbacks','Interp','Stable']
for mod in mods:
 p=base/(mod+'.lean'); original=p.read_text()
 body=original.split('namespace Effect4.Program.CodeClosure.Slots\n',1)[1].rsplit('end Effect4.Program.CodeClosure.Slots',1)[0]
 # Capture declaration spans, including attached docstrings and attributes.
 starts=list(re.finditer(r'(?m)^(?:@\[reducible\] )?(def|abbrev|structure|theorem) ([A-Za-z_][\w.]*)',body))
 decls=[]
 for i,m in enumerate(starts):
  end=starts[i+1].start() if i+1<len(starts) else len(body)
  chunk=body[m.start():end]
  # Strip the next declaration's docstring from this chunk.
  comment=chunk.rfind('\n/--')
  if comment>=0: chunk=chunk[:comment]+'\n'
  decls.append((m.group(1),m.group(2),chunk))
 skip={'operation_at','compile_contract','Contract.of_transport'}
 qualified=body
 for kind,name,chunk in decls:
  if mod=='Callbacks' and name in skip:
   qualified=qualified.replace(chunk,'')
 # All point/env pairs accept the writer argument. Transport remains environment-only.
 qualified=qualified.replace('point env','point env writes')
 qualified=qualified.replace('(env : List Val → Prop)', '(env : List Val → Prop) (writes : RefKey → Term → List Val → Prop)')
 qualified=qualified.replace('(_env : List Val → Prop)', '(_env : List Val → Prop) (writes : RefKey → Term → List Val → Prop)')
 # Transport is independent of writer policy.
 qualified=qualified.replace('structure Transport (point : Point → Prop) (env : List Val → Prop) (writes : RefKey → Term → List Val → Prop)', 'structure Transport (point : Point → Prop) (env : List Val → Prop)')
 qualified=qualified.replace('Transport point env writes','Transport point env')
 # Some helpers refer to no env at all and remain unchanged (ViewStable).
 if mod=='Slots':
  qualified=qualified.replace('.refUpdate _ _ environment | .refGetAndUpdate _ _ environment | .refUpdateAndGet _ _ environment', '.refUpdate key term environment | .refGetAndUpdate key term environment | .refUpdateAndGet key term environment')
  qualified=qualified.replace('.refUpdateSome _ _ environment | .refGetAndUpdateSome _ _ environment | .refUpdateSomeAndGet _ _ environment', '.refUpdateSome key term environment | .refGetAndUpdateSome key term environment | .refUpdateSomeAndGet key term environment')
  qualified=qualified.replace('.refModify _ _ environment | .refModifySome _ _ environment => env environment', '.refModify key term environment | .refModifySome key term environment => writes key term environment')
  # FinAt and RegionAt do not read writes but retain a uniform policy argument.
  qualified=qualified.replace('(writes : RefKey → Term → List Val → Prop) : FinName', '(_writes : RefKey → Term → List Val → Prop) : FinName')
  qualified=qualified.replace('(writes : RefKey → Term → List Val → Prop) : Region', '(_writes : RefKey → Term → List Val → Prop) : Region')
 # Every moved implementation consumes moved dependencies.
 header=original.split('namespace Effect4.Program.CodeClosure.Slots\n',1)[0]
 for dep in mods:
  header=header.replace('import Effect4.Laws.Program.CodeClosure.'+dep+'\n','import Effect4.Laws.Program.CodeClosure.Qualified.'+dep+'\n')
 new=header+'namespace Effect4.Program.CodeClosure.Qualified\n'+qualified+'end Effect4.Program.CodeClosure.Qualified\n'
 out=base/'Qualified'/(mod+'.lean'); out.parent.mkdir(exist_ok=True);out.write_text(new)
 # Preserve the original public interface as specialization at env-only writer policy.
 wrappers=[]
 for kind,name,chunk in decls:
  if mod=='Callbacks' and name in skip:
   wrappers.append(chunk);continue
  # Prefix binders through env; names without env retain their full original declaration.
  marker='(env : List Val → Prop)'
  if marker not in chunk: marker='(_env : List Val → Prop)'
  if marker not in chunk:
   if name=='ViewStable':
    wrappers.append('abbrev ViewStable := Qualified.ViewStable\n');continue
   raise Exception((mod,name))
  prefix=chunk[:chunk.index(marker)+len(marker)]
  binders=re.findall(r'\(([A-Za-z_][\w]*)\s*:',prefix)
  # Strip attributes and use reducible aliases for definitions and proof terms alike.
  prefix=re.sub(r'^@\[reducible\] ','',prefix)
  prefix=re.sub(r'^(def|abbrev|structure|theorem) ','abbrev ',prefix)
  envname=binders[-1]
  if name=='Transport': args=' '.join(binders)
  else: args=' '.join(binders)+' (fun _ _ values => '+envname+' values)'
  wrappers.append(prefix+' := Qualified.'+name+' '+args+'\n')
 oldheader=original.split('namespace Effect4.Program.CodeClosure.Slots\n',1)[0]
 oldheader+='import Effect4.Laws.Program.CodeClosure.Qualified.'+mod+'\n'
 p.write_text(oldheader+'namespace Effect4.Program.CodeClosure.Slots\nopen Effect4 Effect4.Machine Effect4.Program\n\n'+'\n'.join(wrappers)+'\nend Effect4.Program.CodeClosure.Slots\n')

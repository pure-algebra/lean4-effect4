p='Test/Dogfood/Proofs/HostTimeoutNumberPhaseFlow.lean';s=open(p).read();s=s.replace('(head : CodeAt state input first) (ordered : input.grade ≤ output.grade)\n      (callback', '(head : CodeAt state input first) (ordered : input.grade ≤ output.grade)\n      (region : input.grade ≤ 1 → output.grade ≤ 1)\n      (callback')
a=s.index('  apply CodeAt.constant (.fresh phase)');b=s.index('\n/-- A read-only race restore',a)
s=s[:a]+'''  exact CodeAt.pausing phase _ priority _ heap
    (CodeAt.attemptEntry phase n cleanups forms cursor captured fuel delay previous heap)
''' +s[b:]
# all real non-generic bind call sites retain the same early region
s=s.replace('CodeAt.cancelRace phase race heap) (by dsimp only [Kind.grade]; decide)', 'CodeAt.cancelRace phase race heap) (by dsimp only [Kind.grade]; decide) (fun early => early)')
open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberPause.lean';s=open(p).read().replace('head ordered callback skip ih','head ordered region callback skip ih').replace('(ih after future same) ordered','(ih after future same) ordered region');open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberRootControl.lean';s=open(p).read();s=s.replace('(by dsimp only [Kind.grade]; decide)\n      · intro', '(by dsimp only [Kind.grade]; decide) (fun early => early)\n      · intro');open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberPhasePureHead.lean';s=open(p).read();s=s.replace('input.grade ≤ output.grade →\n    (∀ view,', 'input.grade ≤ output.grade →\n    (input.grade ≤ 1 → output.grade ≤ 1) →\n    (∀ view,')
# explicit non-finalizer closed-grade head calls
s=s.replace('(by dsimp only [Kind.grade]; decide) (fun view =>', '(by dsimp only [Kind.grade]; decide) (by dsimp only [Kind.grade]; omega) (fun view =>')
# undo finalizer tail: it does not receive a region condition
s=s.replace('rfl (by trivial) (by dsimp only [Kind.grade]; decide) (by dsimp only [Kind.grade]; omega)', 'rfl (by trivial) (by dsimp only [Kind.grade]; decide)')
s=s.replace('(Nat.le_refl _) (fun completed =>', '(Nat.le_refl _) (fun early => early) (fun completed =>')
s=s.replace('case bind input first name head ordered callback skip', 'case bind input first name head ordered region callback skip').replace('case constant input first body head ordered callback skip', 'case constant input first body head ordered region callback skip')
s=s.replace('first name ordered (fun completed =>', 'first name ordered region (fun completed =>').replace('first body ordered (fun completed =>', 'first body ordered region (fun completed =>')
s=s.replace('⟨fun _ _ _ _ _ _ each => each view, fun _ _ _ _ _ _ each => each view,\n      fun _ _ _ _ _ _ each => each view,', '⟨fun _ _ _ _ _ _ _ each => each view, fun _ _ _ _ _ _ _ each => each view,\n      fun _ _ _ _ _ _ _ each => each view,')
open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberUniform.lean';s=open(p).read();needle='  finalizerFlag : ∀ body name flag, frame = .onExit body name flag → flag = false';s=s.replace(needle,needle+'\n  crossing : input.grade ≤ 1 → 1 < output.grade → ∃ body name flag, frame = .onExit body name flag')
s=s.replace('held.finalizerInput, held.finalizerFlag⟩','held.finalizerInput, held.finalizerFlag, held.crossing⟩')
s=s.replace('intro state input output body name ordered each','intro state input output body name ordered region each').replace('intro state input output body next ordered each','intro state input output body next ordered region each')
s=s.replace('ordered, ?_, ?_⟩','ordered, ?_, ?_, ?_⟩')
# three ordinary constructors terminate with two impossible finalizer lines
needle='''    · intro body name flag impossible; cases impossible
    · intro body name flag impossible; cases impossible'''
s=s.replace(needle,needle+'''
    · intro early later
      exact False.elim (Nat.not_le_of_gt later (region early))''')
needle='''      cases actual
      exact flagFalse''';s=s.replace(needle,needle+'''
    · intro early later
      exact ⟨body, name, flag, rfl⟩''')
s=s.replace('Nat.le_refl _, ?_, ?_⟩','Nat.le_refl _, ?_, ?_, ?_⟩')
needle='''  · intro body name flag impossible; cases impossible
  · intro body name flag impossible; cases impossible''';s=s.replace(needle,needle+'''
  · intro early later
    exact False.elim (Nat.not_le_of_gt later early)''')
open(p,'w').write(s)

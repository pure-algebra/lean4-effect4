# Prepared next slice; execute only after the current checked slice is committed.
from pathlib import Path
p=Path('Test/Dogfood/Proofs/HostTimeoutNumberPhaseFlow.lean')
s=p.read_text()
s=s.replace('  | unit (phase : Phase)\n', '  | unit (phase : Phase)\n  | countUnit (phase : Phase)\n')
s=s.replace('  | .unit phase, value => At phase state ∧ value = .unit', '  | .unit phase, value => At phase state ∧ value = .unit\n  | .countUnit phase, value => At phase state ∧ value = .unit')
s=s.replace('  | .fresh phase, cause => At phase state ∧ HostTimeoutNumberFlow.NoTypedFailure cause', '  | .fresh phase, cause => At phase state ∧ HostTimeoutNumberFlow.NoTypedFailure cause\n  | .countUnit phase, cause => At phase state ∧ HostTimeoutNumberFlow.NoTypedFailure cause')
s=s.replace('  | unit phase => exact False.elim good\n  | before phase => exact good', '  | unit phase => exact False.elim good\n  | countUnit phase => exact ⟨good.1, HostTimeoutNumberFlow.no_typed_combine cause interrupted good.2 clean⟩\n  | before phase => exact good',1)
pos=s.index('theorem cause_strip')
a,b=s[:pos],s[pos:]
b=b.replace('  | unit phase => exact False.elim good\n  | before phase => exact good', '  | unit phase => exact False.elim good\n  | countUnit phase => exact ⟨good.1, HostTimeoutNumberFlow.no_typed_strip cause⟩\n  | before phase => exact good',1)
s=a+b
s=s.replace('(.unit (phase.counted n cleanups forms cursor))', '(.countUnit (phase.counted n cleanups forms cursor))')
a=s.index('theorem count_saved')
b=s.index('/-- The count binder installs',a)
part=s[a:b].replace('(.unit phase)', '(.countUnit phase)').replace('exact False.elim good','exact good.1')
s=s[:a]+part+s[b:]
p.write_text(s)
p=Path('Test/Dogfood/Proofs/HostTimeoutNumberConfiguration.lean')
s=p.read_text().replace('.unit context.entered', '.countUnit context.entered')
p.write_text(s)
p=Path('Test/Dogfood/Proofs/HostTimeoutNumberMaskClass.lean')
s=p.read_text().replace('  | unit phase => exact False.elim restorable','  | unit phase => exact False.elim restorable\n  | countUnit phase => exact ⟨good.1, clean⟩')
p.write_text(s)

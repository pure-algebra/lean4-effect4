import Test.Dogfood.Proofs.HostTimeoutNumberMaskPermission
set_option autoImplicit false
open Effect4 Effect4.Machine Effect4.Program
namespace Test.Dogfood.Proofs.HostTimeoutNumberMaskPermission
example (head : NCode) (scratch : HostTimeoutFrames.NativeFrame)
    (before : scratch.interruptible = false)
    (after : (head.ensure scratch).1.interruptible = true) :
    head = .setInterruptible true := by
  fun_cases Prim.ensure head scratch <;>
    simp only [Prod.fst] at after
  all_goals aesop (rule_sets := [Effect4.CodeClosure])
end Test.Dogfood.Proofs.HostTimeoutNumberMaskPermission

# Apply after countUnit is checked. The existing head producer owns all saved-edge construction.
from pathlib import Path
p=Path('Test/Dogfood/Proofs/HostTimeoutNumberPhaseFlow.lean')
s=p.read_text()
marker='/-- A restored success names the selected exit that the actual form log has just published. -/'
grade='''/-- Saved numeric phases move from ordinary work through protected cleanup to its returned exit.
Consumer: the authored-finalizer membership contradiction for read and unit runtime permissions. -/
@[aesop norm simp (rule_sets := [Effect4.CodeClosure])]
def Kind.grade : Kind → Nat
  | .fresh _ => 0
  | .countUnit _ | .before _ => 1
  | .read _ => 2
  | .unit _ => 3
  | .cleanupExit _ _ | .published _ => 4
  | .attempt _ _ _ => 5

'''
s=s.replace(marker,grade+marker)
s=s.replace('(head : CodeAt state input first)\n      (callback :', '(head : CodeAt state input first) (ordered : input.grade ≤ output.grade)\n      (callback :')
s=s.replace('(CodeAt.yieldNow (.fresh phase) priority heap)\n', '(CodeAt.yieldNow (.fresh phase) priority heap) (by decide)\n')
s=s.replace('(CodeAt.cancelRace phase race heap)\n', '(CodeAt.cancelRace phase race heap) (by decide)\n')
p.write_text(s)
p=Path('Test/Dogfood/Proofs/HostTimeoutNumberRootControl.lean')
s=p.read_text().replace('(ih state phase heap)\n', '(ih state phase heap) (by decide)\n').replace('(ihFirst state phase heap)\n', '(ihFirst state phase heap) (by decide)\n')
p.write_text(s)

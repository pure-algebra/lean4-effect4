#!/bin/bash
set -e
lake build Test.Dogfood.Proofs.HostTimeoutNumberTerminal Test.Dogfood.Proofs.HostTimeoutNumberInjection Test.Dogfood.Proofs.HostTimeoutNumberRootLoop
lake env lean scratch/TimeoutRegionAudit.lean

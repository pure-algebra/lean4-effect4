p='Test/Dogfood/Proofs/HostTimeoutNumberPhaseFlow.lean';s=open(p).read();a=s.index('/-- A restored success names')
s=s[:a]+'''/-- Each numeric endpoint names the committed count of its owning attempt.
Consumer: the uniform pending path's context anchor through actual native returns. -/
@[aesop norm simp (rule_sets := [Effect4.CodeClosure])]
def Kind.ownerCount : Kind → Nat
  | .attempt _ entered _ => entered.count
  | .fresh phase | .read phase | .unit phase | .countUnit phase | .before phase |
      .cleanupExit phase _ | .published phase => phase.count
  | .paused _ incoming => incoming.ownerCount

/-- Pending endpoints exclude root publication and retain the actual count boundary at attempt exits.
Consumer: restoring-mask permission at the same numeric attempt context. -/
@[aesop norm simp (rule_sets := [Effect4.CodeClosure])]
def Kind.Valid : Kind → Prop
  | .attempt before entered _ => before.count + 1 = entered.count
  | .published _ => False
  | .paused _ incoming => incoming.Valid
  | _ => True

''' +s[a:]
s=s.replace('(region : input.grade ≤ 1 → output.grade ≤ 1)\n      (callback','(region : input.grade ≤ 1 → output.grade ≤ 1)\n      (owner : input.ownerCount = output.ownerCount)\n      (valid : output.Valid → input.Valid)\n      (callback')
s=s.replace('(fun early => early)\n  · intro next', '(fun early => early) rfl (fun good => good)\n  · intro next')
open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberPause.lean';s=open(p).read().replace('ordered region callback skip ih','ordered region owner valid callback skip ih').replace('ordered region\n    · intro','ordered region owner valid\n    · intro');open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberRootControl.lean';s=open(p).read().replace('(fun early => early)\n      · intro','(fun early => early) rfl (fun good => good)\n      · intro');open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberPhasePureHead.lean';s=open(p).read();s=s.replace('(input.grade ≤ 1 → output.grade ≤ 1) →\n    (∀ view,','(input.grade ≤ 1 → output.grade ≤ 1) →\n    input.ownerCount = output.ownerCount →\n    (output.Valid → input.Valid) →\n    (∀ view,')
s=s.replace('HostTimeoutNumberMaskClass.Restorable output →\n    input.grade ≤ output.grade →\n    (∀ view,','HostTimeoutNumberMaskClass.Restorable output →\n    input.grade ≤ output.grade →\n    input.ownerCount = output.ownerCount →\n    (output.Valid → input.Valid) →\n    (∀ view,')
s=s.replace('(by dsimp only [Kind.grade]; omega) (fun view =>','(by dsimp only [Kind.grade]; omega) rfl (by intro; trivial) (fun view =>')
s=s.replace('rfl (by trivial) (by dsimp only [Kind.grade]; decide) (fun view =>','rfl (by trivial) (by dsimp only [Kind.grade]; decide) rfl (by intro; trivial) (fun view =>')
s=s.replace('(Nat.le_refl _) (fun early => early) (fun completed =>','(Nat.le_refl _) (fun early => early) rfl (fun good => good) (fun completed =>')
s=s.replace('head ordered region callback skip','head ordered region owner valid callback skip').replace('ordered region (fun completed =>','ordered region owner valid (fun completed =>')
s=s.replace('fun _ _ _ _ _ _ _ each => each view','fun _ _ _ _ _ _ _ _ _ each => each view').replace('fun _ _ _ _ _ _ _ _ _ _ each => each view','fun _ _ _ _ _ _ _ _ _ _ _ _ each => each view')
open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberUniform.lean';s=open(p).read();needle='  crossing : input.grade ≤ 1 → 1 < output.grade → ∃ body name flag, frame = .onExit body name flag';s=s.replace(needle,needle+'\n  owner : input.ownerCount = output.ownerCount\n  valid : output.Valid → input.Valid')
s=s.replace('held.finalizerFlag, held.crossing⟩','held.finalizerFlag, held.crossing, held.owner, held.valid⟩')
s=s.replace('ordered region each','ordered region owner valid each').replace('restorable ordered each','restorable ordered owner valid each')
s=s.replace('ordered, ?_, ?_, ?_⟩','ordered, ?_, ?_, ?_, owner, valid⟩')
s=s.replace('Nat.le_refl _, ?_, ?_, ?_⟩','Nat.le_refl _, ?_, ?_, ?_, rfl, (fun good => good)⟩')
open(p,'w').write(s)

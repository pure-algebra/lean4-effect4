#!/bin/bash
set -e
lake build Effect4.Laws.Machine.AnswerFlowEmpty Effect4.Laws.Machine.AnswerFlowNativeExit Test.Dogfood.Proofs.HostTimeoutNumberTerminal
lake env lean scratch/TimeoutReturnAudit.lean

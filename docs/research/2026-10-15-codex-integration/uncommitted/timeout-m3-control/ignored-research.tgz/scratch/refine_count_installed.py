p='Test/Dogfood/Proofs/HostTimeoutNumberContext.lean';s=open(p).read();s=s.replace('''def CountInstalled (context : CountContext) (frame : HostTimeoutFrames.NativeFrame) : Prop :=
  .onExit context.bound (.fin context.point) false ∈ frame.stack''','''def CountInstalled (context : CountContext) (frame : HostTimeoutFrames.NativeFrame) : Prop :=
  ∃ point body, AttemptSource context point ∧ (.onExit body (.fin point) false : NCode) ∈ frame.stack

/-- The original concrete entry supplies an actual installed source witness. -/
theorem CountInstalled.exact (context : CountContext) (frame : HostTimeoutFrames.NativeFrame)
    (member : (.onExit context.bound (.fin context.point) false : NCode) ∈ frame.stack) :
    CountInstalled context frame := ⟨context.point, context.bound, context.source, member⟩

/-- Retaining the actual saved frame retains its same source witness through native execution. -/
theorem CountInstalled.mono (context : CountContext) (before after : HostTimeoutFrames.NativeFrame)
    (subset : before.stack ⊆ after.stack) (held : CountInstalled context before) : CountInstalled context after := by
  obtain ⟨point, body, source, member⟩ := held
  exact ⟨point, body, source, subset member⟩''')
open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberConfiguration.lean';s=open(p).read();s=s.replace('''  intro installed
  change _ ∈ frame.stack at installed
  rw [empty] at installed
  cases installed''','''  rintro ⟨point, body, source, installed⟩
  rw [empty] at installed
  cases installed''',1)
s=s.replace('''  have installed : CountInstalled context fiber.frame := by
    change _ ∈ fiber.frame.stack''','''  have installed : CountInstalled context fiber.frame := by
    apply CountInstalled.exact
    change _ ∈ fiber.frame.stack''')
s=s.replace('''  have installed := held.pendingCustody context rfl heap unmasked
  rcases HostTimeoutNumberMaskCustody.getCont context.bound (.fin context.point) demand skip exitDemand
      fiber.frame cause installed with masked | retained
  · exact Or.inr masked
  · exact Or.inl retained''','''  obtain ⟨point, body, source, installed⟩ := held.pendingCustody context rfl heap unmasked
  rcases HostTimeoutNumberMaskCustody.getCont body (.fin point) demand skip exitDemand
      fiber.frame cause installed with masked | retained
  · exact Or.inr masked
  · exact Or.inl ⟨point, body, source, retained⟩''')
# direct uniform saved constructors gain the coherent fields
s=s.replace('''HostTimeoutNumberUniform.head_edges.success _ _ _ _ _ (by dsimp only [HostTimeoutNumberPhaseFlow.Kind.grade]; decide)
    (fun view''','''HostTimeoutNumberUniform.head_edges.success _ _ _ _ _ (by dsimp only [HostTimeoutNumberPhaseFlow.Kind.grade]; decide)
    (fun early => early) rfl (fun good => good) (fun view''')
s=s.replace('''rfl (by trivial) (by dsimp only [HostTimeoutNumberPhaseFlow.Kind.grade]; decide)
      (fun view''','''rfl (by trivial) (by dsimp only [HostTimeoutNumberPhaseFlow.Kind.grade]; decide)
      rfl (by intro; trivial) (fun view''')
open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberCountMachine.lean';s=open(p).read().replace('''  have installedFin : CountInstalled context fiber.frame := by
    change''','''  have installedFin : CountInstalled context fiber.frame := by
    apply CountInstalled.exact
    change''');open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberOrdinary.lean';s=open(p).read().replace('''    exact shape.2.subset (held.pendingCustody context rfl entered (shape.1.symm.trans interruptible))''','''    exact CountInstalled.mono context _ _ shape.2.subset
      (held.pendingCustody context rfl entered (shape.1.symm.trans interruptible))''');open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberQueueInterrupt.lean';s=open(p).read().replace('''      change _ ∈ fiber.frame.stack
      change _ ∈ (interruptWithCause cause fiber).1.frame.stack at installed
      rw [fields.2.2.1] at installed
      exact installed''','''      obtain ⟨point, body, source, member⟩ := installed
      exact ⟨point, body, source, fields.2.2.1 ▸ member⟩''');open(p,'w').write(s)
p='Test/Dogfood/Proofs/HostTimeoutNumberMaskPermission.lean';s=open(p).read().replace('''    have installed := held.pendingCustody context rfl heap actual''','''    obtain ⟨point, body, source, installed⟩ := held.pendingCustody context rfl heap actual''').replace('''(.onExit context.bound (.fin context.point) false) 1''','''(.onExit body (.fin point) false) 1''');open(p,'w').write(s)

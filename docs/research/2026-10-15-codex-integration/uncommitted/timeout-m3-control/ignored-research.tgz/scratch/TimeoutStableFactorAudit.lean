import Test.Dogfood.Proofs.HostTimeoutNumberCountQueue
import Test.Dogfood.Scenario.Timeout.CommandCut
import Effect4.Laws.Program.AnswerSlots.Actions
import Effect4.Laws.Program.AnswerSlots.PrefixStable
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.CodeClosure.Interp Effect4.Laws.Program.CodeClosure.Stable Effect4.Laws.Program.AnswerSlots.Interp Effect4.Laws.Program.AnswerSlots.PrefixStable Test.Dogfood.Proofs.HostTimeoutNumberSourceSlots Test.Dogfood.Scenario.Timeout.CommandCut

p='src/Effect4/Laws/Machine/AnswerFlowResume.lean';s=open(p).read()
a=s.index('theorem popFrom_replacement_origin (');b=s.index('/-- Actual fused pops',a)
block=s[a:b];sig=block[:block.index(' := by')];new=block.replace('theorem popFrom_replacement_origin (','theorem popFrom_replacement_origin_recorded (',1)
new=new.replace('(world : World) (demand : Arm) (skip : Bool)\n    (transport', '(world : World) (demand : Arm) (skip : Bool)\n    (recorded : Option (Cause ε δ ι α))\n    (transport',1)
new=new.replace('Edge world input middle head → PopTrace.Passes demand skip head scratch before after →\n      Input input', 'Edge world input middle head → PopTrace.Passes demand skip head scratch before after →\n      scratch.interruptedCause = recorded → Input input',1)
new=new.replace('(carried recorded : Option (Cause ε δ ι α))','(carried : Option (Cause ε δ ι α))',1)
new=new.replace('callback passed good) found','callback passed scratch.2 good) found',1)
wrapper='''/-- The earlier transport interface is the instance that ignores actual recorded-cause provenance. -/
'''+sig+''' :=
  popFrom_replacement_origin_recorded Edge Input world demand skip recorded
    (fun input middle head scratch before after edge passed _ good =>
      transport input middle head scratch before after edge passed good)
    input output frames fiber carried stack empty same good next found

'''
s=s[:a]+new+wrapper+s[b:]
a=s.index('theorem getCont_replacement_hooked\n');b=s.index('/-- The actual value replacement',a)
block=s[a:b];sig=block[:block.index(' := by')];new=block.replace('theorem getCont_replacement_hooked','theorem getCont_replacement_hooked_recorded',1)
new=new.replace('''    (world : World) (demand : Arm) (skip : Bool)
    (transport''','''    (world : World) (demand : Arm) (skip : Bool)
    (fiber : FrameFiber ν σ β ε δ ι α)
    (transport''',1)
new=new.replace('''Edge world input middle head → PopTrace.Passes demand skip head scratch before after →
      Input input''','''Edge world input middle head → PopTrace.Passes demand skip head scratch before after →
      scratch.interruptedCause = fiber.interruptedCause → Input input''',1)
new=new.replace('(input output : Kind) (fiber : FrameFiber ν σ β ε δ ι α)\n    (carried', '(input output : Kind)\n    (carried',1)
new=new.replace('''popFrom_replacement_origin Edge Input world demand skip transport input output fiber.stack
        {fiber with stack := [], deferredInterrupt := false} carried fiber.interruptedCause stack''','''popFrom_replacement_origin_recorded Edge Input world demand skip fiber.interruptedCause transport input output fiber.stack
        {fiber with stack := [], deferredInterrupt := false} carried stack''',1)
new=new.replace('transport incoming middle head scratch before after callback passed good','transport incoming middle head scratch before after callback passed same good',1)
wrapper='''/-- The earlier replacement reader ignores the available actual recorded-cause equation. -/
'''+sig+''' :=
  getCont_replacement_hooked_recorded model Edge mask Input world demand skip fiber
    (fun input middle head scratch before after edge passed _ good =>
      transport input middle head scratch before after edge passed good)
    input output carried good stack next found

'''
s=s[:a]+new+wrapper+s[b:];open(p,'w').write(s)

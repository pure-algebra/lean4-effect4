import Test.Dogfood.Proofs.HostTimeoutNumberPhaseHead
open Effect4.Machine
#check @AnswerFlow.HeadAt.onSuccess
#check @AnswerFlow.HeadAt.async
#check @AnswerFlow.HeadAt.yieldNowWith

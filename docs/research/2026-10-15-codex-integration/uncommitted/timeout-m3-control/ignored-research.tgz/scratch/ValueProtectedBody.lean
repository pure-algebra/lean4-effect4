  have ordinary := value_step view state input output frame value good saved recorded clear pure
  have deferred := Guard.DeferredCause.getCont_deferred_false frame .contA false
  apply AnswerFlow.External.resume_value_dispatch (HostTimeoutFlow.interpreter view).toPrimInterp
    (HostTimeoutNumberPopAuthority.StepPermission context view state output) frame value (some (.success value))
  · intro found
    rw [FrameFiber.resumeValue_empty (HostTimeoutFlow.interpreter view).toPrimInterp frame value _ found] at ordinary
    exact ordinary
  · intro cause found
    exact False.elim (FrameFiber.getCont_never_defers frame .contA false cause clear found)
  · intro next found
    obtain ⟨cause, rfl⟩ := AnswerFlow.External.getCont_replacement_failure Edge state input output
      frame .contA false none saved next found
    have typed := HostTimeoutNumberReplacement.value_frame view state input output frame value (.failure cause)
      good saved recorded found
    by_cases heap : At context.entered state
    · obtain ⟨current, code, path, early⟩ := HostTimeoutNumberPopAuthority.failure_frame_early view context state
        output (frame.getCont .contA false).fiber cause heap owner valid typed
      exact ⟨current, code, path, fun _ _ => early, deferred⟩
    · obtain ⟨current, code, path⟩ := typed
      exact ⟨current, code, path, fun entered _ => (heap entered).elim, deferred⟩
  · intro selected found missing
    simpa only [FrameFiber.resumeValue, found, missing, AnswerFlow.FamilyStep,
      HostTimeoutNumberPopAuthority.StepPermission] using ordinary
  · intro selected next pushed found evaluated
    by_cases heap : At context.entered state
    · obtain ⟨events, current, equation, code, path, early⟩ :=
        HostTimeoutNumberPopAuthority.resume_value_selected_early view context state input output frame value
          selected next pushed (some (.success value)) heap owner valid good (authority heap) saved found
          (fun incoming allowed exit member => by cases member; exact allowed) (pure selected found) evaluated
      exact ⟨current, code, path, fun _ => early, deferred⟩
    · rw [FrameFiber.resumeValue_frame (HostTimeoutFlow.interpreter view).toPrimInterp
        frame value (some (.success value)) selected next pushed found evaluated] at ordinary
      obtain ⟨current, code, path⟩ := ordinary
      exact ⟨current, code, path, fun entered _ => (heap entered).elim, deferred⟩

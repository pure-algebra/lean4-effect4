#!/bin/bash
set -e
lake build Effect4.Laws.Machine.LiftCoupledFact Test.Dogfood.Proofs.HostTimeoutNumberInjection
lake env lean scratch/TimeoutFuelAudit.lean

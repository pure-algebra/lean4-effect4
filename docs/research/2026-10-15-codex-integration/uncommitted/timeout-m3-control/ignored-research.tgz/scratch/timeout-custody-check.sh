#!/bin/bash
set -e
lake build Test.Dogfood.Proofs.HostTimeoutNumberOrdinary Test.Dogfood.Proofs.HostTimeoutNumberCleanupJoint Test.Dogfood.Proofs.HostTimeoutNumberAttemptNative Test.Dogfood.Proofs.HostTimeoutNumberTerminal Test.Dogfood.Proofs.HostTimeoutNumberMaskPermission
lake env lean scratch/TimeoutCustodyAudit.lean

#!/bin/bash
set -e
lake build Test.Dogfood.Proofs.HostTimeoutNumberInjection Test.Dogfood.Proofs.HostTimeoutNumberCleanupJoint Test.Dogfood.Proofs.HostTimeoutNumberTerminal Test.Dogfood.Proofs.HostTimeoutNumberRootLoop Test.Dogfood.Proofs.HostTimeoutNumberRootTransitions Effect4.Laws.Machine.AnswerFlowNativeIteration
lake env lean scratch/TimeoutInjectionAudit.lean

#!/bin/bash
set -e
lake build Test.Dogfood.Proofs.HostTimeoutNumberPopAuthority Test.Dogfood.Proofs.HostTimeoutNumberTerminal
lake env lean scratch/TimeoutAuthorityAudit.lean

import Test.Dogfood.Proofs.HostTimeoutNumberCountQueue
import Effect4.Laws.Program.AnswerSlots.Actions
import Effect4.Laws.Program.AnswerSlots.PrefixStable
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.CodeClosure.Qualified.Slots Effect4.Laws.Program.CodeClosure.Qualified.Stored Effect4.Laws.Program.CodeClosure.Qualified.Callbacks Effect4.Laws.Program.CodeClosure.Qualified.Interp Effect4.Laws.Program.CodeClosure.Qualified.Stable Effect4.Laws.Program.CodeClosure.Slots Effect4.Laws.Program.CodeClosure.Stored Effect4.Laws.Program.CodeClosure.Callbacks Effect4.Laws.Program.CodeClosure.Interp Effect4.Laws.Program.CodeClosure.Stable Test.Dogfood.Proofs.HostTimeoutNumberSourceWrites Test.Dogfood.Proofs.HostTimeoutNumberConfiguration Test.Dogfood.Proofs.HostTimeoutNumberConfigurationInterrupt Test.Dogfood.Proofs.HostTimeoutNumberCountMachine Test.Dogfood.Proofs.HostTimeoutNumberCountQueue

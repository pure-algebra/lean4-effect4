import Test.Dogfood.Scenario.Timeout.SourceCut
import Effect4.Laws.Program.AnswerSlots.Actions
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.CodeClosure.Slots Effect4.Laws.Program.CodeClosure.Stored Effect4.Laws.Program.CodeClosure.Callbacks Effect4.Laws.Program.AnswerSlots.Syntax Effect4.Laws.Program.AnswerSlots.Stored Effect4.Laws.Program.AnswerSlots.Compile Effect4.Laws.Program.AnswerSlots.Callbacks Effect4.Laws.Program.AnswerSlots.Interp Test.Dogfood.Proofs.HostTimeoutNumberSourceSlots Test.Dogfood.Scenario.Timeout.SourceCut

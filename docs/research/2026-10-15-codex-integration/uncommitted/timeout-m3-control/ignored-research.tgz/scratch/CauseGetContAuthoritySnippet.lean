include interp family mask in
/-- The selected failure producer retains authority at the actual carried-cause class.
Consumer: Timeout's actual pending cleanup return and mask custody. -/
theorem getCont_cause_selected_with_authority
    (Authority Post : Kind → FrameFiber ν σ β ε δ ι α → Prop)
    (world : World) (input output : Kind)
    (fiber : FrameFiber ν σ β ε δ ι α)
    (cause : Cause ε δ ι α) (selected : Prim ν σ β ε δ ι α)
    (advance : ∀ incoming middle head rest scratch before after,
      Edge world incoming middle head → Path (Edge world) middle output rest → scratch.stack = [] →
      (∃ cause, model.cause world incoming cause) → (∃ cause, model.cause world middle cause) →
      Authority incoming scratch → PopTrace.Passes .contE true head scratch before after →
      (FrameFiber.passPushed .contE true (head.ensure scratch).1 after).answer = .empty →
      Authority middle (FrameFiber.passPushed .contE true (head.ensure scratch).1 after).fiber)
    (post : ∀ incoming middle rest scratch,
      Edge world incoming middle selected → Path (Edge world) middle output rest → scratch.stack = [] →
      (∃ cause, model.cause world incoming cause) → Authority incoming scratch →
      Post middle {(selected.ensure scratch).1 with stack := (selected.ensure scratch).1.stack ++ rest})
    (good : model.cause world input cause)
    (absorbs : AbsorbsInterrupt model world fiber.interruptedCause)
    (authority : Authority input {fiber with stack := [], deferredInterrupt := false}) (stack : Path (Edge world) input output fiber.stack)
    (found : (fiber.getCont .contE true (some cause)).answer = .frame selected)
    (admitted : Allowed world fiber.interruptedCause := by trivial) :
    ∃ incoming middle delivered,
      (fiber.getCont .contE true (some cause)).carriedCause = some delivered ∧
      model.cause world incoming delivered ∧ Edge world incoming middle selected ∧
      Path (Edge world) middle output (fiber.getCont .contE true (some cause)).fiber.stack ∧
      Post middle (fiber.getCont .contE true (some cause)).fiber := by
  simp only [FrameFiber.getCont, Bool.not_true, Bool.and_false, Bool.false_eq_true, ↓reduceIte] at found ⊢
  exact popFrom_cause_selected_with_authority (admitted := admitted) model interp Edge Allowed family mask
    Authority Post world input output fiber.stack {fiber with stack := [], deferredInterrupt := false}
    cause selected advance post rfl good absorbs authority stack found


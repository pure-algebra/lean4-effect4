/-- The existing value-return split exposes one result predicate at its actual branch.
Concept: scope-lifetime-finalization R11. Consumer: Timeout's whole numeric return authority.
The callback certificates remain application premises. -/
theorem resume_value_dispatch (Post : FrameStep ν σ β ε δ ι α → Prop)
    (fiber : FrameFiber ν σ β ε δ ι α) (value : β) (provided : Option (Exit β ε δ ι α))
    (empty : (fiber.getCont .contA false).answer = .empty → Post (.finished (provided.getD (.success value))))
    (deferred : ∀ cause, (fiber.getCont .contA false).answer = .deferred cause →
      Post (.running {(fiber.getCont .contA false).fiber with current := .failure cause}))
    (replacement : ∀ next, (fiber.getCont .contA false).answer = .replacement next →
      Post (.running {(fiber.getCont .contA false).fiber with current := next}))
    (missing : ∀ selected, (fiber.getCont .contA false).answer = .frame selected →
      selected.armA interp value provided = none → Post (.finished (provided.getD (.success value))))
    (callback : ∀ selected next pushed, (fiber.getCont .contA false).answer = .frame selected →
      selected.armA interp value provided = some (next, pushed) →
      Post (.running {(fiber.getCont .contA false).fiber with
        current := next
        stack := pushed ++ (fiber.getCont .contA false).fiber.stack})) :
    Post (fiber.resumeValue interp value provided).1 := by
  cases selected : (fiber.getCont .contA false).answer with
  | empty =>
    rw [FrameFiber.resumeValue_empty interp fiber value provided selected]
    exact empty selected
  | deferred cause =>
    rw [FrameFiber.resumeValue_deferred interp fiber value provided cause selected]
    exact deferred cause selected
  | replacement next =>
    rw [FrameFiber.resumeValue_replacement interp fiber value provided next selected]
    exact replacement next selected
  | frame frame =>
    cases actual : frame.armA interp value provided with
    | none =>
      simpa only [FrameFiber.resumeValue, selected, actual] using missing frame selected actual
    | some result =>
      obtain ⟨next, pushed⟩ := result
      rw [FrameFiber.resumeValue_frame interp fiber value provided frame next pushed selected actual]
      exact callback frame next pushed selected actual

/-- The existing failure-return split exposes one result predicate at its actual delivered branch.
Concept: scope-lifetime-finalization R11. Consumer: Timeout's whole numeric return authority.
The actual delivered cause and callback certificates remain application premises. -/
theorem resume_cause_dispatch (Post : FrameStep ν σ β ε δ ι α → Prop)
    (fiber : FrameFiber ν σ β ε δ ι α) (cause : Cause ε δ ι α) (provided : Option (Exit β ε δ ι α))
    (empty : (fiber.getCont .contE true (some cause)).answer = .empty →
      Post (.finished ((fiber.getCont .contE true (some cause)).deliveredExit (provided.getD (.failure cause)))))
    (deferred : ∀ reason, (fiber.getCont .contE true (some cause)).answer = .deferred reason →
      Post (.running {(fiber.getCont .contE true (some cause)).fiber with current := .failure reason}))
    (replacement : ∀ next, (fiber.getCont .contE true (some cause)).answer = .replacement next →
      Post (.running {(fiber.getCont .contE true (some cause)).fiber with current := next}))
    (missing : ∀ selected, (fiber.getCont .contE true (some cause)).answer = .frame selected →
      selected.armE interp ((fiber.getCont .contE true (some cause)).carriedCause.getD cause)
        (provided.map (fiber.getCont .contE true (some cause)).deliveredExit) = none →
      Post (.finished ((fiber.getCont .contE true (some cause)).deliveredExit (provided.getD (.failure cause)))))
    (callback : ∀ selected next pushed, (fiber.getCont .contE true (some cause)).answer = .frame selected →
      selected.armE interp ((fiber.getCont .contE true (some cause)).carriedCause.getD cause)
        (provided.map (fiber.getCont .contE true (some cause)).deliveredExit) = some (next, pushed) →
      Post (.running {(fiber.getCont .contE true (some cause)).fiber with
        current := next
        stack := pushed ++ (fiber.getCont .contE true (some cause)).fiber.stack})) :
    Post (fiber.resumeCause interp cause provided).1 := by
  cases selected : (fiber.getCont .contE true (some cause)).answer with
  | empty =>
    rw [FrameFiber.resumeCause_empty interp fiber cause provided selected]
    exact empty selected
  | deferred reason =>
    rw [FrameFiber.resumeCause_deferred interp fiber cause reason provided selected]
    exact deferred reason selected
  | replacement next =>
    rw [FrameFiber.resumeCause_replacement interp fiber cause provided next selected]
    exact replacement next selected
  | frame frame =>
    cases actual : frame.armE interp ((fiber.getCont .contE true (some cause)).carriedCause.getD cause)
        (provided.map (fiber.getCont .contE true (some cause)).deliveredExit) with
    | none =>
      simpa only [FrameFiber.resumeCause, selected, actual] using missing frame selected actual
    | some result =>
      obtain ⟨next, pushed⟩ := result
      rw [FrameFiber.resumeCause_frame interp fiber cause provided frame next pushed selected actual]
      exact callback frame next pushed selected actual


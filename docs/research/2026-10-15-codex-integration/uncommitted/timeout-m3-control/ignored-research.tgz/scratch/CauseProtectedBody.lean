  have ordinary := cause_step view state input output frame cause good saved recorded clear pure
  have deferred : (frame.getCont .contE true (some cause)).fiber.deferredInterrupt = false := by
    rw [FrameFiber.getCont_fiber_cause]
    exact Guard.DeferredCause.getCont_deferred_false frame .contE true
  apply AnswerFlow.External.resume_cause_dispatch (HostTimeoutFlow.interpreter view).toPrimInterp
    (HostTimeoutNumberPopAuthority.StepPermission context view state output) frame cause (some (.failure cause))
  · intro found
    rw [FrameFiber.resumeCause_empty (HostTimeoutFlow.interpreter view).toPrimInterp frame cause _ found] at ordinary
    exact ordinary
  · intro reason found
    rw [FrameFiber.getCont_answer_cause] at found
    exact False.elim (FrameFiber.getCont_never_defers frame .contE true reason clear found)
  · intro next found
    obtain ⟨reason, rfl⟩ := AnswerFlow.External.getCont_replacement_failure Edge state input output
      frame .contE true (some cause) saved next found
    have typed := HostTimeoutNumberReplacement.cause_frame view state input output frame cause (.failure reason)
      good saved recorded found
    by_cases heap : At context.entered state
    · obtain ⟨current, code, path, early⟩ := HostTimeoutNumberPopAuthority.failure_frame_early view context state
        output (frame.getCont .contE true (some cause)).fiber reason heap owner valid typed
      exact ⟨current, code, path, fun _ _ => early, deferred⟩
    · obtain ⟨current, code, path⟩ := typed
      exact ⟨current, code, path, fun entered _ => (heap entered).elim, deferred⟩
  · intro selected found missing
    simpa only [FrameFiber.resumeCause, found, missing, AnswerFlow.FamilyStep,
      HostTimeoutNumberPopAuthority.StepPermission] using ordinary
  · intro selected next pushed found evaluated
    by_cases heap : At context.entered state
    · obtain ⟨events, current, equation, code, path, early⟩ :=
        HostTimeoutNumberPopAuthority.resume_cause_selected_early view context state input output frame cause
          selected next pushed (some (.failure cause)) heap owner valid good recorded (authority heap) saved found
          (by
            intro incoming delivered carried allowed exit member
            simp only [Option.map_some, FramePop.deliveredExit, carried, Option.getD_some] at member
            cases member
            exact allowed)
          (by
            intro delivered carried
            simpa only [Option.map_some, FramePop.deliveredExit, carried, Option.getD_some] using pure selected found)
          evaluated
      exact ⟨current, code, path, fun _ => early, deferred⟩
    · rw [FrameFiber.resumeCause_frame (HostTimeoutFlow.interpreter view).toPrimInterp
        frame cause (some (.failure cause)) selected next pushed found evaluated] at ordinary
      obtain ⟨current, code, path⟩ := ordinary
      exact ⟨current, code, path, fun entered _ => (heap entered).elim, deferred⟩

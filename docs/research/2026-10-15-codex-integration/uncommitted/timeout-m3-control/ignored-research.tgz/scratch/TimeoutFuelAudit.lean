import Effect4.Laws.Machine.LiftCoupledFact
import Test.Dogfood.Proofs.HostTimeoutNumberInjection
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Machine.Lift Effect4.Laws.Machine.LiftCoupledFact Test.Dogfood.Proofs.HostTimeoutNumberOrdinary
#check Effect4.Machine.Lift.driveState_lift_fuel
#check Effect4.Machine.Lift.driveState_lift

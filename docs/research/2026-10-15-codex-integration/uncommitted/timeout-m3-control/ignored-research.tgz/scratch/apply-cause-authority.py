p='src/Effect4/Laws/Machine/AnswerFlowFamilyPop.lean'
s=open(p).read();a=s.index('include interp family mask in\n/-- The selected failure callback retains');b=s.index('\ninclude interp family mask in\n/-- The previous selected-frame reader',a);old=s[a:b];sig=old[:old.index(' := by\n  have popFamily')];body=''' := by
  exact popFrom_cause_selected_with_authority (admitted := admitted) model interp Edge Allowed family mask
    (fun _ _ => True) (fun _ scratch => Post scratch.interruptible)
    world input output frames fiber cause selected
    (fun _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ => trivial)
    (fun incoming middle rest scratch edge _ _ _ _ => by
      exact post incoming middle scratch edge)
    empty good absorbs trivial stack found
''';s=s[:a]+open('scratch/CauseAuthoritySnippet.lean').read()+'\n'+sig+body+s[b:];a=s.index('include interp family mask in\n/-- Actual getCont selects a failure callback');s=s[:a]+open('scratch/CauseGetContAuthoritySnippet.lean').read()+'\n'+s[a:];open(p,'w').write(s)

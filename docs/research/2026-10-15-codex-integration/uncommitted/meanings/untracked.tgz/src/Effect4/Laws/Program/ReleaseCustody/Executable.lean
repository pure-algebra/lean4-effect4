import Effect4.Laws.Program.ReleaseCustody.IterationDebit
import Effect4.Laws.Machine.ExecutionWeights

/-!
Concept: scope-lifetime-finalization R11.
Question: executable release custody serves FinalizerRun.once_placed_outside_census.
Consumer: parallel-close accounting and its command-history lift.
The current reservation follows idle fibers and actual queued evaluator owners.
Other positions retain the existing release-custody reading.
A command outcome transfers current custody before overwriting its stored parent code.
These definitions and local bounds establish no history or once-only conclusion.
-/
set_option autoImplicit false
namespace Effect4.Program.ReleaseCustody.Executable
open Effect4 Effect4.Machine Effect4.Program
open Control

/-- Saved continuations and detached dispatcher tasks stay at their existing fiber. -/
def retained (q : List Nat) (fiber : Control.Fiber) : Nat :=
  stackCredits q fiber.frame.current fiber.frame.stack +
    (fiber.dispatcher.buckets.map fun bucket => (bucket.tasks.map (taskCredits q)).sum).sum

/-- The command list owns exactly its loop and delivery entries. -/
abbrev owners (commands : List Control.Command) : List FiberId :=
  commands.filterMap ExecutionWeights.evaluatorOwner

/-- Current code counts only while its fiber can execute it. -/
abbrev fiber (q : List Nat) (commands : List Control.Command) : Control.Fiber → Nat :=
  ExecutionWeights.fiber (fun f => currentCredits q f.frame.current) (retained q) (owners commands)

/-- Scope entries, executable fibers and unlaunched programs retain custody. -/
def machine (q : List Nat) (m : NativeMachine) (commands : List Control.Command) : Nat :=
  (m.state.scopes.entries.map fun e => scopeCredits q e.scope).sum +
    FiberSum.total (fiber q commands) m +
    (m.races.map fun r => (r.programs.map (currentCredits q)).sum).sum

/-- The original registration/release balance read at the actual executable positions. -/
def Funded (q : List Nat) (m : NativeMachine) (commands : List Control.Command) : Prop :=
  m.trace.countP (ReleaseTrace.releaseAt q) + machine q m commands +
    (commands.map (commandCredits q)).sum ≤ m.trace.countP (ReleaseTrace.registeredAt q)

/-- A command outcome transfers its current work before the later overwrite command. -/
def returned (q : List Nat) (it : RuntimeShape.Iteration) : Nat :=
  (if it.outcome = .commands then 0 else currentCredits q it.fiber.frame.current) + retained q it.fiber

/-- Every old complete-row debit supplies the weaker executable returned-row debit. -/
theorem returned_le (q : List Nat) (it : RuntimeShape.Iteration) :
    returned q it ≤ fiberCredits q it.fiber := by
  unfold returned retained fiberCredits
  split <;> omega

/-- An idle fiber retains the original complete-row custody. -/
theorem idle (q : List Nat) (commands : List Control.Command) (f : Control.Fiber)
    (idle : f.running = false) : fiber q commands f = fiberCredits q f := by
  rw [fiber, ExecutionWeights.idle _ _ _ f idle]
  exact Nat.add_assoc _ _ _ |>.symm

/-- The selected evaluator owns its original complete-row custody. -/
theorem selected (q : List Nat) (commands : List Control.Command) (f : Control.Fiber)
    (present : f.id ∈ owners commands) : fiber q commands f = fiberCredits q f := by
  rw [fiber, ExecutionWeights.owned _ _ _ f present]
  exact Nat.add_assoc _ _ _ |>.symm

/-- Removing the pending queue cannot increase the machine's executable reservation. -/
theorem discard (q : List Nat) (m : NativeMachine) (commands : List Control.Command)
    (funded : Funded q m commands) : Funded q m [] := by
  have bound := ExecutionWeights.total_mono (fun f : Control.Fiber => currentCredits q f.frame.current)
    (retained q) (owners commands) [] (List.nil_subset _) m
  unfold Funded machine at funded ⊢
  change FiberSum.total (fiber q []) m ≤ FiberSum.total (fiber q commands) m at bound
  simp only [List.map_nil, List.sum_nil, Nat.add_zero]
  omega

/-- The local debit discounts only current work already delegated to commands. -/
def Debit (q : List Nat) (before : NativeMachine) (f : Control.Fiber)
    (it : RuntimeShape.Iteration) : Prop :=
  it.machine.trace.countP (ReleaseTrace.releaseAt q) + outsideCredits q f.id it.machine +
    returned q it + (it.nested.map (commandCredits q)).sum +
    before.trace.countP (ReleaseTrace.registeredAt q) ≤
  before.trace.countP (ReleaseTrace.releaseAt q) + outsideCredits q f.id before +
    fiberCredits q f + it.machine.trace.countP (ReleaseTrace.registeredAt q)

/-- Existing evaluator cases enter the executable debit without repeating their proofs. -/
theorem of_full (q : List Nat) (before : NativeMachine) (f : Control.Fiber)
    (it : RuntimeShape.Iteration) (debit : IterDebit q before f it) : Debit q before f it := by
  have bounded := returned_le q it
  unfold IterDebit at debit
  unfold Debit
  omega

end Effect4.Program.ReleaseCustody.Executable

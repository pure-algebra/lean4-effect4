import Effect4.Laws.Machine.FiberSum

/-!
Concept: scope-lifetime-finalization R11 and reactive-scheduling R9.
Question: executable custody serves FinalizerRun.once_placed_outside_census.
Consumer: release-custody installation and actual command settlement.
Current code belongs to an idle fiber or its queued evaluator command.
A running fiber without that command retains only its saved reservations.
The reading uses existing fibers and command owners; it introduces no execution carrier.
These algebraic facts establish neither a local debit nor history preservation.
-/
set_option autoImplicit false
namespace Effect4.Machine.ExecutionWeights
open Effect4 Effect4.Machine
universe u v
variable {ν σ : Type u} {β : Type v} {ε δ ι α χ : Type u} {St : Type (max u v)}

/-- Only loop and delivery commands execute the stored current code. -/
def evaluatorOwner : Cmd ν σ β ε δ ι α → Option FiberId
  | .loop owner _ | .deliver owner _ => some owner
  | _ => none

/-- Current code is reserved while idle or owned by an actual queued evaluator. -/
def fiber (active saved : RunFiber ν σ β ε δ ι α χ → Nat) (owners : List FiberId) (f : RunFiber ν σ β ε δ ι α χ) : Nat :=
  (if f.running = true ∧ f.id ∉ owners then 0 else active f) + saved f

/-- The shared fiber sum reads the same positions at this command prefix. -/
def total (active saved : RunFiber ν σ β ε δ ι α χ → Nat) (owners : List FiberId) (m : RunMachine ν σ β ε δ ι α χ St) : Nat :=
  FiberSum.total (fiber active saved owners) m

variable (active saved : RunFiber ν σ β ε δ ι α χ → Nat)

/-- An idle row owns its complete current and saved reservation. -/
theorem idle (owners : List FiberId) (f : RunFiber ν σ β ε δ ι α χ) (idle : f.running = false) :
    fiber active saved owners f = active f + saved f := by
  simp only [fiber, idle, Bool.false_eq_true, false_and, if_false]

/-- A queued evaluator owns the complete current and saved reservation. -/
theorem owned (owners : List FiberId) (f : RunFiber ν σ β ε δ ι α χ) (member : f.id ∈ owners) :
    fiber active saved owners f = active f + saved f := by
  simp only [fiber, member, not_true_eq_false, and_false, if_false]

/-- An overwrite queue leaves the running row's current code unreserved. -/
theorem dormant (owners : List FiberId) (f : RunFiber ν σ β ε δ ι α χ) (running : f.running = true)
    (missing : f.id ∉ owners) : fiber active saved owners f = saved f := by
  unfold fiber
  rw [if_pos ⟨running, missing⟩, Nat.zero_add]

/-- Removing queued evaluators can only discard reservations. -/
theorem fiber_mono (before after : List FiberId) (included : after ⊆ before) (f : RunFiber ν σ β ε δ ι α χ) :
    fiber active saved after f ≤ fiber active saved before f := by
  unfold fiber
  split
  · omega
  · rename_i kept
    split
    · rename_i dropped
      exact False.elim (kept ⟨dropped.1, fun member => dropped.2 (included member)⟩)
    · exact Nat.le_refl _

/-- Discarding a command suffix at a budget cut cannot mint executable custody. -/
theorem total_mono (before after : List FiberId) (included : after ⊆ before)
    (m : RunMachine ν σ β ε δ ι α χ St) : total active saved after m ≤ total active saved before m := by
  unfold total FiberSum.total
  generalize m.fibers = rows
  induction rows with
  | nil => exact Nat.le_refl 0
  | cons f rest ih =>
    simp only [List.map_cons, List.sum_cons]
    exact Nat.add_le_add (fiber_mono active saved before after included f) ih

/-- A keyed installation uses the existing finite-map sum law. -/
theorem install (owners : List FiberId) (m : RunMachine ν σ β ε δ ι α χ St) (id : FiberId)
    (old next : RunFiber ν σ β ε δ ι α χ) (unique : (m.fibers.map RunFiber.id).Nodup)
    (found : m.fiber? id = some old) (key : next.id = id) :
    total active saved owners (m.update next) =
      FiberSum.outside (fiber active saved owners) id m + fiber active saved owners next :=
  FiberSum.install _ m id old next unique found key

/-- Adding an evaluator owner changes no other fiber's weight. -/
theorem other_owner (owner : FiberId) (owners : List FiberId) (f : RunFiber ν σ β ε δ ι α χ) (other : f.id ≠ owner) :
    fiber active saved (owner :: owners) f = fiber active saved owners f := by
  simp only [fiber, List.mem_cons, other, false_or]

/-- The off-owner sum ignores insertion or removal of that owner's evaluator command. -/
theorem outside_owner (owner : FiberId) (owners : List FiberId) (m : RunMachine ν σ β ε δ ι α χ St) :
    FiberSum.outside (fiber active saved (owner :: owners)) owner m =
      FiberSum.outside (fiber active saved owners) owner m := by
  unfold FiberSum.outside
  apply congrArg List.sum
  apply List.map_congr_left
  intro f _
  unfold ControlWeights.omitted
  split
  · rfl
  · rename_i other
    exact other_owner active saved owner owners f other

/-- A selected evaluator moves its full current credit through the shared owner split. -/
theorem selected (owners : List FiberId) (m : RunMachine ν σ β ε δ ι α χ St) (f : RunFiber ν σ β ε δ ι α χ)
    (unique : (m.fibers.map RunFiber.id).Nodup) (found : m.fiber? f.id = some f) :
    total active saved (f.id :: owners) m =
      FiberSum.outside (fiber active saved owners) f.id m + active f + saved f := by
  have split := FiberSum.split (fiber active saved (f.id :: owners)) m f unique
    (RunMachine.mem_of_fiber? found)
  rw [outside_owner, owned active saved _ f (List.mem_cons_self ..)] at split
  simpa only [total, Nat.add_assoc] using split.symm

end Effect4.Machine.ExecutionWeights

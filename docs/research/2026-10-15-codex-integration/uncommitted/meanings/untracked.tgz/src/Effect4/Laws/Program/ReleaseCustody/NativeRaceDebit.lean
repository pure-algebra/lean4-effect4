import Effect4.Laws.Program.ReleaseCustody.NativePrimitiveDebit
import Effect4.Laws.Program.ReleaseCustody.CommandRaceDebit

/-!
Concept: scope-lifetime-finalization R11.
Question: race registration custody serves FinalizerRun.once_placed_outside_census.
Consumer: the unrestricted primitive debit and its executable-current instance.
Race registration changes metadata while retaining every unlaunched program.
This local debit establishes neither race sequencing nor history closure.
-/
set_option autoImplicit false
namespace Effect4.Program.ReleaseCustody.NativeRaceDebit
open Effect4 Effect4.Machine Effect4.Program
open Control

/-- Race registration retains its program reservation at every actual race table. -/
theorem register (q : List Nat) (m : NativeMachine) (fiber : Control.Fiber)
    (yielding : Bool) (raceId : Nat) (unique : (m.races.map Race.id).Nodup) :
    IterDebit q m fiber (registerRace m fiber yielding raceId) := by
  cases found : m.race? raceId with
  | none =>
    simp only [registerRace, found, IterDebit, List.map_nil, List.sum_nil, Nat.add_zero]
    exact Nat.le_refl _
  | some race =>
    have changed := ControlWeights.replace_sum Race.id
      (fun row : Guard.NRace => (row.programs.map (currentCredits q)).sum)
      race {race with registering := true} rfl m.races unique (List.mem_of_find?_eq_some found)
    have programs := Nat.add_right_cancel changed
    unfold IterDebit
    simp only [registerRace, found, outsideCredits, RunMachine.updateRace,
      List.map_cons, List.map_nil, List.sum_cons, List.sum_nil,
      commandCredits, Nat.add_zero, programs]
    exact Nat.le_refl _

end Effect4.Program.ReleaseCustody.NativeRaceDebit

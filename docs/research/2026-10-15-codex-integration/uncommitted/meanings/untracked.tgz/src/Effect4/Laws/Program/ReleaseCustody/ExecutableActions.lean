import Effect4.Laws.Program.ReleaseCustody.Executable
import Effect4.Laws.Program.ReleaseCustody.NativeActionDebit
import Effect4.Laws.Program.PlaceFunding.Actions
import Effect4.Laws.Machine.FiberSumForks
import Effect4.Laws.Machine.StatePreservation

/-!
Concept: scope-lifetime-finalization R11.
Question: parallel custody transfers serve FinalizerRun.once_placed_outside_census.
Consumer: the complete primitive evaluator debit over executable current positions.
The existing action census supplies every ordinary case.
Parallel close transfers the order into its newly appended children.
The returned parent's stored current code is no longer executable at this command cut.
These local debits establish neither sequencing nor history closure.
-/
set_option autoImplicit false
namespace Effect4.Program.ReleaseCustody.Executable
open Effect4 Effect4.Machine Effect4.Program
open Control Sequencing

/-- Birth and other administrative events change neither release count. -/
theorem administrative_counts (q : List Nat) (before after : NativeMachine)
    (quiet : Moves.AdministrativeTrace before after) :
    after.trace.countP (ReleaseTrace.releaseAt q) = before.trace.countP (ReleaseTrace.releaseAt q) ∧
    after.trace.countP (ReleaseTrace.registeredAt q) = before.trace.countP (ReleaseTrace.registeredAt q) := by
  obtain ⟨events, allowed, trace⟩ := quiet
  have release : events.countP (ReleaseTrace.releaseAt q) = 0 := by
    apply List.countP_eq_zero.mpr
    intro event member
    have administrative := List.all_eq_true.mp allowed event member
    cases event <;> cases administrative <;> exact Bool.false_ne_true
  have registered : events.countP (ReleaseTrace.registeredAt q) = 0 := by
    apply List.countP_eq_zero.mpr
    intro event member
    have administrative := List.all_eq_true.mp allowed event member
    cases event <;> cases administrative <;> exact Bool.false_ne_true
  rw [trace, List.countP_append, List.countP_append, release, registered,
    Nat.add_zero, Nat.add_zero]
  exact ⟨rfl, rfl⟩

/-- The existing spawn fold adds at most the finalizer programs' reserved credits. -/
theorem parallel_outside (q : List Nat) (interp : NativeActionDebit.Interp)
    (m : NativeMachine) (f : Control.Fiber) (programs : List NCode) :
    outsideCredits q f.id (forkFinalizers interp m f programs).1 ≤
      outsideCredits q f.id m + (programs.map (currentCredits q)).sum := by
  have bounds := FiberSum.forks_bounds (fiberCredits q) (currentCredits q)
    interp m f f.id programs (by
      intro id code flag budget context
      simp only [fiberCredits, RunFiber.make, FrameFiber.start, stackCredits,
        Dispatcher.empty, List.map_nil, List.sum_nil, Nat.add_zero, Nat.le_refl])
  have state := StatePreservation.forkFinalizers_state interp m f programs
  have races := Guard.FrameOwned.forkFinalizers_races interp m f programs
  unfold outsideCredits
  rw [state, races]
  change _ + FiberSum.outside (fiberCredits q) f.id _ + _ ≤
    _ + FiberSum.outside (fiberCredits q) f.id m + _ + _
  omega

/-- A parallel close transfers its current reservation into its children exactly once. -/
theorem parallel (q : List Nat) (root : NativeEff) (table : RowTable)
    (m : NativeMachine) (f : Control.Fiber) (yielding : Bool) (programs : List NCode)
    (carried : (programs.map (currentCredits q)).sum ≤ currentCredits q f.frame.current) :
    Debit q m f (evaluatePrim.withFiber (interpAt root m.completedExits table) m f yielding (.closePar programs)) := by
  have outside := parallel_outside q (interpAt root m.completedExits table) m f programs
  have counts := administrative_counts q m _
    (Moves.forkFinalizers_administrative (interpAt root m.completedExits table) m f programs)
  have commands : (((forkFinalizers (interpAt root m.completedExits table) m f programs).2.map
      (fun id => (Cmd.evaluate id : Control.Command))).map (commandCredits q)).sum = 0 := by
    simp only [List.map_map, Function.comp_def, commandCredits, PlaceLedger.zero_sum]
  unfold Debit
  simp only [evaluatePrim.withFiber, returned, retained, ite_true, Nat.zero_add,
    List.map_append, List.sum_append, List.map_cons, List.map_nil, List.sum_cons,
    List.sum_nil, commandCredits, Nat.add_zero, commands, counts.1, counts.2, fiberCredits]
  omega

/-- The shared action census now covers parallel closes without a source-fragment premise. -/
theorem action (q : List Nat) (root : NativeEff) (table : RowTable) (m : NativeMachine)
    (f : Control.Fiber) (yielding : Bool) (selected : NAction) (held : NoAdd f.frame.stack)
    (fibers : (m.fibers.map RunFiber.id).Nodup)
    (scopes : (m.state.scopes.entries.map ScopeEntry.key).Nodup) (fresh : m.state.ScopeKeysFresh)
    (carried : NativeActionDebit.demand q selected ≤ currentCredits q f.frame.current) :
    Debit q m f (evaluatePrim.withFiber (interpAt root m.completedExits table) m f yielding selected) := by
  apply NativeActionDebit.action_with q root table m f yielding selected held fibers scopes fresh carried
    (Debit q m f) (fun it debit => of_full q m f it debit)
  intro programs _ bound
  exact parallel q root table m f yielding programs bound

/-- The actual selected action supplies its demand without a lexical or scope-strategy restriction. -/
theorem native_action (q : List Nat) (root : NativeEff) (table : RowTable) (m : NativeMachine)
    (f : Control.Fiber) (yielding : Bool) (thunk : EffThunk) (selected : NAction)
    (current : f.frame.current = .withFiber thunk) (held : Kept f.frame.current f.frame.stack)
    (fibers : (m.fibers.map RunFiber.id).Nodup)
    (scopes : (m.state.scopes.entries.map ScopeEntry.key).Nodup) (fresh : m.state.ScopeKeysFresh)
    (found : (interpAt root m.completedExits table).withFiberOf thunk = some selected) :
    Debit q m f (evaluatePrim.withFiber (interpAt root m.completedExits table) m f yielding selected) := by
  have clean := opaque_noAdd (current ▸ held) (by intro fin phase; cases phase) (by intro phase; cases phase)
  exact action q root table m f yielding selected clean fibers scopes fresh
    (current ▸ NativeActionDebit.producer_demand q root m.completedExits table thunk selected found)

end Effect4.Program.ReleaseCustody.Executable

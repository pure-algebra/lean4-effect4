import Effect4.Laws.Machine.FiberSum

/-!
Concept: scope-lifetime-finalization R11.
Question: lookup transport serves FinalizerRun.once_placed_outside_census.
Consumer: executable custody discounts inactive stored current code across native interference.
Distinct keys prevent two old reservations from sharing one new row.
New rows may add arbitrary nonnegative weight.
-/
set_option autoImplicit false
namespace Effect4.Machine.ControlWeights
universe u v

/-- Filtering one key reads exactly the existing omitted-key projection. -/
theorem filtered_sum {α : Type u} {K : Type v} [DecidableEq K]
    (key : α → K) (weight : α → Nat) (owner : K) : ∀ rows : List α,
    ((rows.filter (fun row => decide (key row ≠ owner))).map weight).sum =
      (rows.map (omitted key weight owner)).sum
  | [] => rfl
  | row :: rows => by
    by_cases same : key row = owner
    · simp only [List.filter_cons, same, ne_eq, not_true_eq_false, decide_false,
        Bool.false_eq_true, if_false, List.map_cons, List.sum_cons, omitted,
        if_true, Nat.zero_add, filtered_sum key weight owner rows]
    · simp only [List.filter_cons, same, ne_eq, not_false_eq_true, decide_true,
        if_true, List.map_cons, List.sum_cons, omitted, if_false,
        filtered_sum key weight owner rows]

/-- Same-key matches with no smaller weight preserve the old total. -/
theorem matched_sum_le {α : Type u} {K : Type v} [DecidableEq K]
    (key : α → K) (weight : α → Nat) : ∀ before after : List α,
    (before.map key).Nodup → (after.map key).Nodup →
    (∀ old ∈ before, ∃ next ∈ after, key next = key old ∧ weight old ≤ weight next) →
    (before.map weight).sum ≤ (after.map weight).sum
  | [], _, _, _, _ => Nat.zero_le _
  | old :: rest, after, distinct, afterDistinct, matches => by
    have beforeDistinct := List.nodup_cons.mp distinct
    obtain ⟨next, member, same, bounded⟩ := matches old (List.mem_cons_self ..)
    let remaining := after.filter (fun row => decide (key row ≠ key next))
    have remainingDistinct : (remaining.map key).Nodup :=
      List.Nodup.sublist ((List.filter_sublist ..).map key) afterDistinct
    have later : ∀ prior ∈ rest, ∃ row ∈ remaining, key row = key prior ∧ weight prior ≤ weight row := by
      intro prior present
      obtain ⟨row, inside, keyed, cost⟩ := matches prior (List.mem_cons_of_mem old present)
      have different : key row ≠ key next := by
        intro equal
        exact beforeDistinct.1 (List.mem_map.mpr ⟨prior, present, keyed.symm.trans (equal.trans same)⟩)
      exact ⟨row, List.mem_filter.mpr ⟨inside, decide_eq_true different⟩, keyed, cost⟩
    have restBound := matched_sum_le key weight rest remaining beforeDistinct.2 remainingDistinct later
    have split := omit_sum key weight next after afterDistinct member
    rw [filtered_sum] at restBound
    simp only [List.map_cons, List.sum_cons]
    omega

end Effect4.Machine.ControlWeights

namespace Effect4.Machine.FiberSum
universe u v
variable {ν σ : Type u} {β : Type v} {ε δ ι α χ : Type u} {St : Type (max u v)}

/-- Forward lookup transport retains every old reservation once. -/
theorem lookup_le (weight : RunFiber ν σ β ε δ ι α χ → Nat)
    (before after : RunMachine ν σ β ε δ ι α χ St)
    (beforeDistinct : (before.fibers.map RunFiber.id).Nodup)
    (afterDistinct : (after.fibers.map RunFiber.id).Nodup)
    (forward : ∀ id old, before.fiber? id = some old →
      ∃ next, after.fiber? id = some next ∧ weight old ≤ weight next) :
    total weight before ≤ total weight after := by
  apply ControlWeights.matched_sum_le RunFiber.id weight before.fibers after.fibers
    beforeDistinct afterDistinct
  intro old member
  have found := RunMachine.fiber?_of_mem beforeDistinct member
  obtain ⟨next, actual, bounded⟩ := forward old.id old found
  exact ⟨next, RunMachine.mem_of_fiber? actual, RunMachine.id_of_fiber? actual, bounded⟩

end Effect4.Machine.FiberSum

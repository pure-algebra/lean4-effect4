import Effect4.Laws.Program.Footprint

/-!
Concept: scope-lifetime-finalization R11 and reactive-scheduling.
Question: charged evaluator assembly serves FinalizerRun.once_placed_outside_census.
Consumers: complete-row and executable-current release custody.
The actual loop has two native entries: its charged row and its forced-yield wrapper.
This producer supplies that case split once; each invariant supplies its two entries.
-/
set_option autoImplicit false
namespace Effect4.Program
open Effect4 Effect4.Machine

/-- Both actual charged entries suffice for any property of the returned iteration. -/
theorem iteration_of_native (root : NativeEff) (table : RowTable) (m : NativeMachine)
    (fiber : RunFiber EffName EffThunk Val Err Defect FiberId Ann Ctx) (yielding : Bool)
    (claim : Iter EffName EffThunk Val Err Defect FiberId Ann Ctx Stores → Prop)
    (plain : claim (evaluateNative root m (countOp (runloopTop fiber)) yielding table))
    (forced : claim (evaluateNative root
      (m.emit [.yieldInjected (countOp (runloopTop fiber)).id (countOp (runloopTop fiber)).currentOpCount])
      {(countOp (runloopTop fiber)) with
        yieldOverride := none
        frame := {(countOp (runloopTop fiber)).frame with
          current := .onSuccessConst (.yieldNowWith 0) (countOp (runloopTop fiber)).frame.current}}
      true table)) :
    claim (Machine.iteration (evaluator := evaluatorFor root table) (interpOf root table) m fiber yielding) := by
  unfold Machine.iteration
  dsimp only
  cases injected : injectYield m (countOp (runloopTop fiber)) yielding with
  | none => exact plain
  | some it =>
    unfold injectYield at injected
    split at injected
    · cases injected
      exact forced
    · cases injected

end Effect4.Program

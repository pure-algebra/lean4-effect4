import Effect4.Laws.Program.ReleaseCustody.ExecutableActions
import Effect4.Laws.Program.ReleaseCustody.NativeScopeDebit
import Effect4.Laws.Program.IterationCases

/-!
Concept: scope-lifetime-finalization R11.
Question: native release custody serves FinalizerRun.once_placed_outside_census.
Consumer: the full command-history invariant over executable current positions.
Every source form uses the same primitive and scoped branch producers.
The iteration uses the common charged-entry producer.
These local debits establish no command-history conclusion by themselves.
-/
set_option autoImplicit false
namespace Effect4.Program.ReleaseCustody.Executable
open Effect4 Effect4.Machine Effect4.Program
open Control Sequencing

/-- All primitive forms share the old census with the executable parallel-close transfer. -/
theorem primitive (q : List Nat) (root : NativeEff) (table : RowTable) (m : NativeMachine)
    (f : Control.Fiber) (yielding : Bool) (held : Kept f.frame.current f.frame.stack)
    (fibers : (m.fibers.map RunFiber.id).Nodup)
    (scopes : (m.state.scopes.entries.map ScopeEntry.key).Nodup) (fresh : m.state.ScopeKeysFresh)
    (races : (m.races.map Race.id).Nodup) :
    Debit q m f (evaluatePrim (interpAt root m.completedExits table) m f yielding) :=
  NativeParkDebit.primitive_with q root table m f yielding held fibers scopes fresh races
    (Debit q m f) (fun it debit => of_full q m f it debit)
    (fun thunk selected current found => native_action q root table m f yielding thunk selected
      current held fibers scopes fresh found)

/-- Scope entry and exit use the same native producer without a source-fragment restriction. -/
theorem native (q : List Nat) (root : NativeEff) (table : RowTable) (m : NativeMachine)
    (f : Control.Fiber) (yielding : Bool) (held : Kept f.frame.current f.frame.stack)
    (fibers : (m.fibers.map RunFiber.id).Nodup)
    (scopes : (m.state.scopes.entries.map ScopeEntry.key).Nodup) (fresh : m.state.ScopeKeysFresh)
    (races : (m.races.map Race.id).Nodup) :
    Debit q m f (evaluateNative root m f yielding table) :=
  NativeScopeDebit.native_with q root table m f yielding held scopes
    (Debit q m f) (fun it debit => of_full q m f it debit)
    (fun rows => primitive q root rows m f yielding held fibers scopes fresh races)

/-- A charged entry spends only the old local reservation. -/
theorem entry (q : List Nat) (before after : NativeMachine) (f next : Control.Fiber)
    (it : RuntimeShape.Iteration) (key : next.id = f.id)
    (outside : outsideCredits q f.id after = outsideCredits q f.id before)
    (starts : after.trace.countP (ReleaseTrace.releaseAt q) = before.trace.countP (ReleaseTrace.releaseAt q))
    (registrations : after.trace.countP (ReleaseTrace.registeredAt q) = before.trace.countP (ReleaseTrace.registeredAt q))
    (bound : fiberCredits q next ≤ fiberCredits q f) (debit : Debit q after next it) :
    Debit q before f it := by
  unfold Debit at debit ⊢
  rw [key, outside, starts, registrations] at debit
  omega

/-- Actual loop charging and yield injection use the same unrestricted native debit. -/
theorem iteration (q : List Nat) (root : NativeEff) (table : RowTable) (m : NativeMachine)
    (f : Control.Fiber) (yielding : Bool) (held : Kept f.frame.current f.frame.stack)
    (fibers : (m.fibers.map RunFiber.id).Nodup)
    (scopes : (m.state.scopes.entries.map ScopeEntry.key).Nodup) (fresh : m.state.ScopeKeysFresh)
    (races : (m.races.map Race.id).Nodup) :
    Debit q m f (Machine.iteration (evaluator := evaluatorFor root table) (interpOf root table) m f yielding) := by
  have kept := NativeSequencing.loop_top f held
  have bound := Evaluation.loop_top_credits q f
  have key : (countOp (runloopTop f)).id = f.id := by
    unfold runloopTop
    split <;> rfl
  apply iteration_of_native root table m f yielding (Debit q m f)
  · exact entry q m m f _ _ key rfl rfl rfl bound
      (native q root table m (countOp (runloopTop f)) yielding kept fibers scopes fresh races)
  · let next : Control.Fiber := {(countOp (runloopTop f)) with
        yieldOverride := none
        frame := {(countOp (runloopTop f)).frame with
          current := .onSuccessConst (.yieldNowWith 0) (countOp (runloopTop f)).frame.current}}
    let after := m.emit [.yieldInjected (countOp (runloopTop f)).id (countOp (runloopTop f)).currentOpCount]
    have debit := native q root table after next true (forced_wrapper kept 0) fibers scopes fresh races
    apply entry q m after f next _ key rfl _ _ _ debit
    · simp only [after, RunMachine.emit_trace, List.countP_append, List.countP_cons, List.countP_nil,
        ReleaseTrace.releaseAt, Bool.false_eq_true, if_false, Nat.add_zero]
    · simp only [after, RunMachine.emit_trace, List.countP_append, List.countP_cons, List.countP_nil,
        ReleaseTrace.registeredAt, Bool.false_eq_true, if_false, Nat.add_zero]
    · dsimp only [next]
      rw [Evaluation.yield_wrapper_credits]
      exact bound

end Effect4.Program.ReleaseCustody.Executable

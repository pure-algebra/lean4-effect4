import Effect4.Laws.Machine.FiberSum

/-!
Concept: scope-lifetime-finalization R11.
Question: parallel release custody serves FinalizerRun.once_placed_outside_census.
Consumer: the native parallel-close debit and the existing zero-weight writer instance.
The existing spawn appends each child's current reservation once.
The bounds allow a missing or colliding owner; freshness belongs to the history invariant.
These local sums establish neither source ownership nor history preservation.
-/
set_option autoImplicit false
namespace Effect4.Machine.FiberSum
open Effect4 Effect4.Machine
universe u v
variable {ν σ : Type u} {β : Type v} {ε δ ι α χ : Type u} {St : Type (max u v)}
variable (weight : RunFiber ν σ β ε δ ι α χ → Nat) (cost : Prim ν σ β ε δ ι α → Nat)

/-- Appending one child retains the old sum and adds at most its program reservation. -/
theorem spawn_bounds (interp : RunInterp ν σ β ε δ ι α χ St)
    (machine : RunMachine ν σ β ε δ ι α χ St) (parent : RunFiber ν σ β ε δ ι α χ) (owner : FiberId) (program : Prim ν σ β ε δ ι α)
    (options : Supervision.ForkOptions) (site : List Nat)
    (born : ∀ id code flag budget context,
      weight (RunFiber.make id code flag budget context) ≤ cost code) :
    outside weight owner machine ≤ outside weight owner (spawn interp machine parent program options site).1 ∧
    outside weight owner (spawn interp machine parent program options site).1 ≤
      outside weight owner machine + cost program := by
  let flag := match options.maskMode with
    | .interruptible => true
    | .uninterruptible => false
    | .inherit => parent.frame.interruptible
  have bounded := born ⟨machine.nextId⟩ program flag (interp.budgetOf parent.context) parent.context
  unfold outside spawn
  simp only [RunMachine.emit, List.map_append, List.sum_append, List.map_cons,
    List.map_nil, List.sum_cons, List.sum_nil, Nat.add_zero]
  change _ ≤ _ + ControlWeights.omitted RunFiber.id weight owner
    (RunFiber.make ⟨machine.nextId⟩ program flag (interp.budgetOf parent.context) parent.context) ∧
    _ + ControlWeights.omitted RunFiber.id weight owner
      (RunFiber.make ⟨machine.nextId⟩ program flag (interp.budgetOf parent.context) parent.context) ≤ _
  unfold ControlWeights.omitted
  split <;> omega

/-- The parallel spawn fold transfers its supplied program reservations at most once. -/
theorem forks_bounds (interp : RunInterp ν σ β ε δ ι α χ St)
    (machine : RunMachine ν σ β ε δ ι α χ St) (parent : RunFiber ν σ β ε δ ι α χ) (owner : FiberId) (programs : List (Prim ν σ β ε δ ι α))
    (born : ∀ id code flag budget context,
      weight (RunFiber.make id code flag budget context) ≤ cost code) :
    outside weight owner machine ≤ outside weight owner (forkFinalizers interp machine parent programs).1 ∧
    outside weight owner (forkFinalizers interp machine parent programs).1 ≤
      outside weight owner machine + (programs.map cost).sum := by
  induction programs generalizing machine with
  | nil => exact ⟨Nat.le_refl _, Nat.le_refl _⟩
  | cons program rest ih =>
    have spawned := spawn_bounds weight cost interp machine parent owner program
      ⟨true, true, .inherit⟩ [] born
    have remaining := ih (spawn interp machine parent program ⟨true, true, .inherit⟩ []).1
    change _ ≤ outside weight owner
      (forkFinalizers interp (spawn interp machine parent program ⟨true, true, .inherit⟩ []).1 parent rest).1 ∧
      outside weight owner
        (forkFinalizers interp (spawn interp machine parent program ⟨true, true, .inherit⟩ []).1 parent rest).1 ≤ _
    simp only [List.map_cons, List.sum_cons]
    constructor <;> omega

end Effect4.Machine.FiberSum

import Effect4.Laws.Program.ReleaseCustody.ExecutableNative
import Effect4.Laws.Program.ReleaseCustody.NativeIterationDebit
import Effect4.Laws.Machine.WriterActions
import ProofGraph.AxiomAudit

#axiom_audit Effect4.Laws.Machine.ExecutionWeights Effect4.Laws.Machine.FiberSumForks Effect4.Laws.Machine.WriterActions Effect4.Laws.Program.IterationCases Effect4.Laws.Program.ReleaseCustody.Executable Effect4.Laws.Program.ReleaseCustody.ExecutableActions Effect4.Laws.Program.ReleaseCustody.ExecutableNative Effect4.Laws.Program.ReleaseCustody.NativeActionDebit Effect4.Laws.Program.ReleaseCustody.NativeRaceDebit Effect4.Laws.Program.ReleaseCustody.NativeParkDebit Effect4.Laws.Program.ReleaseCustody.NativeScopeDebit Effect4.Laws.Program.ReleaseCustody.NativeIterationDebit

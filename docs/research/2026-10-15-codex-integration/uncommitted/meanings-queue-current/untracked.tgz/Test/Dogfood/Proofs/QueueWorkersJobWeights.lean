import Test.Dogfood.Proofs.QueueWorkersJobPotential
import Effect4.Laws.Machine.PrimWeights
import Effect4.Laws.Machine.FrameWeights

/-!
Concept: translation-simulation R10.
Consumer: QueueWorkers.jobs_step, through the actual feeding event and take answer.
The generated primitive fold retains selected job multiplicity in existing code and saved frames.
A feeding push issues its allowance; a take answer transfers an existing queue occurrence.
The source callback and native bounds remain separate obligations.
-/
set_option autoImplicit false
namespace Test.Dogfood.Proofs.QueueWorkersJobWeights
open Effect4 Effect4.Machine Effect4.Program
open Test.Dogfood.Scenario.QueueWorkers
open QueueWorkersJobPotential

/-- Captured source callback and operation weights use the existing names and thunks. -/
structure Leaves where
  names : PrimWeights.Model EffName EffThunk
  savedSuccess : EffName → Nat

/-- The existing feeding observation issues exactly its resolved selected job occurrence. -/
def issued (selected : Nat) : EffName → Nat
  | .cont point =>
    if point.path == offerEntryPath then
      match (point.env[10]? : Option Val) with
      | some (.nat job) => occurrence selected job
      | _ => 0
    else 0
  | _ => 0

/-- The existing observation determines the actual feeding event's selected allowance. -/
def eventCredit (selected : Nat) (event : RunEvent EffName EffThunk Val Err Defect FiberId Ann Ctx) : Nat :=
  match fedAt event with
  | some (.nat job) => occurrence selected job
  | _ => 0

/-- Callback issuance reads the same actual push as the public feeding observation. -/
theorem issued_event (selected : Nat) (callback : EffName) (fiber : FiberId) (body : NCode) :
    eventCredit selected (.frame fiber (.pushed (.onSuccess body callback))) = issued selected callback := by
  cases callback
  case cont point =>
    by_cases here : (point.path == offerEntryPath) = true
    · simp only [eventCredit, fedAt, issued, if_pos here]
    · simp only [eventCredit, fedAt, issued, if_neg here]
  all_goals rfl

/-- This algebra exchanges issued feeding credit and actual optional-answer credit. -/
abbrev algebra (selected : Nat) (leaves : Leaves) :
    PrimAlgebra EffName EffThunk Val Err Defect FiberId Ann (Nat × Nat) :=
  { PrimWeights.pairedAlgebra (β := Val) (ε := Err) (δ := Defect) (ι := FiberId) (α := Ann) leaves.names leaves.savedSuccess with
    prim_success := fun value => (optionCredit selected value, 0)
    prim_onSuccess := fun body callback =>
      (body.1 + leaves.names.successName callback + leaves.names.successPush callback - issued selected callback,
        leaves.savedSuccess callback)
    prim_iterator := fun callback cursor =>
      (leaves.names.name callback + optionCredit selected cursor,
        leaves.names.name callback + optionCredit selected cursor)
    prim_whileLoop := fun callback cursor =>
      (leaves.names.name callback + optionCredit selected cursor,
        leaves.names.name callback + optionCredit selected cursor) }

abbrev pair (selected : Nat) (leaves : Leaves) (code : NCode) : Nat × Nat :=
  cata_prim (algebra selected leaves) code
abbrev current (selected : Nat) (leaves : Leaves) (code : NCode) := (pair selected leaves code).1
abbrev saved (selected : Nat) (leaves : Leaves) (code : NCode) := (pair selected leaves code).2

/-- Administrative masks add no selected job occurrence to the saved suffix. -/
theorem ensure_saved (selected : Nat) (leaves : Leaves) (code : NCode)
    (fiber : FrameFiber EffName EffThunk Val Err Defect FiberId Ann) :
    ((code.ensure fiber).1.stack.map (saved selected leaves)).sum =
      (fiber.stack.map (saved selected leaves)).sum := by
  fun_cases Prim.ensure code fiber
  all_goals simp only [saved, List.map_cons, List.sum_cons, Nat.zero_add]

/-- A hook replacement is a failure and carries no selected job occurrence. -/
theorem ensure_answer (selected : Nat) (leaves : Leaves) (code : NCode)
    (fiber : FrameFiber EffName EffThunk Val Err Defect FiberId Ann) (next : NCode)
    (found : (code.ensure fiber).2 = some next) : current selected leaves next = 0 := by
  revert found
  fun_cases Prim.ensure code fiber
  all_goals intro found
  all_goals aesop (add norm simp [current, pair, cata_prim])

/-- The existing frame accounting consumes the two projections of the generated fold. -/
def model (selected : Nat) (leaves : Leaves) : FrameWeights.Model EffName EffThunk Val Err Defect FiberId Ann where
  current := current selected leaves
  saved := saved selected leaves
  ensure_stack := fun code fiber => Nat.le_of_eq (ensure_saved selected leaves code fiber)
  ensure_replacement := ensure_answer selected leaves

/-- Issuance pays exactly the actual body's push; it assumes no future callback result. -/
theorem push_bound (selected : Nat) (leaves : Leaves) (body : NCode) (callback : EffName)
    (reserved : leaves.savedSuccess callback ≤ leaves.names.successName callback + leaves.names.successPush callback) :
    current selected leaves body + saved selected leaves (.onSuccess body callback) ≤
      current selected leaves (.onSuccess body callback) + issued selected callback := by
  change current selected leaves body + leaves.savedSuccess callback ≤
    current selected leaves body + leaves.names.successName callback + leaves.names.successPush callback -
      issued selected callback + issued selected callback
  omega

end Test.Dogfood.Proofs.QueueWorkersJobWeights

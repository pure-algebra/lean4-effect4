import Test.Dogfood.Scenario.QueueWorkers.Ledger

/-!
Concept: translation-simulation R10.
Consumer: QueueWorkers.jobs_step, through actual answer-carried queue conservation.
Each selected job has its own natural-number potential, including repeated payloads.
The take result supplies its allowance; unrelated successful values supply none.
-/
set_option autoImplicit false
namespace Test.Dogfood.Proofs.QueueWorkersJobPotential
open Effect4 Effect4.Machine Effect4.Program

/-- One occurrence of the selected job contributes one unit. -/
def occurrence (selected job : Nat) : Nat := if job = selected then 1 else 0

/-- Only an actual optional job result carries a terminal or retry-cursor allowance. -/
def optionCredit (selected : Nat) : Val → Nat
  | .some (.nat job) => occurrence selected job
  | _ => 0

/-- Only a successful singleton take result carries a removed queue occurrence. -/
def takeCredit (selected : Nat) : Queue.Model.TakeReply → Nat
  | .got [job] => occurrence selected job
  | _ => 0

/-- A selected count exposes one concrete occurrence without a generic ordering instance. -/
theorem count_cons (selected job : Nat) (jobs : List Nat) :
    (job :: jobs).count selected = jobs.count selected + occurrence selected job := by
  by_cases same : job = selected
  · subst job
    simp only [List.count_cons_self, occurrence, ↓reduceIte]
  · simp only [List.count_cons_of_ne same, occurrence, if_neg same, Nat.add_zero]

/-- The actual take answer receives exactly the multiplicity removed from the queue. -/
theorem take_transfer (selected : Nat) (state : Queue.Model.State)
    (profile : Queue.Model.FirstProfile state) (request : Nat) :
    (Queue.Model.stateJobs state).count selected =
      (Queue.Model.stateJobs (Queue.Model.take state ⟨request, 1, 1⟩).1).count selected +
        takeCredit selected (Queue.Model.take state ⟨request, 1, 1⟩).2.1 := by
  rcases Queue.Model.take_jobs profile request with obtained | waiting
  · obtain ⟨job, answer, jobs⟩ := obtained
    rw [answer, jobs]
    exact count_cons selected job _
  · rw [waiting.1, waiting.2]
    rfl

/-- The real encoded option receives exactly the queue occurrence removed by its take. -/
theorem take_encoded_transfer (selected : Nat) (state : Queue.Model.State)
    (profile : Queue.Model.FirstProfile state) (request : Nat) (reply : Val)
    (encoded : Queue.Model.takeReplyVal Val.nat (Queue.Model.take state ⟨request, 1, 1⟩).2.1 = some reply) :
    (Queue.Model.stateJobs state).count selected =
      (Queue.Model.stateJobs (Queue.Model.take state ⟨request, 1, 1⟩).1).count selected +
        optionCredit selected reply := by
  rcases Queue.Model.take_jobs profile request with obtained | waiting
  · obtain ⟨job, answer, jobs⟩ := obtained
    rw [answer] at encoded
    have same : reply = .some (.nat job) := (Option.some.inj encoded).symm
    rw [same, jobs]
    exact count_cons selected job _
  · rw [waiting.1] at encoded
    have same : reply = .none := (Option.some.inj encoded).symm
    rw [same, waiting.2]
    rfl

/-- A committed offer receives exactly its feeder occurrence, accepted or still pending. -/
theorem offer_transfer (selected : Nat) (state : Queue.Model.State)
    (profile : Queue.Model.FirstProfile state) (request job : Nat) :
    (Queue.Model.stateJobs (Queue.Model.offer state request job).1).count selected =
      (Queue.Model.stateJobs state).count selected + occurrence selected job := by
  rw [Queue.Model.offer_jobs profile request job, List.count_append]
  have singleton := count_cons selected job []
  simpa only [List.count_nil, Nat.zero_add] using congrArg
    (fun count => (Queue.Model.stateJobs state).count selected + count) singleton

end Test.Dogfood.Proofs.QueueWorkersJobPotential

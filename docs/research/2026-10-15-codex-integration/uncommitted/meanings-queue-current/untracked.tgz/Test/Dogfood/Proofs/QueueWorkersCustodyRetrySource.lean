import Test.Dogfood.Proofs.QueueWorkersCustodyRetry
import Test.Dogfood.Scenario.Programs

/-!
Concept: translation-simulation R10.
Consumer: QueueWorkers.Assertions.jobs_step, through the actual typed retry-loop hook.
The existing address fold certifies the two request loops' option tests and identity steps.
The body producer and whole-history request ownership remain separate obligations.
-/
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
namespace Test.Dogfood.Proofs.QueueWorkersCustodyRetrySource
open Effect4 Effect4.Machine Effect4.Program
open Test.Dogfood.Scenario
open QueueWorkersCustody

/-- Every actual none-initialized loop is the waiter's option-result loop. -/
def head (root : NativeEff) (path : List Nat) : Node NativeOp → Bool
  | .eff (.iterate _ (.app "none" .nil) test step result _) =>
      let level := (SourceScope.levelAt (.eff root) 0 path).getD 0
      decide (test = retryTest level ∧ step = .var (level + 1) ∧ result = .var level)
  | _ => true

/-- Both actual request loops have the classified retry shape, for every job total. -/
theorem census (total : Nat) :
    (Node.addresses (.eff (Programs.queueProgram total))).all (fun path =>
      (Node.at_ (.eff (Programs.queueProgram total)) path).all (head (Programs.queueProgram total) path)) = true := by
  kernel_rfl

/-- An actual source retry point supplies the exact interpreter hook equations. -/
theorem loop_shape (total : Nat) (point : Point) (cursorTy : Option Ty)
    (test step result : Term) (body : NativeEff)
    (source : SourceScope.At (Programs.queueProgram total) point)
    (found : Node.at_ (.eff (Programs.queueProgram total)) point.path =
      some (.eff (.iterate cursorTy (.app "none" .nil) test step result body))) :
    loopAt (Programs.queueProgram total) point =
      some (retryTest point.env.length, .var (point.env.length + 1), body) ∧
    loopResultAt (Programs.queueProgram total) point = some (.var point.env.length) := by
  have member : point.path ∈ Node.addresses (.eff (Programs.queueProgram total)) :=
    (mem_addresses_iff (.eff (Programs.queueProgram total)) point.path).mpr (by rw [found]; rfl)
  have checked := List.all_eq_true.mp (census total) point.path member
  rw [found] at checked
  change decide (test = retryTest ((SourceScope.levelAt (.eff (Programs.queueProgram total)) 0 point.path).getD 0) ∧
    step = .var ((SourceScope.levelAt (.eff (Programs.queueProgram total)) 0 point.path).getD 0 + 1) ∧
    result = .var ((SourceScope.levelAt (.eff (Programs.queueProgram total)) 0 point.path).getD 0)) = true at checked
  rw [source] at checked
  obtain ⟨testEq, stepEq, resultEq⟩ := of_decide_eq_true checked
  subst test step result
  simp only [loopAt, loopResultAt, found]
  exact ⟨rfl, rfl⟩

end Test.Dogfood.Proofs.QueueWorkersCustodyRetrySource

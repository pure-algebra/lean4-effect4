import Test.Dogfood.Proofs.QueueWorkersTakeBinding
open Effect4 Effect4.Program
set_option maxRecDepth 100000
set_option maxHeartbeats 16000000
#eval (Node.addresses (.eff (Test.Dogfood.Scenario.Programs.queueProgram 0))).filterMap fun path =>
  match Node.at_ (.eff (Test.Dogfood.Scenario.Programs.queueProgram 0)) path with
  | some (.eff (.perform (.refModifyWith _) _)) =>
    some (path, SourceScope.levelAt (.eff (Test.Dogfood.Scenario.Programs.queueProgram 0)) 0 path)
  | _ => none

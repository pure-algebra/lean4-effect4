import Test.Dogfood.Scenario.QueueWorkers
set_option maxRecDepth 1000000
set_option maxHeartbeats 16000000
open Effect4 Effect4.Machine Effect4.Program
open Test.Dogfood Test.Dogfood.Scenario Test.Dogfood.Scenario.QueueWorkers
def earlyMoves : List Move := [.cancel ⟨0⟩, .flush]
def earlyRun : Option Run := (P3WorkerQueue.built? (crew 2)).map fun b => Scenario.play (opened b) earlyMoves
#eval earlyRun.map (fun s => (funded s, Run.atRest s, earlyMoves.all Move.hostAct, (observe s).settled, (observe s).queue.view.isSome))
example : earlyRun.map (fun s => (funded s, Run.atRest s, earlyMoves.all Move.hostAct, (observe s).settled)) = some (true,true,true,true) := by kernel_rfl

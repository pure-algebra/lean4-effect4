import Test.Dogfood.Scenario.QueueWorkers
set_option maxRecDepth 1000000
set_option maxHeartbeats 16000000
open Test.Dogfood.Scenario Test.Dogfood.Scenario.QueueWorkers
#eval runsAndControls.1.map (fun named => (named.name, terminalRepliesCheck named.played))
#guard runsAndControls.1.all (fun named => terminalRepliesCheck named.played)

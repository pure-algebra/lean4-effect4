import Effect4.Laws.Program.AnswerSlots.InitializedExecution
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.TypedScopes Effect4.Laws.Program.AnswerSlots.InitializedCounts Effect4.Laws.Program.AnswerSlots.InitializedScoped Effect4.Laws.Program.AnswerSlots.InitializedExecution

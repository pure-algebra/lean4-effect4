import Test.Dogfood.Scenario.QueueWorkers
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
open Effect4 Effect4.Machine Effect4.Program
open Test.Dogfood.Scenario Test.Dogfood.Scenario.QueueWorkers
 def refMoves : List Move := parked ++ [.receive feederCall (.ofRefGet ⟨4⟩), .apply feederCall, .flush]
def runRef : Option Run := (Test.Dogfood.P3WorkerQueue.built? (crew 2)).map fun b => play (opened b) refMoves
#eval runRef.map (fun s => s.phases)
#eval runRef.map (fun s => (observe s).fed)
#eval runRef.map (fun s => (observe s).held)
#eval runRef.map (fun s => funded s)

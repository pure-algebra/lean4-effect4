import Effect4.Laws.Program.AnswerSlots.Actions
import Effect4.Laws.Program.CodeClosure.Qualified.Stable
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.CodeClosure.Compile Effect4.Laws.Program.AnswerSlots.Compile Effect4.Laws.Program.CodeClosure.Qualified.Callbacks

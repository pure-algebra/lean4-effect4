import Test.Dogfood.Proofs.QueueWorkersLogValues
open Effect4 Effect4.Program Test.Dogfood.Scenario
#eval (Node.addresses (.eff (Programs.queueProgram 0))).filterMap (fun path =>
  match Node.at_ (.eff (Programs.queueProgram 0)) path with
  | some (.eff (.perform row request)) =>
    match row with
    | .refMake | .refUpdateWith _ | .refModifyWith _ | .refModifySomeWith _ | .refSet | .refGetAndSet
    | .refSetAndGet | .refGetAndUpdateWith _ | .refUpdateAndGetWith _ | .refUpdateSomeWith _
    | .refGetAndUpdateSomeWith _ | .refUpdateSomeAndGetWith _ => some (path, (match row with | .refMake => 0 | .refUpdateWith _ => 1 | .refModifyWith _ => 2 | .refUpdateAndGetWith _ => 3 | _ => 4), (match request with | .var index => some index | _ => none))
    | _ => none
  | _ => none)

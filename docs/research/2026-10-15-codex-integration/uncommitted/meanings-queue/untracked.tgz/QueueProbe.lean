import Test.Dogfood.Scenario.QueueWorkers.Assertions
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000

open Effect4 Effect4.Machine Effect4.Program Test.Dogfood.Scenario
#reduce Node.at_ (.eff (Programs.queueProgram 1)) (Programs.queueAcquire 1 ++ [1])
#reduce Node.at_ (.eff (Programs.queueProgram 1)) (Programs.queueAcquire 2 ++ [1])
#reduce Node.at_ (.eff (Programs.queueProgram 1)) (Programs.queueAcquire 3 ++ [1])

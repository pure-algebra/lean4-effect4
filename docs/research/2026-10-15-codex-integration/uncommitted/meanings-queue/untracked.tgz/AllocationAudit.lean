import Effect4.Laws.Program.AnswerSlots.AllocationAdapter
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.AllocationAdapter

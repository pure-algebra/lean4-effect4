import Effect4.Laws.Program.AnswerSlots.InitializedQueue
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.InitializedQueue

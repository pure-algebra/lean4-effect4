import Effect4.Laws.Program.Guard.NativeQueueAssembly
import Effect4.Laws.Program.Guard.Observer
import Effect4.Laws.Program.AnswerSlots.InitializedAdmin
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.Interference Effect4.Laws.Program.Guard.Core Effect4.Laws.Program.Guard.FinishQueue Effect4.Laws.Program.Guard.Messages Effect4.Laws.Program.Guard.NativeQueueTail Effect4.Laws.Program.Guard.NativeStateLinks Effect4.Laws.Program.Guard.Observer Effect4.Laws.Program.Guard.RegistrationQueue Effect4.Laws.Program.Guard.SettleQueue Effect4.Laws.Program.AnswerSlots.InitializedAdmin

import Effect4.Laws.Program.AnswerSlots.InitializedScopes
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.InitializedScopes

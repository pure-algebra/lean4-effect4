import Test.Dogfood.Scenario.QueueWorkers.RefReplyControl
set_option maxRecDepth 1000000
set_option maxHeartbeats 16000000
open Effect4 Effect4.Machine Effect4.Program
open Test.Dogfood.Scenario.QueueWorkers
#eval RefReplyControl.run.map fun s => s.machine.trace.filterMap fun
  | .frame ⟨3⟩ (.pushed (.onSuccess _ (.cont p))) =>
    some (p.path, p.env.length, p.env.filterMap (fun v => match v with | .nat n => some n | _ => none))
  | _ => none

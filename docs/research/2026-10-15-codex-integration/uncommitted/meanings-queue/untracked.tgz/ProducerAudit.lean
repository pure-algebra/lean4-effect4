import Effect4.Laws.Program.AnswerSlots.InitializedNative
import Effect4.Laws.Program.AnswerSlots.InitializedOtherRows
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.InitializedNative Effect4.Laws.Program.AnswerSlots.InitializedOtherRows

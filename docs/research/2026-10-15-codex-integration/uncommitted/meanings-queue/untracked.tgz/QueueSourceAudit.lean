import Test.Dogfood.Scenario.QueueWorkers.WriterSource
import Effect4.Laws.Program.AnswerSlots.TypedAcquisition
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.Initialization Effect4.Laws.Program.AnswerSlots.Ordinary Test.Dogfood.Scenario.QueueWorkers.InitialSlots Test.Dogfood.Scenario.QueueWorkers.ReleaseWrites Test.Dogfood.Scenario.QueueWorkers.Connections Test.Dogfood.Scenario.QueueWorkers.WriterSource

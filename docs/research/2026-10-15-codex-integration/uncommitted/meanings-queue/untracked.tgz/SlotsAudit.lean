import Effect4.Laws.Program.AnswerSlots.Actions
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.Interp Effect4.Laws.Program.AnswerSlots.Actions

import Effect4.Laws.Program.AnswerSlots.InitializedNativeRows
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.NativeFrameRows Effect4.Laws.Program.AnswerSlots.InitializedNativeRows

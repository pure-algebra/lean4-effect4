import Effect4.Laws.Machine.WriterWeights
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Machine.FrameWeights Effect4.Laws.Machine.WriterWeights

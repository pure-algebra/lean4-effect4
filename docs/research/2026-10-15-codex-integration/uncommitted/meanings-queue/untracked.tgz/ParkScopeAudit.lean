import Effect4.Laws.Program.AnswerSlots.TypedScopes
import Effect4.Laws.Program.AnswerSlots.InitializedNativeParks
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.TypedScopes Effect4.Laws.Program.AnswerSlots.InitializedNativeParks

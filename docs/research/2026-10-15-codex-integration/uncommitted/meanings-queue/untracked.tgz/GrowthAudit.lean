import Effect4.Laws.Program.AnswerSlots.InitializedGrowth
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.NativeStatePreservation Effect4.Laws.Program.AnswerSlots.InitializedGrowth

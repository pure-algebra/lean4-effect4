import Effect4.Laws.Program.AnswerSlots.InitializedSync
import Effect4.Laws.Machine.AnswerFlowResume
import Test.Dogfood.Proofs.QueueWorkersLogValues
import Test.Dogfood.Scenario.QueueWorkers.RefReplyControl
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.Initialized Effect4.Laws.Program.AnswerSlots.InitializedPhases Effect4.Laws.Program.AnswerSlots.InitializedTransport Effect4.Laws.Program.AnswerSlots.InitializedSync Effect4.Laws.Machine.AnswerFlowResume Test.Dogfood.Proofs.QueueWorkersLogValues Test.Dogfood.Scenario.QueueWorkers.RefReplyControl

import Effect4.Laws.Program.AnswerSlots.InitializedCounts
import Effect4.Laws.Program.AnswerSlots.InitializedIteration
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.InitializedCounts Effect4.Laws.Program.AnswerSlots.InitializedIteration

import Effect4.Laws.Program.AnswerSlots.InitializedAdmin
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.InitializedAdmin

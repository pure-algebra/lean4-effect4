import Test.Dogfood.Proofs.QueueWorkersRequestKeys
import Test.Dogfood.Proofs.QueueWorkersCustodySelections
import Effect4.Laws.Program.CodeClosure.Compile

/-!
Concept: translation-simulation R10 and store-typing R4.
Consumer: QueueWorkers.Assertions.jobs_step, through actual request allocation and bind inputs.
Each real fiber selects one logical request; its native key is published by the actual allocator.
A captured request class becomes empty when its owner selects a later request.
The native source graph and coupled history attachment remain separate obligations.
-/
set_option autoImplicit false
namespace Test.Dogfood.Proofs.QueueWorkersCustodyFlow
open Effect4 Effect4.Machine Effect4.Program
open QueueWorkersCustody

/-- Active request selection belongs to the real fiber, including repeated source iterations. -/
structure World where
  requests : QueueWorkersRequestKeys.World
  active : FiberId → Option Nat
  next : Nat

/-- Unallocated logical requests have neither a payload nor a published native key. -/
def Fresh (world : World) : Prop :=
  ∀ token, world.next ≤ token →
    world.requests.custody.requests token = .fresh ∧ world.requests.keys token = none

/-- Captured callbacks retain their request's key while its custody phase advances. -/
def Future (first last : World) : Prop :=
  QueueWorkersRequestKeys.Future first.requests last.requests ∧ first.next ≤ last.next

/-- The actual callback world advances without assuming that a fiber keeps the same request. -/
def order : Effect4.Laws.Effects.WorldOrder World where
  le := Future
  refl _world := ⟨⟨QueueWorkersCustody.order.refl _, fun _ _ held => held⟩, Nat.le_refl _⟩
  trans one two := ⟨⟨fun token => (one.1.1 token).trans (two.1.1 token),
    fun token key held => two.1.2 token key (one.1.2 token key held)⟩,
    Nat.le_trans one.2 two.2⟩

/-- Inner callbacks retain the literal request captured when their key was returned. -/
def Owns (world : World) (owner : FiberId) (token : Nat) : Prop :=
  world.active owner = some token

/-- Actual successful inputs distinguish a new key, a take result and the delivered job. -/
inductive Kind
  | ordinary
  | newKey (owner : FiberId)
  | captured (owner : FiberId) (token : Nat) (input : QueueWorkersCustody.Kind)
  | job (owner : FiberId)

/-- The outer job binder reads its owner's current request; inner binders retain their literal token. -/
def ValueAt (world : World) : Kind → Val → Prop
  | .ordinary, _ => True
  | .newKey owner, value => ∃ token, Owns world owner token ∧
      QueueWorkersRequestKeys.KeyAt world.requests token value
  | .captured owner token input, value => Owns world owner token ∧
      QueueWorkersCustody.ValueAt world.requests.custody input value
  | .job owner, .nat job => ∃ token, Owns world owner token ∧
      world.requests.custody.requests token = .holding job
  | _, _ => False

/-- A later request cannot consume an old captured callback's successful input. -/
theorem stale_input (world : World) (owner : FiberId) (old current : Nat)
    (different : old ≠ current) (selected : world.active owner = some current)
    (input : QueueWorkersCustody.Kind) (value : Val) :
    ¬ ValueAt world (.captured owner old input) value := by
  intro held
  exact different (Option.some.inj (held.1.symm.trans selected))

/-- Starting an unused request changes no existing held occurrence. -/
theorem waiting_credits (world : QueueWorkersCustody.World) (credits : Credits world)
    (token : Nat) (fresh : world.requests token = .fresh) :
    Credits (setStage world token .waiting) := by
  obtain ⟨claims, unique, counted, phases⟩ := credits
  refine ⟨claims, unique, counted, ?_⟩
  intro selected job
  by_cases same : selected = token
  · subst selected
    constructor
    · intro held
      change (if token = token then Stage.waiting else world.requests token) = .holding job at held
      rw [if_pos rfl] at held
      cases held
    · intro member
      have held := (phases token job).mpr member
      rw [fresh] at held
      cases held
  · simpa only [setStage, if_neg same] using phases selected job

/-- The actual request allocation starts one unused token and publishes its returned native key. -/
def allocate (world : World) (owner : FiberId) (key : DeferredKey) : World :=
  { requests := QueueWorkersRequestKeys.publish
      {world.requests with custody := setStage world.requests.custody world.next .waiting}
      world.next key
    active := fun selected => if selected = owner then some world.next else world.active selected
    next := world.next + 1 }

/-- Starting one request preserves every other fiber's actual selected request. -/
theorem allocate_other (world : World) (owner other : FiberId) (key : DeferredKey)
    (different : other ≠ owner) : (allocate world owner key).active other = world.active other := by
  exact if_neg different

/-- A real allocator cut returns the same proof world for its key, custody and freshness facts. -/
theorem allocate_native (world : World) (owner : FiberId) (state after : Stores) (value : Val)
    (fresh : Fresh world) (credits : Credits world.requests.custody)
    (bound : QueueWorkersRequestKeys.Bound world.requests state)
    (unique : QueueWorkersRequestKeys.Unique world.requests)
    (ran : syncOpStep .deferredMake state = some (after, value)) :
    let next := allocate world owner ⟨state.deferreds.cells.length⟩
    Future world next ∧ ValueAt next (.newKey owner) value ∧
      Credits next.requests.custody ∧ Fresh next ∧
      QueueWorkersRequestKeys.Bound next.requests after ∧
      QueueWorkersRequestKeys.Unique next.requests := by
  have unused := fresh world.next (Nat.le_refl _)
  let waiting : QueueWorkersRequestKeys.World :=
    {world.requests with custody := setStage world.requests.custody world.next .waiting}
  have phase : (waiting.custody.requests world.next).Pending := by
    change (if world.next = world.next then Stage.waiting else _).Pending
    rw [if_pos rfl]
    trivial
  have allocated := QueueWorkersRequestKeys.allocated waiting world.next state after value
    unused.2 phase bound unique ran
  refine ⟨⟨?_, Nat.le_add_right _ _⟩, ?_, ?_, ?_, allocated.2.2.1, allocated.2.2.2⟩
  · refine ⟨?_, allocated.1.2⟩
    exact QueueWorkersCustody.setStage_future world.requests.custody world.next .waiting
      (unused.1 ▸ Advances.fresh .waiting)
  · refine ⟨world.next, ?_, allocated.2.1⟩
    change (if owner = owner then some world.next else world.active owner) = some world.next
    exact if_pos rfl
  · exact waiting_credits world.requests.custody credits world.next unused.1
  · intro token later
    change world.next + 1 ≤ token at later
    have different : token ≠ world.next := by omega
    have old := fresh token (by omega)
    constructor
    · change (if token = world.next then Stage.waiting else world.requests.custody.requests token) = .fresh
      exact (if_neg different).trans old.1
    · change (if token = world.next then some ⟨state.deferreds.cells.length⟩ else world.requests.keys token) = none
      exact (if_neg different).trans old.2

/-- The outer worker binder's actual job class owns an occurrence in the conserving ledger. -/
theorem job_member (world : World) (owner : FiberId) (job : Nat)
    (credits : Credits world.requests.custody) (answer : ValueAt world (.job owner) (.nat job)) :
    job ∈ world.requests.custody.ledger.custody := by
  obtain ⟨token, _, holding⟩ := answer
  exact Credits.member world.requests.custody credits token job holding

/-- Assignment spends the request selected by the actual classified job input. -/
def assigned (world : World) (token job worker : Nat) : World :=
  {world with requests := {world.requests with custody := assignWorld world.requests.custody token job worker}}

/-- The actual assignment write consumes its classified answer and returns the matching spent class.
This cut uses no independent job-membership or conclusion-shaped conservation premise. -/
theorem assignment_native (world : World) (owner : FiberId) (job worker : Nat)
    (credits : Credits world.requests.custody) (conserved : world.requests.custody.ledger.Conserved)
    (answer : ValueAt world (.job owner) (.nat job))
    (env : List Val) (index : Nat) (captured : env[index]? = some (.nat job)) (stores : Stores)
    (read : refPeek stores.refs ⟨3⟩ = some (.list
      (world.requests.custody.ledger.assigned.map (fun p =>
        Test.Dogfood.Scenario.QueueWorkers.gave p.1 p.2)))) :
    ∃ token, Owns world owner token ∧
      syncOpStep (.refUpdate ⟨3⟩ (assignmentTerm env.length index worker) env) stores =
        some ({stores with refs := refPoke stores.refs ⟨3⟩ (.list
          ((assigned world token job worker).requests.custody.ledger.assigned.map (fun p =>
            Test.Dogfood.Scenario.QueueWorkers.gave p.1 p.2)))}, .unit) ∧
      Future world (assigned world token job worker) ∧
      (assigned world token job worker).requests.custody.ledger.Conserved ∧
      Credits (assigned world token job worker).requests.custody ∧
      ValueAt (assigned world token job worker) (.captured owner token (.spent token)) .unit := by
  obtain ⟨token, owns, holding⟩ := answer
  have member := Credits.member world.requests.custody credits token job holding
  obtain ⟨native, future, conserving, spent⟩ := assignment_commit world.requests.custody token job worker
    holding member conserved env index captured stores read
  have counted := assignment_owned world.requests.custody credits token job worker holding conserved
  exact ⟨token, owns, native, ⟨⟨future, fun _ _ old => old⟩, Nat.le_refl _⟩,
    conserving, counted.2, owns, spent⟩

/-- The actual option-unwrapping source returns its own request's held job to the outer worker binder. -/
theorem unwrap_job (root : NativeEff) (point : Point) (fuel : Nat)
    (scrutinee : Term) (fallback : NativeEff) (world : World) (owner : FiberId) (token job : Nat)
    (available : point.fuel = fuel + 2)
    (found : Node.at_ (.eff root) point.path = some (.eff
      (.select scrutinee .option fallback (.succeed (.var point.env.length)))))
    (selected : evalTerm point.env scrutinee = some (.some (.nat job)))
    (input : ValueAt world (.captured owner token (.takeOption token)) (.some (.nat job))) :
    suspendBodyAt root (.body point) = .success (.nat job) ∧
      ValueAt world (.job owner) (.nat job) := by
  exact ⟨select_payload root point fuel scrutinee fallback job available found selected,
    token, input.1, input.2⟩

/-- A spent assignment cannot be replayed using the same owner's old successful job input. -/
theorem assigned_no_job (world : World) (owner : FiberId) (token job worker : Nat)
    (owns : Owns world owner token) (previous : Val) :
    ¬ ValueAt (assigned world token job worker) (.job owner) previous := by
  intro input
  cases previous with
  | nat value =>
    obtain ⟨other, selected, phase⟩ := input
    have same : other = token := Option.some.inj (selected.symm.trans owns)
    subst other
    change (if token = token then Stage.spent job else world.requests.custody.requests token) = .holding value at phase
    rw [if_pos rfl] at phase
    cases phase
  | _ => exact input

end Test.Dogfood.Proofs.QueueWorkersCustodyFlow

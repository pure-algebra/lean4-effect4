import Effect4.Laws.Program.AnswerSlots.TypedHead
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.TypedFamily Effect4.Laws.Program.AnswerSlots.TypedHead

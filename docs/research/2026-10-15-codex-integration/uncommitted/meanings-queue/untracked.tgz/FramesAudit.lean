import Effect4.Laws.Program.AnswerSlots.InitializedFrames
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.NativeStatePreservation Effect4.Laws.Program.AnswerSlots.InitializedGrowth Effect4.Laws.Program.AnswerSlots.InitializedFrames

import Effect4.Laws.Program.AnswerSlots.InitializedNative
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Machine.AnswerFlowViewsRefined Effect4.Laws.Program.AnswerSlots.TypedFamily Effect4.Laws.Program.AnswerSlots.TypedHead Effect4.Laws.Program.AnswerSlots.Initialized Effect4.Laws.Program.AnswerSlots.InitializedHead Effect4.Laws.Program.AnswerSlots.InitializedTransport Effect4.Laws.Program.AnswerSlots.InitializedFrame

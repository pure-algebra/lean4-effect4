import Effect4.Laws.Program.AnswerSlots.Stable
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.Stable

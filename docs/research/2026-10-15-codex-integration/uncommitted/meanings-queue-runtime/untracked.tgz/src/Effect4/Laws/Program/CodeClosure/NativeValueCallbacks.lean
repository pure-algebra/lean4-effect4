import Effect4.Laws.Program.CodeClosure.Predicate
import Effect4.Laws.Program.NativeScope

/-!
Concept: store-typing R4 and translation-simulation R10.
Consumers: Qualified.contA_with and actual Queue and Timeout source callback instances.
Incoming names select their own source leaves and native minted permissions.
The value callback case analysis occurs only in this producer.
-/
set_option autoImplicit false
namespace Effect4.Program.CodeClosure.NativeValueCallbacks
open Effect4 Effect4.Machine Effect4.Program

/-- The direct callback profile excludes the existing unsupported layer callback family. -/
def Direct : EffName → Prop
  | .provideLayerWith _ | .provideLayerBody _ | .buildWithScopeFromContext _ _
  | .withMemoMapThen _ _ | .fromBuildThen _ _ | .memoize _ _ _ | .buildIntoLayerScope _ _ _
  | .thenBuildInto _ _ _ | .freshThen _ _ | .provideThen _ _ _ _ | .mergeChildren _ _
  | .mergeForkOne _ _ _ _ _ | .mergeForkNext _ _ _ _ _ | .mergeAllChildren _ _
  | .mergeAllForkOne _ _ _ _ _ | .mergeAllForkNext _ _ _ _ _ => False
  | _ => True

/-- Existing native callbacks mint these names at their actual constructor slots. -/
inductive NameMint : EffName → EffName → Prop
  | scopeProvide (p : Point) (scope : Nat) : NameMint (.scopeOpen p) (.scopeProvide p scope)
  | scopeClose (p : Point) (scope : Nat) : NameMint (.scopeOpen p) (.scopeClose scope)
  | scopeBody (p : Point) (scope : Nat) (previous : Ctx) : NameMint (.scopeProvide p scope) (.scopeBody p previous)
  | restoreScope (p : Point) (previous : Ctx) : NameMint (.scopeBody p previous) (.restoreCtx previous)
  | acquired (p : Point) (ctx : Ctx) (scope : Nat) : NameMint (.acquireIn p ctx) (.acquired p ctx scope)
  | afterScopeAdd (p : Point) (ctx : Ctx) (scope : Nat) (value : Val) :
      NameMint (.acquired p ctx scope) (.afterScopeAdd value (.foreign (p.capture value ctx)))
  | constant (value : Val) (fin : FinName) : NameMint (.afterScopeAdd value fin) (.constant value)
  | releaseBody (p : Point) (ctx previous : Ctx) (exit : ExitV) :
      NameMint (.releaseUnder p ctx exit) (.releaseBody p exit previous)
  | bodyThen (update : Env.ContextUpdate) (body : Region) (flag : Bool) (previous : Ctx) :
      NameMint (.updateThen update body flag) (.bodyThen body previous flag)
  | restoreBody (body : Region) (previous : Ctx) (flag : Bool) :
      NameMint (.bodyThen body previous flag) (.restoreCtx previous)

/-- Existing native callbacks mint only these thunk templates in the direct profile. -/
inductive ThunkMint : EffName → EffThunk → Prop
  | forkIn (p : Point) (scope : Nat) : ThunkMint (.forkScopedIn p) (.forkInAt p scope)
  | scopeContext (p : Point) : ThunkMint (.scopeOpen p) .getCtx
  | scopeSet (p : Point) (scope : Nat) (ctx : Ctx) : ThunkMint (.scopeProvide p scope) (.setCtx ctx)
  | acquire (p : Point) (ctx : Ctx) : ThunkMint (.acquireCtx p) (.acquireMasked p ctx)
  | registration (p : Point) (ctx : Ctx) (scope : Nat) (value : Val) :
      ThunkMint (.acquired p ctx scope) (.op (.scopeAdd scope (.foreign (p.capture value ctx))))
  | releaseSet (p : Point) (ctx previous : Ctx) (exit : ExitV) :
      ThunkMint (.releaseUnder p ctx exit) (.setCtx previous)
  | release (p : Point) (exit : ExitV) (previous : Ctx) :
      ThunkMint (.releaseBody p exit previous) (.releaseMasked (p.childWith 1 (reifyExitVal exit)) previous)
  | provide (update : Env.ContextUpdate) (body : Region) (flag : Bool) :
      ThunkMint (.provideMask update body) (.provideMasked update body flag)
  | updateRestore (update : Env.ContextUpdate) (body : Region) (flag : Bool) :
      ThunkMint (.updateThen update body flag) (.restoreRegion body flag)
  | updateSet (update : Env.ContextUpdate) (body : Region) (flag : Bool) (ctx : Ctx) :
      ThunkMint (.updateThen update body flag) (.setCtx ctx)
  | bodyRestore (body : Region) (previous : Ctx) (flag : Bool) :
      ThunkMint (.bodyThen body previous flag) (.restoreRegion body flag)

/-- Native constructors consume the caller's exact name and thunk predicates. -/
structure Builders (names : EffName → Prop) (thunks : EffThunk → Prop) (P : NCode → Prop) : Prop where
  success : ∀ value, P (.success value)
  failure : ∀ cause, P (.failure cause)
  sync : ∀ thunk, thunks thunk → P (.sync thunk)
  suspend : ∀ thunk, thunks thunk → P (.suspend thunk)
  withFiber : ∀ thunk, thunks thunk → P (.withFiber thunk)
  onSuccess : ∀ body name, P body → names name → (∀ source, name ≠ .cont source) → P (.onSuccess body name)
  onSuccessConst : ∀ body next, P body → P next → P (.onSuccessConst body next)
  onFailure : ∀ body name, P body → names name → P (.onFailure body name)
  onSuccessAndFailure : ∀ body value cause, P body → names value → names cause → P (.onSuccessAndFailure body value cause)
  onExit : ∀ body name flag, P body → names name → P (.onExit body name flag)
  exitFrame : ∀ body, P body → P (.exitFrame body)
  setInterruptible : ∀ flag, P (.setInterruptible flag)
  iterator : ∀ name cursor, names name → P (.iterator name cursor)
  whileLoop : ∀ name cursor, names name → P (.whileLoop name cursor)
  async : ∀ name flag cancel, names name → (∀ callback ∈ cancel, names callback) → P (.async name flag cancel)
  asyncFinalizer : ∀ name, names name → P (.asyncFinalizer name)

/-- Every source leaf reads the permission of the actual incoming callback constructor. -/
structure Leaves (root : NativeEff) (names : EffName → Prop) (P : NCode → Prop) : Prop where
  cont : ∀ p value, names (.cont p) → P (resolve root (p.childWith 1 value))
  onValue : ∀ p value, names (.onValue p) → P (resolve root (p.childWith 1 value))
  scopeBody : ∀ p previous, names (.scopeBody p previous) → P (resolve root (p.child 0))
  acquireIn : ∀ p ctx, names (.acquireIn p ctx) → P (resolve root (p.child 0))
  stored : ∀ name value, names (.store name) → P (embed (Effect4.Machine.contAOf name value))
  finalizer : ∀ value fin exit, names (.afterScopeAdd value fin) → P (embed (finProgram fin exit))

/-- Minting preserves the selected incoming domain without broad stored or park permissions. -/
structure Minting (names : EffName → Prop) (thunks : EffThunk → Prop) : Prop where
  direct : ∀ name, names name → Direct name
  name : ∀ source target, names source → NameMint source target → names target
  thunk : ∀ source target, names source → ThunkMint source target → thunks target

/-- The sole native value callback walk consumes exact incoming names and actual source leaves. -/
theorem contA (root : NativeEff) (names : EffName → Prop) (thunks : EffThunk → Prop) (P : NCode → Prop)
    (builders : Builders names thunks P) (leaves : Leaves root names P) (minting : Minting names thunks)
    (name : EffName) (value : Val) (held : names name) : P (contAOf root name value) := by
  revert held
  fun_cases contAOf root name value
  all_goals intro held
  all_goals have direct := minting.direct _ held
  all_goals aesop (rule_sets := [Effect4.CodeClosure])
    (add norm simp [Direct, Prim.ofExit, badShape])
    (add norm unfold [updateThenK, addCurrentMemoMapK, combineWithK, mergeContextsK, serviceLookupK, bindServiceK])
    (add safe apply [leaves.cont, leaves.onValue, leaves.scopeBody, leaves.acquireIn, leaves.stored, leaves.finalizer,
      builders.success, builders.failure, builders.sync, builders.suspend, builders.withFiber, builders.onSuccess,
      builders.onSuccessConst, builders.onFailure, builders.onSuccessAndFailure, builders.onExit, builders.exitFrame,
      builders.setInterruptible, builders.iterator, builders.whileLoop, builders.async, builders.asyncFinalizer,
      minting.name, minting.thunk])
    (add safe constructors [NameMint, ThunkMint])
end Effect4.Program.CodeClosure.NativeValueCallbacks

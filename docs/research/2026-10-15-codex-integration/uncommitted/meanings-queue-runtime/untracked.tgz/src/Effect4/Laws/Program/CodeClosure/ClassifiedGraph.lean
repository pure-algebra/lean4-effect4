import Effect4.Laws.Machine.AnswerFlowHead
import Effect4.Program.Compile

/-!
Concept: store-typing R4 and scope-lifetime-finalization R11.
Consumer: Typed.head and the queue's actual classified source binders.
The existing constructor graph is parameterized by its actual name and thunk permissions.
A supplied leaf may reuse a separately checked current-head producer.
This graph supplies no callback, native operation or history permission by itself.
-/
set_option autoImplicit false
namespace Effect4.Program.CodeClosure.ClassifiedGraph
open Effect4 Effect4.Machine Effect4.Program Effect4.Machine.AnswerFlow
universe w

/-- Constructor permissions retain the actual child and classified success name together. -/
structure Policy (World Kind : Type w) where
  rootKind : Kind
  value : World → Kind → Val → Prop
  cause : World → Kind → Cause Err Defect FiberId Ann → Prop
  binding : World → Kind → Kind → NCode → EffName → Prop
  thunk : World → Kind → EffThunk → Prop
  suspended : World → Kind → EffThunk → Prop
  ordinary : World → Kind → Prop
  name : World → EffName → Prop
  simple : World → Kind → NCode → Prop
  overlay : World → Kind → NCode → Prop → Prop := fun _ _ _ held => held

/-- The single classified constructor graph retains immediate code children exactly once. -/
@[reducible] def Code {World Kind : Type w} (policy : Policy World Kind) (world : World) (kind : Kind) : NCode → Prop
  | .success value => policy.overlay world kind (.success value) (policy.value world kind value)
  | .failure cause => policy.overlay world kind (.failure cause) (policy.cause world kind cause)
  | .onSuccess body name => policy.overlay world kind (.onSuccess body name)
      (∃ input, Code policy world input body ∧ policy.binding world input kind body name)
  | .onSuccessConst body next => policy.overlay world kind (.onSuccessConst body next)
      (Code policy world policy.rootKind body ∧ Code policy world kind next)
  | .sync thunk => policy.overlay world kind (.sync thunk) (policy.thunk world kind thunk)
  | .suspend thunk => policy.overlay world kind (.suspend thunk) (policy.suspended world kind thunk)
  | .withFiber thunk => policy.overlay world kind (.withFiber thunk) (policy.thunk world kind thunk)
  | .onFailure body name => policy.overlay world kind (.onFailure body name)
      (policy.ordinary world kind ∧ Code policy world policy.rootKind body ∧ policy.name world name)
  | .onExit body name flag => policy.overlay world kind (.onExit body name flag)
      (policy.ordinary world kind ∧ Code policy world policy.rootKind body ∧ policy.name world name)
  | .onSuccessAndFailure body success failure => policy.overlay world kind (.onSuccessAndFailure body success failure)
      (policy.ordinary world kind ∧ Code policy world policy.rootKind body ∧
        policy.name world success ∧ policy.name world failure)
  | .exitFrame body => policy.overlay world kind (.exitFrame body)
      (policy.ordinary world kind ∧ Code policy world policy.rootKind body)
  | .iterator name cursor => policy.overlay world kind (.iterator name cursor)
      (policy.ordinary world kind ∧ policy.name world name)
  | .whileLoop name cursor => policy.overlay world kind (.whileLoop name cursor)
      (policy.ordinary world kind ∧ policy.name world name)
  | .asyncFinalizer name => policy.overlay world kind (.asyncFinalizer name)
      (policy.ordinary world kind ∧ policy.name world name)
  | .async register signal cancel => policy.overlay world kind (.async register signal cancel)
      (policy.ordinary world kind ∧ policy.name world register ∧ ∀ name ∈ cancel, policy.name world name)
  | code => policy.overlay world kind code (policy.simple world kind code)

variable {World Kind : Type w} (policy : Policy World Kind)
variable (model : Model (ν := EffName) (σ := EffThunk) (β := Val) (ε := Err)
  (δ := Defect) (ι := FiberId) (α := Ann) World Kind)
variable (interp : PrimInterp EffName EffThunk Val Err Defect FiberId Ann)
variable (Edge : World → Kind → Kind → NCode → Prop)

/-- Existing callbacks and primitive producers discharge the local constructor permissions. -/
structure Rules : Prop where
  code : ∀ world kind code, Code policy world kind code → model.code world kind code
  unwrap : ∀ world kind code held, policy.overlay world kind code held →
    HeadAt model interp Edge world kind code ∨ held
  value : ∀ world kind value, policy.value world kind value → model.value world kind value
  cause : ∀ world kind cause, policy.cause world kind cause → model.cause world kind cause
  sync : ∀ world kind thunk, policy.thunk world kind thunk → model.value world kind (interp.syncValue thunk)
  suspend : ∀ world kind thunk, policy.suspended world kind thunk → model.code world kind (interp.suspendBody thunk)
  withFiber : ∀ world kind thunk, policy.thunk world kind thunk → model.code world kind (interp.suspendBody thunk)
  binding : ∀ world input output body name, policy.binding world input output body name →
    Edge world input output (.onSuccess body name)
  constant : ∀ world output body next, model.code world output next →
    Edge world policy.rootKind output (.onSuccessConst body next)
  failed : ∀ world output body name, policy.ordinary world output → policy.name world name →
    Edge world policy.rootKind output (.onFailure body name)
  both : ∀ world output body success failure, policy.ordinary world output →
    policy.name world success → policy.name world failure →
    Edge world policy.rootKind output (.onSuccessAndFailure body success failure)
  exited : ∀ world output body, policy.ordinary world output → Edge world policy.rootKind output (.exitFrame body)
  finalized : ∀ world output body name flag, policy.ordinary world output → policy.name world name →
    Edge world policy.rootKind output (.onExit body name flag)
  iterator : ∀ world output name cursor, policy.ordinary world output → policy.name world name →
    HeadAt model interp Edge world output (.iterator name cursor)
  loop : ∀ world output name cursor, policy.ordinary world output → policy.name world name →
    HeadAt model interp Edge world output (.whileLoop name cursor)
  async : ∀ world output register signal cancel, policy.ordinary world output → policy.name world register →
    (∀ name ∈ cancel, policy.name world name) → model.code world output (.async register signal cancel)
  asyncFinalizer : ∀ world output name, policy.ordinary world output → policy.name world name →
    model.cause world output (.die interp.notImplemented)
  error : ∀ world output error, policy.simple world output (.yieldableError error) → model.cause world output (.fail error)
  mask : ∀ world output flag, policy.simple world output (.setInterruptible flag) → model.cause world output (.die interp.notImplemented)
  yielding : ∀ world output priority, policy.simple world output (.yieldNowWith priority) →
    model.code world output (.yieldNowWith priority)

/-- The existing current-head case split is shared by supplied classified name and thunk policies. -/
theorem head (rules : Rules policy model interp Edge) (world : World) (kind : Kind) (code : NCode)
    (owned : Code policy world kind code) : HeadAt model interp Edge world kind code := by
  cases code
  all_goals refine (rules.unwrap _ _ _ _ owned).elim (fun finished => finished) ?_
  all_goals intro held
  case success value => exact .success value (rules.value _ _ _ held)
  case failure cause => exact .failure cause (rules.cause _ _ _ held)
  case sync thunk => exact .sync thunk (rules.sync _ _ _ held)
  case suspend thunk => exact .suspend thunk (rules.suspend _ _ _ held)
  case withFiber thunk => exact .withFiber thunk (rules.withFiber _ _ _ held)
  case yieldableError error => exact .yieldableError error (rules.error _ _ _ held)
  case onSuccess body name =>
    obtain ⟨input, first, callback⟩ := held
    exact .onSuccess input body name (rules.code _ _ _ first) (rules.binding _ _ _ _ _ callback)
  case onSuccessConst body next =>
    exact .onSuccessConst policy.rootKind body next (rules.code _ _ _ held.1)
      (rules.constant _ _ _ _ (rules.code _ _ _ held.2))
  case onFailure body name =>
    exact .onFailure policy.rootKind body name (rules.code _ _ _ held.2.1)
      (rules.failed _ _ _ _ held.1 held.2.2)
  case onSuccessAndFailure body success failure =>
    exact .onSuccessAndFailure policy.rootKind body success failure (rules.code _ _ _ held.2.1)
      (rules.both _ _ _ _ _ held.1 held.2.2.1 held.2.2.2)
  case exitFrame body =>
    exact .exitFrame policy.rootKind body (rules.code _ _ _ held.2)
      (rules.exited _ _ _ held.1)
  case onExit body name flag =>
    exact .onExit policy.rootKind body name flag (rules.code _ _ _ held.2.1)
      (rules.finalized _ _ _ _ _ held.1 held.2.2)
  case iterator name cursor => exact rules.iterator _ _ _ _ held.1 held.2
  case whileLoop name cursor => exact rules.loop _ _ _ _ held.1 held.2
  case async register signal cancel => exact .async register signal cancel (rules.async _ _ _ _ _ held.1 held.2.1 held.2.2)
  case asyncFinalizer name => exact .asyncFinalizer name (rules.asyncFinalizer _ _ _ held.1 held.2)
  case setInterruptible flag => exact .setInterruptible flag (rules.mask _ _ _ held)
  case yieldNowWith priority => exact .yieldNowWith priority (rules.yielding _ _ _ held)
end Effect4.Program.CodeClosure.ClassifiedGraph

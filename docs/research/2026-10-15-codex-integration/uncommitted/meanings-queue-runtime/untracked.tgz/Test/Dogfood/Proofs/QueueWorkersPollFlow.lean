import Test.Dogfood.Proofs.QueueWorkersOuterSites

/-!
Concept: translation-simulation R10.
Consumer: QueueWorkers.jobs_step, at the actual root poll and subsequent root answer.
A polled job remains in custody until the root publishes its answer.
The existing queue poll law supplies the actual cell transition.
-/
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
namespace Test.Dogfood.Proofs.QueueWorkersPollFlow
open Effect4 Effect4.Machine Effect4.Program
open Test.Dogfood.Scenario Test.Dogfood.Scenario.QueueWorkers
open QueueWorkersCustody

/-- Polling removes one queue occurrence into unfinished root custody. -/
def ledger (before : Accounting.Ledger) (run : Queue.Model.Run) : Accounting.Ledger :=
  {before with queue := some (Queue.Model.step .none run .poll)
    custody := (Queue.Model.poll run.s).2.1.toList ++ before.custody}

/-- The root poll retains the exact conserving ledger before its answer becomes observable. -/
theorem conserved (before : Accounting.Ledger) (run : Queue.Model.Run)
    (queue : before.queue = some run) (profile : Queue.Model.FirstProfile run.s)
    (held : before.Conserved) : (ledger before run).Conserved := by
  apply permutation_of_counts
  intro job
  have counts := held.count_eq job
  change before.fed.count job = _ at counts
  simp only [Accounting.Ledger.heldJobs, Accounting.Ledger.cellJobs, Accounting.stateJobs, queue,
    List.count_append] at counts
  change before.fed.count job = _
  simp only [ledger, Accounting.Ledger.heldJobs, Accounting.Ledger.cellJobs, Accounting.stateJobs,
    Queue.Model.step, Queue.Model.bump, List.count_append]
  rcases Queue.Model.poll_jobs profile with empty | obtained
  · rw [empty.1, empty.2]
    simpa only [Option.toList_none, List.count_nil, Nat.zero_add] using counts
  · obtain ⟨taken, answer, jobs⟩ := obtained
    rw [jobs, List.count_cons] at counts
    rw [answer]
    simp only [Option.toList_some, List.count_cons]
    omega

/-- A root request keeps its selected option while notification and source callbacks run. -/
def world (before : QueueWorkersCustody.World) (run : Queue.Model.Run) (token : Nat) : QueueWorkersCustody.World :=
  match (Queue.Model.poll run.s).2.1 with
  | none => {before with ledger := ledger before.ledger run}
  | some job => setStage {before with ledger := ledger before.ledger run} token (.holding job)

/-- Polling keeps every previously published key and advances only its root request. -/
theorem future (before : QueueWorkersCustody.World) (run : Queue.Model.Run) (token : Nat)
    (waiting : before.requests token = .waiting) : Future before (world before run token) := by
  unfold world
  split
  · exact order.refl before
  · rename_i job _
    intro selected
    by_cases same : selected = token
    · subst selected
      simpa only [setStage, ↓reduceIte, waiting] using Advances.receive job
    · simpa only [setStage, if_neg same] using Advances.refl (before.requests selected)

/-- The selected poll option is the exact root request's pending or held value. -/
theorem option (before : QueueWorkersCustody.World) (run : Queue.Model.Run) (token : Nat)
    (waiting : before.requests token = .waiting) :
    OptionAt (world before run token) token (Queue.Model.pollReplyVal Val.nat (Queue.Model.poll run.s).2.1) := by
  cases selected : (Queue.Model.poll run.s).2.1 with
  | none => simpa only [world, selected, Queue.Model.pollReplyVal, OptionAt] using waiting
  | some job => simp only [world, selected, Queue.Model.pollReplyVal, OptionAt, setStage, ↓reduceIte]

/-- The actual root poll preserves finite occurrence credits, including an empty result. -/
theorem credits (before : QueueWorkersCustody.World) (run : Queue.Model.Run) (token : Nat)
    (waiting : before.requests token = .waiting) (held : Credits before) : Credits (world before run token) := by
  unfold world
  split
  · rename_i selected
    apply held.reledger
    simp only [ledger, selected, Option.toList_none, List.nil_append]
  · rename_i job selected
    apply held.receive token job waiting
    simp only [ledger, selected, Option.toList_some, List.singleton_append]

/-- The root's actual poll commit sits under the last result binding. -/
def path : List Nat := QueueWorkersOuterSites.rootPath ++ [0, 0, 0]

def term : Term :=
  match Node.at_ (.eff (Programs.queueProgram 0)) path with
  | some (.eff (.perform (.refModifyWith term) _)) => term
  | _ => .lit .unit

/-- The concrete root writer addresses only the declared queue reference. -/
theorem source (total : Nat) :
    Node.at_ (.eff (Programs.queueProgram total)) path =
      some (.eff (.perform (.refModifyWith term) (.var 0))) := by kernel_rfl

/-- The root retains its ten captured values at the actual poll writer. -/
theorem level (total : Nat) : SourceScope.levelAt (.eff (Programs.queueProgram total)) 0 path = some 10 := by
  kernel_rfl
open Effect4.Modules Effect4.Program.Authoring

/-- The root poll opens its local term at the ten actual captured bindings. -/
def environment : Env := {names := List.replicate 10 ""}

/-- The concrete root operation is the existing Queue poll term, with no reconstructed algorithm. -/
theorem tree :
    Queue.pollStep .nat (minted (environment.mint "current"))
      (environment.push [environment.mint "current"]) path = .ok term := by kernel_rfl

/-- The actual root poll commits its encoded model cell and its exact pending root option together. -/
theorem source_step (before : QueueWorkersCustody.World) (run : Queue.Model.Run) (token : Nat)
    (queue : before.ledger.queue = some run) (profile : Queue.Model.FirstProfile run.s)
    (counted : before.ledger.Conserved) (owned : Credits before) (waiting : before.requests token = .waiting)
    (table : Queue.Model.Table) (point : Point) (depth : point.env.length = 10)
    (stores : Stores) (held : refPeek stores.refs ⟨0⟩ = some (Queue.Model.cellVal table Val.nat run.s)) :
    ∃ entered : List Queue.Model.Offer,
      Queue.Model.Notified run.s (Queue.Model.poll run.s).1 (Queue.Model.poll run.s).2.2 entered [] ∧
      syncOpStep (.refModify ⟨0⟩ term point.env) stores =
        some ({stores with refs := refPoke stores.refs ⟨0⟩
          (Queue.Model.cellVal table Val.nat (Queue.Model.poll run.s).1)},
          Val.tuple [Queue.Model.pollReplyVal Val.nat (Queue.Model.poll run.s).2.1,
            .list (entered.map (Queue.Model.offerVal table Val.nat))]) ∧
      Future before (world before run token) ∧ (world before run token).ledger.Conserved ∧
      Credits (world before run token) ∧
      OptionAt (world before run token) token (Queue.Model.pollReplyVal Val.nat (Queue.Model.poll run.s).2.1) := by
  have captured : point.env.length = environment.names.length := depth
  obtain ⟨entered, notified, reads⟩ := Queue.Model.pollStep_agrees .nat table Val.nat run.s profile
    (push_minted_length captured "current" _) (reads_minted_last captured path "current" _)
  obtain ⟨actualTerm, compiled, executed⟩ := step_updates held reads
  have same : actualTerm = term := Except.ok.inj (compiled.symm.trans tree)
  subst actualTerm
  refine ⟨entered, notified, executed, future before run token waiting, ?_,
    credits before run token waiting owned, option before run token waiting⟩
  unfold world
  split
  · exact conserved before.ledger run queue profile counted
  · exact conserved before.ledger run queue profile counted

end Test.Dogfood.Proofs.QueueWorkersPollFlow

import Test.Dogfood.Proofs.QueueWorkersOfferWrapper
import Test.Dogfood.Proofs.QueueWorkersWorkerBinding

/-!
Concept: store-typing R4 and translation-simulation R10.
Consumer: QueueWorkers.jobs_step, through the actual outer compiler's protected binders.
The generated address fold separates the worker, feeder and root poll binding bodies.
No callback obtains a job permission from this source certificate alone.
-/
set_option autoImplicit false
set_option maxRecDepth 100000
set_option maxHeartbeats 16000000
namespace Test.Dogfood.Proofs.QueueWorkersOuterSites
open Effect4 Effect4.Machine Effect4.Program
open Test.Dogfood.Scenario Test.Dogfood.Scenario.QueueWorkers

/-- The actual feeder host binder precedes its observed offer entry. -/
def feederPath : List Nat := offerEntryPath.dropLast

/-- The root binds its final poll before constructing its answer tuple. -/
def rootPath : List Nat := List.replicate 10 1

/-- These four binders consume classified answers rather than ordinary source answers. -/
def boundaries : List (List Nat) :=
  [QueueWorkersWorkerBinding.path 1, QueueWorkersWorkerBinding.path 2, feederPath, rootPath]

/-- A boundary itself remains visible; only its strict descendants use its local producer. -/
def outer (path : List Nat) : Bool :=
  boundaries.all fun boundary => decide (¬ (boundary.IsPrefix path ∧ boundary ≠ path))

/-- An ordinary source child cannot cross a protected root without visiting that root first. -/
theorem outer_child (path : List Nat) (index : Nat)
    (held : outer path = true) (ordinary : boundaries.contains path = false) :
    outer (path ++ [index]) = true := by
  apply List.all_eq_true.mpr
  intro boundary member
  apply decide_eq_true
  intro crossed
  rcases List.prefix_concat_iff.mp crossed.1 with same | earlier
  · exact crossed.2 same
  · have excluded := of_decide_eq_true (List.all_eq_true.mp held boundary member)
    apply excluded
    refine ⟨earlier, ?_⟩
    intro same
    subst boundary
    have present : boundaries.contains path = true := List.contains_iff_mem.mpr member
    rw [ordinary] at present
    cases present

/-- The feeder's actual host answer is bound before the observed offer entry. -/
theorem feeder_source (total : Nat) :
    Node.at_ (.eff (Programs.queueProgram total)) feederPath = some (.eff
      (.bind (.perform (.external 0) (.lit .unit))
        (.bind (.withFiber .getInterruptible) (.uninterruptible (QueueWorkersOfferWrapper.allocation total))))) := by
  kernel_rfl

/-- The real feeder binding appends its answer at the offer entry's source point. -/
theorem feeder_child : feederPath ++ [1] = offerEntryPath := by kernel_rfl

/-- An ordinary compiler branch retains only children outside the protected binding bodies. -/
def head (path : List Nat) : Node NativeOp → Bool
  | .eff (.bind _ _) =>
    if outer path && !boundaries.contains path then outer (path ++ [0]) && outer (path ++ [1]) else true
  | .eff (.perform (.refModifyWith _) _) => !outer path
  | .eff (.perform (.refUpdateWith _) (.var 3)) => !outer path
  | _ => true

/-- The existing address fold checks every actual queue writer and outer binder. -/
theorem census (total : Nat) :
    (Node.addresses (.eff (Programs.queueProgram total))).all (fun path =>
      (Node.at_ (.eff (Programs.queueProgram total)) path).all (head path)) = true := by
  kernel_rfl

/-- An actual outer source head receives the checked local constructor contract. -/
theorem source_head (total : Nat) (path : List Nat) (node : Node NativeOp)
    (found : Node.at_ (.eff (Programs.queueProgram total)) path = some node) : head path node = true := by
  have addressed : path ∈ Node.addresses (.eff (Programs.queueProgram total)) :=
    (mem_addresses_iff (.eff (Programs.queueProgram total)) path).mpr (by rw [found]; rfl)
  have checked := List.all_eq_true.mp (census total) path addressed
  rw [found] at checked
  exact checked

/-- Every ordinary binder sends both children to the same outer source certificate. -/
theorem binder_children (total : Nat) (point : Point) (first rest : NativeEff)
    (found : Node.at_ (.eff (Programs.queueProgram total)) point.path = some (.eff (.bind first rest)))
    (held : outer point.path = true) (ordinary : boundaries.contains point.path = false) :
    outer (point.path ++ [0]) = true ∧ outer (point.path ++ [1]) = true := by
  have checked := source_head total point.path _ found
  change (if outer point.path && !boundaries.contains point.path then _ else true) = true at checked
  rw [held, ordinary] at checked
  exact Bool.and_eq_true_iff.mp checked

end Test.Dogfood.Proofs.QueueWorkersOuterSites

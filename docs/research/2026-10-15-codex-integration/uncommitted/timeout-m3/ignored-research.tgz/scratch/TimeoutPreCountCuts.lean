import Test.Dogfood.Proofs.HostTimeoutNumberConfiguration
import Test.Dogfood.Scenario.Timeout
open Effect4 Effect4.Machine Effect4.Program Test.Dogfood.Scenario.Timeout
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
#eval match Effect4.Api.Author.build fetch with
| .error _ => []
| .ok b =>
  letI := evaluatorFor b.program b.table
  let interp := interpOf b.program b.table
  let start := Api.load b.program budget.compileFuel
  ((List.range 120).map fun fuel =>
    let cutMachine := (driveState interp fuel start [.evaluate ⟨0⟩, .drainDue]).1
    (fuel, cutMachine.state.refs, cutMachine.fibers.map fun (f : Effect4.Program.SourceScope.SourceFiber) => (f.id, f.running, f.frame.stack.length))).filter fun (x : Nat × RefHeap × List (FiberId × Bool × Nat)) =>
      x.2.1[0]? == some (Val.nat 0) && 1 < x.2.2.length

import Test.Dogfood.Proofs.HostTimeoutNumberConfiguration
import Test.Dogfood.Scenario.Timeout
open Effect4 Effect4.Machine Effect4.Program Test.Dogfood.Scenario.Timeout
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
#eval match Effect4.Api.Author.build fetch with
| .error _ => []
| .ok b =>
  letI := evaluatorFor b.program b.table
  let interp := interpOf b.program b.table
  let cut := driveState interp 27 (Api.load b.program budget.compileFuel) [.evaluate ⟨0⟩, .drainDue]
  let interrupted := (stepDecisionState interp 2000 cut.1 (.interruptFrom none .empty ⟨1⟩)).1
  (driveState interp 2000 interrupted cut.2).1.state.refs

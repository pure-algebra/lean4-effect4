import Test.Dogfood.Scenario.Timeout
open Effect4 Effect4.Machine Test.Dogfood.Scenario Test.Dogfood.Scenario.Timeout
#eval match Effect4.Api.Author.build fetch with
| .error _ => []
| .ok b => ([[], [.start], [.start, .cancel ⟨0⟩], [.start, .cancel ⟨1⟩], [.start, .cancel ⟨0⟩, .flush]] : List (List Move)).map fun moves =>
  let o := observe (Test.Dogfood.Scenario.play (opened b) moves)
  (o.attempts, o.cleanups, o.forms.length)

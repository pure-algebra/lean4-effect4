import Test.Dogfood.Scenario.Timeout
open Effect4 Effect4.Machine Test.Dogfood.Scenario Test.Dogfood.Scenario.Timeout
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
#eval match Effect4.Api.Author.build fetch with
| .error _ => []
| .ok b => ((List.range 12).flatMap fun fuel => (List.range 20).map fun steps =>
    let moves : List Move := [Effect4.Run.Event.start] ++ List.replicate steps Effect4.Run.Event.flush ++ [Effect4.Run.Event.cancel ⟨1⟩] ++ List.replicate 20 Effect4.Run.Event.flush
    let s := Test.Dogfood.Scenario.play (Run.open b "timeout" {budget with fuel := fuel + 1})
      moves
    let o := observe s
    (fuel + 1, steps, o.attempts, o.cleanups, o.cleanupKeeps)).filter fun (x : Nat × Nat × Nat × List Val × Bool) => !x.2.2.2.2

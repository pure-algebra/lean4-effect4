import Test.Dogfood.Scenario.Timeout
open Effect4 Effect4.Machine Effect4.Program Test.Dogfood.Scenario.Timeout
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
#eval match Effect4.Api.Author.build fetch with
| .error _ => []
| .ok b =>
  letI := evaluatorFor b.program b.table
  let interp := interpOf b.program b.table
  let start := Api.load b.program budget.compileFuel
  (List.range 120).filterMap fun fuel =>
    let cut := (driveState interp fuel start [.evaluate ⟨0⟩, .drainDue]).1
    if cut.state.refs[0]? == some (Val.nat 0) then
      (cut.fiber? ⟨1⟩).map fun fiber => (fuel, fiber.running, fiber.currentOpCount, fiber.frame.stack.length)
    else none

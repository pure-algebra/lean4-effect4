import Test.Dogfood.Scenario.Timeout
open Effect4 Effect4.Machine Effect4.Program Test.Dogfood.Scenario Test.Dogfood.Scenario.Timeout
set_option maxRecDepth 100000
private def label : NCode → String
  | .onSuccess _ (.cont p) => s!"cont {p.path} env {reprStr p.env}"
  | .onFailure _ (.caughtError p) => s!"catch {p.path} env {reprStr p.env}"
  | .onExit _ (.fin p) _ => s!"fin {p.path} env {reprStr p.env}"
  | .whileLoop (.loop p) v => s!"loop {p.path} env {reprStr p.env} cursor {reprStr v}"
  | .asyncFinalizer _ => "async-finalizer"
  | _ => "other"
#eval match Effect4.Api.Author.build fetch with
| .error _ => []
| .ok b =>
  let s := Test.Dogfood.Scenario.play (opened b) parked
  s.machine.fibers.map fun (fiber : RunFiber EffName EffThunk Val Err Defect FiberId Ann Ctx) =>
    (fiber.id, fiber.running, label fiber.frame.current, fiber.frame.stack.map label)

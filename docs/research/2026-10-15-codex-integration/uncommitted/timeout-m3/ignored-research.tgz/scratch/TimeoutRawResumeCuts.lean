import Test.Dogfood.Scenario.Timeout
open Effect4 Effect4.Machine Effect4.Program Test.Dogfood.Scenario.Timeout
set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
#eval match Effect4.Api.Author.build fetch with
| .error _ => []
| .ok b =>
  letI := evaluatorFor b.program b.table
  let interp := interpOf b.program b.table
  let start := Api.load b.program budget.compileFuel
  ((List.range 250).map fun fuel =>
    let cutMachine := (driveState interp fuel start [.evaluate ⟨0⟩, .drainDue]).1
    let interrupted := (stepDecisionState interp 2000 cutMachine (.interruptFrom none .empty ⟨1⟩)).1
    let after := (stepDecisionState interp 2000 interrupted (.evaluate ⟨1⟩)).1
    (fuel, after.state.refs)).filter fun (x : Nat × RefHeap) =>
      x.2[0]? == some (Val.nat 0) && x.2[1]? != some (Val.list [])

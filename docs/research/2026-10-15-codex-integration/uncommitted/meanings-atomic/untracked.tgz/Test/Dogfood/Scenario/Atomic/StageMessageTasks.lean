import Test.Dogfood.Scenario.Atomic.StageMessages
import Test.Dogfood.Scenario.Atomic.StageTaskAdmission

/-!
Concept: reactive-scheduling R11.
Consumer: Atomic's native joint postcondition for shop_stages.
Actual addressed edits retain matching-token detached and stored task admission.
-/
set_option autoImplicit false
namespace Test.Dogfood.Scenario.Atomic.StageConfiguration
open Effect4 Effect4.Machine Effect4.Program
open StageWorld

/-- Actual observer installation preserves every matching parked row. -/
theorem ReplyPermission.observe (machine : NativeMachine) (target : FiberId) (observer : Observer)
    (id : FiberId) (token : Nat) (code : NCode) (held : ReplyPermission machine id token code) :
    ReplyPermission (machine.observe target observer) id token code := by
  apply held.row_origin machine _
  unfold RunMachine.observe RunMachine.modify
  split
  · intro row member
    exact ⟨row, member, rfl, rfl⟩
  · intro row member
    obtain ⟨old, inside, equal⟩ := List.mem_map.mp member
    rw [← equal]
    split
    · rename_i fiber found same
      exact ⟨fiber, RunMachine.mem_of_fiber? found, rfl, rfl⟩
    · exact ⟨old, inside, rfl, rfl⟩

/-- Actual token removal preserves every matching parked row. -/
theorem ReplyPermission.drop (machine : NativeMachine) (token : Nat)
    (id : FiberId) (key : Nat) (code : NCode) (held : ReplyPermission machine id key code) :
    ReplyPermission (machine.dropToken token) id key code := by
  apply held.row_origin machine _
  intro row member
  obtain ⟨old, inside, equal⟩ := List.mem_map.mp member
  rw [← equal]
  exact ⟨old, inside, rfl, rfl⟩

/-- Observer installation changes no stored dispatcher or reply token. -/
theorem AdmittedTasks.observe (machine : NativeMachine) (target : FiberId) (observer : Observer)
    (held : AdmittedTasks machine) : AdmittedTasks (machine.observe target observer) := by
  unfold RunMachine.observe RunMachine.modify
  split
  · exact held
  · rename_i fiber found
    apply held.update machine {fiber with observers := fiber.observers ++ [observer]}
      (held fiber (RunMachine.mem_of_fiber? found))
    intro id token code reply
    exact reply.update_park machine fiber {fiber with observers := fiber.observers ++ [observer]}
      (RunMachine.mem_of_fiber? found) rfl rfl id token code

/-- Token removal changes no stored dispatcher or reply token. -/
theorem AdmittedTasks.drop (machine : NativeMachine) (token : Nat) (held : AdmittedTasks machine) :
    AdmittedTasks (machine.dropToken token) := by
  intro row member bucket inside task present
  obtain ⟨old, oldIn, equal⟩ := List.mem_map.mp member
  rw [← equal] at inside
  exact (held old oldIn bucket inside task present).transport machine (machine.dropToken token) task
    (fun id key code reply => reply.drop machine token id key code)

/-- Each actual addressed message retains stored tasks at its actual resulting machine. -/
theorem AdmittedTasks.edit (machine : NativeMachine) (message : FiberEdit Err Defect FiberId Ann)
    (held : AdmittedTasks machine) : AdmittedTasks (applyFiberEdit message machine).1 := by
  cases message with
  | observe target observer => exact held.observe machine target observer
  | dropToken token => exact held.drop machine token
  | interrupt target cause =>
    cases found : machine.fiber? target with
    | none => simpa only [applyFiberEdit, found] using held
    | some fiber => simpa only [applyFiberEdit, found] using
        held.interruption machine fiber (RunMachine.mem_of_fiber? found) cause

/-- Each actual addressed message retains the same detached snapshot's matching admissions. -/
theorem SnapshotAt.edit (world : StageWorld.World) (machine : NativeMachine) (tasks : List Guard.NTask)
    (message : FiberEdit Err Defect FiberId Ann) (held : SnapshotAt world machine tasks) :
    SnapshotAt world (applyFiberEdit message machine).1 tasks := by
  apply held.transport world machine _ tasks
  intro id token code reply
  cases message with
  | observe target observer => exact reply.observe machine target observer id token code
  | dropToken key => exact reply.drop machine key id token code
  | interrupt target cause =>
    cases found : machine.fiber? target with
    | none => simpa only [applyFiberEdit, found] using reply
    | some fiber => simpa only [applyFiberEdit, found] using
        reply.interruption machine fiber (RunMachine.mem_of_fiber? found) cause id token code

/-- Actual fresh-token installation retains the same reserved detached snapshot. -/
theorem SnapshotAt.native_install (before after : StageWorld.World) (machine : NativeMachine)
    (result : Moves.NIteration) (tasks : List Guard.NTask)
    (fresh : Guard.ReturnFields.FreshPark machine result) (others : Moves.Interferes machine result.machine)
    (reserved : Guard.ReservedKeys machine (tasks.flatMap Guard.taskKeys))
    (held : SnapshotAt before machine tasks) : SnapshotAt after (result.machine.update result.fiber) tasks := by
  intro task member
  cases held task member with
  | start id => exact .start id
  | resume id token code reply =>
    apply TaskPermission.resume id token code
    apply reply.native_install fresh others id token code
    apply reserved.below (id, token)
    exact List.mem_flatMap.mpr ⟨.resume id token code, member, List.mem_singleton_self _⟩

/-- The existing word fold retains P, queued readers, stored tasks and one detached snapshot together. -/
theorem messages_joint (root : NativeEff) (table : RowTable) (tasks : List Guard.NTask) :
    ContextualMessages.Admitted (order := order)
      (P := fun context world machine => MessageState root table context world machine ∧
        AdmittedTasks machine ∧ SnapshotAt world machine tasks)
      (Q := fun _ world machine commands => QueueAt root table world machine commands)
      (fun (_ : MessageContext) message => MessageAt message) := by
  constructor
  intro context world message machine commands admitted held queued
  have state := (message_fixed root table context world message machine [] admitted held.1
    (fun _ member => by cases member)).1
  exact ⟨world, order.refl world, ⟨state, held.2.1.edit machine message,
    held.2.2.edit world machine tasks message⟩,
    queued.edit root table world machine commands message held.1.1 admitted⟩

end Test.Dogfood.Scenario.Atomic.StageConfiguration

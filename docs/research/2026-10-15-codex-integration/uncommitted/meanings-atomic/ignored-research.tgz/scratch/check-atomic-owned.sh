#!/bin/bash
set -e
lake build Test.Dogfood.Scenario.Atomic.StageEntry Test.Dogfood.Scenario.Atomic.StageFrames
lake env lean scratch/AtomicOwnedAudit.lean

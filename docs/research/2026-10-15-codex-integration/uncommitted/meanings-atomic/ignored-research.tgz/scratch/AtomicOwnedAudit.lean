import Test.Dogfood.Scenario.Atomic.StageEntry
import Test.Dogfood.Scenario.Atomic.StageFrames
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageFinalizer Test.Dogfood.Scenario.Atomic.StageGraph Test.Dogfood.Scenario.Atomic.StageHead Test.Dogfood.Scenario.Atomic.StageFrames Test.Dogfood.Scenario.Atomic.StageNative Test.Dogfood.Scenario.Atomic.StageEntry

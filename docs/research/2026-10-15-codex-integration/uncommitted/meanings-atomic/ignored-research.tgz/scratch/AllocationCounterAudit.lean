import Test.Dogfood.Scenario.Atomic.Initialization
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.PrimitiveCounter Effect4.Laws.Program.AnswerSlots.AllocationCounter Effect4.Laws.Program.AnswerSlots.AllocationIteration

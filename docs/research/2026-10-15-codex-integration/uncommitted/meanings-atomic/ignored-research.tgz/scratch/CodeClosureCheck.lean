import Effect4.Laws.Program.CodeClosure.Predicate
open Effect4 Effect4.Machine Effect4.Program
example (name : EffName → Prop) (thunk : EffThunk → Prop) (v : Val) :
 cata_prim (CodeClosure.codeAlg name thunk) (.success v) := by
 simp only [CodeClosure.code_success]
example (name : EffName → Prop) (thunk : EffThunk → Prop) (v : Val) :
 cata_prim (CodeClosure.codeAlg name thunk) (.success v) := by
 aesop (rule_sets := [Effect4.CodeClosure])
#check CodeClosure.code_success
#print CodeClosure.code_success
#print CodeClosure.codeAlg

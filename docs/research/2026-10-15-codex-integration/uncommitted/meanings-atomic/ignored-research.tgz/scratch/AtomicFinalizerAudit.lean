import Effect4.Laws.Program.FinalizerLayerBody
import Effect4.Laws.Program.FinalizerControl
import Effect4.Laws.Program.FinalizerRun
import Test.Dogfood.Scenario.Atomic.Store
import Effect4.Laws.Program.FinalizerPlacement
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.Store Effect4.Laws.Program.FinalizerPlacement Effect4.Laws.Program.FinalizerRun Effect4.Laws.Program.FinalizerSource Effect4.Laws.Program.FinalizerRace Effect4.Laws.Program.FinalizerControl Effect4.Laws.Program.FinalizerPlaces Effect4.Laws.Program.FinalizerLayerBody

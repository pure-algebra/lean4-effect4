#!/bin/bash
set -e
lake build Test.Dogfood.Scenario.Atomic.StageNative
lake env lean scratch/AtomicHeapAudit.lean

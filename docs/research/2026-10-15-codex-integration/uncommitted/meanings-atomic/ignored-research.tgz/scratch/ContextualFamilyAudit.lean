import Test.Machine.AnswerFlowContextual
import Effect4.Laws.Machine.AnswerFlowFamilyPop
import Effect4.Laws.Machine.AnswerFlowContextualFamily
import Effect4.Laws.Machine.AnswerFlowRun
import Effect4.Laws.Machine.AnswerFlowGhostCommands
import ProofGraph.AxiomAudit
#axiom_audit Test.Machine.AnswerFlowContextual Effect4.Laws.Machine.AnswerFlowContextualFamily Effect4.Laws.Machine.AnswerFlowFamilyPop Effect4.Laws.Machine.AnswerFlowRun

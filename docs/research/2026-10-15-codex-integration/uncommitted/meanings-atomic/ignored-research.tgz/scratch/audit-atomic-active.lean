import Test.Dogfood.Scenario.Atomic.StageRoles
import Test.Dogfood.Scenario.Atomic.RootHead
import Test.Dogfood.Scenario.Atomic.StageInterrupt
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Machine.AnswerFlowNativeExit Effect4.Laws.Machine.AnswerFlowNativeIteration Test.Dogfood.Scenario.Atomic.StageFrames Test.Dogfood.Scenario.Atomic.StageRoles Test.Dogfood.Scenario.Atomic.DaemonSource Test.Dogfood.Scenario.Atomic.DaemonGraph Test.Dogfood.Scenario.Atomic.DaemonHead Test.Dogfood.Scenario.Atomic.DaemonNative Test.Dogfood.Scenario.Atomic.DaemonEntry Test.Dogfood.Scenario.Atomic.FailureWitness Test.Dogfood.Scenario.Atomic.RootGraph Test.Dogfood.Scenario.Atomic.RootFrame Test.Dogfood.Scenario.Atomic.RootHead Test.Dogfood.Scenario.Atomic.StageInterrupt

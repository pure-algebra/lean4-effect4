import Test.Dogfood.Scenario.Atomic.StageStoreFields
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Machine.StatePreservation Effect4.Laws.Program.PrimitiveCounter
  Effect4.Laws.Program.NativeActionRows Effect4.Laws.Program.NativeFrameRows
  Test.Dogfood.Scenario.Atomic.RootNativeShape Test.Dogfood.Scenario.Atomic.RootActionResult
  Test.Dogfood.Scenario.Atomic.RootParks Test.Dogfood.Scenario.Atomic.RootPrimitive
  Test.Dogfood.Scenario.Atomic.StageMetadata Test.Dogfood.Scenario.Atomic.StageConfiguration
  Test.Dogfood.Scenario.Atomic.StageEdits Test.Dogfood.Scenario.Atomic.StageSettlement
  Test.Dogfood.Scenario.Atomic.StageQueue Test.Dogfood.Scenario.Atomic.StageResults

#axiom_audit Test.Dogfood.Scenario.Atomic.StageNativeData Test.Dogfood.Scenario.Atomic.StageStoreFields

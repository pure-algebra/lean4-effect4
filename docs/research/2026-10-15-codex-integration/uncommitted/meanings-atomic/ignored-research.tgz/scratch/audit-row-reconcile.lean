import Test.Dogfood.Scenario.Atomic.StageTasks
import Test.Dogfood.Scenario.Atomic.NativeEffects
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.NativeActionRows Test.Dogfood.Scenario.Atomic.StageMetadata Test.Dogfood.Scenario.Atomic.StageTasks Test.Dogfood.Scenario.Atomic.NativeEffects

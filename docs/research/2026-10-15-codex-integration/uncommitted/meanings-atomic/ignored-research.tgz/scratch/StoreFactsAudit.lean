import Test.Dogfood.Scenario.Atomic.Store
import Test.Dogfood.Scenario.Atomic.Writes
import Test.Dogfood.Scenario.Atomic.Writer
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StoreFacts Test.Dogfood.Scenario.Atomic.Store Test.Dogfood.Scenario.Atomic.Writes Test.Dogfood.Scenario.Atomic.Writer

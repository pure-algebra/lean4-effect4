import Effect4.Laws.Program.AnswerSlots.AllocationWaits
import Test.Dogfood.Scenario.RootCells
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.AllocationAdapter Effect4.Laws.Program.AnswerSlots.AllocationPhases Effect4.Laws.Program.AnswerSlots.AllocationHead Effect4.Laws.Program.AnswerSlots.AllocationSync Effect4.Laws.Program.AnswerSlots.AllocationWaits Test.Dogfood.Scenario.RootCells

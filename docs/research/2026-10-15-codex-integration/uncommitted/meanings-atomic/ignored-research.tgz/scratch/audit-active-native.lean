import Test.Dogfood.Scenario.Atomic.RootSpawn
import Test.Dogfood.Scenario.Atomic.DaemonReturn
import Test.Dogfood.Scenario.Atomic.StageRows
import Test.Dogfood.Scenario.Atomic.StageObservation
import Effect4.Laws.Machine.AnswerFlowJointCommands
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.RootActions Test.Dogfood.Scenario.Atomic.RootReturn Test.Dogfood.Scenario.Atomic.RootSpawn Test.Dogfood.Scenario.Atomic.DaemonGraph Test.Dogfood.Scenario.Atomic.DaemonHead Test.Dogfood.Scenario.Atomic.DaemonNative Test.Dogfood.Scenario.Atomic.DaemonReturn Test.Dogfood.Scenario.Atomic.RootGraph Test.Dogfood.Scenario.Atomic.RootHead Test.Dogfood.Scenario.Atomic.StageRows Test.Dogfood.Scenario.Atomic.StageObservation Effect4.Laws.Machine.AnswerFlowJointCommands

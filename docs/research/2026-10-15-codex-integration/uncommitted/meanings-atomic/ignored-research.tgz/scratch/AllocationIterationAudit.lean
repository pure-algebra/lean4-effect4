import Test.Dogfood.Scenario.Atomic.Initialization
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.InitializationExact Effect4.Laws.Program.AnswerSlots.AllocationAdapter Effect4.Laws.Program.AnswerSlots.AllocationSync Effect4.Laws.Program.AnswerSlots.AllocationNative Effect4.Laws.Program.AnswerSlots.AllocationScoped Effect4.Laws.Program.AnswerSlots.AllocationIteration Test.Dogfood.Scenario.RootCells Test.Dogfood.Scenario.Atomic.Initialization

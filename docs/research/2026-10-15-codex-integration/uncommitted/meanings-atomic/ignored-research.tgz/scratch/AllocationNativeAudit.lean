import Effect4.Laws.Program.AnswerSlots.AllocationScoped
import Test.Dogfood.Scenario.RootCells
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.AllocationAdapter Effect4.Laws.Program.AnswerSlots.AllocationFamily Effect4.Laws.Program.AnswerSlots.AllocationFrame Effect4.Laws.Program.AnswerSlots.AllocationHead Effect4.Laws.Program.AnswerSlots.AllocationPhases Effect4.Laws.Program.AnswerSlots.AllocationSync Effect4.Laws.Program.AnswerSlots.AllocationWaits Effect4.Laws.Program.AnswerSlots.AllocationPending Effect4.Laws.Program.AnswerSlots.AllocationNative Effect4.Laws.Program.AnswerSlots.AllocationScoped Test.Dogfood.Scenario.RootCells

import Effect4.Laws.Program.PrimitiveEffects
import Test.Dogfood.Scenario.Atomic.StageTerminal
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.PrimitiveEffects Test.Dogfood.Scenario.Atomic.NativeEffects Test.Dogfood.Scenario.Atomic.RootAfter Test.Dogfood.Scenario.Atomic.RootActionResult Test.Dogfood.Scenario.Atomic.StageQueue Test.Dogfood.Scenario.Atomic.StageNativeJoin Test.Dogfood.Scenario.Atomic.StageWaits Test.Dogfood.Scenario.Atomic.StageCharged Test.Dogfood.Scenario.Atomic.StageTerminal

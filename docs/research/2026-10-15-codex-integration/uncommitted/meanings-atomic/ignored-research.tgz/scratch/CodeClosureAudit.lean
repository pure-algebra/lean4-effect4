import Effect4.Laws.Program.AnswerSlots.Compile
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.CodeClosure.Predicate Effect4.Laws.Program.CodeClosure.Compile Effect4.Laws.Program.AnswerSlots.Syntax Effect4.Laws.Program.AnswerSlots.Compile

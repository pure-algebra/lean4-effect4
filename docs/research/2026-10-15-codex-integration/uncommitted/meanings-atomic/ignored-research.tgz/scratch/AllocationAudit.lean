import Effect4.Laws.Program.AnswerSlots.AllocationSync
import Test.Dogfood.Scenario.RootCells
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.InitializationExact Effect4.Laws.Program.AnswerSlots.AllocationAdapter Effect4.Laws.Program.AnswerSlots.AllocationProvenance Effect4.Laws.Program.AnswerSlots.AllocationFamily Effect4.Laws.Program.AnswerSlots.AllocationPhases Effect4.Laws.Program.AnswerSlots.AllocationHead Effect4.Laws.Program.AnswerSlots.AllocationSync Test.Dogfood.Scenario.RootCells

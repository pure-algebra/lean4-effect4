import Test.Dogfood.Scenario.Atomic.StageIteration
import Test.Dogfood.Scenario.Atomic.StageRoles
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageGraph Test.Dogfood.Scenario.Atomic.StageHead Test.Dogfood.Scenario.Atomic.StageFrames Test.Dogfood.Scenario.Atomic.StagePrimitive Test.Dogfood.Scenario.Atomic.StageIteration Test.Dogfood.Scenario.Atomic.DaemonGraph Test.Dogfood.Scenario.Atomic.DaemonHead Test.Dogfood.Scenario.Atomic.DaemonIteration Test.Dogfood.Scenario.Atomic.RootGraph Test.Dogfood.Scenario.Atomic.RootFrame

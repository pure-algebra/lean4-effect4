import Test.Dogfood.Scenario.Atomic.DaemonNative
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.DaemonSource Test.Dogfood.Scenario.Atomic.DaemonGraph Test.Dogfood.Scenario.Atomic.DaemonHead Test.Dogfood.Scenario.Atomic.DaemonNative

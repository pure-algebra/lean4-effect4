import Test.Dogfood.Scenario.Atomic.RootBindings
set_option pp.all true in
#print Test.Dogfood.Scenario.Atomic.RootBindings.fork_rank._proof_1_2

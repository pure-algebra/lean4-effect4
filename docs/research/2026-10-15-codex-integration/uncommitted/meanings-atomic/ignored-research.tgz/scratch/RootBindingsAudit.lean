import Test.Dogfood.Scenario.Atomic.RootBindings
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.RootBindings

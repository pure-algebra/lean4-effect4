import Test.Dogfood.Scenario.Atomic.RootHead
import Test.Dogfood.Scenario.Atomic.RootFrame
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageWorld Test.Dogfood.Scenario.Atomic.StageGraph Test.Dogfood.Scenario.Atomic.StageFrames Test.Dogfood.Scenario.Atomic.StageFresh Test.Dogfood.Scenario.Atomic.RootSource Test.Dogfood.Scenario.Atomic.RootGraph Test.Dogfood.Scenario.Atomic.RootHead Test.Dogfood.Scenario.Atomic.RootFrame

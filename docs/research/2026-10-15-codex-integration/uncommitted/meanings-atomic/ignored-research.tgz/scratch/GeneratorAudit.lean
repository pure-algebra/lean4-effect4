import Effect4.Laws.Program.FinalizerGeneratorRun
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.FinalizerSource Effect4.Laws.Program.FinalizerGenerator Effect4.Laws.Program.FinalizerGeneratorPC Effect4.Laws.Program.FinalizerGeneratorRun

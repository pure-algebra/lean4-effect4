import Test.Dogfood.Scenario.Atomic.StageSource
namespace Test.Dogfood.Scenario.Atomic.StageSource
open Effect4 Effect4.Machine Effect4.Program Effect4.Laws.Auto
 def depositTailPath (id : Nat) := SourcePaths.requestPath id ++ [0,1,0,1]
 def tailSite (root : NativeEff) (id : Nat) : Bool :=
 match Node.at_ (.eff root) (depositTailPath id) with
 | some (.eff (.fail _)) => true
 | some (.eff (.succeed (.lit (.bool true)))) => true
 | _ => false
 theorem tails : (Store.shopProgram.map fun root => requests.all (tailSite root)) = some true := by kernel_rfl
end Test.Dogfood.Scenario.Atomic.StageSource

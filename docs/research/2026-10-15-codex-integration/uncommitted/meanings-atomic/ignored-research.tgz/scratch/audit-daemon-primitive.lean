import Test.Dogfood.Scenario.Atomic.DaemonPrimitive
import Test.Dogfood.Scenario.Atomic.StageRows
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.NativePrimitiveDefault Test.Dogfood.Scenario.Atomic.DaemonNative Test.Dogfood.Scenario.Atomic.DaemonReturn Test.Dogfood.Scenario.Atomic.DaemonPrimitive Test.Dogfood.Scenario.Atomic.StagePrimitive

import Test.Dogfood.Scenario.Atomic.StageNativeJoin
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageNativeJoin

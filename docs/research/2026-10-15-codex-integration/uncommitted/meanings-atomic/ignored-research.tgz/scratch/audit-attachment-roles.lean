import Test.Dogfood.Scenario.Atomic.StageRoles
import Effect4.Laws.Program.AnswerSlots.AllocationAttachment
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.AllocationAttachment Test.Dogfood.Scenario.Atomic.DaemonEntry Test.Dogfood.Scenario.Atomic.StageRoles

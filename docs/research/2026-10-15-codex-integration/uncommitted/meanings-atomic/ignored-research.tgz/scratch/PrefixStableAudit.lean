import Effect4.Laws.Program.AnswerSlots.PrefixStable
import ProofGraph.AxiomAudit
#axiom_audit Effect4.Laws.Program.AnswerSlots.Stable Effect4.Laws.Program.AnswerSlots.PrefixStable

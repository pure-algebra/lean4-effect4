import Test.Dogfood.Scenario.Atomic.StageObservation
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageObservation

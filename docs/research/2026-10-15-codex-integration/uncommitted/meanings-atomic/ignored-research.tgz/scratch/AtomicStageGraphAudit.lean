import Test.Dogfood.Scenario.Atomic.StageGraph
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageWorld Test.Dogfood.Scenario.Atomic.StageSource Test.Dogfood.Scenario.Atomic.StageFinalizer Test.Dogfood.Scenario.Atomic.StageGraph

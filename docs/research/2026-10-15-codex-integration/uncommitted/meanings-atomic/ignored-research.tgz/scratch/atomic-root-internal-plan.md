Root ignored native cleanup route, design only

Consumer: Atomic.Store.shop_stages actual root native producer.
The exact RootGraph source PointAt handles remain separate from internal code.

Missing internal heads include cancelSleep/cancelPark/await-asVoid/restore wrappers.
Use checked CodeClosure.PredicateFamily + Arms for a no-write/no-fork builtin predicate.
Use existing ClassifiedEmbedding for root ordinary and frozen-counter ignored classes.
RootAnswer fork causes cannot require post-fork counter: abort-before-fork is valid.
RootPause counter may carry counter equality on both value and cause channels.
Then Unit source-family callbacks receive counter equality from the actual input value or cause.
This may require RootGraph's failure/bound cause clauses to retain that small class-dependent condition.
Normal source bind output ordinary remains unrestricted; rootCause rootAnswer stays True.
Alternatively keep explicit internal leaf constructors if that is shorter.

Readonly native builtins may read refs, cancel sleeps, and cancel waiters.
They cannot allocate fibers, write refs, or spawn close-scope finalizers.
Observer/pending/context metadata edits preserve numeric role frames and published exits.
Do not instantiate blanket zero-name weights for source callbacks.
Do not broaden FinalizerSource's target-specific callback funding.
No endpoint or internal family is proved by this note.

import Test.Dogfood.Scenario.Atomic.StageActivation
import Test.Dogfood.Scenario.Atomic.StageNativeWords
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageActivation Test.Dogfood.Scenario.Atomic.StageNativeWords

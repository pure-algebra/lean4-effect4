import Test.Dogfood.Scenario.Atomic.StageSource
namespace Test.Dogfood.Scenario.Atomic.StageSource
open Effect4 Effect4.Machine Effect4.Program Effect4.Laws.Auto
 def decisionPath (id : Nat) := SourcePaths.requestPath id ++ [0,0,1]
 def depositPath (id : Nat) := SourcePaths.requestPath id ++ [0,1,0,0]
 def opSite (root : NativeEff) (path : List Nat) (operation : Nat → NativeOp) (slot : Nat) : Bool :=
 match SourceScope.levelAt (.eff root) 0 path, Node.at_ (.eff root) path with
 | some level, some (.eff (.perform op request)) => op == operation level && request == .var slot
 | _, _ => false
 theorem decisions : (Store.shopProgram.map fun root => requests.all fun id =>
 opSite root (decisionPath id) (fun level => .refModifyWith (Store.decisionAt level)) 0) = some true := by kernel_rfl
 theorem deposits : (Store.shopProgram.map fun root => requests.all fun id =>
 opSite root (depositPath id) (fun level => .refModifyWith (Store.depositAt id level)) 1) = some true := by kernel_rfl
end Test.Dogfood.Scenario.Atomic.StageSource

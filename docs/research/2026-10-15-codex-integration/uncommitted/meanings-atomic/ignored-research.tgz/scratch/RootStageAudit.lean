import Test.Dogfood.Scenario.Atomic.RootBindings
import Test.Dogfood.Scenario.Atomic.StageFinalizer
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.RootSlots Test.Dogfood.Scenario.Atomic.StageWorld Test.Dogfood.Scenario.Atomic.RootBindings Test.Dogfood.Scenario.Atomic.StageFinalizer

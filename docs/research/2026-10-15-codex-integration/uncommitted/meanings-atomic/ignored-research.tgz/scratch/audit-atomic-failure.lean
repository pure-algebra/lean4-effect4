import Test.Dogfood.Scenario.Atomic.StageRoles
import Test.Dogfood.Scenario.Atomic.StageObservation
import Test.Dogfood.Scenario.Atomic.FailureControls
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.FailureWitness Test.Dogfood.Scenario.Atomic.FailureControls Test.Dogfood.Scenario.Atomic.StageWorld Test.Dogfood.Scenario.Atomic.StageFinalizer Test.Dogfood.Scenario.Atomic.StageGraph Test.Dogfood.Scenario.Atomic.StageCleanup Test.Dogfood.Scenario.Atomic.StageObservation

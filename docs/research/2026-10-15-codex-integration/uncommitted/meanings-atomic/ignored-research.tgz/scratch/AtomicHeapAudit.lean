import Test.Dogfood.Scenario.Atomic.StageNative
import ProofGraph.AxiomAudit
#axiom_audit Test.Dogfood.Scenario.Atomic.StageCounts Test.Dogfood.Scenario.Atomic.StageHeap Test.Dogfood.Scenario.Atomic.StageNative

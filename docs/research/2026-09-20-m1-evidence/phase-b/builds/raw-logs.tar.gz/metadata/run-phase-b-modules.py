from pathlib import Path
import json,os,subprocess,sys
plan=json.loads(Path('/tmp/m1-tools/phase-b-serial-plan/serial-plan.json').read_text())
start=int(sys.argv[1]);end=int(sys.argv[2]);env=dict(os.environ,LEAN_NUM_THREADS='1')
for row in plan['statement_build_order']:
 if not start<=row['order']<=end:continue
 p=Path(row['log']);p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():
  attempt=1
  while p.with_suffix('.attempt'+str(attempt)+'.log').exists():attempt+=1
  p.rename(p.with_suffix('.attempt'+str(attempt)+'.log'))
 print('BUILD',row['order'],row['module'],flush=True)
 with p.open('w') as f:r=subprocess.run(['lake','build',row['module']],stdout=f,stderr=subprocess.STDOUT,env=env)
 print('RESULT',r.returncode,str(p),flush=True)
 if r.returncode:
  print('\n'.join(p.read_text().splitlines()[-35:]),flush=True);sys.exit(r.returncode)

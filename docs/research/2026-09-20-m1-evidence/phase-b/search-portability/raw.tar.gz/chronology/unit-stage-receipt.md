Search portability repair — finite evidence

The minimal pre-repair control failed with exit 1 because search returned a proof referring to FreshSearchHelper after rolling that declaration back. The original obligation-status failure also remains archived: it attempted to publish a proof using a missing private spawn splitter. Those failures identify a tool boundary defect, not a failed semantic theorem.

The final source snapshots close over fresh checked definitions/theorems before rollback, validate universe arity, and check the returned proof at its requested proposition against the captured checked kernel environment. The same heartbeat origin/cap and existing recursion-depth setting remain in force. Speculative asynchronous elaboration is disabled within the restored option scope. Missing constants are rejected explicitly. Both proposition and proof dependencies are audited before synchronous publication checking; the census shares that audit.

The first unit build returned 1 solely for quotation hygiene in the existing-theorem opacity control. Replacing the quoted theorem reference with an explicit mkConst fixed that control. The second unit build returned 0. The existing budget/timeout checks and the new fresh-theorem, polymorphic dependency, temporary-axiom, wrong-type, missing-constant, type-only forbidden-axiom, and opacity controls passed. Three published test theorems reported no axioms. These are finite controls; they do not establish universal metaprogram correctness.

The earlier census remains provisional: 648 raw closures, 647 passing its old axiom scan, across 4,062 statements. Its logs are retained separately and are not portable-proof evidence. This bundle claims no corrected census, final-bank increase, complete obligation-status run, or full Test.All result. Full Test.All was still running when this bounded bundle was prepared; its partial log was excluded.

manifest.json records exact known commands, exits, final source hashes, and all archive members. The eleven archived files were read back and compared byte-for-byte; SHA256SUMS covers the three final package files. Packaging ran no compiler and changed no repository source.

import ProofGraph.Search

open Lean Meta Elab Command

run_cmd liftTermElabM do
  let before ← getEnv
  let tactic ← `(tactic| run_tac do
    addDecl <| .thmDecl {
      name := `FreshSearchHelper, levelParams := [],
      type := mkConst ``True, value := mkConst ``True.intro }
    Lean.Elab.Tactic.closeMainGoal `freshDependency (mkConst `FreshSearchHelper))
  let .ok proof ← ProofGraph.search (mkConst ``True) tactic 40000
    | throwError "search did not close the finite helper control"
  if (← getEnv).contains `FreshSearchHelper then
    throwError "search leaked the temporary declaration"
  let missing := proof.getUsedConstants.filter fun name => !before.contains name
  unless missing.isEmpty do
    throwError "search returned rolled-back dependencies: {missing}"
  discard <| ProofGraph.addTheorem `freshDependencyClosed [] (mkConst ``True) proof

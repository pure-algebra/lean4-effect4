# Corrected census classification

The completed repaired census covers 218 modules in 139 successful serial
processes: 648 closed searches among 4,062 statements, with 647 inside the allowed
axiom ceiling. Its exact set of closed names matches the earlier provisional run.
Seven dependency lists changed; all added dependencies are permitted `propext`
or `Quot.sound`. `comparison.json` names each change and pins the new evidence.

All 115 proposed handwritten replacements remain eligible across nine modules.
Their frozen statement/proof fragments each occur exactly once, unchanged, in
the current source. The broader 416-fragment snapshot, including 301 proofs
already written with search, also matches exactly. No proof was replaced here.

Use this directory's `rewrite-ready.json` and `closed-candidates.json` for the
corrected evidence; do not use the earlier provisional manifests as proof-search
evidence. Original classifications, frozen fragments and source copies remain
unchanged in the parent directory. Recheck current fragments immediately before
any later replacement, and validate replacements with their normal narrow build.


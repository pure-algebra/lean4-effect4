import Effect4.Laws.Machine.Behaviour
import Effect4.Laws.Auto.Obligations

/-!
Scratch diagnostic only: no new solver and no relaxed ceiling. Read the same
explicit Obligation shape as the live ledger; call ProofGraph.search at its
unchanged 40000 cap. A closed candidate goes through addTheorem's kernel/axiom
validation before it is reported closed. The tool never deletes wanted markers.
This source is prepared, not yet compiled or run.
-/
namespace M1StatusCollector
open Lean Meta Elab Command
open ProofGraph

private def readGoal (name : Name) : MetaM (Option Goal) := do
  let info ← getConstInfo name
  forallTelescope info.type fun xs body => do
    if body.isAppOfArity ``Obligation 1 then
      return some ⟨name, info.levelParams, (← mkForallFVars xs body.appArg!), #[]⟩
    if info.type.getUsedConstants.contains ``Obligation then
      throwError "M1 status: unsupported obligation shape at {name}"
    return none

syntax (name := m1ObligationStatus)
  "#m1_obligation_status " ident " using " tacticSeq : command

@[command_elab m1ObligationStatus]
def elabM1ObligationStatus : CommandElab := fun stx => do
  let scope := stx[1].getId
  let tactic := stx[3]
  liftTermElabM do
    let env ← getEnv
    let names := env.constants.toList.map (·.1) |>.filter (scope.isPrefixOf ·)
      |>.toArray.qsort (·.toString < ·.toString)
    let mut closed : Nat := 0
    let mut remaining : Nat := 0
    let mut rejected : Nat := 0
    for name in names do
      if let some goal ← readGoal name then
        match ← ProofGraph.search goal.proposition tactic 40000 with
        | .error why =>
          logInfo m!"M1_RESIDUAL {name}\n{why}"
          remaining := remaining + 1
          logInfo m!"M1_STATUS open {name}"
        | .ok proof =>
          let extra := (← ProofGraph.axiomsOf proof).filter fun a =>
            ![``propext, ``Quot.sound].contains a
          if extra.isEmpty then
            -- Temporary scratch declarations only; the source ledger is unchanged.
            discard <| ProofGraph.addTheorem (`M1StatusChecked ++ name)
              goal.levels goal.proposition proof
            closed := closed + 1
            logInfo m!"M1_STATUS closed {name}"
          else
            rejected := rejected + 1
            logInfo m!"M1_STATUS rejected {name}: {extra}"
    if closed + remaining + rejected == 0 then
      throwError "M1 status: no obligations under {scope}"
    logInfo m!"M1_STATUS summary {scope}: {closed} closed; {remaining} open; {rejected} rejected; cap 40000"

end M1StatusCollector

#m1_obligation_status Effect4.Machine.M1Trace using aesop (rule_sets := [Effect4.Stores])

#!/usr/bin/env python3
"""Read-only checks for the prepared serial status route; this never invokes Lean."""
from pathlib import Path
import collections,hashlib,json,re,sys
P=Path(__file__).parent;ROOT=Path('/Users/pooks/Dev/lean4-effect4')
def get_plan():return json.loads((P/'status-route.json').read_text())
def parse_log(row,text,exit_code):
 if exit_code!=0:raise ValueError('failed Lean process is not status evidence')
 expected=set(row['names']);found={}
 for status,name in re.findall(r"^M1_STATUS (open|closed|rejected) ([\w.']+)(?::[^\n]*)?$",text,re.M):
  if name in found:raise ValueError('duplicate result '+name)
  found[name]=status
 if set(found)!=expected:raise ValueError('statement set mismatch: missing='+str(sorted(expected-set(found)))+' extra='+str(sorted(set(found)-expected)))
 pattern=r'^'+re.escape('M1_STATUS summary '+row['namespace'])+r': (\d+) closed; (\d+) open; (\d+) rejected; cap 40000$'
 summaries=re.findall(pattern,text,re.M)
 if len(summaries)!=1:raise ValueError('expected one exact-cap summary')
 closed,opened,rejected=map(int,summaries[0]);counts=collections.Counter(found.values())
 if [closed,opened,rejected]!=[counts['closed'],counts['open'],counts['rejected']]:raise ValueError('summary disagrees with individual rows')
 if closed+opened+rejected!=row['N']:raise ValueError('summary differs from pinned N')
 return {'namespace':row['namespace'],'N':row['N'],'closed':closed,'open':opened,'rejected':rejected,'cap':40000,'names':found,'gate_initial_ceiling_if_admissible':row['N'] if not rejected else None,'status':'validated complete log' if not rejected else 'trust rejection; no marker/gate changes'}
def main(argv):
 plan=get_plan();rows={r['namespace']:r for r in plan['rows']}
 if argv==['preflight']:
  bad=[p for p,h in plan['source_hashes'].items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
  bad += [r['scratch_source'] for r in plan['rows'] if hashlib.sha256(Path(r['scratch_source']).read_bytes()).hexdigest()!=r['scratch_sha256']]
  if bad:raise ValueError('source drift; refresh before Lean: '+str(bad))
  print('Preflight: source and scratch hashes match; compiled prerequisites still require root\'s fresh build result.');return 0
 if len(argv)==4 and argv[0]=='log':
  result=parse_log(rows[argv[1]],Path(argv[2]).read_text(),int(argv[3]));print(json.dumps(result,indent=2));return 2 if result['rejected'] else 0
 if argv==['summary']:
  values=[]
  for r in plan['rows']:
   result=json.loads(Path(r['result']).read_text())
   if result['namespace']!=r['namespace'] or result['N']!=r['N'] or result['rejected']:raise ValueError('invalid scope result')
   values.append(result)
  output={'scopes':len(values),'total':sum(r['N'] for r in values),'closed':sum(r['closed'] for r in values),'open':sum(r['open'] for r in values),'rejected':sum(r['rejected'] for r in values),'cap':40000,'status':'measured uncovered scopes only; existing19zero sites remain separate','rows':values}
  (P/'status-results.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:v for k,v in output.items() if k!='rows'},indent=2));return 0
 raise ValueError('usage: preflight | log NAMESPACE LOG EXITCODE | summary')
if __name__=='__main__':
 try:sys.exit(main(sys.argv[1:]))
 except (ValueError,KeyError,OSError,json.JSONDecodeError) as e:print('REFUSED: '+str(e),file=sys.stderr);sys.exit(2)

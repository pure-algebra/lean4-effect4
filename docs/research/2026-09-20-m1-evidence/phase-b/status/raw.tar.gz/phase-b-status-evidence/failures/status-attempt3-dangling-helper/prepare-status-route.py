from pathlib import Path
import hashlib,json,re,shlex
P=Path(__file__).parent;ROOT=Path('/Users/pooks/Dev/lean4-effect4')
d=json.loads((P/'inventory.json').read_text());sp=json.loads((P/'status-plan.json').read_text())
texts={str(p.relative_to(ROOT)):p.read_text() for prefix in ('src','Test','tools') for p in (ROOT/prefix).rglob('*.lean')}
def locate(mod):
 for prefix in ('src/','','tools/'):
  q=prefix+mod.replace('.','/')+'.lean'
  if q in texts:return q
imports={p:[q for m in re.findall(r'^import\s+(\S+)',s,re.M) if (q:=locate(m))] for p,s in texts.items()}
def closure(path):
 seen=set();todo=[path]
 while todo:
  q=todo.pop()
  if q not in seen:seen.add(q);todo.extend(imports[q])
 return seen
owners={r['namespace']:r['gate_owner'] for r in d['gate_plan'] if not r['complete_existing_zero']}
scopes={r['namespace']:r for r in d['gate_plan']}
deps=set();routes=[]
for n,r in enumerate(sp['rows'],1):
 visible=closure(owners[r['namespace']]);deps|=visible
 assert set(r['source_files'])<=visible
 assert locate(r['imports'][0])==owners[r['namespace']]
 source=Path(r['scratch_source']);text=source.read_text()
 collector=(P/'StatusCollector.lean').read_text()
 assert collector in text
 assert 'ProofGraph.search goal.proposition tactic 40000' in text
 assert '#m1_obligation_status '+r['namespace']+' using aesop' in text
 routes.append(dict(r,order=n,owner=owners[r['namespace']],names=scopes[r['namespace']]['names'],log=str(P/'status-logs'/(r['namespace']+'.log')),result=str(P/'status-logs'/(r['namespace']+'.json')),scratch_sha256=hashlib.sha256(source.read_bytes()).hexdigest()))
deps|={'tools/ProofGraph/Search.lean','tools/ProofGraph/Ledger.lean','src/Effect4/Laws/Auto/Obligations.lean','src/Effect4/Laws/Auto/RuleSets.lean'}
plan={'status':'prepared only; no Lean executed','head':d['head'],'collector_sha256':hashlib.sha256(collector.encode()).hexdigest(),'source_hashes':{p:hashlib.sha256(texts[p].encode()).hexdigest() for p in sorted(deps)},'scope_count':len(routes),'statement_count':sum(r['N'] for r in routes),'rows':routes}
(P/'status-route.json').write_text(json.dumps(plan,indent=2)+'\n')
q=shlex.quote
lines=['#!/usr/bin/env bash','set -euo pipefail','# Sole compiler lease required. This script has been prepared, not executed.',f'cd {q(str(ROOT))}',f'python3 {q(str(P/"validate-status.py"))} preflight',f'mkdir -p {q(str(P/"status-logs"))}']
for r in routes:
 lines.extend(['',f'# {r["order"]:02d}/36: {r["namespace"]}; N={r["N"]}',f'if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true {q(r["scratch_source"])} > {q(r["log"])} 2>&1; then','  m1_lean_rc=0','else','  m1_lean_rc=$?','fi',f'python3 {q(str(P/"validate-status.py"))} log {q(r["namespace"])} {q(r["log"])} "$m1_lean_rc" > {q(r["result"])}'])
lines.extend(['',f'python3 {q(str(P/"validate-status.py"))} summary'])
(P/'status-serial.sh').write_text('\n'.join(lines)+'\n')
# A single dependency-ordered build per changed gate-owner module, after all markers/gates apply.
remaining=set(owners.values());ordered=[]
while remaining:
 ready=sorted(p for p in remaining if not (closure(p)-{p})&remaining)
 assert ready,'cycle in proposed gate owners'
 ordered.extend(ready);remaining-=set(ready)
(P/'gate-build-order.txt').write_text('# Prepared only. After marker/gate application, one command per owner in dependency order.\n'+'\n'.join('LEAN_NUM_THREADS=1 lake build '+p.removeprefix('src/').removesuffix('.lean').replace('/','.') for p in ordered)+'\n')
print(json.dumps({'scopes':len(routes),'statements':sum(r['N'] for r in routes),'source_dependencies_hashed':len(deps),'distinct_new_gate_owner_modules':len(ordered),'all_scope_sources_imported':True,'all_collector_copies_exact':True},indent=2))

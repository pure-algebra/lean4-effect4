from pathlib import Path
import csv,hashlib,json
P=Path(__file__).parent;d=json.loads((P/'inventory.json').read_text())
def tsv(name,headers,rows):
 with (P/name).open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(headers);w.writerows(rows)
tsv('exact-namespaces.tsv',['namespace','exact_N','prefix_N','source_files'],[(r['namespace'],r['exact_N'],r['prefix_N'],'; '.join(r['source_files'])) for r in d['exact_namespaces']])
tsv('gate-plan.tsv',['namespace','N','existing_complete_zero','owner','position','initial_ceiling_bound','final_ceiling','banks','source_files'],[(r['namespace'],r['N'],r['complete_existing_zero'],r['gate_owner'],r['gate_position'],r['new_initial_ceiling_bound'],r['final_ceiling'],','.join(r['banks']),'; '.join(r['sources'])) for r in d['gate_plan']])
new=[r for r in d['gate_plan'] if not r['complete_existing_zero']]
(P/'new-gates.txt').write_text('-- PREPARED ONLY: initial ceiling N is a total-count upper bound, not a measured open count.\n-- First preserve all-wanted snapshots, run the status plan, reconcile live markers, then insert.\n-- No existing zero gate is replaced or relaxed. Final ceiling is 0 except held M4 = 1.\n\n'+'\n\n'.join('-- '+r['gate_owner']+' at '+str(r['gate_position'])+'\n-- N = '+str(r['N'])+'; final ceiling = '+str(r['final_ceiling'])+'\n'+r['planned_command'] for r in new)+'\n')
(P/'retained-gates.txt').write_text('-- Read-only copy of all 19 existing task zero gate sites; retain the exact tactics.\n\n'+'\n\n'.join('-- '+r['path']+':'+str(r['line'])+'; currently visible = '+str(r['visible_count'])+' / full prefix = '+str(r['full_live_prefix_count'])+'\n'+r['command'] for r in d['gates'] if not r['fixture'])+'\n')
cross=[r for r in d['gate_plan'] if len(r['sources'])>1]
readme=f'''# Phase B live obligation and gate inventory

Static source snapshot at HEAD `{d['head']}`. No Lean process, proof search,
proof replacement, marker removal, gate insertion, or live source edit was performed.
Root's compile results remain the evidence for elaboration; these counts are statements,
not claims about how many proofs are open or complete.

## Reconciled counts

| Cohort | Statements |
| --- | ---: |
| Present at placement HEAD | 169 |
| Manual Phase B ledgers | 32 |
| Main statement package, including held M4 | 97 |
| Expect statement | 1 |
| Indexed-column statements: draft 8 + actual 4 | 12 |
| Task total | **311** |
| Separate intentional ledger fixture declarations | 6 |

The script independently reads HEAD, the manual manifest, and the retained main-package
before/after snapshots. It checks that the five cohorts are disjoint and exhaust the 311
live task names. It finds no duplicate obligation declaration names and no parser refusals.
Five similarly named `Conform.Obligation` data declarations were inspected and excluded by
nominal type; their exact names, source locations, and reasons remain in `inventory.json`.

There are **59 exact source namespaces**, grouped into **54 disjoint complete gate scopes**.
Exact namespace counts exclude descendant namespaces; gate counts include descendants.
`exact-namespaces.tsv` records both forms, avoiding double counting nested namespaces.

**19 existing zero-gate sites cover 90 task statements; 36 additional complete gate sites
cover the other 221.** Existing sites use 18 distinct scopes: the earlier partial
`Effect4.Program.Guard.M1Origin` gate in RaceSites and its complete downstream gate in Core
share one prefix. Both remain. Therefore the final proposal has **55 sites / 54 scopes**,
not a duplicate obligation or a relaxation. Each statement belongs to exactly one of the
54 canonical complete scopes. Held `Effect4.Program.Guard.M4Handshake` contains exactly
one statement; its final ceiling stays 1. Other final ceilings are 0.

All 18 originally uncovered namespaces are retained in the plan, including those without
new main-package additions. The original pre-fill snapshots are unchanged. The manual32
are Phase B frozen statements, not retrospectively claimed Phase A before-proof evidence.

## Files and use

- `inventory.json`: full declaration list, exact namespace counts, all gate sites/tactics,
  import visibility, complete gate plan, cohort membership, source hashes, and exclusions.
- `exact-namespaces.tsv`: 59 exact namespace counts and source contributors.
- `gate-plan.tsv`: 54 complete scopes, total N, exact owner, location, bank, and ceilings.
- `new-gates.txt`: all 36 exact proposed gate commands grouped by owner; prepared only.
- `retained-gates.txt`: verbatim commands for the existing 19 task gates, including local
  add-rules clauses. Do not replace these with a generic bank-only command.
- `status-plan.json` and `status/*.lean`: 36 scratch status probes for uncovered scopes,
  using `StatusCollector.lean` at the corrected 40000 cap; its only change is logging the search failure diagnostic as `M1_RESIDUAL`.
  Existing complete zero gates need no redundant status search; retain their tactics and
  use fresh build evidence. Every status probe remains unrun.
- `inventory.py` and `render.py`: repeatable read-only source scan and scratch report producer.

The proposed initial `ceiling N` uses total statements as an upper bound, **not measured
open work**. Preserve all-wanted snapshots before status or marker changes. After the
fresh final-path census, use status results to reconcile markers and pin actual live gates.
A searched proof still carrying a wanted marker is rejected by the real gate, even when
its ceiling is large. `beginRace_pendingOk` is the only uncovered task seat currently
without a wanted marker; this inventory does not infer its proof status from that fact.

The probes use Stores for machine/simulation/origin groups, TypedState for Expect and
indexed controls, and Stores + TypedState for World/ForkSource. Status calls are serial;
no new proof bodies are generated in live files. Scratch temporary theorem names are
separate from the live publication names.

## Cross-file gate placement

These owners already import all contributing modules; no upward or cyclic imports are
proposed. A gate in only the earliest contributing file would miss later declarations.

| Scope | N | Complete gate owner |
| --- | ---: | --- |
'''
for r in cross:
 readme+='| `'+r['namespace']+'` | '+str(r['N'])+' | `'+r['gate_owner']+'` '+str(r['gate_position'])+' |\n'
readme+='''
The indexed fixtures are reachable through the leading imports of
`Test/Audit/TypedStateDecl.lean`; no duplicate `Test.All` imports are proposed. The four
positive generated shapes, five refusal controls, and eight draft wanted statements are
owner-reported compiled green; this inventory directly counts the eight draft plus four
actual declarations. The Expect wanted declaration now precedes `saved_from_clauses`.

A snapshot hash mismatch after this report means the corresponding row must be refreshed,
not that a source edit is wrong. This inventory intentionally does not run the compiler.
'''
(P/'README.md').write_text(readme)
print('Wrote README, exact namespace and gate tables, new/retained gate commands.')

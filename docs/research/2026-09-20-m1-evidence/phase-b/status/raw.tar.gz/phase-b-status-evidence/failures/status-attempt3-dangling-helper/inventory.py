from pathlib import Path
import collections,functools,hashlib,importlib.util,json,re,subprocess,sys
ROOT=Path('/Users/pooks/Dev/lean4-effect4');OUT=Path(__file__).parent
spec=importlib.util.spec_from_file_location('m1_inventory_parser',Path('/tmp/m1-tools/phase-b-integration/source_parser.py'))
parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
texts={str(p.relative_to(ROOT)):p.read_text() for prefix in ['src','Test','tools'] for p in (ROOT/prefix).rglob('*.lean')}
all_rows=[]
for path,s in sorted(texts.items()):
 if 'Obligation' in s:all_rows.extend(r for r in parser.parse(s,path) if r['obligation'])
assert not parser.errors,parser.errors
# These similarly named Conform data types are not ProofGraph.Obligation Prop.
# Inspect nominal ownership rather than excluding tools or whole namespaces.
nominal_exclusions={
 'Conform.Layout.registry':'Conform.Obligation.Registry',
 'Conform.Model.registry':'Conform.Obligation.Registry',
 'Conform.Obligation.Status.toString':'Conform.Obligation.Status → String',
 'Conform.Selftest.registry':'Conform.Obligation.Registry',
 'Conform.Selftest.ob':'Conform.Obligation (record declared tools/Conform/Core/Obligation.lean:77)',
}
excluded=[dict(r,exclusion_reason=nominal_exclusions[r['name']]) for r in all_rows if r['name'] in nominal_exclusions]
assert {r['name'] for r in excluded}==set(nominal_exclusions)
all_rows=[r for r in all_rows if r['name'] not in nominal_exclusions]
by_name=collections.defaultdict(list)
for r in all_rows:by_name[r['name']].append(r)
assert all(len(v)==1 for v in by_name.values()),{k:v for k,v in by_name.items() if len(v)>1}
fixture_path='Test/Audit/Obligations.lean'
work=[r for r in all_rows if r['path']!=fixture_path]
fixtures=[r for r in all_rows if r['path']==fixture_path]
# Exact source namespaces form a disjoint count; a Lean namespace gate also sees descendants.
exact=collections.defaultdict(list)
for r in work:exact[r['name'].rsplit('.',1)[0]].append(r)
def under(scope,name):return name==scope or name.startswith(scope+'.')
def modpath(mod):
 for pref in ['src/','','tools/']:
  path=pref+mod.replace('.','/')+'.lean'
  if path in texts:return path
imports={p:[q for m in re.findall(r'^import\s+(\S+)',s,re.M) if (q:=modpath(m))] for p,s in texts.items()}
@functools.lru_cache(None)
def ancestors(path):
 seen=set();todo=list(imports[path])
 while todo:
  p=todo.pop()
  if p not in seen:seen.add(p);todo.extend(imports[p])
 return frozenset(seen)
def visible(g,r):return r['path'] in ancestors(g['path']) or r['path']==g['path'] and r['line']<g['line']
gates=[]
for path,s in sorted(texts.items()):
 clean=parser.mask_comments(s)
 for m in re.finditer(r'^[ \t]*#typed_state_obligations\s+([\w.]+)\s+ceiling\s+(\d+)\b',clean,re.M):
  g={'namespace':m[1],'ceiling':int(m[2]),'path':path,'line':s.count('\n',0,m.start())+1,'fixture':path==fixture_path}
  command_lines=s[m.start():].splitlines()
  command=[command_lines[0]]
  for following in command_lines[1:]:
   if following and following[0] in ' \t':command.append(following)
   else:break
  g['command']='\n'.join(command)
  g['visible_names']=[r['name'] for r in all_rows if under(g['namespace'],r['name']) and visible(g,r)]
  g['visible_count']=len(g['visible_names'])
  g['full_live_prefix_count']=sum(under(g['namespace'],r['name']) for r in all_rows)
  g['missing_from_full_prefix']=[r['name'] for r in all_rows if under(g['namespace'],r['name']) and not visible(g,r)]
  gates.append(g)
prod=[g for g in gates if not g['fixture']]
assert len(prod)==19 and all(g['ceiling']==0 for g in prod),(len(prod),prod)
covered={n for g in prod for n in g['visible_names']}
# Candidate gate scopes are all existing scopes plus missing exact namespaces, coalescing
# descendants only when a gate for their parent already represents that subtree.
scopes=set(g['namespace'] for g in prod)
for ns in sorted(exact,key=lambda x:(x.count('.'),x)):
 if not any(under(scope,ns) for scope in scopes):scopes.add(ns)
# The public indexed-control gate intentionally includes the sibling and Nat subnamespaces.
scopes={s for s in scopes if not s.startswith('Test.IndexedColumnDraft.')}
scopes.add('Test.IndexedColumnDraft')
plan=[]
for scope in sorted(scopes):
 rows=[r for r in work if under(scope,r['name'])]
 assert rows,scope
 sources=sorted(set(r['path'] for r in rows));names=sorted(r['name'] for r in rows)
 complete=[g for g in prod if g['namespace']==scope and set(names)<=set(g['visible_names'])]
 existing=[g for g in prod if g['namespace']==scope]
 if complete:
  location=complete[-1]['path'];line=complete[-1]['line'];action='retain existing complete zero gate'
 else:
  # Prefer one of the actual statement owners importing all contributors.
  owners=[p for p in sources if set(sources)<=set(ancestors(p))|{p}]
  if owners:location=min(owners,key=lambda p:len(ancestors(p)));line='EOF after all declarations'
  else:location='src/Effect4/Laws.lean';line='EOF after all imports'
  assert set(sources)<=set(ancestors(location))|{location},(scope,sources,location)
  action='add complete gate after status and live-marker reconciliation'
 banks=['Effect4.TypedState'] if scope.startswith('Test.IndexedColumn') or scope=='Effect4.Program.Typed.M2ExpectWanted' else ['Effect4.Stores','Effect4.TypedState'] if scope.startswith('Effect4.Program.Typed.') else ['Effect4.Stores']
 held=scope=='Effect4.Program.Guard.M4Handshake'
 plan.append({'namespace':scope,'N':len(rows),'sources':sources,'names':names,'wanted_markers':sum(r['marker'] for r in rows),'existing_sites':existing,'complete_existing_zero':bool(complete),'gate_owner':location,'gate_position':line,'action':action,'banks':banks,'new_initial_ceiling_bound':None if complete else len(rows),'final_ceiling':1 if held else 0,'held_M4':held,'planned_command':complete[-1]['command'] if complete else f'#typed_state_obligations {scope} ceiling {len(rows)} using aesop (rule_sets := ['+', '.join(banks)+'])','tactic_note':'Retain exact existing tactic/add-rules clauses when present; the generic planned command is only the new-gate default.'})
# Ensure planned scopes partition every work obligation, even where live sites overlap.
for r in work:assert sum(under(p['namespace'],r['name']) for p in plan)==1,r['name']
old=json.loads(Path('/tmp/m1-tools/phase-b-integration/status-plan.json').read_text())
old_ns={r['namespace'] for r in old['rows']}
assert old_ns<=set(exact),(old_ns-set(exact))
# Independently reconcile the installation cohorts against the retained sources.
head_rows=[]
for path in sorted(texts):
 if 'Obligation' not in texts[path]:continue
 original=subprocess.run(['git','show','HEAD:'+path],cwd=ROOT,text=True,capture_output=True)
 if original.returncode==0:
  head_rows.extend(r for r in parser.parse(original.stdout,path) if r['obligation'] and r['name'] not in nominal_exclusions and path!=fixture_path)
head_names={r['name'] for r in head_rows}
work_names={r['name'] for r in work}
manual_manifest=json.loads(Path('/tmp/m1-tools/phase-b-integration/ledger-manifest.json').read_text())
manual_names={r['ledger'] for r in manual_manifest['entries']}
main_names=set()
reviewed=Path('/tmp/m1-tools/phase-b-apply/reviewed-plan')
for after in (reviewed/'after').rglob('*.lean'):
 rel=after.relative_to(reviewed/'after');before=reviewed/'before'/rel
 after_names={r['name'] for r in parser.parse(after.read_text(),str(rel)) if r['obligation']}
 before_names={r['name'] for r in parser.parse(before.read_text(),str(rel)) if r['obligation']} if before.exists() else set()
 main_names.update(after_names-before_names)
expect_names={r['name'] for r in work if r['name'].startswith('Effect4.Program.Typed.M2ExpectWanted.')}
indexed_names={r['name'] for r in work if r['name'].startswith('Test.IndexedColumn')}
cohorts={'existing_at_HEAD':head_names,'manual_ledgers':manual_names,'main_skeleton_including_held_M4':main_names,'Expect':expect_names,'indexed_controls':indexed_names}
assert [len(x) for x in cohorts.values()]==[169,32,97,1,12],{k:len(v) for k,v in cohorts.items()}
assert set().union(*cohorts.values())==work_names
for name in work_names:assert sum(name in v for v in cohorts.values())==1,name
assert not parser.errors,parser.errors
old_missing=json.loads(Path('/tmp/m1-tools/phase-b-integration/gates.json').read_text())['missing_gate_namespaces']
source_hashes={p:hashlib.sha256(texts[p].encode()).hexdigest() for p in sorted(set(r['path'] for r in all_rows)|set(g['path'] for g in gates))}
result={'status':'static live-source inventory; no Lean/search or gate execution','head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'nat_controls':'owner confirmed stable: NatDirect.projection and NatNested.projection, two added wanted seats','all_explicit_obligation_count':len(all_rows),'work_obligation_count':len(work),'intentional_fixture_obligation_count':len(fixtures),'exact_work_namespace_count':len(exact),'complete_gate_scope_count':len(plan),'live_zero_gate_sites':len(prod),'live_zero_distinct_scopes':len({g['namespace'] for g in prod}),'live_zero_covered_work_count':len(covered),'work_uncovered_count':len(work)-len(covered),'new_complete_gate_sites_needed':sum(not p['complete_existing_zero'] for p in plan),'held_M4_count':sum(p['N'] for p in plan if p['held_M4']),'parser_refusals':parser.errors,'nominal_exclusions':excluded,'cohort_counts':{k:len(v) for k,v in cohorts.items()},'cohort_names':{k:sorted(v) for k,v in cohorts.items()},'source_hashes':source_hashes,'exact_namespaces':[{'namespace':ns,'exact_N':len(rs),'prefix_N':sum(under(ns,r['name']) for r in work),'source_files':sorted(set(r['path'] for r in rs)),'names':[r['name'] for r in rs]} for ns,rs in sorted(exact.items())],'gates':gates,'gate_plan':plan,'all_obligations':all_rows,'intentional_fixture_names':[r['name'] for r in fixtures],'original_uncovered_namespaces_retained':old_missing}
(OUT/'inventory.json').write_text(json.dumps(result,indent=2)+'\n')
# Scratch per-scope status sources use the existing trusted collector, unchanged.
collector=(OUT/'StatusCollector.lean').read_text()
statusdir=OUT/'status';statusdir.mkdir(exist_ok=True)
# Remove only this producer's prior wrappers so old diagnostic plans cannot be
# confused with the current no-redundant-search plan.
for stale in statusdir.glob('*.lean'):stale.unlink()
status_plan=[]
for p in plan:
 if p['complete_existing_zero']:continue
 module=p['gate_owner'].removeprefix('src/').removesuffix('.lean').replace('/','.')
 src=statusdir/(p['namespace']+'.lean')
 tactic='aesop (rule_sets := ['+', '.join(p['banks'])+'])'
 src.write_text('import '+module+'\n'+collector+'\n#m1_obligation_status '+p['namespace']+' using '+tactic+'\n')
 status_plan.append({'namespace':p['namespace'],'N':p['N'],'imports':[module],'source_files':p['sources'],'scratch_source':str(src),'command':'LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true '+str(src),'cap':40000,'status':'not run','note':'For this uncovered scope only; status uses current declarations and does not fill proofs or remove markers.'})
(OUT/'status-plan.json').write_text(json.dumps({'status':'prepared, not run','scope':'36 uncovered complete scopes only; existing complete zero gates retain their source tactics and fresh build evidence','retained_live_gate_scopes':[p['namespace'] for p in plan if p['complete_existing_zero']],'rows':status_plan},indent=2)+'\n')
summary={k:v for k,v in result.items() if not isinstance(v,(list,dict))}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))

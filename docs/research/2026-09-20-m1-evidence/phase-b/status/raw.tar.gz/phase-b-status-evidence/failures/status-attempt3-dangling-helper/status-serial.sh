#!/usr/bin/env bash
set -euo pipefail
# Sole compiler lease required. This script has been prepared, not executed.
cd /Users/pooks/Dev/lean4-effect4
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py preflight
mkdir -p /tmp/m1-tools/phase-b-live-ledger/status-logs

# 01/36: Effect4.Api.M1Origin; N=18
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Api.M1Origin.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.M1Origin.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Api.M1Origin /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.M1Origin.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.M1Origin.json

# 02/36: Effect4.Api.M1Trace; N=15
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Api.M1Trace.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.M1Trace.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Api.M1Trace /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.M1Trace.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.M1Trace.json

# 03/36: Effect4.Api.TraceFacts.M1Trace; N=3
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Api.TraceFacts.M1Trace.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.TraceFacts.M1Trace.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Api.TraceFacts.M1Trace /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.TraceFacts.M1Trace.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Api.TraceFacts.M1Trace.json

# 04/36: Effect4.Machine.ArenaObligations; N=15
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.ArenaObligations.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.ArenaObligations.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.ArenaObligations /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.ArenaObligations.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.ArenaObligations.json

# 05/36: Effect4.Machine.ArenaRed.Obligations; N=2
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.ArenaRed.Obligations.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.ArenaRed.Obligations.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.ArenaRed.Obligations /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.ArenaRed.Obligations.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.ArenaRed.Obligations.json

# 06/36: Effect4.Machine.M1.CompletionSupport; N=2
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1.CompletionSupport.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.CompletionSupport.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1.CompletionSupport /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.CompletionSupport.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.CompletionSupport.json

# 07/36: Effect4.Machine.M1.DeferredWanted; N=31
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1.DeferredWanted.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.DeferredWanted.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1.DeferredWanted /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.DeferredWanted.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.DeferredWanted.json

# 08/36: Effect4.Machine.M1.Handles; N=9
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1.Handles.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.Handles.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1.Handles /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.Handles.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1.Handles.json

# 09/36: Effect4.Machine.M1Clock; N=6
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1Clock.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Clock.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1Clock /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Clock.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Clock.json

# 10/36: Effect4.Machine.M1Origin; N=9
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1Origin.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Origin.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1Origin /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Origin.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Origin.json

# 11/36: Effect4.Machine.M1OriginApproximation; N=2
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1OriginApproximation.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginApproximation.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1OriginApproximation /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginApproximation.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginApproximation.json

# 12/36: Effect4.Machine.M1OriginBook; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1OriginBook.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginBook.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1OriginBook /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginBook.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginBook.json

# 13/36: Effect4.Machine.M1OriginClauses; N=10
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1OriginClauses.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginClauses.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1OriginClauses /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginClauses.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1OriginClauses.json

# 14/36: Effect4.Machine.M1Trace; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.M1Trace.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Trace.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.M1Trace /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Trace.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.M1Trace.json

# 15/36: Effect4.Machine.Witnesses.M1Witnesses; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Machine.Witnesses.M1Witnesses.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.Witnesses.M1Witnesses.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Machine.Witnesses.M1Witnesses /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.Witnesses.M1Witnesses.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Machine.Witnesses.M1Witnesses.json

# 16/36: Effect4.Program.Agreement.M1Origin; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Agreement.M1Origin.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Agreement.M1Origin.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Agreement.M1Origin /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Agreement.M1Origin.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Agreement.M1Origin.json

# 17/36: Effect4.Program.Agreement.M1Quiet; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Agreement.M1Quiet.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Agreement.M1Quiet.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Agreement.M1Quiet /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Agreement.M1Quiet.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Agreement.M1Quiet.json

# 18/36: Effect4.Program.Guard.M4Handshake; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Guard.M4Handshake.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.M4Handshake.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Guard.M4Handshake /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.M4Handshake.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.M4Handshake.json

# 19/36: Effect4.Program.Guard.OuterDriver.M1Clock; N=9
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Guard.OuterDriver.M1Clock.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.OuterDriver.M1Clock.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Guard.OuterDriver.M1Clock /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.OuterDriver.M1Clock.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.OuterDriver.M1Clock.json

# 20/36: Effect4.Program.Guard.SingleGuard.M1Clock; N=5
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Guard.SingleGuard.M1Clock.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.SingleGuard.M1Clock.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Guard.SingleGuard.M1Clock /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.SingleGuard.M1Clock.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Guard.SingleGuard.M1Clock.json

# 21/36: Effect4.Program.Sched.M1Actions; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1Actions.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Actions.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1Actions /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Actions.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Actions.json

# 22/36: Effect4.Program.Sched.M1Clock; N=5
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1Clock.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Clock.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1Clock /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Clock.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Clock.json

# 23/36: Effect4.Program.Sched.M1Deliver; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1Deliver.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Deliver.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1Deliver /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Deliver.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Deliver.json

# 24/36: Effect4.Program.Sched.M1Drive; N=7
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1Drive.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Drive.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1Drive /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Drive.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Drive.json

# 25/36: Effect4.Program.Sched.M1Evaluate; N=2
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1Evaluate.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Evaluate.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1Evaluate /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Evaluate.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Evaluate.json

# 26/36: Effect4.Program.Sched.M1Hooks; N=4
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1Hooks.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Hooks.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1Hooks /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Hooks.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Hooks.json

# 27/36: Effect4.Program.Sched.M1Origin; N=10
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1Origin.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Origin.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1Origin /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Origin.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1Origin.json

# 28/36: Effect4.Program.Sched.M1OriginFibers; N=6
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1OriginFibers.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1OriginFibers.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1OriginFibers /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1OriginFibers.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1OriginFibers.json

# 29/36: Effect4.Program.Sched.M1PendingOrigin; N=4
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Sched.M1PendingOrigin.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1PendingOrigin.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Sched.M1PendingOrigin /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1PendingOrigin.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Sched.M1PendingOrigin.json

# 30/36: Effect4.Program.Typed.M2ExpectWanted; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Typed.M2ExpectWanted.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.M2ExpectWanted.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Typed.M2ExpectWanted /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.M2ExpectWanted.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.M2ExpectWanted.json

# 31/36: Effect4.Program.Typed.M2ForkSourceWanted; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Typed.M2ForkSourceWanted.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.M2ForkSourceWanted.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Typed.M2ForkSourceWanted /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.M2ForkSourceWanted.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.M2ForkSourceWanted.json

# 32/36: Effect4.Program.Typed.WorldControlWanted; N=5
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Typed.WorldControlWanted.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.WorldControlWanted.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Typed.WorldControlWanted /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.WorldControlWanted.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.WorldControlWanted.json

# 33/36: Effect4.Program.Typed.WorldWanted; N=19
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Program.Typed.WorldWanted.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.WorldWanted.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Program.Typed.WorldWanted /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.WorldWanted.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Program.Typed.WorldWanted.json

# 34/36: Effect4.Run.M1Trace; N=1
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Effect4.Run.M1Trace.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Run.M1Trace.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Effect4.Run.M1Trace /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Run.M1Trace.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Effect4.Run.M1Trace.json

# 35/36: Test.IndexedColumnActual; N=4
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Test.IndexedColumnActual.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Test.IndexedColumnActual.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Test.IndexedColumnActual /tmp/m1-tools/phase-b-live-ledger/status-logs/Test.IndexedColumnActual.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Test.IndexedColumnActual.json

# 36/36: Test.IndexedColumnDraft; N=8
if LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-tools/phase-b-live-ledger/status/Test.IndexedColumnDraft.lean > /tmp/m1-tools/phase-b-live-ledger/status-logs/Test.IndexedColumnDraft.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py log Test.IndexedColumnDraft /tmp/m1-tools/phase-b-live-ledger/status-logs/Test.IndexedColumnDraft.log "$m1_lean_rc" > /tmp/m1-tools/phase-b-live-ledger/status-logs/Test.IndexedColumnDraft.json

python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py summary

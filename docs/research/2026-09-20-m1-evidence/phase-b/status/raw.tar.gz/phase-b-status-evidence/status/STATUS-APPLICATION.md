# Serial status and guarded gate application

Prepared only. No Lean/compiler process or live source edit was performed here.
The Python controls use synthetic statuses and temporary copies; they are not proof results.

After the fresh before-fill census, with all source changes built and the sole compiler
lease available, run these commands serially from the repository. Refreshing the inventory
and route is read-only and preserves the retained original snapshots.

```sh
python3 /tmp/m1-tools/phase-b-live-ledger/inventory.py
python3 /tmp/m1-tools/phase-b-live-ledger/render.py
python3 /tmp/m1-tools/phase-b-live-ledger/prepare-status-route.py
bash /tmp/m1-tools/phase-b-live-ledger/status-serial.sh
python3 /tmp/m1-tools/phase-b-live-ledger/apply-status-gates.py prepare /tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan
```

The runner performs exactly 36 sequential Lean status calls with `LEAN_NUM_THREADS=1`.
Each call writes its own raw log and validated JSON under `status-logs/`. It stops on a
failed process, missing/extra/duplicate statement, malformed summary, wrong cap or total,
or a rejected searched term. The complete summary must account for exactly 221 names.
Each open search also retains its `M1_RESIDUAL` diagnostic in the raw log. The parser counts only exact `M1_STATUS` lines; residual text is not another status. Open means search did not supply a checked proof at this budget, not logical falsity.

`prepare` creates `before/`, `after/`, `change.patch`, `manifest.json`, and
`gate-serial.sh`. It reads and validates the original raw status logs again. The manifest
records the original declaration and marker line, exact header hash, proposed marker
operation, original/updated file hashes, source dependency hashes, and log hashes.
No live file is changed. Review the concrete patch before invoking the explicit apply:

```sh
python3 /tmp/m1-tools/phase-b-live-ledger/apply-status-gates.py apply /tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan
python3 /tmp/m1-tools/phase-b-live-ledger/apply-status-gates.py apply /tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan --execute
bash /tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-serial.sh
```

The first apply command checks all hashes and writes nothing. The second refuses input,
source, or reviewed snapshot drift before writing. Reapplying is refused. The tool never
writes proof bodies, changes propositions, registers a rule, or changes an existing gate.

## Marker and ceiling policy

- Remove an existing wanted marker only for an admissible, checked `closed` status.
- Retain markers for `open` results. Add the currently missing
  `M1PendingOrigin.beginRace_pendingOk` marker only if its measured status is open.
  Any other missing marker is a refusal, not an automatic repair.
- Preserve all 19 existing zero gate sites and their exact tactic text.
- Add exactly 36 complete gates. **Each Phase B ceiling is its total N**, regardless of
  measured open count. The manifest records measured open/closed counts separately.
- Preserve the one held M4 marker and its N=1 gate. An unexpected closed M4 result stops
  preparation for explicit review; it is not silently treated as completed M4 work.
- Final Phase C ceilings remain 0 except the held M4 ceiling of 1.

The 36 new gates have 30 distinct owners. The generated gate script builds those owners
in dependency order, one command at a time; dependencies also rebuild any earlier source
whose marker changed. Every new gate report must retain its exact N and match its prior
status classification. The compiler's marker checks independently require the same
per-statement classification, not only the same aggregate number.

## Publication order and changed search results

`ProofGraph.addTheorem` in `tools/ProofGraph/Search.lean` publishes with `addDecl`; it does
not register an aesop rule or a simp theorem. Aesop obtains its named global banks through
`getGlobalRuleSets` (`.lake/packages/aesop/Aesop/Frontend/Tactic.lean`); registration is
explicit in its attribute handler. Thus publication of an earlier `.checked` name alone
has no source-level path that adds it to the bank. The status collector also publishes its
checked candidates under separate scratch names without registering them.

This is a source observation, not a replay-invariance theorem. Each actual gate searches
again. If a later gate now closes a marked goal, or fails a goal whose marker was removed,
Lean refuses it; `gate-serial.sh` stops and preserves that build log. If aggregate counts
somehow change on a successful run, `validate-gates.py` also refuses the mismatch. Record
the old and new outcome, collect only the affected scope in the new imported environment,
and prepare a new reviewed marker patch. Do not guess, remove a marker from the error
message alone, raise a cap, or relax any preexisting zero ceiling.

## Checks performed on the preparation tools

`status-application-controls.json` records Python-only finite checks for all-open,
closed-except-held, mixed statuses, all 36 exact scope-name sets (including the two names
ending in apostrophes), failed/truncated/duplicate/mismatched logs, trust rejection,
unexpected M4 closure, total-N ceilings, dry-run nonmutation, source/snapshot drift,
exact application in a temporary copy, repeat-application refusal, and gate-count drift.
`bash -n` checks the prepared status script. No synthetic status file is accepted as live
proof evidence, and no real status or gate result is claimed until the Lean calls run.

# Restart the status pass after the Search repair

This is a prepared sequence, not a compiler result. No live source was changed.

## Preserved failure

`status-attempt3-dangling-helper/` is an independent copy of the third failed
attempt. Its `archive.json` records SHA-256 hashes for 49 files: the failed first
scope's raw log and empty result file, all 36 probes, the inventory and route, the
runner and preparation sources, the corrected local collector, and the exact
pre-repair Search source. The active `status-logs/` directory was left untouched.

The decisive error is in
`status-attempt3-dangling-helper/status-logs/Effect4.Api.M1Origin.log`:
the kernel cannot find
`_private._stdin.0.Effect4.Machine.spawn.match_1.splitter` while publishing
`M1StatusChecked.Effect4.Api.M1Origin.spawn_fibers`. The earlier self-named axiom
diagnostic is part of this failed publication, not a usable theorem result.
The scope has no summary; its partial open/closed lines are not status evidence.

The local `StatusCollector.lean` and every archived probe contain explicit
`Nat` types on `closed`, `remaining`, and `rejected`. The collector hash is
`4b4e1b9fc255e2671ad68b9482d0c63a2f1e62a0a0f61dc2daae4595d394ebd4`.

The active collector and all 36 active probes now use
`ProofGraph.axiomsOfTheorem goal.proposition proof`. This reports a disallowed
dependency from either the proposition or the proof as `rejected` before
publication. `collector-type-body.patch` records the sole collector change;
all three explicit `Nat` counters remain. The active collector hash is
`a969c7e63c0c41e5ffa36dc4528f408dff0d82d3a878cf9999ff8d3d0dafbabd`.
The route was refreshed for consistency, but must be refreshed again after
the repaired build and census finish; it is not compiled status evidence.

## Preconditions

First finish the repaired Search finite controls, rebuild its affected imported
modules, and complete the corrected before-fill census under the sole compiler
lease. Keep the prior census and provisional rewrite fragments unchanged.
Do not run the status pass against old imported object files: the source-hash
preflight deliberately does not claim to validate compiled prerequisites.

The following commands only refresh scratch inputs until the explicit runner.
Run from the repository. Do not copy the older integration collector over the
local one. `inventory.py` reads this local corrected collector and regenerates
all 36 probes; `render.py` writes reports; `prepare-status-route.py` validates
the probe copies and refreshes hashes, but does not regenerate probes itself.

```sh
cd /Users/pooks/Dev/lean4-effect4
python3 - <<'PY'
from pathlib import Path
import hashlib, json
p = Path('/tmp/m1-tools/phase-b-live-ledger')
a = p / 'status-attempt3-dangling-helper'
manifest = json.loads((a / 'archive.json').read_text())
for name, expected in manifest['files'].items():
    assert hashlib.sha256((a / name).read_bytes()).hexdigest() == expected, name
collector = (p / 'StatusCollector.lean').read_text()
assert hashlib.sha256(collector.encode()).hexdigest() == 'a969c7e63c0c41e5ffa36dc4528f408dff0d82d3a878cf9999ff8d3d0dafbabd'
assert 'ProofGraph.axiomsOfTheorem goal.proposition proof' in collector
for name in ('closed', 'remaining', 'rejected'):
    assert f'let mut {name} : Nat := 0' in collector
assert not (p / 'status-results.json').exists(), 'archive any prior complete results explicitly'
old = p / 'status-logs'
saved = p / 'status-attempt3-original-logs'
assert old.is_dir() and not saved.exists(), 'refuse to overwrite prior logs'
old.rename(saved)
PY
python3 /tmp/m1-tools/phase-b-live-ledger/inventory.py
python3 /tmp/m1-tools/phase-b-live-ledger/render.py
python3 /tmp/m1-tools/phase-b-live-ledger/prepare-status-route.py
python3 - <<'PY'
from pathlib import Path
import json
p = Path('/tmp/m1-tools/phase-b-live-ledger')
summary = json.loads((p / 'summary.json').read_text())
route = json.loads((p / 'status-route.json').read_text())
assert summary['work_obligation_count'] == 311
assert summary['live_zero_gate_sites'] == 19
assert summary['held_M4_count'] == 1
assert route['scope_count'] == 36 and route['statement_count'] == 221
collector = (p / 'StatusCollector.lean').read_text()
for name in ('closed', 'remaining', 'rejected'):
    assert f'let mut {name} : Nat := 0' in collector
for row in route['rows']:
    assert collector in Path(row['scratch_source']).read_text(), row['namespace']
old = json.loads((p / 'status-attempt3-dangling-helper/inventory.json').read_text())
new = json.loads((p / 'inventory.json').read_text())
retained = lambda d: sorted((g['path'], g['command']) for g in d['gates'] if not g['fixture'])
assert retained(old) == retained(new), 'existing zero gates changed'
PY
bash -n /tmp/m1-tools/phase-b-live-ledger/status-serial.sh
python3 /tmp/m1-tools/phase-b-live-ledger/validate-status.py preflight
```

After those checks, with the sole compiler lease:

```sh
bash /tmp/m1-tools/phase-b-live-ledger/status-serial.sh
python3 /tmp/m1-tools/phase-b-live-ledger/apply-status-gates.py prepare /tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan
```

The runner starts all 36 scopes from the beginning at cap 40000, serially with
`LEAN_NUM_THREADS=1`. A successful full result must account for exactly 221
statements. A failed process or publication is refused, and any trust rejection
stops preparation. New Phase B ceilings remain each scope's total N; the 19
existing zero gates remain verbatim. Preparing the concrete gate patch writes
no proof bodies or live markers; review and application are still separate.

If a deliberately reviewed collector change becomes necessary, archive it as a
new version and update the equality check above explicitly. Do not bypass a hash
failure or silently restore the earlier untyped counters.

## Receipt paragraph

The first complete before-fill census visited 218 modules and 4,062 theorem
statements. It reported 648 closed searches, of which 647 passed its then-current
axiom scan. Those closure counts are provisional and cannot authorize proof
replacement: the third status attempt exposed a returned proof that still named
a temporary match-splitter after rollback, and the axiom scan had silently ignored
that missing dependency. The first scope then failed kernel publication, so no
complete status scope was accepted. The original census and frozen candidate
fragments are retained unchanged; only a fresh run after the checked-environment
and synchronous-validation repair can establish usable closure results. The
minimal red evidence is `status-attempt3-dangling-helper/status-logs/Effect4.Api.M1Origin.log`,
with its archived `Search-before-repair.lean` and
`status/Effect4.Api.M1Origin.lean` reproducing the relevant wrapper and caller.

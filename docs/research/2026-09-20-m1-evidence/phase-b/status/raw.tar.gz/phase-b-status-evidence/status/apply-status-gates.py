#!/usr/bin/env python3
"""Prepare a reviewable patch, then explicitly apply only unchanged, reviewed inputs."""
from pathlib import Path
import argparse,collections,difflib,hashlib,importlib.util,json,re,shlex,sys
P=Path(__file__).parent;ROOT=Path('/Users/pooks/Dev/lean4-effect4')
spec=importlib.util.spec_from_file_location('m1status_validator',P/'validate-status.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
spec=importlib.util.spec_from_file_location('m1source_parser','/tmp/m1-tools/phase-b-integration/source_parser.py');parser=importlib.util.module_from_spec(spec);spec.loader.exec_module(parser)
def sha(data):return hashlib.sha256(data if isinstance(data,bytes) else data.encode()).hexdigest()
def under(scope,name):return name==scope or name.startswith(scope+'.')
def scan_markers(text,names):
 stack=[];out=[];offset=0
 for raw,masked in zip(text.splitlines(keepends=True),parser.mask_comments(text).splitlines(keepends=True),strict=True):
  m=re.match(r'^\s*namespace\s+(\S+)\s*$',masked)
  if m:stack.append(('ns',m[1]))
  elif re.match(r'^\s*(section(?:\s+\S+)?|mutual)\s*$',masked):stack.append(('other',''))
  elif re.match(r'^\s*end(?:\s+\S+)?\s*$',masked):
   if stack:stack.pop()
  else:
   m=re.match(r'^[ \t]*#proof_wanted[ \t]+([\w.\']+)[ \t]*\n?$',masked)
   if m:
    ident=m[1];ns='.'.join(n for k,n in stack if k=='ns');candidates=[]
    if ident.startswith('_root_.'):candidates=[ident.removeprefix('_root_.')]
    else:
     while ns:
      candidates.append(ns+'.'+ident);ns=ns.rsplit('.',1)[0] if '.' in ns else ''
     candidates.append(ident)
    found=next((n for n in candidates if n in names),None)
    if found is None:raise ValueError('unresolved wanted marker '+ident)
    out.append({'name':found,'line':text.count('\n',0,offset)+1,'start':offset,'end':offset+len(raw),'text':raw})
  offset+=len(raw)
 return out

def candidates(inv,results,texts):
 goals={r['name']:r for r in inv['all_obligations'] if r['path']!='Test/Audit/Obligations.lean'}
 scopes={r['namespace']:r for r in inv['gate_plan'] if not r['complete_existing_zero']}
 if set(results)!=set(scopes):raise ValueError('result scope set differs from36 planned scopes')
 statuses={};operations=collections.defaultdict(list);actions=[];gates=[]
 for scope,p in scopes.items():
  result=results[scope]
  if result['rejected']:raise ValueError('trust rejection at '+scope)
  if set(result['names'])!=set(p['names']) or result['N']!=p['N']:raise ValueError('statement set/count mismatch '+scope)
  if any(s not in ('closed','open') for s in result['names'].values()):raise ValueError('invalid status '+scope)
  if result['open']!=sum(s=='open' for s in result['names'].values()):raise ValueError('open count mismatch')
  if result['closed']!=sum(s=='closed' for s in result['names'].values()):raise ValueError('closed count mismatch')
  for name,status in result['names'].items():
   if name in statuses:raise ValueError('duplicate status '+name)
   statuses[name]=status
  if p['held_M4'] and (result['open']!=1 or result['closed']):raise ValueError('held M4 unexpectedly closes: explicit review required')
  command=f"#typed_state_obligations {scope} ceiling {p['N']} using aesop (rule_sets := ["+', '.join(p['banks'])+'])'
  gates.append({'namespace':scope,'N':p['N'],'ceiling':p['N'],'measured_open':result['open'],'measured_closed':result['closed'],'owner':p['gate_owner'],'position':'EOF after existing declarations/imports','command':command,'final_ceiling':p['final_ceiling']})
 if len(statuses)!=221:raise ValueError('expected221 status statements')
 markers={}
 for path in sorted({goals[n]['path'] for n in statuses}):
  for m in scan_markers(texts[path],set(goals)):
   if m['name'] in markers:raise ValueError('duplicate wanted marker '+m['name'])
   markers[m['name']]=dict(m,path=path)
 for name,status in sorted(statuses.items()):
  goal=goals[name];path=goal['path'];marker=markers.get(name)
  action={'name':name,'path':path,'declaration_line':goal['line'],'declaration_header_sha256':sha(goal['header']),'status':status,'original_marker_line':marker['line'] if marker else None}
  if status=='closed' and marker:
   operations[path].append((marker['start'],marker['end'],''));action['action']='remove exact wanted marker'
  elif status=='open' and not marker:
   if name!='Effect4.Program.Sched.M1PendingOrigin.beginRace_pendingOk':raise ValueError('unapproved missing marker '+name)
   text=texts[path];header=goal['header'];starts=[m.start() for m in re.finditer(re.escape(header),text)]
   if len(starts)!=1:raise ValueError('ambiguous declaration header '+name)
   end=starts[0]+len(header);body=re.match(r'\s*:=\s*⟨⟩[ \t]*\n',text[end:])
   if not body:raise ValueError('unsupported obligation body '+name)
   at=end+body.end();insert='#proof_wanted '+goal['short']+'\n'
   operations[path].append((at,at,insert));action['action']='add missing beginRace marker after explicit declaration';action['insertion_offset']=at
  else:action['action']='retain marker' if marker else 'retain marker absence for closed statement'
  actions.append(action)
 by_owner=collections.defaultdict(list)
 for g in gates:by_owner[g['owner']].append(g)
 after={};appended={}
 for path in sorted(set(operations)|set(by_owner)):
  text=texts[path]
  for start,end,replacement in sorted(operations[path],reverse=True):text=text[:start]+replacement+text[end:]
  # Apart from explicit wanted lines, every existing byte is retained.
  def without_markers(s):return ''.join(l for l in s.splitlines(keepends=True) if not re.match(r'^[ \t]*#proof_wanted\b',l))
  if without_markers(text)!=without_markers(texts[path]):raise ValueError('non-marker bytes changed '+path)
  if by_owner[path]:
   if not text.endswith('\n'):raise ValueError('expected newline at EOF '+path)
   appended[path]='\n'+'\n'.join(g['command'] for g in by_owner[path])+'\n'
   text+=appended[path]
  after[path]=text
 for g in inv['gates']:
  if g['fixture']:continue
  before=texts[g['path']];updated=after.get(g['path'],before)
  if g['ceiling']!=0 or before.count(g['command'])!=updated.count(g['command']):raise ValueError('existing zero gate changed '+g['namespace'])
 return after,actions,gates,appended

def load_status(inv,route):
 results={};evidence={}
 for row in route['rows']:
  log=Path(row['log']);stored=Path(row['result'])
  saved=json.loads(stored.read_text())
  parsed=v.parse_log(row,log.read_text(),0)
  if parsed!=saved:raise ValueError('parsed raw log differs from saved result '+row['namespace'])
  if parsed['rejected']:raise ValueError('trust rejection '+row['namespace'])
  results[row['namespace']]=parsed;evidence[str(log)]=sha(log.read_bytes());evidence[str(stored)]=sha(stored.read_bytes())
 return results,evidence

def prepare(out):
 if out.exists():raise ValueError('prepare directory already exists; retain it and choose a new path')
 inv=json.loads((P/'inventory.json').read_text());route=v.get_plan();v.main(['preflight'])
 results,evidence=load_status(inv,route)
 needed=set(inv['source_hashes'])|{p['gate_owner'] for p in inv['gate_plan']}
 texts={p:(ROOT/p).read_text() for p in needed}
 after,actions,gates,appended=candidates(inv,results,texts)
 out.mkdir(parents=True);patch=[];files=[]
 for path,updated in after.items():
  before=texts[path]
  for side,body in [('before',before),('after',updated)]:
   target=out/side/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(body)
  patch.extend(difflib.unified_diff(before.splitlines(keepends=True),updated.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
  files.append({'path':path,'before_sha256':sha(before),'after_sha256':sha(updated),'before':str(out/'before'/path),'after':str(out/'after'/path)})
 inputs={str(P/f):sha((P/f).read_bytes()) for f in ['inventory.json','status-route.json','validate-status.py','apply-status-gates.py','validate-gates.py','gate-build-order.txt']}
 manifest={'status':'prepared for review; not applied','root':str(ROOT),'head':inv['head'],'scope_count':36,'statement_count':221,'existing_zero_sites_preserved':19,'new_gate_count':len(gates),'proof_body_changes':0,'source_hashes':route['source_hashes'],'input_hashes':inputs,'status_evidence_hashes':evidence,'actions':actions,'gates':gates,'files':files,'appended_gate_blocks':appended}
 (out/'change.patch').write_text(''.join(patch));(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 q=shlex.quote
 modules=[line.removeprefix('LEAN_NUM_THREADS=1 lake build ') for line in (P/'gate-build-order.txt').read_text().splitlines() if line.startswith('LEAN_NUM_THREADS=1 lake build ')]
 owner_by_module={g['owner'].removeprefix('src/').removesuffix('.lean').replace('/','.'):g['owner'] for g in gates}
 if set(modules)!=set(owner_by_module):raise ValueError('gate build order does not cover every owner')
 commands=['#!/usr/bin/env bash','set -euo pipefail',f'cd {q(str(ROOT))}',f'python3 {q(str(P/"validate-gates.py"))} preflight {q(str(out))}',f'mkdir -p {q(str(out/"gate-logs"))}']
 for module in modules:
  log=out/'gate-logs'/(module+'.log');result=out/'gate-logs'/(module+'.json')
  commands.extend(['',f'# {module}',f'if LEAN_NUM_THREADS=1 lake build {q(module)} > {q(str(log))} 2>&1; then','  m1_lean_rc=0','else','  m1_lean_rc=$?','fi',f'python3 {q(str(P/"validate-gates.py"))} log {q(str(out))} {q(owner_by_module[module])} {q(str(log))} "$m1_lean_rc" > {q(str(result))}'])
 (out/'gate-serial.sh').write_text('\n'.join(commands)+'\n')
 print(json.dumps({'prepared':str(out),'files':len(files),'removed_markers':sum(a['action']=='remove exact wanted marker' for a in actions),'added_beginRace_marker':sum(a['action'].startswith('add missing') for a in actions),'new_gates':36,'proof_body_changes':0},indent=2))

def apply(out,execute):
 manifest=json.loads((out/'manifest.json').read_text());root=Path(manifest['root'])
 if manifest.get('control_only'):raise ValueError('synthetic control manifest cannot be applied')
 if root!=ROOT:raise ValueError('prepared root mismatch')
 for group in ['source_hashes','input_hashes','status_evidence_hashes']:
  for path,want in manifest[group].items():
   p=(root/path) if group=='source_hashes' else Path(path)
   if sha(p.read_bytes())!=want:raise ValueError('input drift: '+str(p))
 for row in manifest['files']:
  if sha((root/row['path']).read_bytes())!=row['before_sha256']:raise ValueError('live source drift '+row['path'])
  if sha(Path(row['before']).read_bytes())!=row['before_sha256'] or sha(Path(row['after']).read_bytes())!=row['after_sha256']:raise ValueError('reviewed snapshot drift '+row['path'])
 if not execute:print('Review hashes match; no source written. Use apply --execute only after reviewing change.patch.');return
 for row in manifest['files']:(root/row['path']).write_bytes(Path(row['after']).read_bytes())
 print('Applied marker-only edits and36 gates; no Lean or build was run. Existing19zero sites unchanged.')

def main():
 ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='mode',required=True)
 a=sub.add_parser('prepare');a.add_argument('directory',type=Path)
 a=sub.add_parser('apply');a.add_argument('directory',type=Path);a.add_argument('--execute',action='store_true')
 args=ap.parse_args()
 if args.mode=='prepare':prepare(args.directory.resolve())
 else:apply(args.directory.resolve(),args.execute)
if __name__=='__main__':
 try:main()
 except (ValueError,KeyError,OSError,json.JSONDecodeError) as e:print('REFUSED: '+str(e),file=sys.stderr);sys.exit(2)

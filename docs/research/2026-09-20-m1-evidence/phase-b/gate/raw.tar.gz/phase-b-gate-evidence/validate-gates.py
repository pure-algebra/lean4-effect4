#!/usr/bin/env python3
"""Validate actual gate build logs against the reviewed application manifest."""
from pathlib import Path
import hashlib,json,re,sys

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(manifest,owner,text,rc):
 if rc:raise ValueError('failed gate build; retain log and recheck affected scope without relaxing a ceiling')
 out=[]
 for g in [g for g in manifest['gates'] if g['owner']==owner]:
  pattern=re.escape(g['namespace'])+r': (\d+) open, (\d+) proved, (\d+) total; ceiling (\d+)'
  found={tuple(map(int,x)) for x in re.findall(pattern,text)}
  if len(found)!=1:raise ValueError('missing or conflicting gate report '+g['namespace'])
  opened,closed,total,ceiling=next(iter(found))
  if total!=g['N'] or ceiling!=g['N'] or opened+closed!=total:raise ValueError('gate count/PhaseB ceiling mismatch '+g['namespace'])
  if opened!=g['measured_open'] or closed!=g['measured_closed']:raise ValueError('closure classification changed for '+g['namespace']+'; save both outcomes, collect affected status, prepare a new marker patch')
  out.append({'namespace':g['namespace'],'open':opened,'proved':closed,'N':total,'ceiling':ceiling,'matches_before_gate_status':True})
 if not out:raise ValueError('owner has no planned gate')
 return out

def main(args):
 mode=args[0];p=Path(args[1]);m=json.loads((p/'manifest.json').read_text());root=Path(m['root'])
 if mode=='preflight':
  updated={r['path']:r['after_sha256'] for r in m['files']}
  for file,before in m['source_hashes'].items():
   if digest(root/file)!=updated.get(file,before):raise ValueError('applied source drift '+file)
  print('Applied source hashes match reviewed gate plan.');return
 if mode=='log':
  owner,log,rc=args[2],Path(args[3]),int(args[4]);print(json.dumps({'owner':owner,'log':str(log),'rows':parse(m,owner,log.read_text(),rc)},indent=2));return
 raise ValueError('usage: preflight PLAN | log PLAN OWNER LOG EXITCODE')
if __name__=='__main__':
 try:main(sys.argv[1:])
 except (ValueError,KeyError,OSError,json.JSONDecodeError,IndexError) as e:print('REFUSED: '+str(e),file=sys.stderr);sys.exit(2)

#!/usr/bin/env bash
set -euo pipefail
cd /Users/pooks/Dev/lean4-effect4
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py preflight /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan
mkdir -p /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs

# Test.Audit.IndexedColumns
if LEAN_NUM_THREADS=1 lake build Test.Audit.IndexedColumns > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Audit.IndexedColumns.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan Test/Audit/IndexedColumns.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Audit.IndexedColumns.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Audit.IndexedColumns.json

# Effect4.Laws.Machine.Clauses
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Clauses > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Clauses.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/Clauses.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Clauses.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Clauses.json

# Effect4.Laws.Machine.CompletionData
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.CompletionData > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.CompletionData.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/CompletionData.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.CompletionData.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.CompletionData.json

# Effect4.Laws.Machine.Witnesses
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Witnesses > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Witnesses.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/Witnesses.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Witnesses.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Witnesses.json

# Effect4.Laws.Program.Agreement
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Agreement > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Agreement.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Agreement.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Agreement.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Agreement.json

# Effect4.Laws.Api.Supervision
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Api.Supervision > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Api.Supervision.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Api/Supervision.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Api.Supervision.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Api.Supervision.json

# Effect4.Laws.Machine.Approximation
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Approximation > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Approximation.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/Approximation.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Approximation.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Approximation.json

# Effect4.Laws.Machine.Refinement
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Refinement > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Refinement.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/Refinement.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Refinement.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Refinement.json

# Effect4.Laws.Program.Guard.Single
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Guard.Single > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.Single.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Guard/Single.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.Single.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.Single.json

# Test.Machine.Runtime.ArenaContract
if LEAN_NUM_THREADS=1 lake build Test.Machine.Runtime.ArenaContract > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Machine.Runtime.ArenaContract.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan Test/Machine/Runtime/ArenaContract.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Machine.Runtime.ArenaContract.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Machine.Runtime.ArenaContract.json

# Effect4.Laws.Machine.Behaviour
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Behaviour > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Behaviour.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/Behaviour.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Behaviour.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Behaviour.json

# Effect4.Laws.Machine.Handles
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Handles > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Handles.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/Handles.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Handles.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Handles.json

# Effect4.Laws.Program.Agreement.Machine
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Agreement.Machine > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Agreement.Machine.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Agreement/Machine.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Agreement.Machine.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Agreement.Machine.json

# Effect4.Laws.Program.Guard.TraceOrigin
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Guard.TraceOrigin > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.TraceOrigin.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Guard/TraceOrigin.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.TraceOrigin.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.TraceOrigin.json

# Effect4.Laws.Machine.Book
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Book > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Book.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Machine/Book.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Book.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Machine.Book.json

# Effect4.Laws.Program.Guard.Handshake
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Guard.Handshake > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.Handshake.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Guard/Handshake.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.Handshake.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.Handshake.json

# Effect4.Laws.Program.Guard.OuterDriver
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Guard.OuterDriver > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.OuterDriver.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Guard/OuterDriver.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.OuterDriver.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Guard.OuterDriver.json

# Effect4.Laws.Program.Typed.State
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Typed.State > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.State.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Typed/State.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.State.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.State.json

# Effect4.Laws.Run
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Run > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Run.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Run.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Run.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Run.json

# Test.Audit.IndexedColumnActual
if LEAN_NUM_THREADS=1 lake build Test.Audit.IndexedColumnActual > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Audit.IndexedColumnActual.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan Test/Audit/IndexedColumnActual.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Audit.IndexedColumnActual.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Test.Audit.IndexedColumnActual.json

# Effect4.Laws.Program.Simulation.Hooks
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Simulation.Hooks > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Hooks.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Simulation/Hooks.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Hooks.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Hooks.json

# Effect4.Laws.Program.Typed.World
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Typed.World > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.World.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Typed/World.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.World.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.World.json

# Effect4.Laws.Program.Simulation.Fibers
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Simulation.Fibers > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Fibers.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Simulation/Fibers.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Fibers.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Fibers.json

# Effect4.Laws.Program.Typed.ForkSource
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Typed.ForkSource > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.ForkSource.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Typed/ForkSource.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.ForkSource.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Typed.ForkSource.json

# Effect4.Laws.Program.Simulation.Deliver
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Simulation.Deliver > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Deliver.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Simulation/Deliver.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Deliver.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Deliver.json

# Effect4.Laws.Program.Simulation.Actions
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Simulation.Actions > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Actions.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Simulation/Actions.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Actions.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Actions.json

# Effect4.Laws.Program.Simulation.Evaluate
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Simulation.Evaluate > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Evaluate.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Simulation/Evaluate.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Evaluate.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Evaluate.json

# Effect4.Laws.Program.Simulation.Pending
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Simulation.Pending > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Pending.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Simulation/Pending.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Pending.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Pending.json

# Effect4.Laws.Program.Simulation.Drive
if LEAN_NUM_THREADS=1 lake build Effect4.Laws.Program.Simulation.Drive > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Drive.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws/Program/Simulation/Drive.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Drive.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.Program.Simulation.Drive.json

# Effect4.Laws
if LEAN_NUM_THREADS=1 lake build Effect4.Laws > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.log 2>&1; then
  m1_lean_rc=0
else
  m1_lean_rc=$?
fi
python3 /tmp/m1-tools/phase-b-live-ledger/validate-gates.py log /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan src/Effect4/Laws.lean /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.log "$m1_lean_rc" > /private/tmp/m1-tools/phase-b-live-ledger/reviewed-gate-plan/gate-logs/Effect4.Laws.json

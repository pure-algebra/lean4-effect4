import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.Approximation

#auto_census Effect4.Laws.Machine.Approximation heartbeats 20000 using aesop

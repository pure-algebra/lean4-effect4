import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Simulation.Evaluate

#auto_census Effect4.Laws.Program.Simulation.Evaluate heartbeats 20000 using aesop

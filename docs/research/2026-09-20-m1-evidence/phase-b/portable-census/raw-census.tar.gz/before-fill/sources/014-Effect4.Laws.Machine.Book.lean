import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.Book

#auto_census Effect4.Laws.Machine.Book heartbeats 20000 using aesop

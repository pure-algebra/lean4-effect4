import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Typed.World

#auto_census Effect4.Laws.Program.Typed.World heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Sched

#auto_census Effect4.Laws.Program.Sched heartbeats 20000 using aesop

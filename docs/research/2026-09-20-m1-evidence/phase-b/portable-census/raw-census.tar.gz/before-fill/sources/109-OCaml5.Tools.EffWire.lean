import Effect4.Laws
import Effect4.Laws.Auto.Census
import OCaml5.Tools.EffWire

#auto_census OCaml5.Tools.EffWire heartbeats 20000 using aesop

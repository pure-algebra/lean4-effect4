import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Domain.ProgramWire

#auto_census Effect4.Store.Domain.ProgramWire heartbeats 20000 using aesop

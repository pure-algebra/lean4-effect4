import Effect4.Laws
import Effect4.Laws.Auto.Census
import Tools.HostProtocol

#auto_census Tools.HostProtocol heartbeats 20000 using aesop

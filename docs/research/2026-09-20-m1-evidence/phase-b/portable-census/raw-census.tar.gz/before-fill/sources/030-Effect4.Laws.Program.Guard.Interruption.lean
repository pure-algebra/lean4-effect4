import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.Interruption

#auto_census Effect4.Laws.Program.Guard.Interruption heartbeats 20000 using aesop

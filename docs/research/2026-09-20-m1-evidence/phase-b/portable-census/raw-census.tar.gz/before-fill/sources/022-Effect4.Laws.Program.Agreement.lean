import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Agreement

#auto_census Effect4.Laws.Program.Agreement heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Handles.Layer

#auto_census Effect4.Laws.Program.Handles.Layer heartbeats 20000 using aesop

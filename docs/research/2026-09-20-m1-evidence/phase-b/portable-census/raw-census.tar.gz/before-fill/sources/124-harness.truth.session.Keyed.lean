import Effect4.Laws
import Effect4.Laws.Auto.Census
import harness.truth.session.Keyed

#auto_census harness.truth.session.Keyed heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Tools.Variances

#auto_census Tools.Variances heartbeats 20000 using aesop

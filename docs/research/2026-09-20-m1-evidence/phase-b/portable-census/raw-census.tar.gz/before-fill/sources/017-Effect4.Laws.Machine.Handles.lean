import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.Handles

#auto_census Effect4.Laws.Machine.Handles heartbeats 20000 using aesop

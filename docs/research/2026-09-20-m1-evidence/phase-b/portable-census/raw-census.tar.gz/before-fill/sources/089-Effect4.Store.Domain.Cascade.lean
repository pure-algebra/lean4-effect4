import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Domain.Cascade

#auto_census Effect4.Store.Domain.Cascade heartbeats 20000 using aesop

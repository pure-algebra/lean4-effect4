import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.RuntimeR

#auto_census Effect4.Laws.Program.RuntimeR heartbeats 20000 using aesop

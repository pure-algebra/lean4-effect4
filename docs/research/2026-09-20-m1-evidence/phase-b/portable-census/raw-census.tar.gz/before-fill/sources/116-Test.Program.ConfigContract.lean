import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Program.ConfigContract

#auto_census Test.Program.ConfigContract heartbeats 20000 using aesop

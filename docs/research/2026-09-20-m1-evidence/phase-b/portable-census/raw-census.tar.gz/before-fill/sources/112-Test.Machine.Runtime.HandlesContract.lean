import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Machine.Runtime.HandlesContract

#auto_census Test.Machine.Runtime.HandlesContract heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.NativeAssembly

#auto_census Effect4.Laws.Program.Guard.NativeAssembly heartbeats 20000 using aesop

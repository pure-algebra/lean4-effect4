import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Intro.Weight

#auto_census Effect4.Laws.Program.Intro.Weight heartbeats 20000 using aesop

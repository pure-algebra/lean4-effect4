import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Audit.IndexedColumns

#auto_census Test.Audit.IndexedColumns heartbeats 20000 using aesop

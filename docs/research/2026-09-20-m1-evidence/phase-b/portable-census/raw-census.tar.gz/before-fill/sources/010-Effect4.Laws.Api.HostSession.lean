import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Api.HostSession

#auto_census Effect4.Laws.Api.HostSession heartbeats 20000 using aesop

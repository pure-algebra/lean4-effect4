import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4Gen.Main

#auto_census Effect4Gen.Main heartbeats 20000 using aesop

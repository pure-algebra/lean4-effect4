import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.ReturnTasks

#auto_census Effect4.Laws.Program.Guard.ReturnTasks heartbeats 20000 using aesop

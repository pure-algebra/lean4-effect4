import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Api.Supervision

#auto_census Effect4.Laws.Api.Supervision heartbeats 20000 using aesop

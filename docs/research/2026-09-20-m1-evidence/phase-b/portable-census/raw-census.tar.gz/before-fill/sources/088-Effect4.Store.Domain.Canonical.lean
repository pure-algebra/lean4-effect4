import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Domain.Canonical

#auto_census Effect4.Store.Domain.Canonical heartbeats 20000 using aesop

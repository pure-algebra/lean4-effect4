import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.TyView

#auto_census Effect4.Laws.Program.TyView heartbeats 20000 using aesop

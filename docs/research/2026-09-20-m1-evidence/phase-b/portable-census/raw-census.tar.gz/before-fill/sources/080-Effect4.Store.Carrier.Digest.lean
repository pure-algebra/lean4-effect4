import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Carrier.Digest

#auto_census Effect4.Store.Carrier.Digest heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Audit.IndexedColumnActual

#auto_census Test.Audit.IndexedColumnActual heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Handles.Compile

#auto_census Effect4.Laws.Program.Handles.Compile heartbeats 20000 using aesop

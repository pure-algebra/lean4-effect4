import Effect4.Laws
import Effect4.Laws.Auto.Census
import Drivers.Corpus

#auto_census Drivers.Corpus heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4Gen.Check

#auto_census Effect4Gen.Check heartbeats 20000 using aesop

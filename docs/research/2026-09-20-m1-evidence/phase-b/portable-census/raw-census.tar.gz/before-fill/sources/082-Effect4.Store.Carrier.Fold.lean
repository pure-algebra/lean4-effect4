import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Carrier.Fold

#auto_census Effect4.Store.Carrier.Fold heartbeats 20000 using aesop

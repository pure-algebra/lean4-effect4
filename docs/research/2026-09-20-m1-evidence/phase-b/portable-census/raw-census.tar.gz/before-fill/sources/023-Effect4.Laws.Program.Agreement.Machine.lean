import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Agreement.Machine

#auto_census Effect4.Laws.Program.Agreement.Machine heartbeats 20000 using aesop

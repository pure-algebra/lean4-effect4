import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Typed.State

#auto_census Effect4.Laws.Program.Typed.State heartbeats 20000 using aesop

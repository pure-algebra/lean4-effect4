import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Program.AuthorContract

#auto_census Test.Program.AuthorContract heartbeats 20000 using aesop

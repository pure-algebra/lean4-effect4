import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.NativeStateLinks

#auto_census Effect4.Laws.Program.Guard.NativeStateLinks heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Program.DenoteRContract

#auto_census Test.Program.DenoteRContract heartbeats 20000 using aesop

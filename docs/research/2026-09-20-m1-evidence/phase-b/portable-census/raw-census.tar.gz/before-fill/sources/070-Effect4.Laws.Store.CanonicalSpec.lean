import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Store.CanonicalSpec

#auto_census Effect4.Laws.Store.CanonicalSpec heartbeats 20000 using aesop

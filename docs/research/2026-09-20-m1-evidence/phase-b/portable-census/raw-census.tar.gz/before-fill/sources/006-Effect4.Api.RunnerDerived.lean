import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Api.RunnerDerived

#auto_census Effect4.Api.RunnerDerived heartbeats 20000 using aesop

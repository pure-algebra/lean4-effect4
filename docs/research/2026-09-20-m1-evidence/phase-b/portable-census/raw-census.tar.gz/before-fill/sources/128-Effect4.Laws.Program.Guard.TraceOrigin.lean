import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.TraceOrigin

#auto_census Effect4.Laws.Program.Guard.TraceOrigin heartbeats 20000 using aesop

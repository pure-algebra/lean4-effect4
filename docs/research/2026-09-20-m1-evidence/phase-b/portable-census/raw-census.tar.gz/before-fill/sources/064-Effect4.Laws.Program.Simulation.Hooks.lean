import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Simulation.Hooks

#auto_census Effect4.Laws.Program.Simulation.Hooks heartbeats 20000 using aesop

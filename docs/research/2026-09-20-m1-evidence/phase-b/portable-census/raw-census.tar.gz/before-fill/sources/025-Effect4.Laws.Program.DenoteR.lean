import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.DenoteR

#auto_census Effect4.Laws.Program.DenoteR heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Simulation.Drive

#auto_census Effect4.Laws.Program.Simulation.Drive heartbeats 20000 using aesop

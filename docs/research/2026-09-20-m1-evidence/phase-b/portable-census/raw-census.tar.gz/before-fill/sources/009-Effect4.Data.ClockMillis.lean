import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Data.ClockMillis

#auto_census Effect4.Data.ClockMillis heartbeats 20000 using aesop

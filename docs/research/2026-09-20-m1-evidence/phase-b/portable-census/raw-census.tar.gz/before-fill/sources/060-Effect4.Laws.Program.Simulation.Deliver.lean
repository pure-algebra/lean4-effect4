import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Simulation.Deliver

#auto_census Effect4.Laws.Program.Simulation.Deliver heartbeats 20000 using aesop

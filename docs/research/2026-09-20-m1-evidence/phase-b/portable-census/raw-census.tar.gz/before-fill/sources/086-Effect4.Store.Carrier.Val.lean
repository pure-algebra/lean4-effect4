import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Carrier.Val

#auto_census Effect4.Store.Carrier.Val heartbeats 20000 using aesop

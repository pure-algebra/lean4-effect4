import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Program.AuthoringContract

#auto_census Test.Program.AuthoringContract heartbeats 20000 using aesop

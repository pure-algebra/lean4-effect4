import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.Single

#auto_census Effect4.Laws.Program.Guard.Single heartbeats 20000 using aesop

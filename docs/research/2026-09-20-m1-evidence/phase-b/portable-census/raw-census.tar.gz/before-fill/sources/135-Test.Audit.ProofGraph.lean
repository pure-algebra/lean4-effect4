import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Audit.ProofGraph

#auto_census Test.Audit.ProofGraph heartbeats 20000 using aesop

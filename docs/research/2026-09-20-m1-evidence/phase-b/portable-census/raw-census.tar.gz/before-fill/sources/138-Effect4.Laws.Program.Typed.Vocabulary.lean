import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Typed.Vocabulary

#auto_census Effect4.Laws.Program.Typed.Vocabulary heartbeats 20000 using aesop

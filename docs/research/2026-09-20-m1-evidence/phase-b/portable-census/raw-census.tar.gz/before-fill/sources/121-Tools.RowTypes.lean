import Effect4.Laws
import Effect4.Laws.Auto.Census
import Tools.RowTypes

#auto_census Tools.RowTypes heartbeats 20000 using aesop

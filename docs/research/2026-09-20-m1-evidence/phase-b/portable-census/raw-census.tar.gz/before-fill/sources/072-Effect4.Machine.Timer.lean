import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Machine.Timer

#auto_census Effect4.Machine.Timer heartbeats 20000 using aesop

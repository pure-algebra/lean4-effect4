import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Domain.Derived.Schema

#auto_census Effect4.Store.Domain.Derived.Schema heartbeats 20000 using aesop

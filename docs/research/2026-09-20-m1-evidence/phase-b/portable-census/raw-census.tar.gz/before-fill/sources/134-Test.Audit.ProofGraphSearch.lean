import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Audit.ProofGraphSearch

#auto_census Test.Audit.ProofGraphSearch heartbeats 20000 using aesop

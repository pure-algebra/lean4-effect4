import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.Scheduling

#auto_census Effect4.Laws.Machine.Scheduling heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.LayerSharing

#auto_census Effect4.Laws.Program.LayerSharing heartbeats 20000 using aesop

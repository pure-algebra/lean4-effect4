import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4Gen.Forms

#auto_census Effect4Gen.Forms heartbeats 20000 using aesop

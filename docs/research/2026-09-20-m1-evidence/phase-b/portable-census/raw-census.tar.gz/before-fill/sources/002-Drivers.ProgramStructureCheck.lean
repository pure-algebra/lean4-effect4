import Effect4.Laws
import Effect4.Laws.Auto.Census
import Drivers.ProgramStructureCheck

#auto_census Drivers.ProgramStructureCheck heartbeats 20000 using aesop

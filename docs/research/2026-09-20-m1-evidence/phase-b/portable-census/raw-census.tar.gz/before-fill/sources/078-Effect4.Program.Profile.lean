import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Program.Profile

#auto_census Effect4.Program.Profile heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Simulation.Fibers

#auto_census Effect4.Laws.Program.Simulation.Fibers heartbeats 20000 using aesop

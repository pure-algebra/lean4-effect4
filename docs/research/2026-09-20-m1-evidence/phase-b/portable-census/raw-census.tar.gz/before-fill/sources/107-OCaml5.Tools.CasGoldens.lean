import Effect4.Laws
import Effect4.Laws.Auto.Census
import OCaml5.Tools.CasGoldens

#auto_census OCaml5.Tools.CasGoldens heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Domain.Clock

#auto_census Effect4.Store.Domain.Clock heartbeats 20000 using aesop

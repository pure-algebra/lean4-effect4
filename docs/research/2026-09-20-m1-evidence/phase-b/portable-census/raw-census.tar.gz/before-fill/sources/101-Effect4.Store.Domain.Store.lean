import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Domain.Store

#auto_census Effect4.Store.Domain.Store heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Means

#auto_census Effect4.Laws.Program.Means heartbeats 20000 using aesop

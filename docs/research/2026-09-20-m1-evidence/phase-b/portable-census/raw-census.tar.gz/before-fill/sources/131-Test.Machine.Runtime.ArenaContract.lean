import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Machine.Runtime.ArenaContract

#auto_census Test.Machine.Runtime.ArenaContract heartbeats 20000 using aesop

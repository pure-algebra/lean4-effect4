import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.CompletionData

#auto_census Effect4.Laws.Machine.CompletionData heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import harness.truth.Truth

#auto_census harness.truth.Truth heartbeats 20000 using aesop

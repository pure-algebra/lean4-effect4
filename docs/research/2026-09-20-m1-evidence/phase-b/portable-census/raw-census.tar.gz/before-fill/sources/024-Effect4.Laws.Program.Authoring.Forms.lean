import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Authoring.Forms

#auto_census Effect4.Laws.Program.Authoring.Forms heartbeats 20000 using aesop

import Drivers.ForeignCorpus
import Drivers.Styles
import Effect4
import Effect4.Api.Frontier
import Effect4.Api.HostProtocol
import Effect4.Api.HostSession
import Effect4.Api.Supervision
import Effect4.Api.TestClock
import Effect4.Codegen.Authoring.Forms
import Effect4.Codegen.SourceBindings
import Effect4.Data.JsonNumber
import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Auto.Frames
import Effect4.Laws.Auto.Obligations
import Effect4.Laws.Auto.RuleSets
import Effect4.Laws.Machine.Clock
import Effect4.Laws.Machine.Folds.Stores
import Effect4.Laws.Machine.Folds.Val
import Effect4.Laws.Machine.Refinement
import Effect4.Laws.Program.EvaluateR
import Effect4.Laws.Program.Folds.Checker
import Effect4.Laws.Program.Folds.Looped
import Effect4.Laws.Program.Folds.Projections
import Effect4.Laws.Program.Folds.Provision
import Effect4.Laws.Program.Folds.Representation
import Effect4.Laws.Program.Folds.Straight
import Effect4.Laws.Program.Folds.Term
import Effect4.Laws.Program.Folds.Ty
import Effect4.Laws.Program.InterpR
import Effect4.Laws.Program.Typed.Frames
import Effect4.Laws.Program.Typed.PositionGate
import Effect4.Laws.Program.Typed.Sources
import Effect4.Laws.Program.Typed.TypedSources
import Effect4.Laws.Program.Typed.TypedStateDecl
import Effect4.Laws.Program.ValueModel
import Effect4.Laws.Store.Folds.Val
import Effect4.Machine.Fibers
import Effect4.Program.Packages
import Effect4.Run
import Effect4.Schema.Accepts
import Effect4.Schema.Codec
import Effect4.Schema.Image
import Effect4.Store.Carrier.Image.Containers
import Effect4.Store.Domain.RowCanonical
import OCaml5.Eff.Emit
import OCaml5.Eff.Goldens
import OCaml5.Eff.Metadata
import OCaml5.Lcnf.Clock
import OCaml5.Lcnf.ClockFlow
import OCaml5.Lcnf.Externs
import OCaml5.Lcnf.Translate
import OCaml5.Lcnf.Types
import ProofGraph.Search
import Test.All
import Test.Api.AcquireHandleContract
import Test.Api.KeyedHostContract
import Test.Api.SupervisionContract
import Test.Audit.AxiomGate
import Test.Audit.ClockLiteralFixtures
import Test.Audit.ClockLowering
import Test.Audit.PositionAnalysis
import Test.Audit.PositionCensus
import Test.Audit.RuntimeCoverage
import Test.Audit.TypedStateDecl
import Test.Machine.Fuzz
import Test.Machine.Runtime.CompletionDataContract
import Test.Machine.Runtime.StoresLawsContract
import Test.Program.Gen
import Test.Program.LinkedRowsContract
import Test.Program.RuntimeRShapesContract
import Test.Schema.DialectContract
import Test.Store.DerivedCheck
import Test.Store.NodeContract
import Test.Store.ProbeContract
import Test.Store.StoreContract
import Test.Store.TraitContract
import Test.Store.WordContract
import TestSupport.AcquireHandle
import Tools.ArchitectureRoles

#auto_census Drivers.ForeignCorpus heartbeats 20000 using aesop
#auto_census Drivers.Styles heartbeats 20000 using aesop
#auto_census Effect4 heartbeats 20000 using aesop
#auto_census Effect4.Api.Frontier heartbeats 20000 using aesop
#auto_census Effect4.Api.HostProtocol heartbeats 20000 using aesop
#auto_census Effect4.Api.HostSession heartbeats 20000 using aesop
#auto_census Effect4.Api.Supervision heartbeats 20000 using aesop
#auto_census Effect4.Api.TestClock heartbeats 20000 using aesop
#auto_census Effect4.Codegen.Authoring.Forms heartbeats 20000 using aesop
#auto_census Effect4.Codegen.SourceBindings heartbeats 20000 using aesop
#auto_census Effect4.Data.JsonNumber heartbeats 20000 using aesop
#auto_census Effect4.Laws heartbeats 20000 using aesop
#auto_census Effect4.Laws.Auto.Census heartbeats 20000 using aesop
#auto_census Effect4.Laws.Auto.Frames heartbeats 20000 using aesop
#auto_census Effect4.Laws.Auto.Obligations heartbeats 20000 using aesop
#auto_census Effect4.Laws.Auto.RuleSets heartbeats 20000 using aesop
#auto_census Effect4.Laws.Machine.Clock heartbeats 20000 using aesop
#auto_census Effect4.Laws.Machine.Folds.Stores heartbeats 20000 using aesop
#auto_census Effect4.Laws.Machine.Folds.Val heartbeats 20000 using aesop
#auto_census Effect4.Laws.Machine.Refinement heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.EvaluateR heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Checker heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Looped heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Projections heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Provision heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Representation heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Straight heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Term heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Folds.Ty heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.InterpR heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Typed.Frames heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Typed.PositionGate heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Typed.Sources heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Typed.TypedSources heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.Typed.TypedStateDecl heartbeats 20000 using aesop
#auto_census Effect4.Laws.Program.ValueModel heartbeats 20000 using aesop
#auto_census Effect4.Laws.Store.Folds.Val heartbeats 20000 using aesop
#auto_census Effect4.Machine.Fibers heartbeats 20000 using aesop
#auto_census Effect4.Program.Packages heartbeats 20000 using aesop
#auto_census Effect4.Run heartbeats 20000 using aesop
#auto_census Effect4.Schema.Accepts heartbeats 20000 using aesop
#auto_census Effect4.Schema.Codec heartbeats 20000 using aesop
#auto_census Effect4.Schema.Image heartbeats 20000 using aesop
#auto_census Effect4.Store.Carrier.Image.Containers heartbeats 20000 using aesop
#auto_census Effect4.Store.Domain.RowCanonical heartbeats 20000 using aesop
#auto_census OCaml5.Eff.Emit heartbeats 20000 using aesop
#auto_census OCaml5.Eff.Goldens heartbeats 20000 using aesop
#auto_census OCaml5.Eff.Metadata heartbeats 20000 using aesop
#auto_census OCaml5.Lcnf.Clock heartbeats 20000 using aesop
#auto_census OCaml5.Lcnf.ClockFlow heartbeats 20000 using aesop
#auto_census OCaml5.Lcnf.Externs heartbeats 20000 using aesop
#auto_census OCaml5.Lcnf.Translate heartbeats 20000 using aesop
#auto_census OCaml5.Lcnf.Types heartbeats 20000 using aesop
#auto_census ProofGraph.Search heartbeats 20000 using aesop
#auto_census Test.All heartbeats 20000 using aesop
#auto_census Test.Api.AcquireHandleContract heartbeats 20000 using aesop
#auto_census Test.Api.KeyedHostContract heartbeats 20000 using aesop
#auto_census Test.Api.SupervisionContract heartbeats 20000 using aesop
#auto_census Test.Audit.AxiomGate heartbeats 20000 using aesop
#auto_census Test.Audit.ClockLiteralFixtures heartbeats 20000 using aesop
#auto_census Test.Audit.ClockLowering heartbeats 20000 using aesop
#auto_census Test.Audit.PositionAnalysis heartbeats 20000 using aesop
#auto_census Test.Audit.PositionCensus heartbeats 20000 using aesop
#auto_census Test.Audit.RuntimeCoverage heartbeats 20000 using aesop
#auto_census Test.Audit.TypedStateDecl heartbeats 20000 using aesop
#auto_census Test.Machine.Fuzz heartbeats 20000 using aesop
#auto_census Test.Machine.Runtime.CompletionDataContract heartbeats 20000 using aesop
#auto_census Test.Machine.Runtime.StoresLawsContract heartbeats 20000 using aesop
#auto_census Test.Program.Gen heartbeats 20000 using aesop
#auto_census Test.Program.LinkedRowsContract heartbeats 20000 using aesop
#auto_census Test.Program.RuntimeRShapesContract heartbeats 20000 using aesop
#auto_census Test.Schema.DialectContract heartbeats 20000 using aesop
#auto_census Test.Store.DerivedCheck heartbeats 20000 using aesop
#auto_census Test.Store.NodeContract heartbeats 20000 using aesop
#auto_census Test.Store.ProbeContract heartbeats 20000 using aesop
#auto_census Test.Store.StoreContract heartbeats 20000 using aesop
#auto_census Test.Store.TraitContract heartbeats 20000 using aesop
#auto_census Test.Store.WordContract heartbeats 20000 using aesop
#auto_census TestSupport.AcquireHandle heartbeats 20000 using aesop
#auto_census Tools.ArchitectureRoles heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Store.Domain.Derived.Program

#auto_census Effect4.Store.Domain.Derived.Program heartbeats 20000 using aesop

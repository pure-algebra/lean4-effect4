import Effect4.Laws
import Effect4.Laws.Auto.Census
import TestSupport.CasEntry

#auto_census TestSupport.CasEntry heartbeats 20000 using aesop

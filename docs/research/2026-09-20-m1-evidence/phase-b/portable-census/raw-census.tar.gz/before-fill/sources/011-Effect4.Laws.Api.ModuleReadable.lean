import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Api.ModuleReadable

#auto_census Effect4.Laws.Api.ModuleReadable heartbeats 20000 using aesop

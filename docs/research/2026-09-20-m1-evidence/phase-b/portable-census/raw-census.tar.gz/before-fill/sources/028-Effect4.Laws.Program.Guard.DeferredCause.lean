import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.DeferredCause

#auto_census Effect4.Laws.Program.Guard.DeferredCause heartbeats 20000 using aesop

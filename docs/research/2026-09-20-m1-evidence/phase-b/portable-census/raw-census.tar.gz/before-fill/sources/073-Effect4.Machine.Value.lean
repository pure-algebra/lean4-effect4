import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Machine.Value

#auto_census Effect4.Machine.Value heartbeats 20000 using aesop

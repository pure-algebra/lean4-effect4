import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.RefKernel

#auto_census Effect4.Laws.Machine.RefKernel heartbeats 20000 using aesop

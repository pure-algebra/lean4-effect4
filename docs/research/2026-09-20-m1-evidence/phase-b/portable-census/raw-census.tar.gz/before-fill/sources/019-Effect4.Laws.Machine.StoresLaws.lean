import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.StoresLaws

#auto_census Effect4.Laws.Machine.StoresLaws heartbeats 20000 using aesop

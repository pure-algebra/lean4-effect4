import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Program.Decision

#auto_census Effect4.Program.Decision heartbeats 20000 using aesop

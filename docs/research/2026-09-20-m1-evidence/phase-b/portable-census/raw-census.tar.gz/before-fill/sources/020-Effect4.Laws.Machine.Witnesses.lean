import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.Witnesses

#auto_census Effect4.Laws.Machine.Witnesses heartbeats 20000 using aesop

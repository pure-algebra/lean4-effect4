import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Api.Derived

#auto_census Effect4.Api.Derived heartbeats 20000 using aesop

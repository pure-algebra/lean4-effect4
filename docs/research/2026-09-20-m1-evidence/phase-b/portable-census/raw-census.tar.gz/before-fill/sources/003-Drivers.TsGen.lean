import Effect4.Laws
import Effect4.Laws.Auto.Census
import Drivers.TsGen

#auto_census Drivers.TsGen heartbeats 20000 using aesop

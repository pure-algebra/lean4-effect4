import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Machine.Stores

#auto_census Effect4.Machine.Stores heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Run

#auto_census Effect4.Laws.Run heartbeats 20000 using aesop

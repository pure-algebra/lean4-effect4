import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Codegen.Types

#auto_census Effect4.Codegen.Types heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Data.Ascii

#auto_census Effect4.Data.Ascii heartbeats 20000 using aesop

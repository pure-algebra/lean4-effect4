import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Typing.FoldAgreement

#auto_census Effect4.Laws.Program.Typing.FoldAgreement heartbeats 20000 using aesop

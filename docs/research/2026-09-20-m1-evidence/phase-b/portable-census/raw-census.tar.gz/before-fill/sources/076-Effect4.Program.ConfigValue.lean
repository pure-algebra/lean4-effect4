import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Program.ConfigValue

#auto_census Effect4.Program.ConfigValue heartbeats 20000 using aesop

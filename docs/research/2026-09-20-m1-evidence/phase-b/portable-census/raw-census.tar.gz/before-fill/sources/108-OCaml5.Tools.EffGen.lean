import Effect4.Laws
import Effect4.Laws.Auto.Census
import OCaml5.Tools.EffGen

#auto_census OCaml5.Tools.EffGen heartbeats 20000 using aesop

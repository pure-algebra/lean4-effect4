import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.Arena

#auto_census Effect4.Laws.Machine.Arena heartbeats 20000 using aesop

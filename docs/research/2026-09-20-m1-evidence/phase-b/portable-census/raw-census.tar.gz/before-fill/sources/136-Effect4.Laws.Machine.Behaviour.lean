import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Machine.Behaviour

#auto_census Effect4.Laws.Machine.Behaviour heartbeats 20000 using aesop

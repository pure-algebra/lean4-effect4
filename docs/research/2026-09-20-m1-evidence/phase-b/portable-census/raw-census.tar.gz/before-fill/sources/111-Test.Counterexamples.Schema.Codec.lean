import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Counterexamples.Schema.Codec

#auto_census Test.Counterexamples.Schema.Codec heartbeats 20000 using aesop

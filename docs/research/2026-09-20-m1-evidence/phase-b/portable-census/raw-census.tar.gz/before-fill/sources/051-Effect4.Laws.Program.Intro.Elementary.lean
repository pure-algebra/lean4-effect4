import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Intro.Elementary

#auto_census Effect4.Laws.Program.Intro.Elementary heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Program.Typing.Agreement

#auto_census Effect4.Program.Typing.Agreement heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Program.Compile

#auto_census Effect4.Program.Compile heartbeats 20000 using aesop

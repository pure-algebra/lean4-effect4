import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Machine.Runtime.SchedulerCoreContract

#auto_census Test.Machine.Runtime.SchedulerCoreContract heartbeats 20000 using aesop

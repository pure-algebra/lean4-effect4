import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Store.Templates

#auto_census Test.Store.Templates heartbeats 20000 using aesop

import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Guard.OuterDriver

#auto_census Effect4.Laws.Program.Guard.OuterDriver heartbeats 20000 using aesop

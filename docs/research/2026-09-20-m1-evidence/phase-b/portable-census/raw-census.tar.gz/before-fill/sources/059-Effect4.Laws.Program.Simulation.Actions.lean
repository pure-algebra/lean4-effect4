import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Laws.Program.Simulation.Actions

#auto_census Effect4.Laws.Program.Simulation.Actions heartbeats 20000 using aesop

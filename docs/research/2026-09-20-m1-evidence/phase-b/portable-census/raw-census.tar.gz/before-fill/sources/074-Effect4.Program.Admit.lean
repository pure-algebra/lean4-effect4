import Effect4.Laws
import Effect4.Laws.Auto.Census
import Effect4.Program.Admit

#auto_census Effect4.Program.Admit heartbeats 20000 using aesop

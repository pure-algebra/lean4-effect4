import Effect4.Laws
import Effect4.Laws.Auto.Census
import Test.Api.HostSessionContract

#auto_census Test.Api.HostSessionContract heartbeats 20000 using aesop

#!/usr/bin/env python3
"""Keep raw instrument closure totals separate from trust-admissible closures."""
from pathlib import Path
import argparse,json,re,sys

def report(text,module,exit_code):
 if exit_code!=0:raise ValueError('failed Lean process; not a census result')
 header=re.compile(re.escape(module)+r': (\d+) of (\d+) theorems closed from their statements; (\d+) source lines they now take')
 hits=list(header.finditer(text))
 if len(hits)!=1:raise ValueError('expected exactly one report for '+module)
 m=hits[0];closed,total,lines=map(int,m.groups());rows=[]
 # Module reports may share a scratch file. A theorem row belongs to this report
 # until the next ordinary nonempty line (usually the next Lean info location).
 for line in text[m.end():].splitlines():
  if not line.strip():continue
  r=re.fullmatch(r'\s*(\d+)\s+(\d+)-(\d+)\s+(\S+)\s+\[(.*)\]\s*',line)
  if not r:break
  axioms=[a.strip() for a in r[5].split(',') if a.strip()]
  extra=sorted(set(axioms)-{'propext','Quot.sound'})
  rows.append({'name':r[4],'first_line':int(r[2]),'last_line':int(r[3]),'source_lines':int(r[1]),'axioms':axioms,'trust_admissible':not extra,'disallowed_axioms':extra})
 if len(rows)!=closed:raise ValueError(f'closed rows {len(rows)} do not match raw instrument count {closed}')
 if len({r['name'] for r in rows})!=len(rows):raise ValueError('duplicate theorem row')
 return {'module':module,'instrument_closed_count':closed,'instrument_total_count':total,'instrument_source_lines':lines,'trust_admissible_closed_count':sum(r['trust_admissible'] for r in rows),'inadmissible_closed_names':[r['name'] for r in rows if not r['trust_admissible']],'rows':rows,'evidence':'Reported searched-term axioms only; proof replacements still require the normal narrow build.'}
if __name__=='__main__':
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--module',required=True);ap.add_argument('--log',required=True,type=Path);ap.add_argument('--exit-code',required=True,type=int);ap.add_argument('--lane',choices=['before-fill','final-bank'],required=True)
 args=ap.parse_args()
 try:r=report(args.log.read_text(),args.module,args.exit_code)
 except ValueError as e:print('REFUSED: '+str(e),file=sys.stderr);sys.exit(2)
 r.update(lane=args.lane,log=str(args.log),cap=20000);print(json.dumps(r,indent=2))

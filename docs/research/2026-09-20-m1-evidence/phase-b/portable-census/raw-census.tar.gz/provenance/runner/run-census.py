#!/usr/bin/env python3
"""One guarded before-fill census, serially. Default: audit only; --run launches Lean.

Never builds modules, changes live sources, raises the 20,000 cap, retries failures,
combines historical counts, or fabricates zero results. Requires the root's compiler
lease when --run is selected. Evidence directories may not be reused accidentally.
"""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,re,signal,subprocess,sys,time
HERE=Path(__file__).resolve().parent
ROOT=Path('/Users/pooks/Dev/lean4-effect4')
DEFAULT_PLAN=Path('/tmp/m1-tools/phase-b-serial-plan/census-plan.json')
SPEC=importlib.util.spec_from_file_location('census_log_reader',HERE/'read-census-log.py')
READER=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(READER)
INSTRUMENT_MODULES={
 'ProofGraph.Search':'tools/ProofGraph/Search.lean',
 'ProofGraph.Proof':'tools/ProofGraph/Proof.lean',
 'Effect4.Laws.Auto.Census':'src/Effect4/Laws/Auto/Census.lean',
 'Effect4.Laws.Auto.RuleSets':'src/Effect4/Laws/Auto/RuleSets.lean',
 'Test.Audit.ProofGraphSearch':'Test/Audit/ProofGraphSearch.lean',
 'Effect4.Laws':'src/Effect4/Laws.lean',
}
def require(ok,msg):
 if not ok:raise ValueError(msg)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def write_json(path,data):
 path.parent.mkdir(parents=True,exist_ok=True);temp=path.with_name(path.name+'.tmp')
 temp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');os.replace(temp,path)
def olean(module):return ROOT/'.lake/build/lib/lean'/ (module.replace('.','/')+'.olean')
def command_for_missing(module,path):
 if module=='Effect4Gen.Forms' or module in ('harness.truth.Truth','harness.truth.session.Keyed'):
  module_root='tools' if module=='Effect4Gen.Forms' else '.'
  return ['lake','env','lean','-M6144','-DwarningAsError=true','--root='+module_root,path,'-o',str(olean(module).relative_to(ROOT)),'-i',str(olean(module).relative_to(ROOT)).removesuffix('.olean')+'.ilean']
 return ['lake','build',module]
def jobs_for(plan):
 rows=plan['rows'];known={r['module']:r for r in rows}
 require(len(known)==len(rows)==plan['count'],'duplicate or inconsistent manifest modules')
 batch=[r['module'] for r in rows if r['execution']=='batched_zero_candidate']
 jobs=[]
 if batch:
  old=Path(plan['extension_provenance']['existing_census_sources'])/'before-fill'/'ZeroCandidates.lean'
  jobs.append({'id':'000-ZeroCandidates','source':str(old),'modules':batch})
 for r in rows:
  if r['execution']!='individual_census':continue
  src=r.get('before_fill_scratch_source')
  if not src:src=str(Path(plan['extension_provenance']['existing_census_sources'])/'before-fill'/(r['module']+'.lean'))
  jobs.append({'id':str(len(jobs)).zfill(3)+'-'+r['module'],'source':src,'modules':[r['module']]})
 require(len(jobs)==plan['execution_summary']['sequential_processes_per_lane'],'process count differs from plan')
 covered=[]
 for job in jobs:
  text=Path(job['source']).read_text();found=[]
  for line in text.splitlines():
   if not line.strip():continue
   if re.fullmatch(r'import\s+[A-Za-z0-9_.]+',line):continue
   m=re.fullmatch(r'#auto_census\s+([A-Za-z0-9_.]+)\s+heartbeats\s+20000\s+using\s+aesop',line)
   require(m is not None,'unexpected command, tactic or cap in '+job['source']+': '+line)
   found.append(m[1])
  require(sorted(found)==sorted(job['modules']) and len(set(found))==len(found),'scratch module list differs: '+job['source'])
  job['source_sha256']=sha(job['source']);covered+=found
 require(len(set(covered))==len(covered)==plan['execution_summary']['importable_modules'],'missing/duplicate census coverage')
 return jobs

def audit(plan):
 by_module={r['module']:r['path'] for r in plan['rows'] if r['execution']!='skip_nonlibrary_driver'}
 by_module.update(INSTRUMENT_MODULES)
 requested=set(by_module);todo=list(by_module.values());external=set()
 # Freeze the local imported proof environment as well as the measured modules.
 # Only import headers before the first declaration are read; nested header comments
 # are masked so documentation examples cannot invent dependencies.
 while todo:
  source=todo.pop();text=(ROOT/source).read_text();depth=0;clean=[];i=0
  while i<len(text):
   if text.startswith('/-',i):depth+=1;i+=2;continue
   if depth and text.startswith('-/',i):depth-=1;i+=2;continue
   if depth:i+=1;continue
   if text.startswith('--',i):
    j=text.find('\n',i);i=len(text) if j<0 else j;continue
   clean.append(text[i]);i+=1
  for line in ''.join(clean).splitlines():
   line=line.strip()
   if not line or line in ('module','prelude'):continue
   match=re.fullmatch(r'(?:public\s+)?import\s+([A-Za-z0-9_.]+)',line)
   if match is None:break
   name=match[1]
   if name in by_module:continue
   options=[prefix+name.replace('.','/')+'.lean' for prefix in ('src/','tools/','')]
   found=next((p for p in options if (ROOT/p).is_file()),None)
   if found:by_module[name]=found;todo.append(found)
   else:external.add(name)
 rows=[]
 for mod,source in sorted(by_module.items()):
  src=ROOT/source;obj=olean(mod)
  r={'module':mod,'input_role':'measured_or_instrument' if mod in requested else 'local_import_dependency','source':source,'source_exists':src.is_file(),'olean':str(obj.relative_to(ROOT)),'olean_exists':obj.is_file()}
  if src.exists() and obj.exists():
   r['source_newer_than_olean']=src.stat().st_mtime_ns>obj.stat().st_mtime_ns
   r['freshness_meaning']='mtime-only observation; not proof of semantic staleness. Root builds/tests establish readiness; no automatic rebuild or fabricated census result.'
  if not obj.exists():r['needed_command']=command_for_missing(mod,source)
  rows.append(r)
 return {'checked_utc':utc(),'local_input_module_count':len(rows),'external_imports_pinned_by_toolchain_manifest':sorted(external),'rows':rows,'missing_sources':[r for r in rows if not r['source_exists']],'missing_required_oleans':[r for r in rows if not r['olean_exists']],'ordinary_source_newer':[r['module'] for r in rows if r.get('source_newer_than_olean')],'skip_records':[{'module':r['module'],'path':r['path'],'reason':r['skip_reason']} for r in plan['rows'] if r['execution']=='skip_nonlibrary_driver'], 'note':'No Lean run. Missing oleans are blockers; mtime-only newer source observations are separate and are not guessed zeros.'}

def stamp(path):
 path=Path(path);before=path.stat();digest=sha(path);after=path.stat()
 require((before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),'input changed while hashing: '+str(path))
 return {'path':str(path),'sha256':digest,'size':after.st_size,'mtime_ns':after.st_mtime_ns}
def stable(stamps):
 for x in stamps:
  p=Path(x['path']);s=p.stat()
  require((s.st_size,s.st_mtime_ns)==(x['size'],x['mtime_ns']),'frozen input changed during census: '+str(p))
def capture_inputs(audit_result,plan_path):
 paths={plan_path,HERE/'run-census.py',HERE/'read-census-log.py',HERE/'guards.json',ROOT/'lean-toolchain',ROOT/'lake-manifest.json',ROOT/'lakefile.toml'}
 module_inputs={}
 for r in audit_result['rows']:
  src=ROOT/r['source'];obj=ROOT/r['olean'];related=[src,obj]
  for suffix in ['.olean.private','.olean.server','.ir','.ilean','.trace']:
   extra=obj.with_suffix(suffix)
   if extra.is_file():related.append(extra)
  paths.update(related);module_inputs[r['module']]=[str(x) for x in related]
 stamps=[stamp(p) for p in sorted(paths)]
 return stamps,module_inputs

def check_guards():
 g=json.loads((HERE/'guards.json').read_text())
 for r in g['reviewed_sources']:
  require(sha(ROOT/r['path'])==r['sha256'],'reviewed instrument/control source changed: '+r['path'])
 for r in g['control_logs']:
  require(sha(r['path'])==r['sha256'],'cap-control log changed: '+r['path'])
  log=Path(r['path']).read_text()
  require('Build completed successfully' in log and 'error:' not in log,'cap-control green log missing or failed')
 return g

def split_report(text,module,parsed):
 header=re.compile(re.escape(module)+r': \d+ of \d+ theorems closed from their statements; \d+ source lines they now take')
 match=header.search(text);require(match is not None,'report missing')
 count=parsed['instrument_closed_count'];out=[match[0]]
 for line in text[match.end():].splitlines():
  if not line.strip():continue
  if count==0:break
  out.append(line);count-=1
 require(count==0,'truncated report while splitting log')
 return '\n'.join(out)+'\n'

def run_process(command,log,timeout):
 env=os.environ.copy();env['LEAN_NUM_THREADS']='1'
 with log.open('wb') as output:
  process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
  try:return process.wait(timeout=timeout)
  except (subprocess.TimeoutExpired,KeyboardInterrupt):
   os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
   raise

def execute(plan,plan_path,jobs,audit_result,out,timeout):
 require(not out.exists(),'evidence directory already exists; refusing a duplicate/replacement baseline: '+str(out))
 require(not audit_result['missing_sources'],'missing source files')
 require(not audit_result['missing_required_oleans'],'missing required oleans; run the listed one-module builds first')
 guards=check_guards();inputs,module_inputs=capture_inputs(audit_result,plan_path)
 out.mkdir(parents=True);(out/'process-logs').mkdir();(out/'module-logs').mkdir();(out/'sources').mkdir()
 rows_by_name={r['module']:r for r in plan['rows']}
 input_index={x['path']:x for x in inputs}
 for j in jobs:
  destination=out/'sources'/(j['id']+'.lean');destination.write_bytes(Path(j['source']).read_bytes())
  require(sha(destination)==j['source_sha256'],'census scratch changed during freeze')
  j['frozen_source']=str(destination)
 write_json(out/'source-plan.json',plan);write_json(out/'inputs.json',{'captured_utc':utc(),'files':inputs,'module_inputs':module_inputs,'cap_guards':guards,'audit':audit_result})
 state={'lane':'before-fill','instrument_status':'corrected Search source and finite cap/rollback controls pinned in inputs.json; original plan preparation note is historical','status':'running','started_utc':utc(),'census_cap':20000,'proof_tactic':'aesop','serialization':'one subprocess at a time, LEAN_NUM_THREADS=1','expected_modules':len(rows_by_name)-len(audit_result['skip_records']),'expected_processes':len(jobs),'skipped':audit_result['skip_records'],'historical_counts_used':False,'jobs':[],'results':[]}
 write_json(out/'run.json',state)
 try:
  for index,job in enumerate(jobs):
   stable(inputs);require(sha(job['frozen_source'])==job['source_sha256'],'frozen census source changed')
   command=['lake','env','lean','-M6144','-DwarningAsError=true',job['frozen_source']]
   process_log=out/'process-logs'/(job['id']+'.log');start=time.monotonic()
   item={**job,'command':command,'process_log':str(process_log),'started_utc':utc(),'status':'running'}
   state['jobs'].append(item);write_json(out/'run.json',state)
   print(f'[{index+1}/{len(jobs)}] {job["id"]} ({len(job["modules"])} module reports)',flush=True)
   try:code=run_process(command,process_log,timeout)
   except subprocess.TimeoutExpired:
    item.update(status='wall_timeout',wall_seconds=time.monotonic()-start);raise ValueError('census process exceeded wall timeout; no result attributed')
   item.update(exit_code=code,wall_seconds=time.monotonic()-start,finished_utc=utc(),process_log_sha256=sha(process_log))
   require(code==0,'census process failed: '+str(process_log))
   stable(inputs)
   text=process_log.read_text();batch=[]
   for module in job['modules']:
    result=READER.report(text,module,code)
    result.update(lane='before-fill',cap=20000,tactic='aesop',process_id=job['id'],process_log=str(process_log),input_files=module_inputs[module],original_radius38=rows_by_name[module]['original_radius38'],historical_module=rows_by_name[module]['historical_module'])
    result['source_sha256']=input_index[str(ROOT/rows_by_name[module]['path'])]['sha256']
    result['olean_sha256']=input_index[str(olean(module))]['sha256']
    module_log=out/'module-logs'/(module+'.log');module_log.write_text(split_report(text,module,result))
    result.update(module_log=str(module_log),module_log_sha256=sha(module_log));batch.append(result)
   # A failed/partial batch publishes no synthetic successful/zero module results.
   state['results'].extend(batch);item['status']='complete'
   print('  closed '+str(sum(r['instrument_closed_count'] for r in batch))+'; trust-admissible '+str(sum(r['trust_admissible_closed_count'] for r in batch)),flush=True)
   write_json(out/'run.json',state)
  stable(inputs)
  # Rehash once at the end; timestamp/size checks above keep every process bounded.
  for x in inputs:require(sha(x['path'])==x['sha256'],'frozen input bytes changed: '+x['path'])
  require(len(state['results'])==state['expected_modules'],'incomplete module coverage')
  state.update(status='complete',finished_utc=utc(),summary={'instrument_closed_count':sum(r['instrument_closed_count'] for r in state['results']),'instrument_total_count':sum(r['instrument_total_count'] for r in state['results']),'trust_admissible_closed_count':sum(r['trust_admissible_closed_count'] for r in state['results']),'inadmissible_closed_count':sum(len(r['inadmissible_closed_names']) for r in state['results'])})
 except BaseException as e:
  state.update(status='stopped',finished_utc=utc(),failure=type(e).__name__+': '+str(e))
  if state['jobs'] and state['jobs'][-1]['status']=='running':state['jobs'][-1]['status']='failed'
  write_json(out/'run.json',state);raise
 write_json(out/'run.json',state);write_json(out/'results.json',state['results'])
 print(json.dumps({'status':'complete','modules':len(state['results']),**state['summary']},indent=2),flush=True)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--plan',type=Path,default=DEFAULT_PLAN);ap.add_argument('--run',action='store_true');ap.add_argument('--out',type=Path);ap.add_argument('--audit-out',type=Path);ap.add_argument('--timeout',type=int,default=3600)
 args=ap.parse_args();require(args.timeout>0,'wall timeout must be positive')
 plan=json.loads(args.plan.read_text());require(plan['instrument']['census_cap']==20000,'manifest changed census cap')
 jobs=jobs_for(plan);a=audit(plan)
 if args.audit_out:write_json(args.audit_out,a)
 summary={'status':'audit_only','compiler_run':False,'modules':plan['count'],'importable':plan['execution_summary']['importable_modules'],'processes':len(jobs),'missing_oleans':a['missing_required_oleans'],'source_newer_mtime_only':a['ordinary_source_newer']}
 print(json.dumps(summary,indent=2),flush=True)
 if args.run:
  require(args.out is not None,'--run requires a new --out evidence directory')
  execute(plan,args.plan.resolve(),jobs,a,args.out.resolve(),args.timeout)
if __name__=='__main__':
 try:main()
 except (ValueError,OSError,KeyboardInterrupt) as e:print('STOPPED: '+str(e),file=sys.stderr);sys.exit(2)

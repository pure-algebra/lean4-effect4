#!/usr/bin/env bash
# Prepared only. Root executes after Test.All releases the sole Lean compiler lane.
set -euo pipefail
cd /Users/pooks/Dev/lean4-effect4
mkdir -p .lake/build/lib/lean/harness/truth/session
LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true --root=. harness/truth/Truth.lean -o .lake/build/lib/lean/harness/truth/Truth.olean -i .lake/build/lib/lean/harness/truth/Truth.ilean > /tmp/m1-phase-b-census-truth-build.log 2>&1
LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true --root=. harness/truth/session/Keyed.lean -o .lake/build/lib/lean/harness/truth/session/Keyed.olean -i .lake/build/lib/lean/harness/truth/session/Keyed.ilean > /tmp/m1-phase-b-census-keyed-build.log 2>&1

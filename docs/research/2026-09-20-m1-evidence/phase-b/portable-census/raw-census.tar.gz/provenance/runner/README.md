# Guarded Phase B before-fill census

Prepared only. No Lean or lake command was executed by this seat. The executed controls replace the process function with fixture writers; `runner-controls.json` records them.

The current plan has 218 rows, all 218 importable modules and 139 serial processes. Every imported module receives `#auto_census ... heartbeats 20000 using aesop`, including predicted-zero modules. The 80-module batch retains separate named reports and per-module logs. Both formerly skipped harness drivers receive explicit module compilation and individual scratch imports. No module is skipped. The original 214-row manifest is preserved byte-for-byte in `../phase-b-serial-plan/census-plan.original214.json`; its historical counts are unchanged.

## Before running

Let the current Laws and all-test builds finish. Compile any independently missing driver modules serially after those builds: `Effect4Gen.Forms` uses `--root=tools`; `harness.truth.Truth` and `harness.truth.session.Keyed` use `--root=.`. Each writes an explicit `.olean` and `.ilean` under `.lake/build/lib/lean`, retaining its full module identity. `direct-driver-compiles.sh` contains the two new harness commands and creates their output directories. The audit's `missing-module-commands.sh` lists only currently absent outputs; neither script has been executed by this seat.

Re-run the audit after builds complete. An output temporarily absent during the active build is a build-in-progress observation, not evidence to fabricate a zero or launch a competing build. Source-newer timestamps are separate mtime-only observations, not proof of semantic staleness. The root's build receipts establish readiness; the runner freezes current source/olean bytes. External packages are pinned through the toolchain and Lake manifest.

```sh
python3 /tmp/m1-tools/phase-b-census-runner/run-census.py --audit-out /tmp/m1-tools/phase-b-census-runner/olean-audit.json
```

## Run once, with the compiler lease

```sh
python3 /tmp/m1-tools/phase-b-census-runner/run-census.py --run --out /tmp/m1-tools/phase-b-before-fill-evidence
```

Choose a new evidence directory. The runner refuses an existing one, missing sources/oleans, changed instrument/control sources, or a changed/failed finite cap-control log. It never rebuilds automatically. The reviewed corrected Search/Census and control sources, plus successful finite cap/rollback and empty-module logs are pinned in `guards.json`. All census inputs are validated before the first compiler call; only imports and the exact requested census command are accepted in scratch sources.

Only one subprocess runs at a time, with `LEAN_NUM_THREADS=1`, `-M6144`, and warnings as errors. The wall timeout defaults to 3,600 seconds per process; it does not change the 20,000 heartbeat cap. Any compiler failure, timeout, incomplete/duplicate report, or frozen-input change stops the run. A failed batch produces no invented successful or zero module rows. There are no implicit retries.

## Evidence

- `inputs.json` records exact source, olean and available build-sidecar hashes for the measured modules and their local import closure, toolchain/manifest files, and the reviewed instrument/control evidence. Timestamp-only observations are retained separately.
- `sources/` contains the exact scratch inputs the run executed.
- `process-logs/` contains complete subprocess output and each job’s command, timing, exit status and hash in `run.json`.
- `module-logs/` preserves each named module report, including actual 0/0 reports from the batch.
- `results.json` is written only after all 218 module reports succeed. Raw closures and `[propext, Quot.sound]`-admissible closures remain separate, with every found theorem name, source range and axiom list.
- No historical old-cap count contributes to any aggregate. A partial run remains marked stopped, with completed evidence and the exact failure.

The runner hashes inputs before starting, checks their timestamps/sizes before and after each process, and verifies all bytes again at completion. Do not edit sources or run another compiler during this census.

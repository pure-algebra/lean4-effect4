"""Python-only fixture tests. No Lean, lake, compiler or actual census invocation."""
from pathlib import Path
import importlib.util,json,tempfile,copy
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('runner',HERE/'run-census.py');r=importlib.util.module_from_spec(s);s.loader.exec_module(r)
root=Path(tempfile.mkdtemp(prefix='m1-census-runner-test-',dir='/tmp'))
r.ROOT=root
for n in ['lean-toolchain','lake-manifest.json','lakefile.toml']:(root/n).write_text('fixture')
rows=[];audit_rows=[]
for m in ['Fixture.A','Fixture.B','Fixture.C']:
 src=root/'src'/(m.replace('.','/')+'.lean');src.parent.mkdir(parents=True,exist_ok=True);src.write_text('theorem fixture : True := True.intro\n')
 obj=r.olean(m);obj.parent.mkdir(parents=True,exist_ok=True);obj.write_bytes(b'FAKE OLEAN: this test never calls Lean')
 rows.append({'module':m,'path':str(src.relative_to(root)),'original_radius38':False,'historical_module':None})
 audit_rows.append({'module':m,'source':str(src.relative_to(root)),'olean':str(obj.relative_to(root))})
plan={'rows':rows};plan_path=root/'plan.json';plan_path.write_text(json.dumps(plan))
a={'rows':audit_rows,'missing_sources':[],'missing_required_oleans':[],'skip_records':[]}
jobs=[]
for i,modules in enumerate([['Fixture.A','Fixture.B'],['Fixture.C']]):
 p=root/(str(i)+'.lean');p.write_text('\n'.join('#auto_census '+m+' heartbeats 20000 using aesop' for m in modules)+'\n')
 jobs.append({'id':str(i),'source':str(p),'source_sha256':r.sha(p),'modules':modules})
r.check_guards=lambda:{'fixture_only':True}
called=[]
def fake_success(command,log,timeout):
 called.append(command[-1]);modules=[ln.split()[1] for ln in Path(command[-1]).read_text().splitlines()]
 text=''
 for m in modules:
  if m=='Fixture.A':text+=m+': 2 of 3 theorems closed from their statements; 5 source lines they now take\n  3\t1-3\tFixture.A.good\t[propext, Quot.sound]\n  2\t5-6\tFixture.A.bad\t[Classical.choice]\n'
  else:text+=m+': 0 of 0 theorems closed from their statements; 0 source lines they now take\n'
 log.write_text(text);return 0
r.run_process=fake_success
r.execute(plan,plan_path,copy.deepcopy(jobs),a,root/'success',5)
state=json.loads((root/'success/run.json').read_text())
assert state['status']=='complete' and len(called)==2
assert state['summary']=={'instrument_closed_count':2,'instrument_total_count':3,'trust_admissible_closed_count':1,'inadmissible_closed_count':1}
assert len(list((root/'success/module-logs').glob('*.log')))==3
assert all('source_sha256' in x and 'olean_sha256' in x for x in state['results'])
checks=['serial two-process/three-module collection','raw2 vs admissible1','separate logs including observed0/0','exact source/olean hashes']
try:r.execute(plan,plan_path,copy.deepcopy(jobs),a,root/'success',5);raise AssertionError('reused output accepted')
except ValueError:checks.append('existing evidence directory refused')
def fake_failure(command,log,timeout):log.write_text('Fixture.A: 0 of 0 theorems closed from their statements; 0 source lines they now take\nerror: import failed\n');return 1
r.run_process=fake_failure
try:r.execute(plan,plan_path,copy.deepcopy(jobs),a,root/'failed',5);raise AssertionError('failed process accepted')
except ValueError:pass
failed=json.loads((root/'failed/run.json').read_text());assert failed['status']=='stopped' and failed['results']==[] and len(failed['jobs'])==1
checks.append('failed batch stops before next process and produces no0 result')
def fake_truncated(command,log,timeout):log.write_text('Fixture.A: 1 of 3 theorems closed from their statements; 3 source lines they now take\n');return 0
r.run_process=fake_truncated
try:r.execute(plan,plan_path,copy.deepcopy(jobs),a,root/'truncated',5);raise AssertionError('truncated report accepted')
except ValueError:pass
assert json.loads((root/'truncated/run.json').read_text())['results']==[]
checks.append('truncated report refused')
def fake_mutation(command,log,timeout):
 code=fake_success(command,log,timeout);(root/rows[0]['path']).write_text('-- changed during run\n');return code
r.run_process=fake_mutation
try:r.execute(plan,plan_path,copy.deepcopy(jobs),a,root/'mutated',5);raise AssertionError('input mutation accepted')
except ValueError:pass
assert json.loads((root/'mutated/run.json').read_text())['results']==[]
checks.append('frozen input change refused')
result={'kind':'Python-only fake process controls; no compiler execution','fixture_root':str(root),'checks':checks,'passed':True}
(HERE/'runner-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

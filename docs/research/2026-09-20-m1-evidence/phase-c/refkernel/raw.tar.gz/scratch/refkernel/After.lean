import Effect4.Laws.Machine.RefKernel
import Effect4.Laws.Auto.Census

#auto_census Effect4.Laws.Machine.RefKernel heartbeats 20000 using aesop
#auto_census Effect4.Laws.Machine.RefKernel heartbeats 20000 using aesop (rule_sets := [Effect4.Stores])

#print axioms Effect4.Machine.refStep_eq_refStepOf
#print axioms Effect4.Machine.refStep_cases
#print axioms Effect4.Machine.syncOpStep_eq_refStepOf
#print axioms Effect4.Machine.refWriteBack_length
#print axioms Effect4.Machine.mem_refWriteBack
#print axioms Effect4.Machine.refStepOf_length
#print axioms Effect4.Machine.RefKernel.getD_keeps
#print axioms Effect4.Machine.refStepOf_keeps
#print axioms Effect4.Machine.toList_writeBackA
#print axioms Effect4.Machine.toList_refStepOf
#print axioms Effect4.Machine.refStepOfA_list
#print axioms Effect4.Machine.refStepOfA_size
#print axioms Effect4.Machine.refStepOfA_keeps
#print axioms Effect4.Machine.ArenaObligations.toList_refStepOf.checked
#print axioms Effect4.Machine.ArenaObligations.refStepOfA_list.checked
#print axioms Effect4.Machine.ArenaObligations.refStepOfA_size.checked
#print axioms Effect4.Machine.ArenaObligations.refStepOfA_keeps.checked
#print axioms Effect4.Machine.M1.RefKernelSupport.toList_writeBackA.checked

import Effect4.Laws.Machine.RefKernel
import Effect4.Laws.Machine.CompletionData
namespace Effect4.Machine.RefKernelProbe
open Effect4

-- toList_refStepOf
example {σ : Type} [Arena σ Val] [LawfulArena σ Val]
    (cell : RefKey) (k : RefKernel) (s : σ) :  (
    (refStepOfA cell k s).map (Prod.map id Arena.toList) =
      refStepOf cell k (Arena.toList s)) := by
  aesop (rule_sets := [Effect4.Stores])

-- refStepOfA_list
example (cell : RefKey) (k : RefKernel) (xs : List Val) :
     (refStepOfA cell k xs = refStepOf cell k xs) := by
  aesop (rule_sets := [Effect4.Stores])

-- refStepOfA_size
example {σ : Type} [Arena σ Val] [LawfulArena σ Val]
    {cell : RefKey} {k : RefKernel} {s s' : σ} {a : Val}
    (_h : refStepOfA cell k s = some (a, s')) :
     (Arena.size s' = Arena.size s) := by
  aesop (rule_sets := [Effect4.Stores])

-- refStepOfA_keeps
example {σ : Type} [Arena σ Val] [LawfulArena σ Val]
    {P Q : Val → Prop} {cell : RefKey} {k : RefKernel} {s s' : σ} {a : Val}
    (_hheap : ∀ i v, Arena.peek s i = some v → P v)
    (_hk : RefKernel.Keeps P Q k) (_h : refStepOfA cell k s = some (a, s')) :
     (Q a ∧ ∀ i v, Arena.peek s' i = some v → P v) := by
  aesop (rule_sets := [Effect4.Stores])

end Effect4.Machine.RefKernelProbe

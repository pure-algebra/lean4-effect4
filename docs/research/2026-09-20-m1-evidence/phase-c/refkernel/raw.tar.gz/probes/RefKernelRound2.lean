import Effect4.Laws.Machine.RefKernel
import Effect4.Laws.Machine.CompletionData
namespace Effect4.Machine
attribute [aesop norm simp (rule_sets := [Effect4.Stores])]
  writeBackA refStepOfA refStepOf refWriteBack refPeek refPoke
  Arena.peek_toList

def M1.RefKernelSupport.toList_writeBackA {σ : Type} [Arena σ Val]
    [LawfulArena σ Val] (s : σ) (cell : RefKey) (next : Option Val) :
    ProofGraph.Obligation
      (Arena.toList (writeBackA s cell next) = refWriteBack (Arena.toList s) cell next) := ⟨⟩
#proof_wanted M1.RefKernelSupport.toList_writeBackA

theorem toList_writeBackA {σ : Type} [Arena σ Val] [LawfulArena σ Val]
    (s : σ) (cell : RefKey) (next : Option Val) :
    Arena.toList (writeBackA s cell next) = refWriteBack (Arena.toList s) cell next := by
  aesop (rule_sets := [Effect4.Stores])

attribute [aesop norm simp (rule_sets := [Effect4.Stores])] toList_writeBackA
end Effect4.Machine
namespace Effect4.Machine.RefKernelProbe
open Effect4

-- toList_refStepOf
example {σ : Type} [Arena σ Val] [LawfulArena σ Val]
    (cell : RefKey) (k : RefKernel) (s : σ) :  (
    (refStepOfA cell k s).map (Prod.map id Arena.toList) =
      refStepOf cell k (Arena.toList s)) := by
  aesop (rule_sets := [Effect4.Stores])

-- refStepOfA_list
example (cell : RefKey) (k : RefKernel) (xs : List Val) :
     (refStepOfA cell k xs = refStepOf cell k xs) := by
  aesop (rule_sets := [Effect4.Stores])

-- refStepOfA_size
example {σ : Type} [Arena σ Val] [LawfulArena σ Val]
    {cell : RefKey} {k : RefKernel} {s s' : σ} {a : Val}
    (_h : refStepOfA cell k s = some (a, s')) :
     (Arena.size s' = Arena.size s) := by
  aesop (rule_sets := [Effect4.Stores])

-- refStepOfA_keeps
example {σ : Type} [Arena σ Val] [LawfulArena σ Val]
    {P Q : Val → Prop} {cell : RefKey} {k : RefKernel} {s s' : σ} {a : Val}
    (_hheap : ∀ i v, Arena.peek s i = some v → P v)
    (_hk : RefKernel.Keeps P Q k) (_h : refStepOfA cell k s = some (a, s')) :
     (Q a ∧ ∀ i v, Arena.peek s' i = some v → P v) := by
  aesop (rule_sets := [Effect4.Stores])

end Effect4.Machine.RefKernelProbe

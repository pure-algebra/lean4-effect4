import Effect4.Laws.Machine.CompletionData
#auto_census Effect4.Laws.Machine.CompletionData using aesop (rule_sets := [Effect4.Stores])

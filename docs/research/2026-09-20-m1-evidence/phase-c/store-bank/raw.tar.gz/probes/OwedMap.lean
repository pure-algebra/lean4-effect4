import Effect4.Laws.Machine.CompletionData
namespace Effect4.Machine
universe u v w
variable {κ : Type u} {κ' : Type v} {κ'' : Type w}
def M1.OwedMapWanted.code (f : κ → κ') (d : Owed κ) : ProofGraph.Obligation
    ((d.mapCode f).code = f d.code) := ⟨⟩
#proof_wanted M1.OwedMapWanted.code
def M1.OwedMapWanted.id (d : Owed κ) : ProofGraph.Obligation
    (d.mapCode id = d) := ⟨⟩
#proof_wanted M1.OwedMapWanted.id
def M1.OwedMapWanted.comp (f : κ → κ') (g : κ' → κ'') (d : Owed κ) : ProofGraph.Obligation
    ((d.mapCode f).mapCode g = d.mapCode (g ∘ f)) := ⟨⟩
#proof_wanted M1.OwedMapWanted.comp
example (f : κ → κ') (d : Owed κ) : (d.mapCode f).code = f d.code := by
  aesop (rule_sets := [Effect4.Stores])
example (d : Owed κ) : d.mapCode id = d := by
  aesop (rule_sets := [Effect4.Stores])
example (f : κ → κ') (g : κ' → κ'') (d : Owed κ) :
    (d.mapCode f).mapCode g = d.mapCode (g ∘ f) := by
  aesop (rule_sets := [Effect4.Stores])
end Effect4.Machine

import Effect4.Laws.Machine.RefKernel
import Effect4.Laws.Machine.CompletionData
namespace Effect4.Machine
variable {κ κ' : Type}
def DeferredCell.map (f : κ → κ') (cell : DeferredCell κ) : DeferredCell κ' := ⟨cell.completion.map f, cell.wake⟩
def DeferredStore.map (f : κ → κ') (s : DeferredStore κ) : DeferredStore κ' := ⟨s.cells.map (DeferredCell.map f), s.due.map (Owed.mapCode f)⟩
end Effect4.Machine
attribute [aesop norm simp (rule_sets := [Effect4.Stores])] Effect4.Machine.DeferredCell.map Effect4.Machine.DeferredStore.map

namespace Effect4.Machine
variable {κ : Type}
def M1.OwedMapWanted.id_fun : ProofGraph.Obligation
    (Owed.mapCode (id : κ → κ) = id) := ⟨⟩
#proof_wanted M1.OwedMapWanted.id_fun
def M1.CellMapWanted.id_fun : ProofGraph.Obligation
    (DeferredCell.map (id : κ → κ) = id) := ⟨⟩
#proof_wanted M1.CellMapWanted.id_fun
theorem Owed.mapCode_id_fun : Owed.mapCode (id : κ → κ) = id := by
  aesop (rule_sets := [Effect4.Stores])
attribute [aesop norm simp (rule_sets := [Effect4.Stores])] Owed.mapCode_id_fun
theorem DeferredCell.map_id_fun : DeferredCell.map (id : κ → κ) = id := by
  aesop (rule_sets := [Effect4.Stores])
attribute [aesop norm simp (rule_sets := [Effect4.Stores])] DeferredCell.map_id_fun
end Effect4.Machine
namespace Effect4.Machine.PhaseCProbe
open Effect4
variable {κ κ' κ'' : Type}

variable (f : κ → κ') (g : κ' → κ'') (d : DeferredStore κ)

-- cell_map_id
example (c : DeferredCell κ) : 
    (c.map id = c) := by
  aesop (rule_sets := [Effect4.Stores])

-- cell_map_comp
example (c : DeferredCell κ) : 
    ((c.map f).map g = c.map (g ∘ f)) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_id
example :  (d.map id = d) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_comp
example :  ((d.map f).map g = d.map (g ∘ f)) := by
  aesop (rule_sets := [Effect4.Stores])

-- The ten operations, in the declaration order of Machine/Stores.lean.

-- map_make
example : 
    ((d.map f).make = ((d.make).1, (d.make).2.map f)) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_cellAt
example (cell : DeferredKey) : 
    ((d.map f).cellAt cell = (d.cellAt cell).map (DeferredCell.map f)) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_setCell
example (cell : DeferredKey) (value : DeferredCell κ) : 
    ((d.map f).setCell cell (value.map f) = (d.setCell cell value).map f) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_isDone
example (cell : DeferredKey) : 
    ((d.map f).isDone cell = d.isDone cell) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_poll
example (cell : DeferredKey) : 
    ((d.map f).poll cell = (d.poll cell).map (Option.map f)) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_register
example (cell : DeferredKey) (waiter : FiberId) (token : Nat) : 
    ((d.map f).register cell waiter token =
      ((d.register cell waiter token).1.map f, (d.register cell waiter token).2.map f)) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_cancel
example (cell : DeferredKey) (waiter : FiberId) (token : Nat) : 
    ((d.map f).cancel cell waiter token = (d.cancel cell waiter token).map f) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_complete
example (cell : DeferredKey) (completion : κ) : 
    ((d.map f).complete cell (f completion) =
      ((d.complete cell completion).1.map f, (d.complete cell completion).2)) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_drainDue
example : 
    ((d.map f).drainDue =
      ((d.drainDue).1.map (Owed.mapCode f), (d.drainDue).2.map f)) := by
  aesop (rule_sets := [Effect4.Stores])

-- map_wakeBatch
example (cell : DeferredKey) : 
    ((d.map f).wakeBatch cell = (d.wakeBatch cell).map f) := by
  aesop (rule_sets := [Effect4.Stores])

end Effect4.Machine.PhaseCProbe

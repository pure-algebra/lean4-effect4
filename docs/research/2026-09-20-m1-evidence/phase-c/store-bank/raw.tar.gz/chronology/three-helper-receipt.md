Phase C store-bank slice

The two narrow builds, the Owed.mapCode proof probe, and both bank censuses returned 0. The original two-theorem population improves from 0/2 with plain aesop in the corrected baseline to 1/2 with Effect4.Stores. Three new Owed.mapCode helpers then bring the current module to 4/5; all four searched proofs report only [propext]. The denominator increase is recorded separately from the one additional closure on the original population.

The bank adds cancel, wakeBatch and mapCode normalization, plus the code projection, identity and composition helpers. The probe preserves all three Obligation and #proof_wanted statements before any searched example. Final ledger reports are Core 0 open / 5 proved, CompletionSupport 0 open / 2 proved (ceiling 2→0), and OwedMapWanted 0 open / 3 proved. The existing positive poll control and the plain-aesop negative control both pass in the narrow builds.

This package contains only CompletionData, its existing control, and the associated probe/build/census records; it includes no dirty Refinement work. Source snapshots, the exact slice diff, commands, exits and hashes are in manifest.json and the lossless archive. All 13 archive members were read back and compared byte-for-byte. The coordinator reports 314 total task obligations and 172 active remaining; those are ongoing task figures, not a completion claim or a count inferred from this slice.

No compiler or live-source edit was performed for packaging. The full authorized-radius final-bank census and remaining Phase C proofs are still separate work.

This retained stage predates the pending higher-order identity-adapter helper. It remains valid historical evidence and is held for refresh before the bank commit.

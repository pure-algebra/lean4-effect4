import Effect4.Laws.Machine.Refinement
#auto_census Effect4.Laws.Machine.Refinement using aesop (rule_sets := [Effect4.Stores])

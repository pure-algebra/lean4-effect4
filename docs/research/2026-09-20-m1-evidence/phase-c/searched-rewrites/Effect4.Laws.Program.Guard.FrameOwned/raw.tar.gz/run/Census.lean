import Effect4.Laws.Program.Guard.FrameOwned
import Effect4.Laws.Auto.Census
import Effect4.Laws.Auto.RuleSets
#auto_census Effect4.Laws.Program.Guard.FrameOwned heartbeats 20000 using aesop (rule_sets := [Effect4.Stores])

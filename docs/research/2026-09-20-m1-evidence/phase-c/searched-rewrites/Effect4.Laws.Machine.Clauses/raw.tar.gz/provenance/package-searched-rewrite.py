#!/usr/bin/env python3
"""Package only explicitly named completed rewrite results; no subprocesses or live writes."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import tarfile

BASE = Path('/tmp/m1-tools/phase-c-searched-rewrites')
DEFAULT_OUT = Path('/tmp/m1-tools/phase-c-searched-rewrite-evidence')
COUNT_KEYS = ('instrument_closed_count', 'trust_admissible_closed_count', 'instrument_total_count')

def require(test, message):
    if not test:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def data(path):
    return Path(path).read_bytes()

def read(path):
    return json.loads(data(path))

def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def checked(path, digest):
    value = data(path)
    require(sha(value) == digest, 'Hash mismatch: ' + str(path))
    return value

def report_counts(report, raw_log, module):
    match = re.search(r'^' + re.escape(module) + r': (\d+) of (\d+) theorems closed from their statements;', raw_log.decode(), re.M)
    require(match is not None, 'Missing census header: ' + module)
    require(tuple(map(int, match.groups())) == (report[COUNT_KEYS[0]], report[COUNT_KEYS[2]]), 'Census count mismatch')
    require(len(report['rows']) == report[COUNT_KEYS[0]], 'Census row count mismatch')
    require(sum(bool(row['trust_admissible']) for row in report['rows']) == report[COUNT_KEYS[1]], 'Admissible row count mismatch')
    return {key: report[key] for key in COUNT_KEYS}

def package(module, out_root):
    require(re.fullmatch(r'[A-Za-z][A-Za-z0-9_.]*', module) is not None, 'Invalid module argument')
    target = out_root / module
    require(not target.exists(), 'Output exists; no overwrite: ' + str(target))
    result_path = BASE / 'runs' / module / 'result.json'
    result_bytes = data(result_path)
    result = json.loads(result_bytes)
    require(result['module'] == module and result['status'] == 'complete', 'Result must be complete: ' + module)
    require(result.get('finished_utc'), 'Missing recorded completion time')
    master_bytes = checked(BASE / 'manifest.json', result['manifest_sha256'])
    master = json.loads(master_bytes)
    row = next(x for x in master['modules'] if x['module'] == module)
    details_bytes = data(BASE / row['manifest'])
    details = json.loads(details_bytes)
    require(all(details[key] == value for key, value in row.items()), 'Module details mismatch')
    cert_bytes = checked(master['certified_candidates'], master['certified_candidates_sha256'])
    cert = json.loads(cert_bytes)
    candidates = [x for x in cert['rows'] if x['module'] == module]
    by_name = {x['name']: x for x in candidates}
    require(len(by_name) == len(candidates) == row['count'] == result['candidates'] == len(details['statements']), 'Candidate count mismatch')
    before_bytes = checked(BASE / row['before'], row['before_sha256'])
    after_bytes = checked(BASE / row['after'], row['after_sha256'])
    patch = checked(BASE / row['patch'], row['patch_sha256'])
    require(result['before_sha256'] == row['before_sha256'], 'Runner before-source mismatch')
    require(result['after_sha256'] == result['final_source_sha256'] == row['after_sha256'], 'Runner after-source mismatch')
    before, after = before_bytes.decode(), after_bytes.decode()
    pieces, previous, headers = [], 0, []
    for statement in details['statements']:
        candidate = by_name[statement['name']]
        start, end = statement['before_body_start_char'], statement['before_body_end_char']
        header = candidate['header_prefix']
        require(start >= previous and start <= end <= len(before), 'Invalid/overlapping proof span')
        require(before[start-len(header):end] == candidate['fragment'], 'Frozen fragment mismatch: ' + candidate['name'])
        require(sha(candidate['fragment'].encode()) == candidate['fragment_sha256'] == statement['frozen_fragment_sha256'], 'Fragment hash mismatch')
        require(before[start-len(header):start] == header, 'Before header mismatch')
        astart, aend = statement['after_body_start_char'], statement['after_body_end_char']
        require(after[astart-len(header):astart] == header, 'After header mismatch')
        require(sha(header.encode()) == statement['frozen_header_sha256'], 'Header hash mismatch')
        require(after[astart:aend] == statement['after_body'] and statement['after_body'].strip() == 'by aesop', 'Unexpected proof replacement')
        require(sha(before[start:end].encode()) == statement['before_body_sha256'], 'Old body hash mismatch')
        require(sha(statement['after_body'].encode()) == statement['after_body_sha256'], 'New body hash mismatch')
        pieces.extend([before[previous:start], statement['after_body']]); previous = end
        headers.append({'name': candidate['name'], 'header_sha256': sha(header.encode()), 'exact_before_after_header_match': True})
    pieces.append(before[previous:])
    require(''.join(pieces) == after, 'Changes outside certified body spans')
    raw = {}
    origins = {}
    def add(name, content, source=None):
        require(name not in raw and not name.startswith('/') and '..' not in Path(name).parts, 'Invalid archive member')
        raw[name] = content
        origins[name] = str(source) if source else 'derived record; see provenance in contents'
    add('run/result.json', result_bytes, result_path)
    for process in result['processes']:
        require(process.get('exit_code') == 0, 'Incomplete/failed subprocess in complete result')
        content = checked(process['log'], process['log_sha256'])
        add('run/' + process['label'] + '.log', content, process['log'])
    labels = {p['label'] for p in result['processes']}
    require({'build', 'census', 'diff-check'} <= labels, 'Required subprocess evidence missing')
    require(result['fresh_build_line'] in raw['run/build.log'].decode(), 'Fresh build line missing')
    require('Build completed successfully' in raw['run/build.log'].decode(), 'Successful build conclusion missing')
    census_path = result_path.parent / 'census.json'
    census_bytes = checked(census_path, result['census_json_sha256'])
    census = json.loads(census_bytes)
    after_counts = report_counts(census, raw['run/census.log'], module)
    require(census['tactic'] == result['census_tactic'] and census['cap'] == 20000, 'Census tactic/cap mismatch')
    add('run/census.json', census_bytes, census_path)
    add('run/Census.lean', checked(result_path.parent / 'Census.lean', census['source_sha256']), result_path.parent / 'Census.lean')
    provenance = master['census_provenance']
    baseline_results = json.loads(checked(provenance['census_results'], provenance['census_results_sha256']))
    baseline = next(x for x in baseline_results if x['module'] == module)
    baseline_dir = Path(provenance['census_results']).parent
    baseline_run = json.loads(checked(provenance['census_run'], provenance['census_run_sha256']))
    require(baseline_run['status'] == 'complete' and baseline_run['proof_tactic'] == 'aesop' and baseline_run['census_cap'] == 20000, 'Baseline mode mismatch')
    job = next(x for x in baseline_run['jobs'] if module in x['modules'])
    require(job['status'] == 'complete' and job['exit_code'] == 0, 'Baseline process not complete')
    baseline_log = data(baseline_dir / 'module-logs' / (module + '.log'))
    require(all(sha(baseline_log) == x['module_log_sha256'] for x in candidates), 'Certified baseline log mismatch')
    before_counts = report_counts(baseline, baseline_log, module)
    require(census['plain_baseline'] == before_counts, 'Runner baseline comparison mismatch')
    add('baseline/module-result.json', encoded(baseline))
    add('baseline/job.json', encoded(job))
    add('baseline/module.log', baseline_log, baseline_dir / 'module-logs' / (module + '.log'))
    add('baseline/process.log', checked(job['process_log'], job['process_log_sha256']), job['process_log'])
    add('baseline/Census.lean', checked(job['frozen_source'], job['source_sha256']), job['frozen_source'])
    add('sources/before/' + row['path'], before_bytes, BASE / row['before'])
    add('sources/after/' + row['path'], after_bytes, BASE / row['after'])
    add('rewrite/change.patch', patch, BASE / row['patch'])
    add('rewrite/module.json', details_bytes, BASE / row['manifest'])
    add('rewrite/master-manifest.json', master_bytes, BASE / 'manifest.json')
    add('rewrite/certified-candidates.json', encoded({'parent_path': master['certified_candidates'], 'parent_sha256': master['certified_candidates_sha256'], 'rows': candidates}))
    comparison_path = Path(master['certified_candidates']).parent / 'comparison.json'
    add('rewrite/certified-comparison.json', checked(comparison_path, master['certified_comparison_sha256']), comparison_path)
    add('rewrite/header-comparisons.json', encoded(headers))
    add('provenance/run-one.py', data(BASE / 'run-one.py'), BASE / 'run-one.py')
    add('provenance/package-searched-rewrite.py', data(__file__), Path(__file__).resolve())
    # Reject a result changed during collection; never inspect another module or current live source.
    require(data(result_path) == result_bytes, 'Result changed during packaging')
    gates = [line for line in raw['run/build.log'].decode().splitlines()
             if row['path'] + ':' in line and re.search(r'\d+ open, \d+ proved, \d+ total; ceiling \d+', line)]
    records = [{'path': name, 'bytes': len(content), 'sha256': sha(content), 'source': origins[name]}
               for name, content in sorted(raw.items())]
    manifest = {'module': module, 'evidence_kind': 'completed finite rewrite/build/census slice',
                'phase_b_commit': master['head'], 'recorded_finished_utc': result['finished_utc'],
                'rewritten_bodies': row['count'], 'source_path': row['path'],
                'source_before_sha256': row['before_sha256'], 'source_after_sha256': row['after_sha256'],
                'certified_headers_equal': True, 'only_certified_body_spans_changed': True,
                'before': {'tactic': 'aesop', 'cap': 20000, **before_counts},
                'after': {'tactic': census['tactic'], 'cap': census['cap'], **after_counts},
                'comparison_limit': 'After search may use a different rule-bank context; counts do not attribute any change solely to shorter proof bodies.',
                'processes': result['processes'], 'fresh_build_line': result['fresh_build_line'],
                'local_gate_lines': gates, 'headers': headers, 'baseline_provenance': provenance,
                'runner_source_limit': 'Runner source is packaged as currently retained; result pins its input manifest and census reader, not the runner script itself.',
                'no_claims': ['No compiler or git command run by packager', 'No full-tree gate or task completion inferred', 'No live source/current HEAD revalidation', 'No other module inspected'],
                'members': records}
    receipt = (f'# {module}\n\n'
               f'{row["count"]} certified proof bodies were replaced with `by aesop`. The full before/after source snapshots reconstruct exactly from those body edits; declaration headers and all other bytes match.\n\n'
               f'The recorded narrow build and census both returned zero. Fresh build: `{result["fresh_build_line"]}`. '
               f'Baseline plain aesop: {before_counts[COUNT_KEYS[0]]}/{before_counts[COUNT_KEYS[2]]} closed, {before_counts[COUNT_KEYS[1]]} admissible. '
               f'After `{census["tactic"]}`: {after_counts[COUNT_KEYS[0]]}/{after_counts[COUNT_KEYS[2]]} closed, {after_counts[COUNT_KEYS[1]]} admissible. Both caps are 20,000. '
               'The bank context differs when stated; this comparison does not isolate an effect of shortening proofs.\n\n'
               + ('Local gate output, distinct from theorem census:\n\n' + '\n'.join('- `' + line + '`' for line in gates) + '\n\n' if gates else 'No local obligation-gate line was reported for this source in its build log.\n\n')
               + 'The archive retains exact commands/results, successful raw logs, census source, baseline module evidence, certified fragments/header comparisons, and exact source snapshots. Its member bytes and the outer checksums were read back. This packager runs no compiler, git command, or live-source check and makes no full-task completion claim.\n')
    target.mkdir(parents=True)
    with (target / 'raw.tar.gz').open('wb') as out:
        with gzip.GzipFile(filename='', mode='wb', fileobj=out, mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w') as archive:
                for name, content in sorted(raw.items()):
                    info = tarfile.TarInfo(name); info.size = len(content); info.mode = 0o644; info.mtime = 0
                    archive.addfile(info, io.BytesIO(content))
    with tarfile.open(target / 'raw.tar.gz', 'r:gz') as archive:
        require(archive.getnames() == sorted(raw), 'Archive member set mismatch')
        for member in archive.getmembers():
            require(archive.extractfile(member).read() == raw[member.name], 'Archive byte mismatch: ' + member.name)
    manifest['archive'] = {'path': 'raw.tar.gz', 'sha256': sha(data(target / 'raw.tar.gz')), 'members': len(raw), 'bytes': (target / 'raw.tar.gz').stat().st_size, 'lossless_readback_verified': True}
    (target / 'manifest.json').write_bytes(encoded(manifest))
    (target / 'receipt.md').write_text(receipt)
    names = ['manifest.json', 'raw.tar.gz', 'receipt.md']
    (target / 'SHA256SUMS').write_text(''.join(sha(data(target / name)) + '  ' + name + '\n' for name in names))
    for line in (target / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split('  '); require(sha(data(target / name)) == digest, 'Outer checksum mismatch')
    print(json.dumps({'module': module, 'output': str(target), 'members': len(raw), 'archive_bytes': manifest['archive']['bytes'], 'before': manifest['before'], 'after': manifest['after'], 'headers_verified': len(headers)}))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('modules', nargs='+', help='Explicit completed module names; no discovery or polling')
    parser.add_argument('--output-root', type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    out = args.output_root.resolve()
    require(out.is_relative_to(Path('/tmp').resolve()), 'Output must stay under /tmp')
    require(len(args.modules) == len(set(args.modules)), 'Duplicate module argument')
    for module in args.modules:
        package(module, out)

if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, OSError, StopIteration) as error:
        print('REFUSED: ' + str(error), file=sys.stderr)
        sys.exit(2)

#!/usr/bin/env python3
"""Prepare or execute one reviewed rewrite, build, and census; never retry or commit."""
import argparse, datetime, fcntl, hashlib, importlib.util, json, os, re
import subprocess, sys, tomllib
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = Path('/Users/pooks/Dev/lean4-effect4')
READER = Path('/tmp/m1-tools/phase-b-census-runner/read-census-log.py')
ORDER = [
    'Effect4.Laws.Machine.Clauses',
    'Test.Audit.ProofGraph', 'Effect4.Laws.Api.Supervision',
    'Effect4.Laws.Machine.Approximation', 'Test.Program.DenoteRContract',
    'Effect4.Laws.Program.Guard.FrameOwned',
    'Effect4.Laws.Program.Simulation.Fibers',
    'Effect4.Laws.Program.Simulation.Pending',
]

def require(ok, why):
    if not ok:
        raise ValueError(why)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def inspect(module, already_applied):
    master = json.loads((P / 'manifest.json').read_text())
    row = next(r for r in master['modules'] if r['module'] == module)
    cert_path = Path(master['certified_candidates'])
    require(digest(cert_path) == master['certified_candidates_sha256'], 'candidate provenance drift')
    cert = json.loads(cert_path.read_text())
    frozen = {r['name']: r for r in cert['rows'] if r['module'] == module}
    details = json.loads((P / row['manifest']).read_text())
    before, after = (P / row['before']).read_text(), (P / row['after']).read_text()
    for label in ('before', 'after', 'patch'):
        require(digest(P / row[label]) == row[label + '_sha256'], label + ' snapshot drift')
    require(len(frozen) == row['count'] == len(details['statements']), 'candidate count drift')
    pieces, last = [], 0
    for statement in details['statements']:
        f = frozen[statement['name']]
        header = f['header_prefix']
        start, end = statement['before_body_start_char'], statement['before_body_end_char']
        require(before[start-len(header):end] == f['fragment'], 'frozen fragment drift: ' + f['name'])
        require(before[start-len(header):start] == header, 'statement header drift: ' + f['name'])
        require(statement['after_body'].strip() == 'by aesop', 'unexpected replacement tactic')
        require(start >= last, 'overlapping body spans')
        pieces.extend([before[last:start], statement['after_body']])
        last = end
    pieces.append(before[last:])
    require(''.join(pieces) == after, 'after-image changes more than the frozen proof bodies')
    expected = row['after_sha256'] if already_applied else row['before_sha256']
    require(digest(ROOT / row['path']) == expected,
            'live hash mismatch; use --already-applied only for the exact reviewed after-image')
    config = tomllib.loads((ROOT / 'lakefile.toml').read_text())
    library = 'Test' if module.startswith('Test.') else 'Effect4Laws'
    lib = next(x for x in config['lean_lib'] if x['name'] == library)
    require('-DwarningAsError=true' in lib['moreLeanArgs'], 'build warnings-as-errors disabled')
    return master, row, frozen

def description(module, census, already_applied, output):
    master, row, frozen = inspect(module, already_applied)
    tactic = 'aesop' + (' (rule_sets := [Effect4.Stores])' if census == 'stores' else '')
    return master, row, frozen, {
        'module': module, 'candidates': row['count'], 'census_tactic': tactic,
        'source_mode': 'already applied by root' if already_applied else 'apply reviewed patch',
        'before_sha256': row['before_sha256'], 'after_sha256': row['after_sha256'],
        'headers': 'exact frozen headers; only proof-body spans change',
        'build': 'LEAN_NUM_THREADS=1 lake build ' + module,
        'warnings_as_errors': 'verified in the owning library in lakefile.toml',
        'census': 'LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true ' + str(output / 'Census.lean'),
        'output': str(output), 'processes': [],
    }

def run_one(args):
    output = (args.output or P / 'runs' / args.module).resolve()
    master, row, frozen, result = description(args.module, args.census, args.already_applied, output)
    if not args.execute:
        print(json.dumps(result, indent=2)); return
    require(not output.exists(), 'output exists; review it rather than retrying automatically')
    # This protects this runner only. Root must also hold the sole repository compiler lease.
    with (P / 'runner.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        output.mkdir(parents=True)
        result.update(status='started', started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      manifest_sha256=digest(P / 'manifest.json'),
                      census_reader_sha256=digest(READER), lakefile_sha256=digest(ROOT / 'lakefile.toml'))
        report = output / 'result.json'
        env = dict(os.environ, LEAN_NUM_THREADS='1')
        def process(label, command):
            log = output / (label + '.log')
            item = {'label': label, 'command': command, 'environment': {'LEAN_NUM_THREADS': '1'}}
            result['processes'].append(item); write(report, result)
            with log.open('w') as stream:
                completed = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
            item.update(exit_code=completed.returncode, log=str(log), log_sha256=digest(log))
            write(report, result)
            require(completed.returncode == 0, label + ' failed; retained output, no retry or rollback')
            return log.read_text()
        try:
            if not args.already_applied:
                process('patch-check', ['git', 'apply', '--check', str(P / row['patch'])])
                process('apply', ['git', 'apply', str(P / row['patch'])])
            require(digest(ROOT / row['path']) == row['after_sha256'], 'applied source hash mismatch')
            process('diff-check', ['git', 'diff', '--check', '--', row['path']])
            log = process('build', ['lake', 'build', args.module])
            built = [line for line in log.splitlines()
                     if re.search(r'\] Built ' + re.escape(args.module) + r'(?=\s|$)', line)]
            require(len(built) == 1, 'requested module was not freshly Built; no confirmation-only result accepted')
            require('Build completed successfully' in log, 'missing successful build conclusion')
            result['fresh_build_line'] = built[0]; write(report, result)
            require(digest(ROOT / row['path']) == row['after_sha256'], 'source changed during build')
            source = output / 'Census.lean'
            source.write_text('import ' + args.module + '\nimport Effect4.Laws.Auto.Census\n'
                              'import Effect4.Laws.Auto.RuleSets\n#auto_census ' + args.module +
                              ' heartbeats 20000 using ' + result['census_tactic'] + '\n')
            log = process('census', ['lake', 'env', 'lean', '-M6144', '-DwarningAsError=true', str(source)])
            spec = importlib.util.spec_from_file_location('rewrite_census_reader', READER)
            reader = importlib.util.module_from_spec(spec); spec.loader.exec_module(reader)
            census = reader.report(log, args.module, 0)
            census.update(tactic=result['census_tactic'], cap=20000, source_sha256=digest(source))
            baseline_file = Path(master['census_provenance']['census_results'])
            require(digest(baseline_file) == master['census_provenance']['census_results_sha256'], 'baseline drift')
            baseline = next(x for x in json.loads(baseline_file.read_text()) if x['module'] == args.module)
            census['plain_baseline'] = {k: baseline[k] for k in
                ('instrument_closed_count', 'instrument_total_count', 'trust_admissible_closed_count')}
            census['comparison_limit'] = 'Stores differs from the plain baseline; no change is attributed solely to shorter proof bodies.'
            write(output / 'census.json', census)
            require(digest(ROOT / row['path']) == row['after_sha256'], 'source changed during census')
            result.update(status='complete', census_json_sha256=digest(output / 'census.json'),
                          census_closed=census['instrument_closed_count'],
                          census_allowed=census['trust_admissible_closed_count'],
                          census_rejected_names=census['inadmissible_closed_names'],
                          final_source_sha256=digest(ROOT / row['path']))
        except BaseException as error:
            result.update(status='stopped', error=str(error)); raise
        finally:
            result['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            write(report, result)
        print(json.dumps(result, indent=2))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['plan', 'run'])
    parser.add_argument('module', choices=ORDER)
    parser.add_argument('--census', choices=['plain', 'stores'], required=True)
    parser.add_argument('--already-applied', action='store_true')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    require(args.mode == 'run' or not args.execute, 'plan never executes')
    if args.mode == 'plan':
        args.execute = False
    run_one(args)

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError) as error:
        print('REFUSED: ' + str(error), file=sys.stderr); sys.exit(2)

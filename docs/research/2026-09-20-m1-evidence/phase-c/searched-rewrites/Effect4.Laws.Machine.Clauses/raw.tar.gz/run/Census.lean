import Effect4.Laws.Machine.Clauses
import Effect4.Laws.Auto.Census
import Effect4.Laws.Auto.RuleSets
#auto_census Effect4.Laws.Machine.Clauses heartbeats 20000 using aesop (rule_sets := [Effect4.Stores])

import Test.Program.DenoteRContract
import Effect4.Laws.Auto.Census
import Effect4.Laws.Auto.RuleSets
#auto_census Test.Program.DenoteRContract heartbeats 20000 using aesop

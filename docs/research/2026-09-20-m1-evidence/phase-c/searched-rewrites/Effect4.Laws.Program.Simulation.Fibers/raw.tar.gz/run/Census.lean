import Effect4.Laws.Program.Simulation.Fibers
import Effect4.Laws.Auto.Census
import Effect4.Laws.Auto.RuleSets
#auto_census Effect4.Laws.Program.Simulation.Fibers heartbeats 20000 using aesop (rule_sets := [Effect4.Stores])

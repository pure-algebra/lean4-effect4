import Test.Audit.ProofGraph
import Effect4.Laws.Auto.Census
import Effect4.Laws.Auto.RuleSets
#auto_census Test.Audit.ProofGraph heartbeats 20000 using aesop

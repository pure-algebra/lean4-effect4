import Effect4.Laws.Program.Agreement
import Effect4.Laws.Machine.CompletionData
#auto_census Effect4.Laws.Program.Agreement using aesop (rule_sets := [Effect4.Stores])

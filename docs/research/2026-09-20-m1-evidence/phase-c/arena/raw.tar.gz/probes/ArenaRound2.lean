import Effect4.Laws.Machine.Arena
import Effect4.Laws.Machine.CompletionData
attribute [aesop norm simp (rule_sets := [Effect4.Stores])]
  Effect4.Machine.instArenaList Effect4.Machine.Arena.toList
  Effect4.Machine.LawfulArena.size_empty Effect4.Machine.LawfulArena.dense
  Effect4.Machine.LawfulArena.alloc_fresh Effect4.Machine.LawfulArena.size_alloc
  Effect4.Machine.LawfulArena.peek_alloc_new Effect4.Machine.LawfulArena.peek_alloc_old
  Effect4.Machine.LawfulArena.size_poke Effect4.Machine.LawfulArena.peek_poke_same
  Effect4.Machine.LawfulArena.peek_poke_other Effect4.Machine.LawfulArena.poke_absent
namespace Effect4.Machine.ArenaProbe

-- list_lawful
example (α : Type) :  (LawfulArena (List α) α) := by
  aesop (rule_sets := [Effect4.Stores]) (add safe constructors [LawfulArena])

-- toList_empty
example {σ α : Type} [Arena σ α] [LawfulArena σ α] :
     (Arena.toList (Arena.empty : σ) = []) := by
  aesop (rule_sets := [Effect4.Stores])

-- toList_list
example {α : Type} [LawfulArena (List α) α] (xs : List α) :
     (Arena.toList xs = xs) := by
  aesop (rule_sets := [Effect4.Stores])

-- toList_length
example {σ α : Type} [Arena σ α] [LawfulArena σ α] (s : σ) :
     ((Arena.toList s).length = Arena.size s) := by
  aesop (rule_sets := [Effect4.Stores])

-- peek_toList
example {σ α : Type} [Arena σ α] [LawfulArena σ α] (s : σ) (i : Nat) :
     (Arena.peek s i = (Arena.toList s)[i]?) := by
  aesop (rule_sets := [Effect4.Stores])

-- toList_poke
example {σ α : Type} [Arena σ α] [LawfulArena σ α] (s : σ) (i : Nat) (v : α) :
     (Arena.toList (Arena.poke s i v) = (Arena.toList s).set i v) := by
  aesop (rule_sets := [Effect4.Stores])

-- toList_alloc
example {σ α : Type} [Arena σ α] [LawfulArena σ α] (s : σ) (v : α) :
     (Arena.toList (Arena.alloc s v).2 = Arena.toList s ++ [v]) := by
  aesop (rule_sets := [Effect4.Stores])

-- deferred_make
example {κ : Type} (d : DeferredStore κ) :  (
    d.make =
      (⟨(Arena.alloc d.cells (⟨none, WakeList.empty⟩ : DeferredCell κ)).1⟩,
       { d with cells := (Arena.alloc d.cells (⟨none, WakeList.empty⟩ : DeferredCell κ)).2 })) := by
  aesop (rule_sets := [Effect4.Stores])

-- deferred_cellAt
example {κ : Type} (d : DeferredStore κ) (cell : DeferredKey) :
     (d.cellAt cell = Arena.peek d.cells cell.index) := by
  aesop (rule_sets := [Effect4.Stores])

-- deferred_setCell
example {κ : Type} (d : DeferredStore κ) (cell : DeferredKey)
    (value : DeferredCell κ) :  (
    d.setCell cell value = { d with cells := Arena.poke d.cells cell.index value }) := by
  aesop (rule_sets := [Effect4.Stores])

end Effect4.Machine.ArenaProbe

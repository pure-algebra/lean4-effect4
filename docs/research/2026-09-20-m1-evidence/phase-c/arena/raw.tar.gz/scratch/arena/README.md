# Arena Phase C evidence

Only live source changed: `src/Effect4/Laws/Machine/Arena.lean`.
The ten existing ArenaObligations statements are byte-identical after removing wanted-marker lines. Three support statements were recorded before proof attempts in `Arena-helpers-wanted.lean`; the initial file is `Arena-before.lean`. No admission or statement weakening was added.

The module now proves the lawful list instance, dense list projection (empty, identity on lists, length, lookup, update, allocation), and the three DeferredStore adapters. The module documentation describes these laws. Extensionality stays local. Reusable equations are registered in Effect4.Stores; list-lawfulness, lookup transport, and the unequal-index list update rule use safe apply. The full source at each attempted build is retained as `Arena-attempt-N.lean`.

## Verification

Every narrow build used:

    LEAN_NUM_THREADS=1 lake build Effect4.Laws.Machine.Arena

The Lake command enforces `-M6144 -DwarningAsError=true`.

- `build-1.log`: initial bank residuals; exit 1.
- `build-2.log`: lawful list instance, empty projection, and three support lemmas; exit 0.
- `build-3.log`: lookup-update and lookup-allocation residuals; exit 1.
- `build-4.log`: two local lemma-name errors; exit 1.
- `build-5.log`: all proof bodies; exit 0.
- `build-6-gates.log`: ArenaObligations 10 proved / 0 open; ArenaSupportWanted 3 proved / 0 open; both ceiling 0; exit 0.
- `build-7-final.log`: after the four census-selected proof rewrites; both gates still zero; exit 0, 1.8 seconds.

The scratch report used:

    LEAN_NUM_THREADS=1 lake env lean -M6144 -DwarningAsError=true /tmp/m1-phase-c/arena/After.lean

`after-census-axioms.log` exited 0 against `Arena-attempt-6.lean`, before the final four proof rewrites. Both census commands explicitly used a 20,000-heartbeat cap. Default search closed 3/24; Stores search closed 1/24. All four reported closures are trust-admissible. The B baseline was 0/10; the source population grew, so these are not a same-population improvement measurement. The bank count rejects solutions that refer to their own newly registered theorem, as the unchanged instrument requires. No count was forced or instrument modified.

The four searched proofs were then written directly: the three DeferredStore adapters use `aesop`; `instLawfulArenaList` uses `aesop (rule_sets := [Effect4.Stores])`. The final build checks those source changes. The report printed axioms for all 13 public theorems, the list instance, and all 13 gate-generated checked theorems: the union is `[propext, Quot.sound]`, with no Classical.choice. The census also reports the axioms for the exact searched forms subsequently installed. A final-tree full axiom gate remains part of the coordinator's later sweep.

Offline final checks passed: frozen-statement comparison, no remaining wanted markers, no first/try/simp_all/bare simp forms, and `git diff --check -- src/Effect4/Laws/Machine/Arena.lean`.

`receipt.json` records source hashes, counts, and precise evidence version. Compiler lease was returned immediately after build 7. No dependent module was built and no staging or commit was performed.

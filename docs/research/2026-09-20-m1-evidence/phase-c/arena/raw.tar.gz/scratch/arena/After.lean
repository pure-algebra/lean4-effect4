import Effect4.Laws.Machine.Arena
import Effect4.Laws.Auto.Census

#auto_census Effect4.Laws.Machine.Arena heartbeats 20000 using aesop
#auto_census Effect4.Laws.Machine.Arena heartbeats 20000 using aesop (rule_sets := [Effect4.Stores])

#print axioms Effect4.Machine.Arena.list_lawful
#print axioms Effect4.Machine.Arena.map_some_filterMap
#print axioms Effect4.Machine.Arena.lookup_filterMap
#print axioms Effect4.Machine.Arena.peek_none
#print axioms Effect4.Machine.Arena.toList_empty
#print axioms Effect4.Machine.Arena.toList_length
#print axioms Effect4.Machine.Arena.peek_toList
#print axioms Effect4.Machine.Arena.toList_list
#print axioms Effect4.Machine.Arena.toList_poke
#print axioms Effect4.Machine.Arena.toList_alloc
#print axioms Effect4.Machine.Arena.deferred_make
#print axioms Effect4.Machine.Arena.deferred_cellAt
#print axioms Effect4.Machine.Arena.deferred_setCell
#print axioms Effect4.Machine.Arena.instLawfulArenaList
#print axioms Effect4.Machine.ArenaObligations.list_lawful.checked
#print axioms Effect4.Machine.ArenaObligations.toList_empty.checked
#print axioms Effect4.Machine.ArenaObligations.toList_list.checked
#print axioms Effect4.Machine.ArenaObligations.toList_length.checked
#print axioms Effect4.Machine.ArenaObligations.peek_toList.checked
#print axioms Effect4.Machine.ArenaObligations.toList_poke.checked
#print axioms Effect4.Machine.ArenaObligations.toList_alloc.checked
#print axioms Effect4.Machine.ArenaObligations.deferred_make.checked
#print axioms Effect4.Machine.ArenaObligations.deferred_cellAt.checked
#print axioms Effect4.Machine.ArenaObligations.deferred_setCell.checked
#print axioms Effect4.Machine.ArenaSupportWanted.map_some_filterMap.checked
#print axioms Effect4.Machine.ArenaSupportWanted.lookup_filterMap.checked
#print axioms Effect4.Machine.ArenaSupportWanted.peek_none.checked

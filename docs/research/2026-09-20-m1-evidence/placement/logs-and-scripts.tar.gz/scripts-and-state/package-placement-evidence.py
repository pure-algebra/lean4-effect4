#!/usr/bin/env python3
"""Offline placement receipt; never builds, generates runtime data, stages, or commits."""
from pathlib import Path
import csv, hashlib, importlib.util, json, re, shutil, subprocess, tarfile
from datetime import datetime, timezone
ROOT=Path('/Users/pooks/Dev/lean4-effect4'); TMP=Path('/tmp/m1-tools')
OUT=ROOT/'docs/research/2026-09-20-m1-evidence/placement';OUT.mkdir(exist_ok=True)
plan=json.loads((TMP/'placement-plan.json').read_text()); state=json.loads((TMP/'placement-state.json').read_text())
base=state['head']; before=Path(state['before']); sha=lambda b:hashlib.sha256(b).hexdigest()
spec=importlib.util.spec_from_file_location('placement',TMP/'prepare-placement.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
paths={r['source']:r['destination'] for r in plan['moves']}
def normalize(s):
 for old,new in sorted(paths.items(),key=lambda kv:-len(kv[1])):
  s=s.replace(new,old).replace(new.replace('/','\\'),old.replace('/','\\'))
 return mod.lean_code(s)
def old(p):return (before/p).read_text()
def now(p):return (ROOT/p).read_text()
checks=[]
for m in plan['moves']:
 assert not (ROOT/m['source']).exists(),m['source']
 assert normalize(old(m['source']))==normalize(now(m['destination'])),m['source']
 checks.append({'old':m['source'],'new':m['destination'],'generated':m['generated'],'old_sha256':sha((before/m['source']).read_bytes()),'new_sha256':sha((ROOT/m['destination']).read_bytes()),'declaration_and_proof_tokens_unchanged':True})
special={'src/Effect4/Program/Typing/Agreement.lean','Test/Store/Templates.lean','Test/Store/NodeContract.lean','Test/Api/AcquireHandleContract.lean','Test/Audit/AxiomGate.lean','tools/Tools/ArchitectureRoles.lean'}
import_checks=[]
for f in sorted(before.rglob('*.lean')):
 source=str(f.relative_to(before));dest=paths.get(source,source)
 if source in special or not (ROOT/dest).exists():continue
 assert normalize(f.read_text())==normalize(now(dest)),source
 import_checks.append({'old':source,'new':dest,'declaration_and_proof_tokens_unchanged':True})
ag='src/Effect4/Program/Typing/Agreement.lean';mark="namespace Checker\n\n/-! ## The checker's projections as the fold -/"
suffix=old(ag).split(mark)[1]
assert now('src/Effect4/Laws/Program/Typing/FoldAgreement.lean').endswith(suffix)
assert normalize(old(ag).split(mark)[0]+'\nend Effect4.Program\n')==normalize(now(ag))
template=old('Test/Store/Templates.lean');block=template[template.index('/-! ## An all-nullary sum'):template.index('/-! ## A mutual pair')]
assert block in now('tools/TestSupport/CasEntry.lean')
sample='/-- The census entry of the facts note: `Effect.gen`, a `const` at line 1947. -/\ndef entry : Entry := ⟨"Effect", "gen", .const, 1947⟩\n'
assert sample in now('tools/TestSupport/CasEntry.lean')
assert normalize(template.replace(block,'').replace(sample,''))==normalize(now('Test/Store/Templates.lean'))
inst='/-- `Templates.Entry` files as `export`, the kind the plan\'s §3 gives the census entry. -/\ninstance instContentEntry : Content Effect4.Store.Templates.Entry := ⟨.«export»⟩\n'
assert inst in now('tools/TestSupport/CasEntry.lean')
assert normalize(old('Test/Store/NodeContract.lean').replace(inst,''))==normalize(now('Test/Store/NodeContract.lean'))
host=old('Test/Api/AcquireHandleContract.lean');block=host[host.index('def resource :='):host.index('\ndef acquire :')]
assert block in now('tools/TestSupport/AcquireHandle.lean')
assert normalize(host.replace(block,''))==normalize(now('Test/Api/AcquireHandleContract.lean'))
commands=re.compile(r'^#(?:guard(?:_msgs)?|check|print)\b.*(?:\n(?!\S).*)*',re.M)
for p in ['Test/Store/Templates.lean','Test/Store/NodeContract.lean','Test/Api/AcquireHandleContract.lean']:
 assert commands.findall(old(p))==commands.findall(now(p)),p
roles=old('tools/Tools/ArchitectureRoles.lean');allowed=roles[roles.index('def allowed '):roles.index('/-- The roots loaded')]
assert allowed in now('tools/Tools/ArchitectureRoles.lean')
axioms=old('Test/Audit/AxiomGate.lean')
for a,b in [('Effect4.Laws.Auto.PositionGate','Effect4.Laws.Program.Typed.PositionGate'),('Effect4.Laws.Auto.TypedStateDecl','Effect4.Laws.Program.Typed.TypedStateDecl'),('Effect4.Laws.Auto.TypedSources','Effect4.Laws.Program.Typed.TypedSources')]:axioms=axioms.replace(a,b)
assert axioms==now('Test/Audit/AxiomGate.lean')
oldmanifest=json.loads(old('tools/Effect4Gen/manifest.json'));manifest=json.loads(now('tools/Effect4Gen/manifest.json'))
for a,b in zip(oldmanifest['groups'],manifest['groups'],strict=True):
 assert {k:v for k,v in a.items() if k not in ['Imports','Out']}=={k:v for k,v in b.items() if k not in ['Imports','Out']}
protected=['README.md','ocaml/gen','ocaml/engine/api_engine.ml','generated','Test/contracts','Test/fixtures/baseline']
assert not subprocess.check_output(['git','diff','--name-only',base,'--',*protected],cwd=ROOT)
diff=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True);assert diff.returncode==0,diff.stdout+diff.stderr
(OUT/'diff-check.log').write_text(diff.stdout+diff.stderr)
source_checks={'base':base,'checked_at_utc':datetime.now(timezone.utc).isoformat(),'comparison':'Imports, comments, whitespace and approved physical provenance paths removed; declaration/proof/name tokens compared. No semantic equivalence claim.', 'moves':checks,'import_only_files':import_checks,'six_fold_laws':plan['split']['move_declarations'],'fold_law_suffix_exact':True,'remaining_typing_declarations_unchanged':True,'neutral_fixture_blocks_exact':True,'three_fixture_battery_commands_unchanged':True,'architecture_allowed_relation_unchanged':True,'axiom_gate_only_three_exact_meta_module_renames':True,'manifest_non_import_output_fields_unchanged':True,'protected_paths_unchanged':protected,'diff_check_exit':diff.returncode,'retired_imports':json.loads((TMP/'placement-post-source-check.json').read_text())['retired_imports']}
(OUT/'source-checks.json').write_text(json.dumps(source_checks,indent=2)+'\n')
progress={}
for start in [0,12,35,64,66]:
 for r in json.loads((TMP/f'placement-build-logs/progress-from-{start}.json').read_text()):progress[r['index']]=r
assert list(sorted(progress))==list(range(68));assert all(r['returncode']==0 for r in progress.values())
rows=[]
for r in [progress[i] for i in range(68)]:
 r=dict(r);r['log']=r['log'].replace(str(TMP)+'/','')
 if r['module']=='Effect4Gen.Forms':r['source']='fresh Forms and FormsLaws producer elaboration'
 else:r.setdefault('source','direct invocation')
 if r['source']=='direct invocation':r['argv']=(['lake','env','lean','-DwarningAsError=true','harness/truth/Truth.lean'] if r['module']=='harness.truth.Truth' else ['lake','build',r['module']])
 rows.append(r)
(OUT/'module-results.json').write_text(json.dumps(rows,indent=2)+'\n')
with (OUT/'module-results.tsv').open('w') as f:
 writer=csv.writer(f,delimiter='\t');writer.writerow(['index','module','result','source','log'])
 for r in rows:writer.writerow([r['index'],r['module'],'pass',r['source'],r['log']])
with (OUT/'moves.tsv').open('w') as f:
 writer=csv.writer(f,delimiter='\t');writer.writerow(['old','new','generated','old_sha256','new_sha256'])
 for r in checks:writer.writerow([r[k] for k in ['old','new','generated','old_sha256','new_sha256']])
selected={g['name'] for g in state['generator_groups']};commands=json.loads((TMP/'placement-derived-logs/commands.log').read_text());actual=[]
for row in commands:
 if row['name'] not in selected:continue
 args=row['args'].copy();args[args.index('--out')+1]=str(TMP/'placement-derived-logs'/(row['name']+'.lean'))
 if '--append' in args:args[args.index('--append')+1]=args[args.index('--append')+1].replace('\\','/')
 args.insert(args.index('lean')+1,'-DwarningAsError=true');args+=['--header-out',row['out']]
 actual.append({'group':row['name'],'argv':['lake',*args],'env':{'LEAN_NUM_THREADS':'1'},'result':'pass','output':row['out']})
assert len(actual)==11
(OUT/'producer-commands.json').write_text(json.dumps(actual,indent=2)+'\n')
shutil.copy2(TMP/'placement-derived-checks.json',OUT/'derived-checks.json')
failed=[{'log':'placement-derived-logs/projection-check.log','result':'unchanged 200000-heartbeat timeout','resolution':'Checked each of seven applicable Main/default outputs separately at unchanged cap; no producer rerun.'},{'log':'placement-derived-logs/TyView-projection-check.log','result':'no shape declaration found','resolution':'Canonical checker is inapplicable to View/Fold/Forms output. Those four groups retain producer fingerprint comparison, narrow build, embedded checks.'},{'log':'placement-build-logs/035-Effect4Gen.Forms.log','result':'unknown lake target','resolution':'Forms is not a library root. Its exact source had already elaborated in both fresh canonical producer invocations.'},{'log':'placement-build-logs/064-harness.truth.Truth-wrong-lake-target.log','result':'unknown lake target','resolution':'Direct lake env lean -DwarningAsError=true harness/truth/Truth.lean passed.'},{'log':'placement-build-logs/066-Effect4.Laws-import-placement-failed.log','result':'import after module doc command','resolution':'Moved added imports into leading block; unchanged declaration tokens; root rebuilt and passed.'}]
(OUT/'failed-attempts.json').write_text(json.dumps(failed,indent=2)+'\n')
archive={}
for folder in ['placement-derived-logs','placement-build-logs']:
 for p in (TMP/folder).iterdir():
  if p.is_file():archive[f'{folder}/{p.name}']=p
for p in Path('/tmp').glob('m1-placement-*.log'):archive['orchestration/'+p.name]=p
for name in ['prepare-placement.py','build-placement.py','finish-placement-derived.py','placement-plan.json','placement-state.json','placement-execution-order.json','placement-post-source-check.json','package-placement-evidence.py']:
 archive['scripts-and-state/'+name]=TMP/name
with tarfile.open(OUT/'logs-and-scripts.tar.gz','w:gz') as tar:
 for name,p in sorted(archive.items()):tar.add(p,arcname=name,recursive=False)
# Verify lossless archive content against every retained file before publishing its manifest.
with tarfile.open(OUT/'logs-and-scripts.tar.gz','r:gz') as tar:
 for name,p in archive.items():assert tar.extractfile(name).read()==p.read_bytes()
with (OUT/'archive-manifest.tsv').open('w') as f:
 writer=csv.writer(f,delimiter='\t');writer.writerow(['archive_member','bytes','sha256'])
 for name,p in sorted(archive.items()):writer.writerow([name,p.stat().st_size,sha(p.read_bytes())])
source_files=sorted(set(state['writes'])|{m['destination'] for m in plan['moves']}|{g['new_output'] for g in state['generator_groups']})
with (OUT/'source-sha256.tsv').open('w') as f:
 writer=csv.writer(f,delimiter='\t');writer.writerow(['path','sha256'])
 for p in source_files:
  if (ROOT/p).is_file():writer.writerow([p,sha((ROOT/p).read_bytes())])
print(json.dumps({'bundle':str(OUT),'moves':len(checks),'import_body_comparisons':len(import_checks),'module_results':len(rows),'producer_runs':len(actual),'archive_files':len(archive),'archive_bytes':(OUT/'logs-and-scripts.tar.gz').stat().st_size,'diff_check':diff.returncode},indent=2))

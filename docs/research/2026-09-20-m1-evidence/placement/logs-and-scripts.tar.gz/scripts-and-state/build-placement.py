#!/usr/bin/env python3
"""Serial placement checks; stop on the first failed module and retain its own log."""
import argparse,json,os,re,subprocess
from pathlib import Path
root=Path('/Users/pooks/Dev/lean4-effect4')
base=Path('/tmp/m1-tools')
plan=json.loads((base/'placement-execution-order.json').read_text())
parser=argparse.ArgumentParser();parser.add_argument('--start',type=int,default=0);args=parser.parse_args()
narrow=next(s['modules_in_order'] for s in plan['steps'] if s['stage']=='narrow_builds')
roots=next(s['modules_in_order'] for s in plan['steps'] if s['stage']=='root_and_trust_checks')
modules=narrow+roots
logs=base/'placement-build-logs';logs.mkdir(exist_ok=True)
progress=[]
def fresh_evidence(module):
 # Standalone generator Forms is intentionally outside Effect4Gen's Main/Check lake roots.
 # Its two successful --run producer calls type-checked this exact placed source already.
 if module == 'Effect4Gen.Forms':
  state=json.loads((base/'placement-state.json').read_text())
  if state.get('status')=='derived_regenerated':
   return dict(log=str(base/'placement-derived-logs/Forms-generate.log'),
               diagnostic='Fresh successful --run tools/Effect4Gen/Forms.lean; output fingerprint/build checked; not a lake library target.')
 for folder in [base/'placement-derived-logs',logs]:
  for path in sorted(folder.glob('*.log')):
   text=path.read_text()
   if 'Build completed successfully' not in text:continue
   # A replay or a cache hit is not fresh evidence; only successful Built diagnostics count.
   for line in text.splitlines():
    if re.search(r'\] Built '+re.escape(module)+r' \(',line):
     return dict(log=str(path),diagnostic=line)
 return None
for i,module in enumerate(modules):
 if i<args.start:continue
 evidence=fresh_evidence(module)
 if evidence is not None:
  print(f'{i+1}/{len(modules)} {module}: freshly built as dependency; skip',flush=True)
  progress.append(dict(index=i,module=module,returncode=0,source='fresh dependency build',**evidence))
  (logs/f'progress-from-{args.start}.json').write_text(json.dumps(progress,indent=2)+'\n')
  continue
 label=f'{i:03d}-{module}'
 path=logs/(label+'.log')
 print(f'{i+1}/{len(modules)} {module}',flush=True)
 with path.open('w') as log:
  argv=(['lake','env','lean','-DwarningAsError=true','harness/truth/Truth.lean']
        if module=='harness.truth.Truth' else ['lake','build',module])
  result=subprocess.run(argv,cwd=root,env={**os.environ,'LEAN_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT)
 progress.append(dict(index=i,module=module,returncode=result.returncode,log=str(path)))
 (logs/f'progress-from-{args.start}.json').write_text(json.dumps(progress,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
print('Placement narrow and root checks completed.',flush=True)

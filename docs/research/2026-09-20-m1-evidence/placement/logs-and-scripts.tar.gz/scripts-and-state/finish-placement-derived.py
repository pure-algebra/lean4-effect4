#!/usr/bin/env python3
"""Resume only the failed final check stage; every existing output is fingerprinted first."""
from pathlib import Path
import importlib.util,json,subprocess,os
base=Path('/tmp/m1-tools');root=Path('/Users/pooks/Dev/lean4-effect4')
spec=importlib.util.spec_from_file_location('placement',base/'prepare-placement.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
state=json.loads((base/'placement-state.json').read_text())
assert state['status']=='source_placement_applied'
for group in state['generator_groups']:
 before=(Path(state['before'])/group['old_output']).read_text();after=(root/group['new_output']).read_text()
 assert m.lean_code(before)==m.lean_code(after),group['name']
for group in state['generator_groups']:
 name=group['name'];print(name,flush=True)
 with (base/'placement-derived-logs'/(name+'-projection-check.log')).open('w') as log:
  subprocess.run(['lake','env','lean','-M4096','-DwarningAsError=true','--run','tools/Effect4Gen/Check.lean',group['new_output']],cwd=root,env={**os.environ,'LEAN_NUM_THREADS':'1'},stdout=log,stderr=subprocess.STDOUT,check=True)
for move in state['generated_moves']:(root/move['source']).unlink()
state['status']='derived_regenerated';state['projection_checks']='one file per unchanged-budget invocation'
(base/'placement-state.json').write_text(json.dumps(state,indent=2)+'\n')
print('All11 projection checks passed; obsolete generated paths removed.',flush=True)

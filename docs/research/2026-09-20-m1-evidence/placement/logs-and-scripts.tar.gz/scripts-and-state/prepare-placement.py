#!/usr/bin/env python3
"""Apply the reviewed placement plan, or regenerate only derived projections.

Prepared for coordinator execution AFTER the Phase A commit. Not executed by the scout.

  python3 /tmp/m1-tools/prepare-placement.py --refresh-plan
  python3 /tmp/m1-tools/prepare-placement.py --check
  python3 /tmp/m1-tools/prepare-placement.py --apply
  python3 /tmp/m1-tools/prepare-placement.py --regenerate-derived

--apply edits handwritten paths/imports and producer inputs, leaving all generated source
bytes in their old locations until --regenerate-derived writes the new outputs. This is an
explicit transient state, not a buildable stopping point. --regenerate-derived invokes the
existing producer for each affected group once, then removes obsolete generated paths. It never invokes
LCNF, CAS, EFF, TS, architecture, or the broad check. All declaration namespaces stay unchanged.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
PLAN = HERE / 'placement-plan.json'
ROOT = Path('/Users/pooks/Dev/lean4-effect4')
STATE = HERE / 'placement-state.json'

def module(path: str) -> str:
    if path.startswith(('src/', 'tools/')):
        path = path.split('/', 1)[1]
    return path.removesuffix('.lean').replace('/', '.')

def replace_once(text: str, old: str, new: str, label: str) -> str:
    if text.count(old) != 1:
        raise RuntimeError(f'{label}: expected one anchor, found {text.count(old)}')
    return text.replace(old, new, 1)

def is_generated(text: str) -> bool:
    return bool(re.match(r'\A[ \t]*--[ \t]*GENERATED\b', text))

def paths() -> list[str]:
    raw = subprocess.check_output(['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z'], cwd=ROOT).decode()
    return sorted({p for p in raw.split('\0') if p and (ROOT / p).is_file()})

def frozen(path: str) -> bool:
    return path == 'README.md' or path.startswith((
        'docs/research/', 'Test/contracts/', 'Test/fixtures/', 'vendor/', 'generated/',
        'ocaml/gen/', 'ocaml/goldens/', 'ocaml/engine/cas/goldens/'))

def produce_edits(plan: dict) -> tuple[dict[str, str], list[str], list[dict]]:
    moves = plan['moves']
    mm = {x['source_module']: x['destination_module'] for x in moves}
    pm = {x['source']: x['destination'] for x in moves}
    originals = {p: (ROOT / p).read_text() for p in paths()
                 if p.endswith('.lean') and not frozen(p)}
    edits: dict[str, str] = {}
    deletes: list[str] = []
    generated_moves = [x for x in moves if x['generated']]
    for x in moves:
        if not (ROOT / x['source']).is_file():
            raise RuntimeError(f"missing source: {x['source']}")
        if (ROOT / x['destination']).exists():
            raise RuntimeError(f"occupied destination: {x['destination']}")

    # Imports identify modules; all namespace/open/qualified-constant references remain literal.
    def rewrite_imports(text: str) -> str:
        return re.sub(r'^(import[ \t]+)([\w.]+)([ \t]*(?:--[^\r\n]*)?)$',
                      lambda m: m[1] + mm.get(m[2], m[2]) + m[3], text, flags=re.M)

    # Code/documentation physical paths are distinct from declaration names. Frozen historical
    # records and all generated outputs are excluded from this mechanical path substitution.
    def rewrite_paths(text: str) -> str:
        for old, new in sorted(pm.items(), key=lambda kv: -len(kv[0])):
            text = text.replace(old, new)
            text = text.replace(old.replace('/', '\\'), new.replace('/', '\\'))
        return text

    for source, text in originals.items():
        if is_generated(text):
            continue
        changed = rewrite_paths(rewrite_imports(text))
        dest = pm.get(source, source)
        if dest != source:
            deletes.append(source)
        if dest != source or changed != text:
            edits[dest] = changed

    def get(path: str) -> str:
        return edits[path] if path in edits else (ROOT / path).read_text()

    # The runtime projection theorem stays with Typing; only six fold connector laws move.
    agreement = 'src/Effect4/Program/Typing/Agreement.lean'
    text = get(agreement)
    marker = 'namespace Checker\n\n/-! ## The checker\'s projections as the fold -/'
    if text.count(marker) != 1:
        raise RuntimeError('Typing.Agreement fold split anchor drifted')
    prefix, suffix = text.split(marker)
    text = prefix.replace('import Effect4.Laws.Program.Folds.Checker\n', '')
    edits[agreement] = text.rstrip() + '\n\nend Effect4.Program\n'
    edits['src/Effect4/Laws/Program/Typing/FoldAgreement.lean'] = (
        'import Effect4.Program.Typing.Agreement\n'
        'import Effect4.Laws.Program.Folds.Checker\n\n'
        '/-! The checker projections as folds; moved without changing declarations or proofs. -/\n\n'
        'namespace Effect4.Program\n\nnamespace Checker\n\n'
        '/-! ## The checker\'s projections as the fold -/' + suffix)

    # Runtime root loses proof imports; Laws root takes ownership.
    connectors = [x for x in moves if '/Folds/' in x['source']
                  and x['source'].startswith('src/Effect4/') and '/Laws/' not in x['source']]
    core = get('src/Effect4.lean')
    for x in connectors:
        core = replace_once(core, f"import {x['destination_module']}\n", '', 'core fold import')
    edits['src/Effect4.lean'] = core
    laws = get('src/Effect4/Laws.lean')
    additions = [x['destination_module'] for x in connectors]
    additions.append('Effect4.Laws.Program.Typing.FoldAgreement')
    laws_head, laws_body = laws.split('\n/-!', 1)
    edits['src/Effect4/Laws.lean'] = laws_head.rstrip() + '\n' + ''.join(f'import {m}\n' for m in additions) + '\n/-!' + laws_body

    # Neutral shared fixtures. Rehome the very same declarations, including proof bodies.
    template_path = 'Test/Store/Templates.lean'
    template = get(template_path)
    start = template.index('/-! ## An all-nullary sum')
    stop = template.index('/-! ## A mutual pair', start)
    shared_entry = template[start:stop]
    sample = '/-- The census entry of the facts note: `Effect.gen`, a `const` at line 1947. -/\ndef entry : Entry := ⟨"Effect", "gen", .const, 1947⟩\n'
    template = template[:start] + template[stop:]
    template = replace_once(template, sample, '', 'Templates.entry')
    edits[template_path] = 'import TestSupport.CasEntry\n' + template
    node_path = 'Test/Store/NodeContract.lean'
    node = get(node_path)
    inst = '/-- `Templates.Entry` files as `export`, the kind the plan\'s §3 gives the census entry. -/\ninstance instContentEntry : Content Effect4.Store.Templates.Entry := ⟨.«export»⟩\n'
    node = replace_once(node, inst, '', 'NodeContract content instance')
    edits[node_path] = 'import TestSupport.CasEntry\n' + node
    edits['tools/TestSupport/CasEntry.lean'] = (
        'import Effect4.Store.Domain.Node\n'
        'import Effect4.Store.Domain.Derived.Json\n\n'
        '/-! Shared CAS entry fixture. No runtime module imports test support.\n'
        'Declarations and proofs retain their existing names; tests retain all guards. -/\n\n'
        'set_option autoImplicit false\n\nnamespace Effect4.Store.Templates\n\n'
        + shared_entry + sample + '\nend Effect4.Store.Templates\n\n'
        'namespace Test.Store.NodeContract\nopen Effect4.Store\n\n'
        + inst + '\nend Test.Store.NodeContract\n')
    cas = 'src/OCaml5/Tools/CasGoldens.lean'
    edits[cas] = replace_once(get(cas), 'import Test.Store.NodeContract',
                              'import TestSupport.CasEntry', 'CasGoldens fixture import')

    host_path = 'Test/Api/AcquireHandleContract.lean'
    host = get(host_path)
    start = host.index('def resource :=')
    stop = host.index('\ndef acquire :', start)
    host_fixture = host[start:stop]
    edits[host_path] = 'import TestSupport.AcquireHandle\n' + host[:start] + host[stop:]
    edits['tools/TestSupport/AcquireHandle.lean'] = (
        'import Effect4.Program.Native\n\n'
        '/-! Shared host resource-row fixture; runtime modules do not import test support. -/\n\n'
        'namespace Test.Api.AcquireHandleContract\nopen Effect4 Effect4.Program Effect4.Machine\n\n'
        + host_fixture + '\n\nend Test.Api.AcquireHandleContract\n')
    rowtypes = 'tools/Tools/RowTypes.lean'
    edits[rowtypes] = replace_once(get(rowtypes), 'import Test.Api.AcquireHandleContract',
                                   'import TestSupport.AcquireHandle', 'RowTypes fixture import')

    # Meta exemptions identify source modules, not declaration namespaces.
    audit = 'Test/Audit/AxiomGate.lean'
    at = get(audit)
    for short in ['PositionGate', 'TypedSources', 'TypedStateDecl']:
        at = at.replace(f'`Effect4.Laws.Auto.{short}', f'`Effect4.Laws.Program.Typed.{short}')
    edits[audit] = at

    # The manifest names MODULES in Imports, PATHS in Out, but DECLARATIONS in Types/Kinds.
    manifest_path = 'tools/Effect4Gen/manifest.json'
    manifest = json.loads((ROOT / manifest_path).read_text())
    changed_groups = []
    def update_manifest(value):
        if isinstance(value, dict):
            if all(k in value for k in ('Name', 'Imports', 'Out')):
                oldi, oldo = value['Imports'], value['Out']
                value['Imports'] = ','.join(mm.get(m, m) for m in oldi.split(','))
                path = oldo.replace('\\', '/')
                value['Out'] = pm.get(path, path).replace('/', '\\')
                if (oldi, oldo) != (value['Imports'], value['Out']):
                    changed_groups.append(value['Name'])
            for child in value.values(): update_manifest(child)
        elif isinstance(value, list):
            for child in value: update_manifest(child)
    update_manifest(manifest)
    edits[manifest_path] = json.dumps(manifest, ensure_ascii=False, indent=2) + '\n'

    # Build recipe paths and import-target module literals. No declaration-name substitutions.
    recipe_paths = ['Makefile', 'lakefile.toml', 'scripts/generate.py', 'scripts/check-ingest.sh',
                    'ocaml/eff/test/dune']
    for path in recipe_paths:
        text = rewrite_paths((ROOT / path).read_text())
        if path == 'Makefile':
            for old, new in pm.items():
                if old.startswith('src/Effect4/'):
                    a = old.removeprefix('src/Effect4/').removesuffix('.lean') + '.trace'
                    b = new.removeprefix('src/Effect4/').removesuffix('.lean') + '.trace'
                    text = text.replace(a, b)
            text = text.replace('$(wildcard tools/Tools/*.lean)',
                                '$(wildcard tools/Tools/*.lean tools/Drivers/*.lean tools/TestSupport/*.lean)')
            for old, new in mm.items():
                if old.startswith('Tools.'):
                    text = re.sub(r'(?<![\w.])' + re.escape(old) + r'(?![\w.])', new, text)
            text = text.replace('.lake/build/lib/lean/Tools/Corpus.trace',
                                '.lake/build/lib/lean/Drivers/Corpus.trace')
            # Build hygiene only: preserve the existing typed-state module order and flags.
            typed_build = next((line for line in text.splitlines()
                                if line.startswith('\tlake build Effect4.Laws.Program.Typed.Frames ')), None)
            if typed_build is not None:
                names = typed_build.removeprefix('\tlake build ').split()
                text = replace_once(text, typed_build,
                                    '\n'.join('\tlake build ' + name for name in names),
                                    'typed-state serial builds')
        elif path == 'lakefile.toml':
            text = replace_once(text, 'globs = ["Tools.+"]',
                                'globs = ["Tools.+", "Drivers.+", "TestSupport.+"]', 'Tools globs')
        elif path == 'scripts/generate.py':
            for x in moves:
                if x['source'].startswith('tools/Tools/'):
                    text = text.replace("'" + x['source_module'] + "'", "'" + x['destination_module'] + "'")
                    text = text.replace('"' + x['source_module'] + '"', '"' + x['destination_module'] + '"')
            text = replace_once(text, "('Tools.' if family == 'ts' else 'OCaml5.Tools.')",
                                "('Drivers.' if family == 'ts' else 'OCaml5.Tools.')",
                                'TypeScript generator module prefix')
        edits[path] = text

    # Role register: physical ownership determines the existing rule; no direction rule weakened.
    roles_path = 'tools/Tools/ArchitectureRoles.lean'
    roles = get(roles_path)
    lines = []
    for line in roles.splitlines():
        if '⟨"src/Effect4/Arch",' in line or '⟨"src/Effect4/Program/Folds",' in line:
            continue
        if '⟨"src/Effect4/Store",' in line:
            lines.extend([
                '  ⟨"src/Effect4/Store/Carrier", .runtime, 1, "Store/Carrier", "value trees, their byte codec, images, digests and folds below Machine", false, true⟩,',
                '  ⟨"src/Effect4/Store/Domain", .runtime, 4, "Store/Domain", "canonical documents, nodes, persistence, and program wire projections above Schema", false, true⟩,'])
            continue
        if '⟨"src/Effect4/Store/Derived",' in line:
            line = line.replace('src/Effect4/Store/Derived', 'src/Effect4/Store/Domain/Derived').replace('.runtime, 1,', '.runtime, 4,').replace('"Store/Derived"', '"Store/Domain/Derived"')
        if '⟨"src/Effect4/Laws/Machine", .laws,' in line:
            lines.append(line)
            lines.append('  ⟨"src/Effect4/Laws/Machine/Folds", .laws, 2, "Laws/Machine/Folds", "fold connectors for machine stores", true, true⟩,')
            continue
        if '⟨"src/Effect4/Laws/Store", .laws,' in line:
            lines.append(line)
            lines.append('  ⟨"src/Effect4/Laws/Store/Folds", .laws, 1, "Laws/Store/Folds", "fold connectors for store values", true, true⟩,')
            continue
        if '⟨"tools/Tools", .tools,' in line:
            lines.append('  ⟨"tools/Tools", .tools, 2, "Tools", "shared descriptions, stamps, inventory and neutral tool utilities", false, true⟩,')
            lines.append('  ⟨"tools/Drivers", .tools, 4, "Drivers", "Effect4 drivers that consume the OCaml5 projection", false, true⟩,')
            lines.append('  ⟨"tools/TestSupport", .tools, 2, "TestSupport", "shared immutable fixtures consumed by tooling and batteries; no runtime imports", false, true⟩,')
            continue
        if '⟨"tools/Tools", "Test.Program.Gen"' in line:
            line = line.replace('⟨"tools/Tools",', '⟨"tools/Drivers",')
        for old, new in mm.items():
            line = line.replace('"' + old + '"', '"' + new + '"')
        lines.append(line)
    edits[roles_path] = '\n'.join(lines) + '\n'

    # Live authority/document paths only; historical contracts, decisions and baselines stay put.
    for path in ['docs/ARCHITECTURE.md', 'docs/GENERATED.md', 'docs/core/traversal-census.md']:
        text = rewrite_paths((ROOT / path).read_text())
        # These docs use short source paths in tables in addition to full filesystem paths.
        for old, new in pm.items():
            if old.startswith('src/Effect4/'):
                text = text.replace('`' + old.removeprefix('src/Effect4/'), '`' + new.removeprefix('src/Effect4/'))
        edits[path] = text
    edits['docs/ARCHITECTURE.md'] += (
        '\nPlacement ownership: `Store/Carrier` holds values below Machine; `Store/Domain` holds '
        'canonical store operations above Schema, including the program instances and wire face. '
        'Fold connectors and their six typing projection agreements belong to Laws. '
        '`Codegen/Authoring/Forms` holds the target-profile authoring adapters while retaining '
        'their declaration names. `tools/Drivers` sits above OCaml5; `tools/TestSupport` shares '
        'the existing CAS and host-row fixtures between tools and tests, and has no runtime importer.\n')
    return edits, deletes, generated_moves

def imported(text: str) -> list[tuple[int, str]]:
    return [(i, m[1]) for i, line in enumerate(text.splitlines(), 1)
            if (m := re.fullmatch(r'import[ \t]+([\w.]+)[ \t]*(?:--.*)?', line))]


def refresh_plan(plan: dict) -> dict:
    """Refresh scratch metadata only. Destination rulings remain explicit data."""
    additions = [
        ('src/Effect4/Program/Derived.lean', 'src/Effect4/Store/Domain/Derived/Program.lean',
         'approved: program canonical instances belong to Store.Domain; declaration names stay'),
        ('src/Effect4/Program/Wire.lean', 'src/Effect4/Store/Domain/ProgramWire.lean',
         'approved: program canonical wire facade follows its Store.Domain instance'),
        ('src/Effect4/Program/Authoring/Forms.lean', 'src/Effect4/Codegen/Authoring/Forms.lean',
         'approved: target-profile authoring adapters belong above Codegen.Forms'),
        ('src/Effect4/Store/Clock.lean', 'src/Effect4/Store/Domain/Clock.lean',
         'approved: canonical clock instance follows Store.Domain.Canonical'),
    ]
    by_source = {m['source']: m for m in plan['moves']}
    for source, destination, reason in additions:
        if source in by_source and by_source[source]['destination'] != destination:
            raise RuntimeError(f'conflicting placement ruling: {source}')
        if source not in by_source:
            plan['moves'].append(dict(source=source, destination=destination, reason=reason))
    lean = {p: (ROOT / p).read_text() for p in paths()
            if p.endswith('.lean') and not frozen(p)}
    imports = {p: imported(t) for p, t in lean.items()}
    for m in plan['moves']:
        text = lean[m['source']]
        m.update(source_module=module(m['source']), destination_module=module(m['destination']),
                 status='approved_prepared_not_applied', generated=is_generated(text),
                 source_sha256=hashlib.sha256(text.encode()).hexdigest(),
                 direct_dependencies=[n for _, n in imports[m['source']]],
                 direct_importers=[dict(path=p, line=i) for p, rows in imports.items()
                                   for i, n in rows if n == module(m['source'])])
    mm = {m['source_module']: m['destination_module'] for m in plan['moves']}
    pm = {m['source']: m['destination'] for m in plan['moves']}
    groups = []
    manifest = json.loads((ROOT / 'tools/Effect4Gen/manifest.json').read_text())
    for g in manifest['groups']:
        old_imports = g['Imports'].split(',')
        new_imports = [mm.get(m, m) for m in old_imports]
        old_output = g['Out'].replace('\\', '/')
        new_output = pm.get(old_output, old_output)
        if old_imports != new_imports or old_output != new_output:
            groups.append(dict(name=g['Name'], old_imports=old_imports, new_imports=new_imports,
                               old_output=old_output, new_output=new_output,
                               freeze_output_until_producer=True,
                               types_unchanged=g.get('Types', []),
                               kinds_unchanged=g.get('Kinds', []), guards_unchanged=g.get('Guards')))
    plan['head'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
    plan['status'] = 'Approved placement prepared against current working tree; not applied. Refresh after Phase A commit.'
    plan['authority'] += '; coordinator final placement approval: Domain Program/Derived+Wire, Codegen Forms, neutral TestSupport fixtures, Domain Clock'
    plan['authority'] = '; '.join(dict.fromkeys(plan['authority'].split('; ')))
    plan['counts'].update(physical_moves=len(plan['moves']), affected_generator_groups=len(groups),
                          generated_moves=sum(m['generated'] for m in plan['moves']), neutral_fixture_files=2)
    plan['generator_input_updates']['groups'] = groups
    plan['generated_importers_frozen'] = [dict(path=p, imports_to_retarget=[m for _, m in rows if m in mm])
        for p, rows in imports.items() if is_generated(lean[p]) and any(m in mm for _, m in rows)]
    plan['root_rewiring']['lakefile.toml'] = 'Keep library Tools; add Drivers.+ and TestSupport.+ globs. Declaration namespaces remain unchanged.'
    plan['open_decisions'] = []
    plan['placement_blockers'] = []
    plan['execution_constraints'] = [
        'Apply only after Phase A commit and fresh --refresh-plan then --check.',
        'No Lean runs in --refresh-plan, --check or --apply.',
        'After apply, generated modules are a transient boundary until --regenerate-derived.',
        'Derived regeneration is serial: Driver --commands exits before producer; one module per build.',
        'LCNF/CAS/EFF and architecture regeneration remain coordinator-owned final actions.',
        'Generated declarations and theorem bodies must match their before snapshot after stripping only comments/imports.',
        'README, historical contracts, source namespaces and fixture guard commands stay unchanged.',
    ]
    plan['resolved_decisions'] = [dict(id='test-fixture-boundary', resolution='Exact shared declarations rehome to tools/TestSupport/CasEntry and AcquireHandle; guards remain in original Test files.'),
        dict(id='store-domain-generated-consumer', resolution='Program.Derived and Program.Wire move to Domain; regenerate changed derived groups through manifest.'),
        dict(id='residual-upward-edge', resolution='Program.Authoring.Forms moves to Codegen.Authoring.Forms; declarations unchanged.')]
    plan['nonlean_references'] = []
    for p in paths():
        path = ROOT / p
        if frozen(p) or p.endswith('.lean') or path.stat().st_size > 200000: continue
        if path.suffix not in ('.md', '.toml', '.json', '.py', '.sh', '.yml', '.yaml', ''): continue
        try: text = path.read_text()
        except UnicodeError: continue
        hits = [dict(line=i, names=sorted({n for n in (*pm, *mm) if n in line}))
                for i, line in enumerate(text.splitlines(), 1) if any(n in line for n in (*pm, *mm))]
        if hits: plan['nonlean_references'].append(dict(path=p, references=hits,
            requires_contextual_rewrite_not_global_replace=True))
    return plan


def lean_code(text: str) -> str:
    """Comparison fingerprint: remove imports/comments; retain every other byte/token."""
    text = re.sub(r'^import[ \t]+[\w.]+[^\n]*\n?', '', text, flags=re.M)
    out, i = [], 0
    while i < len(text):
        if text.startswith('--', i):
            end = text.find('\n', i)
            i = len(text) if end < 0 else end
        elif text.startswith('/-', i):
            depth, i = 1, i + 2
            while depth:
                if i >= len(text): raise RuntimeError('unclosed Lean comment')
                if text.startswith('/-', i): depth, i = depth + 1, i + 2
                elif text.startswith('-/', i): depth, i = depth - 1, i + 2
                else: i += 1
        elif text[i] == '"':
            start, i = i, i + 1
            while i < len(text):
                if text[i] == '\\': i += 2
                elif text[i] == '"': i += 1; break
                else: i += 1
            out.append(text[start:i])
        else:
            if not text[i].isspace(): out.append(text[i])
            i += 1
    return ''.join(out)


def validate(plan: dict, edits: dict[str, str], deletes: list[str]) -> dict:
    moves = plan['moves']
    pm = {m['source']: m['destination'] for m in moves}
    mm = {m['source_module']: m['destination_module'] for m in moves}
    if len(pm) != len(moves) or len(set(pm.values())) != len(moves):
        raise RuntimeError('duplicate placement source or destination')
    for m in moves:
        actual = hashlib.sha256((ROOT / m['source']).read_bytes()).hexdigest()
        if actual != m['source_sha256']:
            raise RuntimeError(f"stale snapshot: {m['source']}; run --refresh-plan")
        if m['generated'] != is_generated((ROOT / m['source']).read_text()):
            raise RuntimeError(f"generated classification drift: {m['source']}")
    special = {'src/Effect4/Program/Typing/Agreement.lean', 'Test/Store/Templates.lean',
               'Test/Store/NodeContract.lean', 'Test/Api/AcquireHandleContract.lean',
               'Test/Audit/AxiomGate.lean', 'tools/Tools/ArchitectureRoles.lean'}
    unchanged = []
    for source in paths():
        if not source.endswith('.lean') or frozen(source) or source in special: continue
        dest = pm.get(source, source)
        if dest not in edits: continue
        before, after = (ROOT / source).read_text(), edits[dest]
        # Only physical source-path strings may change in a producer's provenance header.
        for old, new in sorted(pm.items(), key=lambda kv: -len(kv[1])):
            after = after.replace(new, old).replace(new.replace('/', '\\'), old.replace('/', '\\'))
        if lean_code(before) != lean_code(after):
            raise RuntimeError(f'declaration/proof changed outside import-only move: {source}')
        unchanged.append(source)
    # Exact extraction retains every test command in the battery, in its previous order.
    commands = re.compile(r'^#(?:guard(?:_msgs)?|check|print)\b.*(?:\n(?!\S).*)*', re.M)
    for p in ['Test/Store/Templates.lean', 'Test/Store/NodeContract.lean', 'Test/Api/AcquireHandleContract.lean']:
        if commands.findall((ROOT / p).read_text()) != commands.findall(edits[p]):
            raise RuntimeError(f'fixture battery command drift: {p}')
    # Reconstruct the three extracted declaration blocks exactly, not from a name count.
    templates = (ROOT / 'Test/Store/Templates.lean').read_text()
    block = templates[templates.index('/-! ## An all-nullary sum'):templates.index('/-! ## A mutual pair')]
    if block not in edits['tools/TestSupport/CasEntry.lean']:
        raise RuntimeError('CAS fixture declaration/proof extraction changed')
    host = (ROOT / 'Test/Api/AcquireHandleContract.lean').read_text()
    block = host[host.index('def resource :='):host.index('\ndef acquire :')]
    if block not in edits['tools/TestSupport/AcquireHandle.lean']:
        raise RuntimeError('host fixture declaration extraction changed')
    agreement = (ROOT / 'src/Effect4/Program/Typing/Agreement.lean').read_text()
    marker = "namespace Checker\n\n/-! ## The checker's projections as the fold -/"
    suffix = agreement.split(marker)[1]
    if not edits['src/Effect4/Laws/Program/Typing/FoldAgreement.lean'].endswith(suffix):
        raise RuntimeError('fold agreement theorem statement/proof extraction changed')
    roles = (ROOT / 'tools/Tools/ArchitectureRoles.lean').read_text()
    allowed = roles[roles.index('def allowed '):roles.index('/-- The roots loaded')]
    if allowed not in edits['tools/Tools/ArchitectureRoles.lean']:
        raise RuntimeError('architecture direction rule changed')
    original_manifest = json.loads((ROOT / 'tools/Effect4Gen/manifest.json').read_text())
    after_manifest = json.loads(edits['tools/Effect4Gen/manifest.json'])
    for before, after in zip(original_manifest['groups'], after_manifest['groups'], strict=True):
        for k in before:
            if k not in ('Imports', 'Out') and before[k] != after[k]:
                raise RuntimeError(f'manifest declaration metadata changed: {before["Name"]}.{k}')
    projected = {p: (ROOT / p).read_text() for p in paths() if p.endswith('.lean') and not frozen(p)}
    for p in deletes: projected.pop(p, None)
    projected.update({p: t for p, t in edits.items() if p.endswith('.lean')})
    # Predict producer-owned imports only; never write a generated source in this command.
    for p in list(projected):
        if not is_generated(projected[p]): continue
        t = re.sub(r'^(import[ \t]+)([\w.]+)([ \t]*(?:--[^\r\n]*)?)$',
                   lambda m: m[1] + mm.get(m[2], m[2]) + m[3], projected.pop(p), flags=re.M)
        projected[pm.get(p, p)] = t
    retired = set(mm)
    residual = [(p, i, n) for p, t in projected.items() for i, n in imported(t) if n in retired]
    if residual: raise RuntimeError(f'retired module imports remain: {residual[:10]}')
    graph = {module(p): [n for _, n in imported(t)] for p, t in projected.items()}
    seen, pending = set(), ['Effect4']
    while pending:
        m = pending.pop()
        if m in seen: continue
        if m.startswith(('Effect4.Laws', 'Test.', 'TestSupport.', 'Drivers.')):
            raise RuntimeError(f'runtime root reaches nonruntime module: {m}')
        seen.add(m); pending.extend(graph.get(m, []))
    for p, t in projected.items():
        if p.startswith('src/Effect4/') and '/Laws/' not in p:
            for _, n in imported(t):
                if n.startswith('TestSupport.'): raise RuntimeError(f'runtime imports fixture: {p}')
    return dict(import_only_files_checked=len(unchanged), fixture_batteries_unchanged=3,
                manifest_declaration_fields_unchanged=True, retired_imports=0,
                runtime_root_has_no_laws_or_tests=True, runtime_reachable_modules=len(seen),
                generated_checks_are_predictions_until_producer=True)


def regenerate_derived() -> None:
    """One selected producer at a time; no Lean process starts another Lean process."""
    state = json.loads(STATE.read_text())
    if state.get('status') != 'source_placement_applied':
        raise RuntimeError('placement state is not ready for derived regeneration')
    logdir = HERE / 'placement-derived-logs'
    logdir.mkdir(exist_ok=True)
    def run(label: str, argv: list[str]) -> str:
        print(label, flush=True)
        with (logdir / (label + '.log')).open('w') as log:
            subprocess.run(argv, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, check=True,
                           env={**os.environ, 'LEAN_NUM_THREADS': '1'})
        return (logdir / (label + '.log')).read_text()
    rows = json.loads(run('commands', ['lake', 'env', 'lean', '-M4096', '-DwarningAsError=true',
        '--run', 'tools/Effect4Gen/Driver.lean', '--commands']))
    expected = {g['name']: g for g in state['generator_groups']}
    selected = [row for row in rows if row['name'] in expected]
    if [row['name'] for row in selected] != list(expected):
        raise RuntimeError('derived group selection/order drifted after placement')
    for prerequisite in ['Tools.GeneratedStamp', 'Tools.ProgramStructure', 'Tools.WireTags']:
        run('tool-' + prerequisite, ['lake', 'build', prerequisite])
    for row in selected:
        g = expected[row['name']]
        if row['out'].replace('\\', '/') != g['new_output']:
            raise RuntimeError(f"producer output drift: {g['name']}")
        args = row['args'].copy()
        imports = args[args.index('--imports') + 1].split(',')
        if imports != g['new_imports']:
            raise RuntimeError(f"producer imports drift: {g['name']}")
        for name in imports:
            run(g['name'] + '-import-' + name, ['lake', 'build', name])
        target = ROOT / g['new_output']
        temporary = logdir / (g['name'] + '.lean')
        args[args.index('--out') + 1] = str(temporary)
        if '--append' in args:
            i = args.index('--append') + 1
            args[i] = args[i].replace('\\', '/')
        args.insert(args.index('lean') + 1, '-DwarningAsError=true')
        args += ['--header-out', g['new_output']]
        run(g['name'] + '-generate', ['lake', *args])
        before = (Path(state['before']) / g['old_output']).read_text()
        after = temporary.read_text()
        if not is_generated(after): raise RuntimeError('producer omitted generated header')
        if lean_code(before) != lean_code(after):
            raise RuntimeError(f"producer changed a declaration/proof during placement: {g['name']}; output retained in {temporary}")
        target.parent.mkdir(parents=True, exist_ok=True)
        stage = target.with_suffix('.placement-tmp')
        stage.write_text(after)
        stage.replace(target)
        log = run(g['name'] + '-build', ['lake', 'build', module(g['new_output'])])
        if 'sorryAx' in log or 'Classical.choice' in log:
            raise RuntimeError(f"inadmissible generated axiom receipt: {g['name']}")
    manifest_groups = json.loads((ROOT / 'tools/Effect4Gen/manifest.json').read_text())['groups']
    canonical = {g['Name'] for g in manifest_groups
                 if g.get('Tool', 'tools/Effect4Gen/Main.lean') == 'tools/Effect4Gen/Main.lean'}
    for g in expected.values():
        if g['name'] not in canonical:
            continue  # Other producers carry their own checked laws/guards, built above.
        run(g['name'] + '-projection-check', ['lake', 'env', 'lean', '-M4096',
            '-DwarningAsError=true', '--run', 'tools/Effect4Gen/Check.lean', g['new_output']])
    for item in state['generated_moves']:
        (ROOT / item['source']).unlink()
    state['status'] = 'derived_regenerated'
    STATE.write_text(json.dumps(state, indent=2) + '\n')
    print('Selected derived groups regenerated with unchanged declarations/proofs; old generated paths removed. LCNF/CAS/EFF/TS/architecture untouched.')


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--check', action='store_true')
    actions.add_argument('--refresh-plan', action='store_true')
    actions.add_argument('--apply', action='store_true')
    actions.add_argument('--regenerate-derived', action='store_true')
    args = parser.parse_args()
    plan = json.loads(PLAN.read_text())
    if args.refresh_plan:
        plan = refresh_plan(plan)
        PLAN.write_text(json.dumps(plan, indent=2) + '\n')
    if args.regenerate_derived:
        regenerate_derived()
        return
    edits, deletes, generated_moves = produce_edits(plan)
    checks = validate(plan, edits, deletes)
    if args.check or args.refresh_plan:
        print(json.dumps({'validation':checks, 'writes':sorted(edits), 'deletes':sorted(deletes),
                          'generated_moves_pending_producer':generated_moves}, indent=2))
        return
    if STATE.exists():
        raise RuntimeError(f'refusing duplicate application: {STATE}')
    dirty = set(subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=ROOT).decode().splitlines())
    touched_sources = set(edits) | set(deletes) | {m['source'] for m in plan['moves']}
    if dirty & touched_sources:
        raise RuntimeError('commit Phase A before applying placement: ' + ', '.join(sorted(dirty & touched_sources)))
    baseline = HERE / 'placement-before'
    baseline.mkdir(exist_ok=False)
    touched = sorted(set(edits) | set(deletes) | {g['source'] for g in generated_moves}
                     | {g['old_output'] for g in plan['generator_input_updates']['groups']})
    for path in touched:
        source = ROOT / path
        if source.is_file():
            target = baseline / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(source.read_bytes())
    state = {'status':'applying', 'generated_moves':generated_moves,
             'generator_groups':plan['generator_input_updates']['groups'],
             'before':str(baseline), 'writes':sorted(edits), 'deletes':sorted(deletes),
             'head':subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()}
    STATE.write_text(json.dumps(state, indent=2) + '\n')
    for path, text in sorted(edits.items()):
        target = ROOT / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text)
    for path in deletes:
        (ROOT / path).unlink()
    state['status'] = 'source_placement_applied'
    STATE.write_text(json.dumps(state, indent=2) + '\n')
    print('Source placement prepared. Run --regenerate-derived with the compiler lease before building roots.')

if __name__ == '__main__':
    main()
